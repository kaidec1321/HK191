# Generated from E:/ASS1PPL/initial/src/main/mc/parser\MC.g4 by ANTLR 4.7.2
from antlr4 import *
if __name__ is not None and "." in __name__:
    from .MCParser import MCParser
else:
    from MCParser import MCParser

# This class defines a complete listener for a parse tree produced by MCParser.
class MCListener(ParseTreeListener):

    # Enter a parse tree produced by MCParser#program.
    def enterProgram(self, ctx:MCParser.ProgramContext):
        pass

    # Exit a parse tree produced by MCParser#program.
    def exitProgram(self, ctx:MCParser.ProgramContext):
        pass


    # Enter a parse tree produced by MCParser#manydecls.
    def enterManydecls(self, ctx:MCParser.ManydeclsContext):
        pass

    # Exit a parse tree produced by MCParser#manydecls.
    def exitManydecls(self, ctx:MCParser.ManydeclsContext):
        pass


    # Enter a parse tree produced by MCParser#vardecl.
    def enterVardecl(self, ctx:MCParser.VardeclContext):
        pass

    # Exit a parse tree produced by MCParser#vardecl.
    def exitVardecl(self, ctx:MCParser.VardeclContext):
        pass


    # Enter a parse tree produced by MCParser#primtype.
    def enterPrimtype(self, ctx:MCParser.PrimtypeContext):
        pass

    # Exit a parse tree produced by MCParser#primtype.
    def exitPrimtype(self, ctx:MCParser.PrimtypeContext):
        pass


    # Enter a parse tree produced by MCParser#varlist.
    def enterVarlist(self, ctx:MCParser.VarlistContext):
        pass

    # Exit a parse tree produced by MCParser#varlist.
    def exitVarlist(self, ctx:MCParser.VarlistContext):
        pass


    # Enter a parse tree produced by MCParser#var.
    def enterVar(self, ctx:MCParser.VarContext):
        pass

    # Exit a parse tree produced by MCParser#var.
    def exitVar(self, ctx:MCParser.VarContext):
        pass


    # Enter a parse tree produced by MCParser#arrayvar.
    def enterArrayvar(self, ctx:MCParser.ArrayvarContext):
        pass

    # Exit a parse tree produced by MCParser#arrayvar.
    def exitArrayvar(self, ctx:MCParser.ArrayvarContext):
        pass


    # Enter a parse tree produced by MCParser#fundecl.
    def enterFundecl(self, ctx:MCParser.FundeclContext):
        pass

    # Exit a parse tree produced by MCParser#fundecl.
    def exitFundecl(self, ctx:MCParser.FundeclContext):
        pass


    # Enter a parse tree produced by MCParser#typ.
    def enterTyp(self, ctx:MCParser.TypContext):
        pass

    # Exit a parse tree produced by MCParser#typ.
    def exitTyp(self, ctx:MCParser.TypContext):
        pass


    # Enter a parse tree produced by MCParser#arrp_type.
    def enterArrp_type(self, ctx:MCParser.Arrp_typeContext):
        pass

    # Exit a parse tree produced by MCParser#arrp_type.
    def exitArrp_type(self, ctx:MCParser.Arrp_typeContext):
        pass


    # Enter a parse tree produced by MCParser#paralist.
    def enterParalist(self, ctx:MCParser.ParalistContext):
        pass

    # Exit a parse tree produced by MCParser#paralist.
    def exitParalist(self, ctx:MCParser.ParalistContext):
        pass


    # Enter a parse tree produced by MCParser#paradecls.
    def enterParadecls(self, ctx:MCParser.ParadeclsContext):
        pass

    # Exit a parse tree produced by MCParser#paradecls.
    def exitParadecls(self, ctx:MCParser.ParadeclsContext):
        pass


    # Enter a parse tree produced by MCParser#paradecl.
    def enterParadecl(self, ctx:MCParser.ParadeclContext):
        pass

    # Exit a parse tree produced by MCParser#paradecl.
    def exitParadecl(self, ctx:MCParser.ParadeclContext):
        pass


    # Enter a parse tree produced by MCParser#notif_stmt.
    def enterNotif_stmt(self, ctx:MCParser.Notif_stmtContext):
        pass

    # Exit a parse tree produced by MCParser#notif_stmt.
    def exitNotif_stmt(self, ctx:MCParser.Notif_stmtContext):
        pass


    # Enter a parse tree produced by MCParser#stmt.
    def enterStmt(self, ctx:MCParser.StmtContext):
        pass

    # Exit a parse tree produced by MCParser#stmt.
    def exitStmt(self, ctx:MCParser.StmtContext):
        pass


    # Enter a parse tree produced by MCParser#if_stmt.
    def enterIf_stmt(self, ctx:MCParser.If_stmtContext):
        pass

    # Exit a parse tree produced by MCParser#if_stmt.
    def exitIf_stmt(self, ctx:MCParser.If_stmtContext):
        pass


    # Enter a parse tree produced by MCParser#match_stmt.
    def enterMatch_stmt(self, ctx:MCParser.Match_stmtContext):
        pass

    # Exit a parse tree produced by MCParser#match_stmt.
    def exitMatch_stmt(self, ctx:MCParser.Match_stmtContext):
        pass


    # Enter a parse tree produced by MCParser#unmatch_stmt.
    def enterUnmatch_stmt(self, ctx:MCParser.Unmatch_stmtContext):
        pass

    # Exit a parse tree produced by MCParser#unmatch_stmt.
    def exitUnmatch_stmt(self, ctx:MCParser.Unmatch_stmtContext):
        pass


    # Enter a parse tree produced by MCParser#dowhile_stmt.
    def enterDowhile_stmt(self, ctx:MCParser.Dowhile_stmtContext):
        pass

    # Exit a parse tree produced by MCParser#dowhile_stmt.
    def exitDowhile_stmt(self, ctx:MCParser.Dowhile_stmtContext):
        pass


    # Enter a parse tree produced by MCParser#for_stmt.
    def enterFor_stmt(self, ctx:MCParser.For_stmtContext):
        pass

    # Exit a parse tree produced by MCParser#for_stmt.
    def exitFor_stmt(self, ctx:MCParser.For_stmtContext):
        pass


    # Enter a parse tree produced by MCParser#break_stmt.
    def enterBreak_stmt(self, ctx:MCParser.Break_stmtContext):
        pass

    # Exit a parse tree produced by MCParser#break_stmt.
    def exitBreak_stmt(self, ctx:MCParser.Break_stmtContext):
        pass


    # Enter a parse tree produced by MCParser#continue_stmt.
    def enterContinue_stmt(self, ctx:MCParser.Continue_stmtContext):
        pass

    # Exit a parse tree produced by MCParser#continue_stmt.
    def exitContinue_stmt(self, ctx:MCParser.Continue_stmtContext):
        pass


    # Enter a parse tree produced by MCParser#return_stmt.
    def enterReturn_stmt(self, ctx:MCParser.Return_stmtContext):
        pass

    # Exit a parse tree produced by MCParser#return_stmt.
    def exitReturn_stmt(self, ctx:MCParser.Return_stmtContext):
        pass


    # Enter a parse tree produced by MCParser#block_stmt.
    def enterBlock_stmt(self, ctx:MCParser.Block_stmtContext):
        pass

    # Exit a parse tree produced by MCParser#block_stmt.
    def exitBlock_stmt(self, ctx:MCParser.Block_stmtContext):
        pass


    # Enter a parse tree produced by MCParser#vardecl_stmtlist.
    def enterVardecl_stmtlist(self, ctx:MCParser.Vardecl_stmtlistContext):
        pass

    # Exit a parse tree produced by MCParser#vardecl_stmtlist.
    def exitVardecl_stmtlist(self, ctx:MCParser.Vardecl_stmtlistContext):
        pass


    # Enter a parse tree produced by MCParser#vardecl_stmt.
    def enterVardecl_stmt(self, ctx:MCParser.Vardecl_stmtContext):
        pass

    # Exit a parse tree produced by MCParser#vardecl_stmt.
    def exitVardecl_stmt(self, ctx:MCParser.Vardecl_stmtContext):
        pass


    # Enter a parse tree produced by MCParser#exp.
    def enterExp(self, ctx:MCParser.ExpContext):
        pass

    # Exit a parse tree produced by MCParser#exp.
    def exitExp(self, ctx:MCParser.ExpContext):
        pass


    # Enter a parse tree produced by MCParser#exp1.
    def enterExp1(self, ctx:MCParser.Exp1Context):
        pass

    # Exit a parse tree produced by MCParser#exp1.
    def exitExp1(self, ctx:MCParser.Exp1Context):
        pass


    # Enter a parse tree produced by MCParser#exp2.
    def enterExp2(self, ctx:MCParser.Exp2Context):
        pass

    # Exit a parse tree produced by MCParser#exp2.
    def exitExp2(self, ctx:MCParser.Exp2Context):
        pass


    # Enter a parse tree produced by MCParser#exp3.
    def enterExp3(self, ctx:MCParser.Exp3Context):
        pass

    # Exit a parse tree produced by MCParser#exp3.
    def exitExp3(self, ctx:MCParser.Exp3Context):
        pass


    # Enter a parse tree produced by MCParser#exp4.
    def enterExp4(self, ctx:MCParser.Exp4Context):
        pass

    # Exit a parse tree produced by MCParser#exp4.
    def exitExp4(self, ctx:MCParser.Exp4Context):
        pass


    # Enter a parse tree produced by MCParser#exp5.
    def enterExp5(self, ctx:MCParser.Exp5Context):
        pass

    # Exit a parse tree produced by MCParser#exp5.
    def exitExp5(self, ctx:MCParser.Exp5Context):
        pass


    # Enter a parse tree produced by MCParser#exp6.
    def enterExp6(self, ctx:MCParser.Exp6Context):
        pass

    # Exit a parse tree produced by MCParser#exp6.
    def exitExp6(self, ctx:MCParser.Exp6Context):
        pass


    # Enter a parse tree produced by MCParser#exp7.
    def enterExp7(self, ctx:MCParser.Exp7Context):
        pass

    # Exit a parse tree produced by MCParser#exp7.
    def exitExp7(self, ctx:MCParser.Exp7Context):
        pass


    # Enter a parse tree produced by MCParser#exp8.
    def enterExp8(self, ctx:MCParser.Exp8Context):
        pass

    # Exit a parse tree produced by MCParser#exp8.
    def exitExp8(self, ctx:MCParser.Exp8Context):
        pass


    # Enter a parse tree produced by MCParser#exp9.
    def enterExp9(self, ctx:MCParser.Exp9Context):
        pass

    # Exit a parse tree produced by MCParser#exp9.
    def exitExp9(self, ctx:MCParser.Exp9Context):
        pass


    # Enter a parse tree produced by MCParser#funcall.
    def enterFuncall(self, ctx:MCParser.FuncallContext):
        pass

    # Exit a parse tree produced by MCParser#funcall.
    def exitFuncall(self, ctx:MCParser.FuncallContext):
        pass


    # Enter a parse tree produced by MCParser#explist.
    def enterExplist(self, ctx:MCParser.ExplistContext):
        pass

    # Exit a parse tree produced by MCParser#explist.
    def exitExplist(self, ctx:MCParser.ExplistContext):
        pass


