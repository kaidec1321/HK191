# Generated from e:\ASS1PPL\initial\src\main\mc\parser\MC.g4 by ANTLR 4.7.1
# encoding: utf-8
from antlr4 import *
from io import StringIO
from typing.io import TextIO
import sys

def serializedATN():
    with StringIO() as buf:
        buf.write("\3\u608b\ua72a\u8133\ub9ed\u417c\u3be7\u7786\u5964\3\63")
        buf.write("\u0152\4\2\t\2\4\3\t\3\4\4\t\4\4\5\t\5\4\6\t\6\4\7\t\7")
        buf.write("\4\b\t\b\4\t\t\t\4\n\t\n\4\13\t\13\4\f\t\f\4\r\t\r\4\16")
        buf.write("\t\16\4\17\t\17\4\20\t\20\4\21\t\21\4\22\t\22\4\23\t\23")
        buf.write("\4\24\t\24\4\25\t\25\4\26\t\26\4\27\t\27\4\30\t\30\4\31")
        buf.write("\t\31\4\32\t\32\4\33\t\33\4\34\t\34\4\35\t\35\4\36\t\36")
        buf.write("\4\37\t\37\4 \t \4!\t!\4\"\t\"\4#\t#\4$\t$\3\2\3\2\3\2")
        buf.write("\3\3\3\3\6\3N\n\3\r\3\16\3O\3\4\3\4\3\4\3\4\3\5\3\5\3")
        buf.write("\6\3\6\3\6\7\6[\n\6\f\6\16\6^\13\6\3\7\3\7\5\7b\n\7\3")
        buf.write("\b\3\b\3\b\3\b\3\b\3\t\3\t\3\t\3\t\3\t\3\t\3\t\3\n\3\n")
        buf.write("\3\n\5\ns\n\n\3\13\3\13\3\13\3\13\3\f\3\f\3\r\3\r\3\r")
        buf.write("\7\r~\n\r\f\r\16\r\u0081\13\r\5\r\u0083\n\r\3\16\3\16")
        buf.write("\3\16\3\16\5\16\u0089\n\16\3\17\3\17\3\17\3\17\3\17\3")
        buf.write("\17\3\17\3\17\3\17\3\17\5\17\u0095\n\17\3\20\3\20\3\20")
        buf.write("\3\20\3\20\3\20\3\20\5\20\u009e\n\20\3\21\3\21\6\21\u00a2")
        buf.write("\n\21\r\21\16\21\u00a3\3\21\3\21\3\21\3\21\3\22\3\22\3")
        buf.write("\22\3\22\3\22\3\22\3\22\3\22\3\22\3\22\3\23\3\23\3\23")
        buf.write("\3\24\3\24\3\24\3\25\3\25\5\25\u00bc\n\25\3\25\3\25\3")
        buf.write("\26\3\26\3\26\3\26\3\27\7\27\u00c5\n\27\f\27\16\27\u00c8")
        buf.write("\13\27\3\30\3\30\5\30\u00cc\n\30\3\31\3\31\3\31\3\31\3")
        buf.write("\31\5\31\u00d3\n\31\3\32\3\32\3\32\3\32\3\32\3\32\7\32")
        buf.write("\u00db\n\32\f\32\16\32\u00de\13\32\3\33\3\33\3\33\3\33")
        buf.write("\3\33\3\33\7\33\u00e6\n\33\f\33\16\33\u00e9\13\33\3\34")
        buf.write("\3\34\3\34\3\34\3\34\3\34\3\34\3\34\3\34\5\34\u00f4\n")
        buf.write("\34\3\35\3\35\3\35\3\35\3\35\3\35\3\35\3\35\3\35\3\35")
        buf.write("\3\35\3\35\3\35\3\35\3\35\3\35\3\35\5\35\u0107\n\35\3")
        buf.write("\36\3\36\3\36\3\36\3\36\3\36\3\36\3\36\3\36\7\36\u0112")
        buf.write("\n\36\f\36\16\36\u0115\13\36\3\37\3\37\3\37\3\37\3\37")
        buf.write("\3\37\3\37\3\37\3\37\3\37\3\37\3\37\7\37\u0123\n\37\f")
        buf.write("\37\16\37\u0126\13\37\3 \3 \3 \3 \3 \5 \u012d\n \3!\3")
        buf.write("!\3!\3!\3!\3!\5!\u0135\n!\3\"\3\"\3\"\3\"\3\"\3\"\3\"")
        buf.write("\3\"\3\"\3\"\5\"\u0141\n\"\3#\3#\3#\3#\3#\3$\3$\3$\7$")
        buf.write("\u014b\n$\f$\16$\u014e\13$\5$\u0150\n$\3$\2\6\62\64:<")
        buf.write("%\2\4\6\b\n\f\16\20\22\24\26\30\32\34\36 \"$&(*,.\60\62")
        buf.write("\64\668:<>@BDF\2\3\4\2\32\34))\2\u015c\2H\3\2\2\2\4M\3")
        buf.write("\2\2\2\6Q\3\2\2\2\bU\3\2\2\2\nW\3\2\2\2\fa\3\2\2\2\16")
        buf.write("c\3\2\2\2\20h\3\2\2\2\22r\3\2\2\2\24t\3\2\2\2\26x\3\2")
        buf.write("\2\2\30\u0082\3\2\2\2\32\u0084\3\2\2\2\34\u0094\3\2\2")
        buf.write("\2\36\u0096\3\2\2\2 \u009f\3\2\2\2\"\u00a9\3\2\2\2$\u00b3")
        buf.write("\3\2\2\2&\u00b6\3\2\2\2(\u00b9\3\2\2\2*\u00bf\3\2\2\2")
        buf.write(",\u00c6\3\2\2\2.\u00cb\3\2\2\2\60\u00d2\3\2\2\2\62\u00d4")
        buf.write("\3\2\2\2\64\u00df\3\2\2\2\66\u00f3\3\2\2\28\u0106\3\2")
        buf.write("\2\2:\u0108\3\2\2\2<\u0116\3\2\2\2>\u012c\3\2\2\2@\u0134")
        buf.write("\3\2\2\2B\u0140\3\2\2\2D\u0142\3\2\2\2F\u014f\3\2\2\2")
        buf.write("HI\5\4\3\2IJ\7\2\2\3J\3\3\2\2\2KN\5\6\4\2LN\5\20\t\2M")
        buf.write("K\3\2\2\2ML\3\2\2\2NO\3\2\2\2OM\3\2\2\2OP\3\2\2\2P\5\3")
        buf.write("\2\2\2QR\5\b\5\2RS\5\n\6\2ST\7\3\2\2T\7\3\2\2\2UV\t\2")
        buf.write("\2\2V\t\3\2\2\2W\\\5\f\7\2XY\7\4\2\2Y[\5\n\6\2ZX\3\2\2")
        buf.write("\2[^\3\2\2\2\\Z\3\2\2\2\\]\3\2\2\2]\13\3\2\2\2^\\\3\2")
        buf.write("\2\2_b\7,\2\2`b\5\16\b\2a_\3\2\2\2a`\3\2\2\2b\r\3\2\2")
        buf.write("\2cd\7,\2\2de\7\26\2\2ef\7*\2\2fg\7\27\2\2g\17\3\2\2\2")
        buf.write("hi\5\22\n\2ij\7,\2\2jk\7\5\2\2kl\5\26\f\2lm\7\6\2\2mn")
        buf.write("\5*\26\2n\21\3\2\2\2os\5\b\5\2ps\5\24\13\2qs\7\35\2\2")
        buf.write("ro\3\2\2\2rp\3\2\2\2rq\3\2\2\2s\23\3\2\2\2tu\5\b\5\2u")
        buf.write("v\7\26\2\2vw\7\27\2\2w\25\3\2\2\2xy\5\30\r\2y\27\3\2\2")
        buf.write("\2z\177\5\32\16\2{|\7\4\2\2|~\5\30\r\2}{\3\2\2\2~\u0081")
        buf.write("\3\2\2\2\177}\3\2\2\2\177\u0080\3\2\2\2\u0080\u0083\3")
        buf.write("\2\2\2\u0081\177\3\2\2\2\u0082z\3\2\2\2\u0082\u0083\3")
        buf.write("\2\2\2\u0083\31\3\2\2\2\u0084\u0085\5\b\5\2\u0085\u0088")
        buf.write("\7,\2\2\u0086\u0087\7\26\2\2\u0087\u0089\7\27\2\2\u0088")
        buf.write("\u0086\3\2\2\2\u0088\u0089\3\2\2\2\u0089\33\3\2\2\2\u008a")
        buf.write("\u0095\5\36\20\2\u008b\u0095\5\"\22\2\u008c\u0095\5 \21")
        buf.write("\2\u008d\u0095\5$\23\2\u008e\u0095\5&\24\2\u008f\u0095")
        buf.write("\5(\25\2\u0090\u0091\5\60\31\2\u0091\u0092\7\3\2\2\u0092")
        buf.write("\u0095\3\2\2\2\u0093\u0095\5*\26\2\u0094\u008a\3\2\2\2")
        buf.write("\u0094\u008b\3\2\2\2\u0094\u008c\3\2\2\2\u0094\u008d\3")
        buf.write("\2\2\2\u0094\u008e\3\2\2\2\u0094\u008f\3\2\2\2\u0094\u0090")
        buf.write("\3\2\2\2\u0094\u0093\3\2\2\2\u0095\35\3\2\2\2\u0096\u0097")
        buf.write("\7!\2\2\u0097\u0098\7\5\2\2\u0098\u0099\5\60\31\2\u0099")
        buf.write("\u009a\7\6\2\2\u009a\u009d\5\34\17\2\u009b\u009c\7\"\2")
        buf.write("\2\u009c\u009e\5\34\17\2\u009d\u009b\3\2\2\2\u009d\u009e")
        buf.write("\3\2\2\2\u009e\37\3\2\2\2\u009f\u00a1\7$\2\2\u00a0\u00a2")
        buf.write("\5\34\17\2\u00a1\u00a0\3\2\2\2\u00a2\u00a3\3\2\2\2\u00a3")
        buf.write("\u00a1\3\2\2\2\u00a3\u00a4\3\2\2\2\u00a4\u00a5\3\2\2\2")
        buf.write("\u00a5\u00a6\7%\2\2\u00a6\u00a7\5\60\31\2\u00a7\u00a8")
        buf.write("\7\3\2\2\u00a8!\3\2\2\2\u00a9\u00aa\7 \2\2\u00aa\u00ab")
        buf.write("\7\5\2\2\u00ab\u00ac\5\60\31\2\u00ac\u00ad\7\3\2\2\u00ad")
        buf.write("\u00ae\5\60\31\2\u00ae\u00af\7\3\2\2\u00af\u00b0\5\60")
        buf.write("\31\2\u00b0\u00b1\7\6\2\2\u00b1\u00b2\5\34\17\2\u00b2")
        buf.write("#\3\2\2\2\u00b3\u00b4\7\36\2\2\u00b4\u00b5\7\3\2\2\u00b5")
        buf.write("%\3\2\2\2\u00b6\u00b7\7\37\2\2\u00b7\u00b8\7\3\2\2\u00b8")
        buf.write("\'\3\2\2\2\u00b9\u00bb\7#\2\2\u00ba\u00bc\5\60\31\2\u00bb")
        buf.write("\u00ba\3\2\2\2\u00bb\u00bc\3\2\2\2\u00bc\u00bd\3\2\2\2")
        buf.write("\u00bd\u00be\7\3\2\2\u00be)\3\2\2\2\u00bf\u00c0\7\30\2")
        buf.write("\2\u00c0\u00c1\5,\27\2\u00c1\u00c2\7\31\2\2\u00c2+\3\2")
        buf.write("\2\2\u00c3\u00c5\5.\30\2\u00c4\u00c3\3\2\2\2\u00c5\u00c8")
        buf.write("\3\2\2\2\u00c6\u00c4\3\2\2\2\u00c6\u00c7\3\2\2\2\u00c7")
        buf.write("-\3\2\2\2\u00c8\u00c6\3\2\2\2\u00c9\u00cc\5\6\4\2\u00ca")
        buf.write("\u00cc\5\34\17\2\u00cb\u00c9\3\2\2\2\u00cb\u00ca\3\2\2")
        buf.write("\2\u00cc/\3\2\2\2\u00cd\u00ce\5\62\32\2\u00ce\u00cf\7")
        buf.write("\17\2\2\u00cf\u00d0\5\60\31\2\u00d0\u00d3\3\2\2\2\u00d1")
        buf.write("\u00d3\5\62\32\2\u00d2\u00cd\3\2\2\2\u00d2\u00d1\3\2\2")
        buf.write("\2\u00d3\61\3\2\2\2\u00d4\u00d5\b\32\1\2\u00d5\u00d6\5")
        buf.write("\64\33\2\u00d6\u00dc\3\2\2\2\u00d7\u00d8\f\4\2\2\u00d8")
        buf.write("\u00d9\7\20\2\2\u00d9\u00db\5\64\33\2\u00da\u00d7\3\2")
        buf.write("\2\2\u00db\u00de\3\2\2\2\u00dc\u00da\3\2\2\2\u00dc\u00dd")
        buf.write("\3\2\2\2\u00dd\63\3\2\2\2\u00de\u00dc\3\2\2\2\u00df\u00e0")
        buf.write("\b\33\1\2\u00e0\u00e1\5\66\34\2\u00e1\u00e7\3\2\2\2\u00e2")
        buf.write("\u00e3\f\4\2\2\u00e3\u00e4\7\21\2\2\u00e4\u00e6\5\66\34")
        buf.write("\2\u00e5\u00e2\3\2\2\2\u00e6\u00e9\3\2\2\2\u00e7\u00e5")
        buf.write("\3\2\2\2\u00e7\u00e8\3\2\2\2\u00e8\65\3\2\2\2\u00e9\u00e7")
        buf.write("\3\2\2\2\u00ea\u00eb\58\35\2\u00eb\u00ec\7\23\2\2\u00ec")
        buf.write("\u00ed\58\35\2\u00ed\u00f4\3\2\2\2\u00ee\u00ef\58\35\2")
        buf.write("\u00ef\u00f0\7\22\2\2\u00f0\u00f1\58\35\2\u00f1\u00f4")
        buf.write("\3\2\2\2\u00f2\u00f4\58\35\2\u00f3\u00ea\3\2\2\2\u00f3")
        buf.write("\u00ee\3\2\2\2\u00f3\u00f2\3\2\2\2\u00f4\67\3\2\2\2\u00f5")
        buf.write("\u00f6\5:\36\2\u00f6\u00f7\7\r\2\2\u00f7\u00f8\5:\36\2")
        buf.write("\u00f8\u0107\3\2\2\2\u00f9\u00fa\5:\36\2\u00fa\u00fb\7")
        buf.write("\24\2\2\u00fb\u00fc\5:\36\2\u00fc\u0107\3\2\2\2\u00fd")
        buf.write("\u00fe\5:\36\2\u00fe\u00ff\7\16\2\2\u00ff\u0100\5:\36")
        buf.write("\2\u0100\u0107\3\2\2\2\u0101\u0102\5:\36\2\u0102\u0103")
        buf.write("\7\25\2\2\u0103\u0104\5:\36\2\u0104\u0107\3\2\2\2\u0105")
        buf.write("\u0107\5:\36\2\u0106\u00f5\3\2\2\2\u0106\u00f9\3\2\2\2")
        buf.write("\u0106\u00fd\3\2\2\2\u0106\u0101\3\2\2\2\u0106\u0105\3")
        buf.write("\2\2\2\u01079\3\2\2\2\u0108\u0109\b\36\1\2\u0109\u010a")
        buf.write("\5<\37\2\u010a\u0113\3\2\2\2\u010b\u010c\f\5\2\2\u010c")
        buf.write("\u010d\7\7\2\2\u010d\u0112\5<\37\2\u010e\u010f\f\4\2\2")
        buf.write("\u010f\u0110\7\b\2\2\u0110\u0112\5<\37\2\u0111\u010b\3")
        buf.write("\2\2\2\u0111\u010e\3\2\2\2\u0112\u0115\3\2\2\2\u0113\u0111")
        buf.write("\3\2\2\2\u0113\u0114\3\2\2\2\u0114;\3\2\2\2\u0115\u0113")
        buf.write("\3\2\2\2\u0116\u0117\b\37\1\2\u0117\u0118\5> \2\u0118")
        buf.write("\u0124\3\2\2\2\u0119\u011a\f\6\2\2\u011a\u011b\7\n\2\2")
        buf.write("\u011b\u0123\5> \2\u011c\u011d\f\5\2\2\u011d\u011e\7\t")
        buf.write("\2\2\u011e\u0123\5> \2\u011f\u0120\f\4\2\2\u0120\u0121")
        buf.write("\7\13\2\2\u0121\u0123\5> \2\u0122\u0119\3\2\2\2\u0122")
        buf.write("\u011c\3\2\2\2\u0122\u011f\3\2\2\2\u0123\u0126\3\2\2\2")
        buf.write("\u0124\u0122\3\2\2\2\u0124\u0125\3\2\2\2\u0125=\3\2\2")
        buf.write("\2\u0126\u0124\3\2\2\2\u0127\u0128\7\b\2\2\u0128\u012d")
        buf.write("\5> \2\u0129\u012a\7\f\2\2\u012a\u012d\5> \2\u012b\u012d")
        buf.write("\5@!\2\u012c\u0127\3\2\2\2\u012c\u0129\3\2\2\2\u012c\u012b")
        buf.write("\3\2\2\2\u012d?\3\2\2\2\u012e\u012f\5B\"\2\u012f\u0130")
        buf.write("\7\26\2\2\u0130\u0131\5\60\31\2\u0131\u0132\7\27\2\2\u0132")
        buf.write("\u0135\3\2\2\2\u0133\u0135\5B\"\2\u0134\u012e\3\2\2\2")
        buf.write("\u0134\u0133\3\2\2\2\u0135A\3\2\2\2\u0136\u0137\7\5\2")
        buf.write("\2\u0137\u0138\5\60\31\2\u0138\u0139\7\6\2\2\u0139\u0141")
        buf.write("\3\2\2\2\u013a\u0141\5D#\2\u013b\u0141\7*\2\2\u013c\u0141")
        buf.write("\7+\2\2\u013d\u0141\7&\2\2\u013e\u0141\7-\2\2\u013f\u0141")
        buf.write("\7,\2\2\u0140\u0136\3\2\2\2\u0140\u013a\3\2\2\2\u0140")
        buf.write("\u013b\3\2\2\2\u0140\u013c\3\2\2\2\u0140\u013d\3\2\2\2")
        buf.write("\u0140\u013e\3\2\2\2\u0140\u013f\3\2\2\2\u0141C\3\2\2")
        buf.write("\2\u0142\u0143\7,\2\2\u0143\u0144\7\5\2\2\u0144\u0145")
        buf.write("\5F$\2\u0145\u0146\7\6\2\2\u0146E\3\2\2\2\u0147\u014c")
        buf.write("\5\60\31\2\u0148\u0149\7\4\2\2\u0149\u014b\5\60\31\2\u014a")
        buf.write("\u0148\3\2\2\2\u014b\u014e\3\2\2\2\u014c\u014a\3\2\2\2")
        buf.write("\u014c\u014d\3\2\2\2\u014d\u0150\3\2\2\2\u014e\u014c\3")
        buf.write("\2\2\2\u014f\u0147\3\2\2\2\u014f\u0150\3\2\2\2\u0150G")
        buf.write("\3\2\2\2\36MO\\ar\177\u0082\u0088\u0094\u009d\u00a3\u00bb")
        buf.write("\u00c6\u00cb\u00d2\u00dc\u00e7\u00f3\u0106\u0111\u0113")
        buf.write("\u0122\u0124\u012c\u0134\u0140\u014c\u014f")
        return buf.getvalue()


class MCParser ( Parser ):

    grammarFileName = "MC.g4"

    atn = ATNDeserializer().deserialize(serializedATN())

    decisionsToDFA = [ DFA(ds, i) for i, ds in enumerate(atn.decisionToState) ]

    sharedContextCache = PredictionContextCache()

    literalNames = [ "<INVALID>", "';'", "','", "'('", "')'", "'+'", "'-'", 
                     "'*'", "'/'", "'%'", "'!'", "'<'", "'>'", "'='", "'||'", 
                     "'&&'", "'!='", "'=='", "'<='", "'>='", "'['", "']'", 
                     "'{'", "'}'", "'int'", "'float'", "'boolean'", "'void'", 
                     "'break'", "'continue'", "'for'", "'if'", "'else'", 
                     "'return'", "'do'", "'while'", "<INVALID>", "'true'", 
                     "'false'", "'string'" ]

    symbolicNames = [ "<INVALID>", "SM", "CM", "LB", "RB", "ADD", "SUB", 
                      "MUL", "DIV", "MOD", "NOT", "LT", "GT", "ASSIGN", 
                      "OR", "AND", "NE", "EQ", "LE", "GE", "LS", "RS", "LP", 
                      "RP", "INTTYPE", "FLOATTYPE", "BOOLTYPE", "VOIDTYPE", 
                      "BREAK", "CONTINUE", "FOR", "IF", "ELSE", "RETURN", 
                      "DO", "WHILE", "BOOLLIT", "TRUE", "FALSE", "STRING", 
                      "INTLIT", "FLOATLIT", "ID", "STRINGLIT", "ILLEGAL_ESCAPE", 
                      "UNCLOSE_STRING", "BLOCKCMT", "LINECMT", "WS", "ERROR_CHAR" ]

    RULE_program = 0
    RULE_manydecls = 1
    RULE_vardecl = 2
    RULE_primtype = 3
    RULE_varlist = 4
    RULE_var = 5
    RULE_arrayvar = 6
    RULE_fundecl = 7
    RULE_typ = 8
    RULE_arrp_type = 9
    RULE_paralist = 10
    RULE_paradecls = 11
    RULE_paradecl = 12
    RULE_stmt = 13
    RULE_if_stmt = 14
    RULE_dowhile_stmt = 15
    RULE_for_stmt = 16
    RULE_break_stmt = 17
    RULE_continue_stmt = 18
    RULE_return_stmt = 19
    RULE_block_stmt = 20
    RULE_vardecl_stmtlist = 21
    RULE_vardecl_stmt = 22
    RULE_exp = 23
    RULE_exp1 = 24
    RULE_exp2 = 25
    RULE_exp3 = 26
    RULE_exp4 = 27
    RULE_exp5 = 28
    RULE_exp6 = 29
    RULE_exp7 = 30
    RULE_exp8 = 31
    RULE_operand = 32
    RULE_funcall = 33
    RULE_explist = 34

    ruleNames =  [ "program", "manydecls", "vardecl", "primtype", "varlist", 
                   "var", "arrayvar", "fundecl", "typ", "arrp_type", "paralist", 
                   "paradecls", "paradecl", "stmt", "if_stmt", "dowhile_stmt", 
                   "for_stmt", "break_stmt", "continue_stmt", "return_stmt", 
                   "block_stmt", "vardecl_stmtlist", "vardecl_stmt", "exp", 
                   "exp1", "exp2", "exp3", "exp4", "exp5", "exp6", "exp7", 
                   "exp8", "operand", "funcall", "explist" ]

    EOF = Token.EOF
    SM=1
    CM=2
    LB=3
    RB=4
    ADD=5
    SUB=6
    MUL=7
    DIV=8
    MOD=9
    NOT=10
    LT=11
    GT=12
    ASSIGN=13
    OR=14
    AND=15
    NE=16
    EQ=17
    LE=18
    GE=19
    LS=20
    RS=21
    LP=22
    RP=23
    INTTYPE=24
    FLOATTYPE=25
    BOOLTYPE=26
    VOIDTYPE=27
    BREAK=28
    CONTINUE=29
    FOR=30
    IF=31
    ELSE=32
    RETURN=33
    DO=34
    WHILE=35
    BOOLLIT=36
    TRUE=37
    FALSE=38
    STRING=39
    INTLIT=40
    FLOATLIT=41
    ID=42
    STRINGLIT=43
    ILLEGAL_ESCAPE=44
    UNCLOSE_STRING=45
    BLOCKCMT=46
    LINECMT=47
    WS=48
    ERROR_CHAR=49

    def __init__(self, input:TokenStream, output:TextIO = sys.stdout):
        super().__init__(input, output)
        self.checkVersion("4.7.1")
        self._interp = ParserATNSimulator(self, self.atn, self.decisionsToDFA, self.sharedContextCache)
        self._predicates = None



    class ProgramContext(ParserRuleContext):

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def manydecls(self):
            return self.getTypedRuleContext(MCParser.ManydeclsContext,0)


        def EOF(self):
            return self.getToken(MCParser.EOF, 0)

        def getRuleIndex(self):
            return MCParser.RULE_program




    def program(self):

        localctx = MCParser.ProgramContext(self, self._ctx, self.state)
        self.enterRule(localctx, 0, self.RULE_program)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 70
            self.manydecls()
            self.state = 71
            self.match(MCParser.EOF)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx

    class ManydeclsContext(ParserRuleContext):

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def vardecl(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(MCParser.VardeclContext)
            else:
                return self.getTypedRuleContext(MCParser.VardeclContext,i)


        def fundecl(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(MCParser.FundeclContext)
            else:
                return self.getTypedRuleContext(MCParser.FundeclContext,i)


        def getRuleIndex(self):
            return MCParser.RULE_manydecls




    def manydecls(self):

        localctx = MCParser.ManydeclsContext(self, self._ctx, self.state)
        self.enterRule(localctx, 2, self.RULE_manydecls)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 75 
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while True:
                self.state = 75
                self._errHandler.sync(self)
                la_ = self._interp.adaptivePredict(self._input,0,self._ctx)
                if la_ == 1:
                    self.state = 73
                    self.vardecl()
                    pass

                elif la_ == 2:
                    self.state = 74
                    self.fundecl()
                    pass


                self.state = 77 
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                if not ((((_la) & ~0x3f) == 0 and ((1 << _la) & ((1 << MCParser.INTTYPE) | (1 << MCParser.FLOATTYPE) | (1 << MCParser.BOOLTYPE) | (1 << MCParser.VOIDTYPE) | (1 << MCParser.STRING))) != 0)):
                    break

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx

    class VardeclContext(ParserRuleContext):

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def primtype(self):
            return self.getTypedRuleContext(MCParser.PrimtypeContext,0)


        def varlist(self):
            return self.getTypedRuleContext(MCParser.VarlistContext,0)


        def SM(self):
            return self.getToken(MCParser.SM, 0)

        def getRuleIndex(self):
            return MCParser.RULE_vardecl




    def vardecl(self):

        localctx = MCParser.VardeclContext(self, self._ctx, self.state)
        self.enterRule(localctx, 4, self.RULE_vardecl)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 79
            self.primtype()
            self.state = 80
            self.varlist()
            self.state = 81
            self.match(MCParser.SM)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx

    class PrimtypeContext(ParserRuleContext):

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def INTTYPE(self):
            return self.getToken(MCParser.INTTYPE, 0)

        def FLOATTYPE(self):
            return self.getToken(MCParser.FLOATTYPE, 0)

        def BOOLTYPE(self):
            return self.getToken(MCParser.BOOLTYPE, 0)

        def STRING(self):
            return self.getToken(MCParser.STRING, 0)

        def getRuleIndex(self):
            return MCParser.RULE_primtype




    def primtype(self):

        localctx = MCParser.PrimtypeContext(self, self._ctx, self.state)
        self.enterRule(localctx, 6, self.RULE_primtype)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 83
            _la = self._input.LA(1)
            if not((((_la) & ~0x3f) == 0 and ((1 << _la) & ((1 << MCParser.INTTYPE) | (1 << MCParser.FLOATTYPE) | (1 << MCParser.BOOLTYPE) | (1 << MCParser.STRING))) != 0)):
                self._errHandler.recoverInline(self)
            else:
                self._errHandler.reportMatch(self)
                self.consume()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx

    class VarlistContext(ParserRuleContext):

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def var(self):
            return self.getTypedRuleContext(MCParser.VarContext,0)


        def CM(self, i:int=None):
            if i is None:
                return self.getTokens(MCParser.CM)
            else:
                return self.getToken(MCParser.CM, i)

        def varlist(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(MCParser.VarlistContext)
            else:
                return self.getTypedRuleContext(MCParser.VarlistContext,i)


        def getRuleIndex(self):
            return MCParser.RULE_varlist




    def varlist(self):

        localctx = MCParser.VarlistContext(self, self._ctx, self.state)
        self.enterRule(localctx, 8, self.RULE_varlist)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 85
            self.var()
            self.state = 90
            self._errHandler.sync(self)
            _alt = self._interp.adaptivePredict(self._input,2,self._ctx)
            while _alt!=2 and _alt!=ATN.INVALID_ALT_NUMBER:
                if _alt==1:
                    self.state = 86
                    self.match(MCParser.CM)
                    self.state = 87
                    self.varlist() 
                self.state = 92
                self._errHandler.sync(self)
                _alt = self._interp.adaptivePredict(self._input,2,self._ctx)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx

    class VarContext(ParserRuleContext):

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def ID(self):
            return self.getToken(MCParser.ID, 0)

        def arrayvar(self):
            return self.getTypedRuleContext(MCParser.ArrayvarContext,0)


        def getRuleIndex(self):
            return MCParser.RULE_var




    def var(self):

        localctx = MCParser.VarContext(self, self._ctx, self.state)
        self.enterRule(localctx, 10, self.RULE_var)
        try:
            self.state = 95
            self._errHandler.sync(self)
            la_ = self._interp.adaptivePredict(self._input,3,self._ctx)
            if la_ == 1:
                self.enterOuterAlt(localctx, 1)
                self.state = 93
                self.match(MCParser.ID)
                pass

            elif la_ == 2:
                self.enterOuterAlt(localctx, 2)
                self.state = 94
                self.arrayvar()
                pass


        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx

    class ArrayvarContext(ParserRuleContext):

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def ID(self):
            return self.getToken(MCParser.ID, 0)

        def LS(self):
            return self.getToken(MCParser.LS, 0)

        def INTLIT(self):
            return self.getToken(MCParser.INTLIT, 0)

        def RS(self):
            return self.getToken(MCParser.RS, 0)

        def getRuleIndex(self):
            return MCParser.RULE_arrayvar




    def arrayvar(self):

        localctx = MCParser.ArrayvarContext(self, self._ctx, self.state)
        self.enterRule(localctx, 12, self.RULE_arrayvar)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 97
            self.match(MCParser.ID)
            self.state = 98
            self.match(MCParser.LS)
            self.state = 99
            self.match(MCParser.INTLIT)
            self.state = 100
            self.match(MCParser.RS)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx

    class FundeclContext(ParserRuleContext):

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def typ(self):
            return self.getTypedRuleContext(MCParser.TypContext,0)


        def ID(self):
            return self.getToken(MCParser.ID, 0)

        def LB(self):
            return self.getToken(MCParser.LB, 0)

        def paralist(self):
            return self.getTypedRuleContext(MCParser.ParalistContext,0)


        def RB(self):
            return self.getToken(MCParser.RB, 0)

        def block_stmt(self):
            return self.getTypedRuleContext(MCParser.Block_stmtContext,0)


        def getRuleIndex(self):
            return MCParser.RULE_fundecl




    def fundecl(self):

        localctx = MCParser.FundeclContext(self, self._ctx, self.state)
        self.enterRule(localctx, 14, self.RULE_fundecl)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 102
            self.typ()
            self.state = 103
            self.match(MCParser.ID)
            self.state = 104
            self.match(MCParser.LB)
            self.state = 105
            self.paralist()
            self.state = 106
            self.match(MCParser.RB)
            self.state = 107
            self.block_stmt()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx

    class TypContext(ParserRuleContext):

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def primtype(self):
            return self.getTypedRuleContext(MCParser.PrimtypeContext,0)


        def arrp_type(self):
            return self.getTypedRuleContext(MCParser.Arrp_typeContext,0)


        def VOIDTYPE(self):
            return self.getToken(MCParser.VOIDTYPE, 0)

        def getRuleIndex(self):
            return MCParser.RULE_typ




    def typ(self):

        localctx = MCParser.TypContext(self, self._ctx, self.state)
        self.enterRule(localctx, 16, self.RULE_typ)
        try:
            self.state = 112
            self._errHandler.sync(self)
            la_ = self._interp.adaptivePredict(self._input,4,self._ctx)
            if la_ == 1:
                self.enterOuterAlt(localctx, 1)
                self.state = 109
                self.primtype()
                pass

            elif la_ == 2:
                self.enterOuterAlt(localctx, 2)
                self.state = 110
                self.arrp_type()
                pass

            elif la_ == 3:
                self.enterOuterAlt(localctx, 3)
                self.state = 111
                self.match(MCParser.VOIDTYPE)
                pass


        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx

    class Arrp_typeContext(ParserRuleContext):

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def primtype(self):
            return self.getTypedRuleContext(MCParser.PrimtypeContext,0)


        def LS(self):
            return self.getToken(MCParser.LS, 0)

        def RS(self):
            return self.getToken(MCParser.RS, 0)

        def getRuleIndex(self):
            return MCParser.RULE_arrp_type




    def arrp_type(self):

        localctx = MCParser.Arrp_typeContext(self, self._ctx, self.state)
        self.enterRule(localctx, 18, self.RULE_arrp_type)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 114
            self.primtype()
            self.state = 115
            self.match(MCParser.LS)
            self.state = 116
            self.match(MCParser.RS)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx

    class ParalistContext(ParserRuleContext):

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def paradecls(self):
            return self.getTypedRuleContext(MCParser.ParadeclsContext,0)


        def getRuleIndex(self):
            return MCParser.RULE_paralist




    def paralist(self):

        localctx = MCParser.ParalistContext(self, self._ctx, self.state)
        self.enterRule(localctx, 20, self.RULE_paralist)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 118
            self.paradecls()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx

    class ParadeclsContext(ParserRuleContext):

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def paradecl(self):
            return self.getTypedRuleContext(MCParser.ParadeclContext,0)


        def CM(self, i:int=None):
            if i is None:
                return self.getTokens(MCParser.CM)
            else:
                return self.getToken(MCParser.CM, i)

        def paradecls(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(MCParser.ParadeclsContext)
            else:
                return self.getTypedRuleContext(MCParser.ParadeclsContext,i)


        def getRuleIndex(self):
            return MCParser.RULE_paradecls




    def paradecls(self):

        localctx = MCParser.ParadeclsContext(self, self._ctx, self.state)
        self.enterRule(localctx, 22, self.RULE_paradecls)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 128
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if (((_la) & ~0x3f) == 0 and ((1 << _la) & ((1 << MCParser.INTTYPE) | (1 << MCParser.FLOATTYPE) | (1 << MCParser.BOOLTYPE) | (1 << MCParser.STRING))) != 0):
                self.state = 120
                self.paradecl()
                self.state = 125
                self._errHandler.sync(self)
                _alt = self._interp.adaptivePredict(self._input,5,self._ctx)
                while _alt!=2 and _alt!=ATN.INVALID_ALT_NUMBER:
                    if _alt==1:
                        self.state = 121
                        self.match(MCParser.CM)
                        self.state = 122
                        self.paradecls() 
                    self.state = 127
                    self._errHandler.sync(self)
                    _alt = self._interp.adaptivePredict(self._input,5,self._ctx)



        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx

    class ParadeclContext(ParserRuleContext):

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def primtype(self):
            return self.getTypedRuleContext(MCParser.PrimtypeContext,0)


        def ID(self):
            return self.getToken(MCParser.ID, 0)

        def getRuleIndex(self):
            return MCParser.RULE_paradecl




    def paradecl(self):

        localctx = MCParser.ParadeclContext(self, self._ctx, self.state)
        self.enterRule(localctx, 24, self.RULE_paradecl)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 130
            self.primtype()
            self.state = 131
            self.match(MCParser.ID)
            self.state = 134
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==MCParser.LS:
                self.state = 132
                self.match(MCParser.LS)
                self.state = 133
                self.match(MCParser.RS)


        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx

    class StmtContext(ParserRuleContext):

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def if_stmt(self):
            return self.getTypedRuleContext(MCParser.If_stmtContext,0)


        def for_stmt(self):
            return self.getTypedRuleContext(MCParser.For_stmtContext,0)


        def dowhile_stmt(self):
            return self.getTypedRuleContext(MCParser.Dowhile_stmtContext,0)


        def break_stmt(self):
            return self.getTypedRuleContext(MCParser.Break_stmtContext,0)


        def continue_stmt(self):
            return self.getTypedRuleContext(MCParser.Continue_stmtContext,0)


        def return_stmt(self):
            return self.getTypedRuleContext(MCParser.Return_stmtContext,0)


        def exp(self):
            return self.getTypedRuleContext(MCParser.ExpContext,0)


        def SM(self):
            return self.getToken(MCParser.SM, 0)

        def block_stmt(self):
            return self.getTypedRuleContext(MCParser.Block_stmtContext,0)


        def getRuleIndex(self):
            return MCParser.RULE_stmt




    def stmt(self):

        localctx = MCParser.StmtContext(self, self._ctx, self.state)
        self.enterRule(localctx, 26, self.RULE_stmt)
        try:
            self.state = 146
            self._errHandler.sync(self)
            token = self._input.LA(1)
            if token in [MCParser.IF]:
                self.enterOuterAlt(localctx, 1)
                self.state = 136
                self.if_stmt()
                pass
            elif token in [MCParser.FOR]:
                self.enterOuterAlt(localctx, 2)
                self.state = 137
                self.for_stmt()
                pass
            elif token in [MCParser.DO]:
                self.enterOuterAlt(localctx, 3)
                self.state = 138
                self.dowhile_stmt()
                pass
            elif token in [MCParser.BREAK]:
                self.enterOuterAlt(localctx, 4)
                self.state = 139
                self.break_stmt()
                pass
            elif token in [MCParser.CONTINUE]:
                self.enterOuterAlt(localctx, 5)
                self.state = 140
                self.continue_stmt()
                pass
            elif token in [MCParser.RETURN]:
                self.enterOuterAlt(localctx, 6)
                self.state = 141
                self.return_stmt()
                pass
            elif token in [MCParser.LB, MCParser.SUB, MCParser.NOT, MCParser.BOOLLIT, MCParser.INTLIT, MCParser.FLOATLIT, MCParser.ID, MCParser.STRINGLIT]:
                self.enterOuterAlt(localctx, 7)
                self.state = 142
                self.exp()
                self.state = 143
                self.match(MCParser.SM)
                pass
            elif token in [MCParser.LP]:
                self.enterOuterAlt(localctx, 8)
                self.state = 145
                self.block_stmt()
                pass
            else:
                raise NoViableAltException(self)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx

    class If_stmtContext(ParserRuleContext):

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def IF(self):
            return self.getToken(MCParser.IF, 0)

        def LB(self):
            return self.getToken(MCParser.LB, 0)

        def exp(self):
            return self.getTypedRuleContext(MCParser.ExpContext,0)


        def RB(self):
            return self.getToken(MCParser.RB, 0)

        def stmt(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(MCParser.StmtContext)
            else:
                return self.getTypedRuleContext(MCParser.StmtContext,i)


        def ELSE(self):
            return self.getToken(MCParser.ELSE, 0)

        def getRuleIndex(self):
            return MCParser.RULE_if_stmt




    def if_stmt(self):

        localctx = MCParser.If_stmtContext(self, self._ctx, self.state)
        self.enterRule(localctx, 28, self.RULE_if_stmt)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 148
            self.match(MCParser.IF)
            self.state = 149
            self.match(MCParser.LB)
            self.state = 150
            self.exp()
            self.state = 151
            self.match(MCParser.RB)
            self.state = 152
            self.stmt()
            self.state = 155
            self._errHandler.sync(self)
            la_ = self._interp.adaptivePredict(self._input,9,self._ctx)
            if la_ == 1:
                self.state = 153
                self.match(MCParser.ELSE)
                self.state = 154
                self.stmt()


        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx

    class Dowhile_stmtContext(ParserRuleContext):

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def DO(self):
            return self.getToken(MCParser.DO, 0)

        def WHILE(self):
            return self.getToken(MCParser.WHILE, 0)

        def exp(self):
            return self.getTypedRuleContext(MCParser.ExpContext,0)


        def SM(self):
            return self.getToken(MCParser.SM, 0)

        def stmt(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(MCParser.StmtContext)
            else:
                return self.getTypedRuleContext(MCParser.StmtContext,i)


        def getRuleIndex(self):
            return MCParser.RULE_dowhile_stmt




    def dowhile_stmt(self):

        localctx = MCParser.Dowhile_stmtContext(self, self._ctx, self.state)
        self.enterRule(localctx, 30, self.RULE_dowhile_stmt)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 157
            self.match(MCParser.DO)
            self.state = 159 
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while True:
                self.state = 158
                self.stmt()
                self.state = 161 
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                if not ((((_la) & ~0x3f) == 0 and ((1 << _la) & ((1 << MCParser.LB) | (1 << MCParser.SUB) | (1 << MCParser.NOT) | (1 << MCParser.LP) | (1 << MCParser.BREAK) | (1 << MCParser.CONTINUE) | (1 << MCParser.FOR) | (1 << MCParser.IF) | (1 << MCParser.RETURN) | (1 << MCParser.DO) | (1 << MCParser.BOOLLIT) | (1 << MCParser.INTLIT) | (1 << MCParser.FLOATLIT) | (1 << MCParser.ID) | (1 << MCParser.STRINGLIT))) != 0)):
                    break

            self.state = 163
            self.match(MCParser.WHILE)
            self.state = 164
            self.exp()
            self.state = 165
            self.match(MCParser.SM)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx

    class For_stmtContext(ParserRuleContext):

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def FOR(self):
            return self.getToken(MCParser.FOR, 0)

        def LB(self):
            return self.getToken(MCParser.LB, 0)

        def exp(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(MCParser.ExpContext)
            else:
                return self.getTypedRuleContext(MCParser.ExpContext,i)


        def SM(self, i:int=None):
            if i is None:
                return self.getTokens(MCParser.SM)
            else:
                return self.getToken(MCParser.SM, i)

        def RB(self):
            return self.getToken(MCParser.RB, 0)

        def stmt(self):
            return self.getTypedRuleContext(MCParser.StmtContext,0)


        def getRuleIndex(self):
            return MCParser.RULE_for_stmt




    def for_stmt(self):

        localctx = MCParser.For_stmtContext(self, self._ctx, self.state)
        self.enterRule(localctx, 32, self.RULE_for_stmt)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 167
            self.match(MCParser.FOR)
            self.state = 168
            self.match(MCParser.LB)
            self.state = 169
            self.exp()
            self.state = 170
            self.match(MCParser.SM)
            self.state = 171
            self.exp()
            self.state = 172
            self.match(MCParser.SM)
            self.state = 173
            self.exp()
            self.state = 174
            self.match(MCParser.RB)
            self.state = 175
            self.stmt()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx

    class Break_stmtContext(ParserRuleContext):

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def BREAK(self):
            return self.getToken(MCParser.BREAK, 0)

        def SM(self):
            return self.getToken(MCParser.SM, 0)

        def getRuleIndex(self):
            return MCParser.RULE_break_stmt




    def break_stmt(self):

        localctx = MCParser.Break_stmtContext(self, self._ctx, self.state)
        self.enterRule(localctx, 34, self.RULE_break_stmt)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 177
            self.match(MCParser.BREAK)
            self.state = 178
            self.match(MCParser.SM)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx

    class Continue_stmtContext(ParserRuleContext):

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def CONTINUE(self):
            return self.getToken(MCParser.CONTINUE, 0)

        def SM(self):
            return self.getToken(MCParser.SM, 0)

        def getRuleIndex(self):
            return MCParser.RULE_continue_stmt




    def continue_stmt(self):

        localctx = MCParser.Continue_stmtContext(self, self._ctx, self.state)
        self.enterRule(localctx, 36, self.RULE_continue_stmt)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 180
            self.match(MCParser.CONTINUE)
            self.state = 181
            self.match(MCParser.SM)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx

    class Return_stmtContext(ParserRuleContext):

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def RETURN(self):
            return self.getToken(MCParser.RETURN, 0)

        def SM(self):
            return self.getToken(MCParser.SM, 0)

        def exp(self):
            return self.getTypedRuleContext(MCParser.ExpContext,0)


        def getRuleIndex(self):
            return MCParser.RULE_return_stmt




    def return_stmt(self):

        localctx = MCParser.Return_stmtContext(self, self._ctx, self.state)
        self.enterRule(localctx, 38, self.RULE_return_stmt)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 183
            self.match(MCParser.RETURN)
            self.state = 185
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if (((_la) & ~0x3f) == 0 and ((1 << _la) & ((1 << MCParser.LB) | (1 << MCParser.SUB) | (1 << MCParser.NOT) | (1 << MCParser.BOOLLIT) | (1 << MCParser.INTLIT) | (1 << MCParser.FLOATLIT) | (1 << MCParser.ID) | (1 << MCParser.STRINGLIT))) != 0):
                self.state = 184
                self.exp()


            self.state = 187
            self.match(MCParser.SM)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx

    class Block_stmtContext(ParserRuleContext):

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def LP(self):
            return self.getToken(MCParser.LP, 0)

        def vardecl_stmtlist(self):
            return self.getTypedRuleContext(MCParser.Vardecl_stmtlistContext,0)


        def RP(self):
            return self.getToken(MCParser.RP, 0)

        def getRuleIndex(self):
            return MCParser.RULE_block_stmt




    def block_stmt(self):

        localctx = MCParser.Block_stmtContext(self, self._ctx, self.state)
        self.enterRule(localctx, 40, self.RULE_block_stmt)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 189
            self.match(MCParser.LP)
            self.state = 190
            self.vardecl_stmtlist()
            self.state = 191
            self.match(MCParser.RP)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx

    class Vardecl_stmtlistContext(ParserRuleContext):

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def vardecl_stmt(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(MCParser.Vardecl_stmtContext)
            else:
                return self.getTypedRuleContext(MCParser.Vardecl_stmtContext,i)


        def getRuleIndex(self):
            return MCParser.RULE_vardecl_stmtlist




    def vardecl_stmtlist(self):

        localctx = MCParser.Vardecl_stmtlistContext(self, self._ctx, self.state)
        self.enterRule(localctx, 42, self.RULE_vardecl_stmtlist)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 196
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while (((_la) & ~0x3f) == 0 and ((1 << _la) & ((1 << MCParser.LB) | (1 << MCParser.SUB) | (1 << MCParser.NOT) | (1 << MCParser.LP) | (1 << MCParser.INTTYPE) | (1 << MCParser.FLOATTYPE) | (1 << MCParser.BOOLTYPE) | (1 << MCParser.BREAK) | (1 << MCParser.CONTINUE) | (1 << MCParser.FOR) | (1 << MCParser.IF) | (1 << MCParser.RETURN) | (1 << MCParser.DO) | (1 << MCParser.BOOLLIT) | (1 << MCParser.STRING) | (1 << MCParser.INTLIT) | (1 << MCParser.FLOATLIT) | (1 << MCParser.ID) | (1 << MCParser.STRINGLIT))) != 0):
                self.state = 193
                self.vardecl_stmt()
                self.state = 198
                self._errHandler.sync(self)
                _la = self._input.LA(1)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx

    class Vardecl_stmtContext(ParserRuleContext):

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def vardecl(self):
            return self.getTypedRuleContext(MCParser.VardeclContext,0)


        def stmt(self):
            return self.getTypedRuleContext(MCParser.StmtContext,0)


        def getRuleIndex(self):
            return MCParser.RULE_vardecl_stmt




    def vardecl_stmt(self):

        localctx = MCParser.Vardecl_stmtContext(self, self._ctx, self.state)
        self.enterRule(localctx, 44, self.RULE_vardecl_stmt)
        try:
            self.state = 201
            self._errHandler.sync(self)
            token = self._input.LA(1)
            if token in [MCParser.INTTYPE, MCParser.FLOATTYPE, MCParser.BOOLTYPE, MCParser.STRING]:
                self.enterOuterAlt(localctx, 1)
                self.state = 199
                self.vardecl()
                pass
            elif token in [MCParser.LB, MCParser.SUB, MCParser.NOT, MCParser.LP, MCParser.BREAK, MCParser.CONTINUE, MCParser.FOR, MCParser.IF, MCParser.RETURN, MCParser.DO, MCParser.BOOLLIT, MCParser.INTLIT, MCParser.FLOATLIT, MCParser.ID, MCParser.STRINGLIT]:
                self.enterOuterAlt(localctx, 2)
                self.state = 200
                self.stmt()
                pass
            else:
                raise NoViableAltException(self)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx

    class ExpContext(ParserRuleContext):

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def exp1(self):
            return self.getTypedRuleContext(MCParser.Exp1Context,0)


        def ASSIGN(self):
            return self.getToken(MCParser.ASSIGN, 0)

        def exp(self):
            return self.getTypedRuleContext(MCParser.ExpContext,0)


        def getRuleIndex(self):
            return MCParser.RULE_exp




    def exp(self):

        localctx = MCParser.ExpContext(self, self._ctx, self.state)
        self.enterRule(localctx, 46, self.RULE_exp)
        try:
            self.state = 208
            self._errHandler.sync(self)
            la_ = self._interp.adaptivePredict(self._input,14,self._ctx)
            if la_ == 1:
                self.enterOuterAlt(localctx, 1)
                self.state = 203
                self.exp1(0)
                self.state = 204
                self.match(MCParser.ASSIGN)
                self.state = 205
                self.exp()
                pass

            elif la_ == 2:
                self.enterOuterAlt(localctx, 2)
                self.state = 207
                self.exp1(0)
                pass


        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx

    class Exp1Context(ParserRuleContext):

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def exp2(self):
            return self.getTypedRuleContext(MCParser.Exp2Context,0)


        def exp1(self):
            return self.getTypedRuleContext(MCParser.Exp1Context,0)


        def OR(self):
            return self.getToken(MCParser.OR, 0)

        def getRuleIndex(self):
            return MCParser.RULE_exp1



    def exp1(self, _p:int=0):
        _parentctx = self._ctx
        _parentState = self.state
        localctx = MCParser.Exp1Context(self, self._ctx, _parentState)
        _prevctx = localctx
        _startState = 48
        self.enterRecursionRule(localctx, 48, self.RULE_exp1, _p)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 211
            self.exp2(0)
            self._ctx.stop = self._input.LT(-1)
            self.state = 218
            self._errHandler.sync(self)
            _alt = self._interp.adaptivePredict(self._input,15,self._ctx)
            while _alt!=2 and _alt!=ATN.INVALID_ALT_NUMBER:
                if _alt==1:
                    if self._parseListeners is not None:
                        self.triggerExitRuleEvent()
                    _prevctx = localctx
                    localctx = MCParser.Exp1Context(self, _parentctx, _parentState)
                    self.pushNewRecursionContext(localctx, _startState, self.RULE_exp1)
                    self.state = 213
                    if not self.precpred(self._ctx, 2):
                        from antlr4.error.Errors import FailedPredicateException
                        raise FailedPredicateException(self, "self.precpred(self._ctx, 2)")
                    self.state = 214
                    self.match(MCParser.OR)
                    self.state = 215
                    self.exp2(0) 
                self.state = 220
                self._errHandler.sync(self)
                _alt = self._interp.adaptivePredict(self._input,15,self._ctx)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.unrollRecursionContexts(_parentctx)
        return localctx

    class Exp2Context(ParserRuleContext):

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def exp3(self):
            return self.getTypedRuleContext(MCParser.Exp3Context,0)


        def exp2(self):
            return self.getTypedRuleContext(MCParser.Exp2Context,0)


        def AND(self):
            return self.getToken(MCParser.AND, 0)

        def getRuleIndex(self):
            return MCParser.RULE_exp2



    def exp2(self, _p:int=0):
        _parentctx = self._ctx
        _parentState = self.state
        localctx = MCParser.Exp2Context(self, self._ctx, _parentState)
        _prevctx = localctx
        _startState = 50
        self.enterRecursionRule(localctx, 50, self.RULE_exp2, _p)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 222
            self.exp3()
            self._ctx.stop = self._input.LT(-1)
            self.state = 229
            self._errHandler.sync(self)
            _alt = self._interp.adaptivePredict(self._input,16,self._ctx)
            while _alt!=2 and _alt!=ATN.INVALID_ALT_NUMBER:
                if _alt==1:
                    if self._parseListeners is not None:
                        self.triggerExitRuleEvent()
                    _prevctx = localctx
                    localctx = MCParser.Exp2Context(self, _parentctx, _parentState)
                    self.pushNewRecursionContext(localctx, _startState, self.RULE_exp2)
                    self.state = 224
                    if not self.precpred(self._ctx, 2):
                        from antlr4.error.Errors import FailedPredicateException
                        raise FailedPredicateException(self, "self.precpred(self._ctx, 2)")
                    self.state = 225
                    self.match(MCParser.AND)
                    self.state = 226
                    self.exp3() 
                self.state = 231
                self._errHandler.sync(self)
                _alt = self._interp.adaptivePredict(self._input,16,self._ctx)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.unrollRecursionContexts(_parentctx)
        return localctx

    class Exp3Context(ParserRuleContext):

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def exp4(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(MCParser.Exp4Context)
            else:
                return self.getTypedRuleContext(MCParser.Exp4Context,i)


        def EQ(self):
            return self.getToken(MCParser.EQ, 0)

        def NE(self):
            return self.getToken(MCParser.NE, 0)

        def getRuleIndex(self):
            return MCParser.RULE_exp3




    def exp3(self):

        localctx = MCParser.Exp3Context(self, self._ctx, self.state)
        self.enterRule(localctx, 52, self.RULE_exp3)
        try:
            self.state = 241
            self._errHandler.sync(self)
            la_ = self._interp.adaptivePredict(self._input,17,self._ctx)
            if la_ == 1:
                self.enterOuterAlt(localctx, 1)
                self.state = 232
                self.exp4()
                self.state = 233
                self.match(MCParser.EQ)
                self.state = 234
                self.exp4()
                pass

            elif la_ == 2:
                self.enterOuterAlt(localctx, 2)
                self.state = 236
                self.exp4()
                self.state = 237
                self.match(MCParser.NE)
                self.state = 238
                self.exp4()
                pass

            elif la_ == 3:
                self.enterOuterAlt(localctx, 3)
                self.state = 240
                self.exp4()
                pass


        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx

    class Exp4Context(ParserRuleContext):

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def exp5(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(MCParser.Exp5Context)
            else:
                return self.getTypedRuleContext(MCParser.Exp5Context,i)


        def LT(self):
            return self.getToken(MCParser.LT, 0)

        def LE(self):
            return self.getToken(MCParser.LE, 0)

        def GT(self):
            return self.getToken(MCParser.GT, 0)

        def GE(self):
            return self.getToken(MCParser.GE, 0)

        def getRuleIndex(self):
            return MCParser.RULE_exp4




    def exp4(self):

        localctx = MCParser.Exp4Context(self, self._ctx, self.state)
        self.enterRule(localctx, 54, self.RULE_exp4)
        try:
            self.state = 260
            self._errHandler.sync(self)
            la_ = self._interp.adaptivePredict(self._input,18,self._ctx)
            if la_ == 1:
                self.enterOuterAlt(localctx, 1)
                self.state = 243
                self.exp5(0)
                self.state = 244
                self.match(MCParser.LT)
                self.state = 245
                self.exp5(0)
                pass

            elif la_ == 2:
                self.enterOuterAlt(localctx, 2)
                self.state = 247
                self.exp5(0)
                self.state = 248
                self.match(MCParser.LE)
                self.state = 249
                self.exp5(0)
                pass

            elif la_ == 3:
                self.enterOuterAlt(localctx, 3)
                self.state = 251
                self.exp5(0)
                self.state = 252
                self.match(MCParser.GT)
                self.state = 253
                self.exp5(0)
                pass

            elif la_ == 4:
                self.enterOuterAlt(localctx, 4)
                self.state = 255
                self.exp5(0)
                self.state = 256
                self.match(MCParser.GE)
                self.state = 257
                self.exp5(0)
                pass

            elif la_ == 5:
                self.enterOuterAlt(localctx, 5)
                self.state = 259
                self.exp5(0)
                pass


        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx

    class Exp5Context(ParserRuleContext):

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def exp6(self):
            return self.getTypedRuleContext(MCParser.Exp6Context,0)


        def exp5(self):
            return self.getTypedRuleContext(MCParser.Exp5Context,0)


        def ADD(self):
            return self.getToken(MCParser.ADD, 0)

        def SUB(self):
            return self.getToken(MCParser.SUB, 0)

        def getRuleIndex(self):
            return MCParser.RULE_exp5



    def exp5(self, _p:int=0):
        _parentctx = self._ctx
        _parentState = self.state
        localctx = MCParser.Exp5Context(self, self._ctx, _parentState)
        _prevctx = localctx
        _startState = 56
        self.enterRecursionRule(localctx, 56, self.RULE_exp5, _p)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 263
            self.exp6(0)
            self._ctx.stop = self._input.LT(-1)
            self.state = 273
            self._errHandler.sync(self)
            _alt = self._interp.adaptivePredict(self._input,20,self._ctx)
            while _alt!=2 and _alt!=ATN.INVALID_ALT_NUMBER:
                if _alt==1:
                    if self._parseListeners is not None:
                        self.triggerExitRuleEvent()
                    _prevctx = localctx
                    self.state = 271
                    self._errHandler.sync(self)
                    la_ = self._interp.adaptivePredict(self._input,19,self._ctx)
                    if la_ == 1:
                        localctx = MCParser.Exp5Context(self, _parentctx, _parentState)
                        self.pushNewRecursionContext(localctx, _startState, self.RULE_exp5)
                        self.state = 265
                        if not self.precpred(self._ctx, 3):
                            from antlr4.error.Errors import FailedPredicateException
                            raise FailedPredicateException(self, "self.precpred(self._ctx, 3)")
                        self.state = 266
                        self.match(MCParser.ADD)
                        self.state = 267
                        self.exp6(0)
                        pass

                    elif la_ == 2:
                        localctx = MCParser.Exp5Context(self, _parentctx, _parentState)
                        self.pushNewRecursionContext(localctx, _startState, self.RULE_exp5)
                        self.state = 268
                        if not self.precpred(self._ctx, 2):
                            from antlr4.error.Errors import FailedPredicateException
                            raise FailedPredicateException(self, "self.precpred(self._ctx, 2)")
                        self.state = 269
                        self.match(MCParser.SUB)
                        self.state = 270
                        self.exp6(0)
                        pass

             
                self.state = 275
                self._errHandler.sync(self)
                _alt = self._interp.adaptivePredict(self._input,20,self._ctx)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.unrollRecursionContexts(_parentctx)
        return localctx

    class Exp6Context(ParserRuleContext):

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def exp7(self):
            return self.getTypedRuleContext(MCParser.Exp7Context,0)


        def exp6(self):
            return self.getTypedRuleContext(MCParser.Exp6Context,0)


        def DIV(self):
            return self.getToken(MCParser.DIV, 0)

        def MUL(self):
            return self.getToken(MCParser.MUL, 0)

        def MOD(self):
            return self.getToken(MCParser.MOD, 0)

        def getRuleIndex(self):
            return MCParser.RULE_exp6



    def exp6(self, _p:int=0):
        _parentctx = self._ctx
        _parentState = self.state
        localctx = MCParser.Exp6Context(self, self._ctx, _parentState)
        _prevctx = localctx
        _startState = 58
        self.enterRecursionRule(localctx, 58, self.RULE_exp6, _p)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 277
            self.exp7()
            self._ctx.stop = self._input.LT(-1)
            self.state = 290
            self._errHandler.sync(self)
            _alt = self._interp.adaptivePredict(self._input,22,self._ctx)
            while _alt!=2 and _alt!=ATN.INVALID_ALT_NUMBER:
                if _alt==1:
                    if self._parseListeners is not None:
                        self.triggerExitRuleEvent()
                    _prevctx = localctx
                    self.state = 288
                    self._errHandler.sync(self)
                    la_ = self._interp.adaptivePredict(self._input,21,self._ctx)
                    if la_ == 1:
                        localctx = MCParser.Exp6Context(self, _parentctx, _parentState)
                        self.pushNewRecursionContext(localctx, _startState, self.RULE_exp6)
                        self.state = 279
                        if not self.precpred(self._ctx, 4):
                            from antlr4.error.Errors import FailedPredicateException
                            raise FailedPredicateException(self, "self.precpred(self._ctx, 4)")
                        self.state = 280
                        self.match(MCParser.DIV)
                        self.state = 281
                        self.exp7()
                        pass

                    elif la_ == 2:
                        localctx = MCParser.Exp6Context(self, _parentctx, _parentState)
                        self.pushNewRecursionContext(localctx, _startState, self.RULE_exp6)
                        self.state = 282
                        if not self.precpred(self._ctx, 3):
                            from antlr4.error.Errors import FailedPredicateException
                            raise FailedPredicateException(self, "self.precpred(self._ctx, 3)")
                        self.state = 283
                        self.match(MCParser.MUL)
                        self.state = 284
                        self.exp7()
                        pass

                    elif la_ == 3:
                        localctx = MCParser.Exp6Context(self, _parentctx, _parentState)
                        self.pushNewRecursionContext(localctx, _startState, self.RULE_exp6)
                        self.state = 285
                        if not self.precpred(self._ctx, 2):
                            from antlr4.error.Errors import FailedPredicateException
                            raise FailedPredicateException(self, "self.precpred(self._ctx, 2)")
                        self.state = 286
                        self.match(MCParser.MOD)
                        self.state = 287
                        self.exp7()
                        pass

             
                self.state = 292
                self._errHandler.sync(self)
                _alt = self._interp.adaptivePredict(self._input,22,self._ctx)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.unrollRecursionContexts(_parentctx)
        return localctx

    class Exp7Context(ParserRuleContext):

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def SUB(self):
            return self.getToken(MCParser.SUB, 0)

        def exp7(self):
            return self.getTypedRuleContext(MCParser.Exp7Context,0)


        def NOT(self):
            return self.getToken(MCParser.NOT, 0)

        def exp8(self):
            return self.getTypedRuleContext(MCParser.Exp8Context,0)


        def getRuleIndex(self):
            return MCParser.RULE_exp7




    def exp7(self):

        localctx = MCParser.Exp7Context(self, self._ctx, self.state)
        self.enterRule(localctx, 60, self.RULE_exp7)
        try:
            self.state = 298
            self._errHandler.sync(self)
            token = self._input.LA(1)
            if token in [MCParser.SUB]:
                self.enterOuterAlt(localctx, 1)
                self.state = 293
                self.match(MCParser.SUB)
                self.state = 294
                self.exp7()
                pass
            elif token in [MCParser.NOT]:
                self.enterOuterAlt(localctx, 2)
                self.state = 295
                self.match(MCParser.NOT)
                self.state = 296
                self.exp7()
                pass
            elif token in [MCParser.LB, MCParser.BOOLLIT, MCParser.INTLIT, MCParser.FLOATLIT, MCParser.ID, MCParser.STRINGLIT]:
                self.enterOuterAlt(localctx, 3)
                self.state = 297
                self.exp8()
                pass
            else:
                raise NoViableAltException(self)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx

    class Exp8Context(ParserRuleContext):

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def operand(self):
            return self.getTypedRuleContext(MCParser.OperandContext,0)


        def LS(self):
            return self.getToken(MCParser.LS, 0)

        def exp(self):
            return self.getTypedRuleContext(MCParser.ExpContext,0)


        def RS(self):
            return self.getToken(MCParser.RS, 0)

        def getRuleIndex(self):
            return MCParser.RULE_exp8




    def exp8(self):

        localctx = MCParser.Exp8Context(self, self._ctx, self.state)
        self.enterRule(localctx, 62, self.RULE_exp8)
        try:
            self.state = 306
            self._errHandler.sync(self)
            la_ = self._interp.adaptivePredict(self._input,24,self._ctx)
            if la_ == 1:
                self.enterOuterAlt(localctx, 1)
                self.state = 300
                self.operand()
                self.state = 301
                self.match(MCParser.LS)
                self.state = 302
                self.exp()
                self.state = 303
                self.match(MCParser.RS)
                pass

            elif la_ == 2:
                self.enterOuterAlt(localctx, 2)
                self.state = 305
                self.operand()
                pass


        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx

    class OperandContext(ParserRuleContext):

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def LB(self):
            return self.getToken(MCParser.LB, 0)

        def exp(self):
            return self.getTypedRuleContext(MCParser.ExpContext,0)


        def RB(self):
            return self.getToken(MCParser.RB, 0)

        def funcall(self):
            return self.getTypedRuleContext(MCParser.FuncallContext,0)


        def INTLIT(self):
            return self.getToken(MCParser.INTLIT, 0)

        def FLOATLIT(self):
            return self.getToken(MCParser.FLOATLIT, 0)

        def BOOLLIT(self):
            return self.getToken(MCParser.BOOLLIT, 0)

        def STRINGLIT(self):
            return self.getToken(MCParser.STRINGLIT, 0)

        def ID(self):
            return self.getToken(MCParser.ID, 0)

        def getRuleIndex(self):
            return MCParser.RULE_operand




    def operand(self):

        localctx = MCParser.OperandContext(self, self._ctx, self.state)
        self.enterRule(localctx, 64, self.RULE_operand)
        try:
            self.state = 318
            self._errHandler.sync(self)
            la_ = self._interp.adaptivePredict(self._input,25,self._ctx)
            if la_ == 1:
                self.enterOuterAlt(localctx, 1)
                self.state = 308
                self.match(MCParser.LB)
                self.state = 309
                self.exp()
                self.state = 310
                self.match(MCParser.RB)
                pass

            elif la_ == 2:
                self.enterOuterAlt(localctx, 2)
                self.state = 312
                self.funcall()
                pass

            elif la_ == 3:
                self.enterOuterAlt(localctx, 3)
                self.state = 313
                self.match(MCParser.INTLIT)
                pass

            elif la_ == 4:
                self.enterOuterAlt(localctx, 4)
                self.state = 314
                self.match(MCParser.FLOATLIT)
                pass

            elif la_ == 5:
                self.enterOuterAlt(localctx, 5)
                self.state = 315
                self.match(MCParser.BOOLLIT)
                pass

            elif la_ == 6:
                self.enterOuterAlt(localctx, 6)
                self.state = 316
                self.match(MCParser.STRINGLIT)
                pass

            elif la_ == 7:
                self.enterOuterAlt(localctx, 7)
                self.state = 317
                self.match(MCParser.ID)
                pass


        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx

    class FuncallContext(ParserRuleContext):

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def ID(self):
            return self.getToken(MCParser.ID, 0)

        def LB(self):
            return self.getToken(MCParser.LB, 0)

        def explist(self):
            return self.getTypedRuleContext(MCParser.ExplistContext,0)


        def RB(self):
            return self.getToken(MCParser.RB, 0)

        def getRuleIndex(self):
            return MCParser.RULE_funcall




    def funcall(self):

        localctx = MCParser.FuncallContext(self, self._ctx, self.state)
        self.enterRule(localctx, 66, self.RULE_funcall)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 320
            self.match(MCParser.ID)
            self.state = 321
            self.match(MCParser.LB)
            self.state = 322
            self.explist()
            self.state = 323
            self.match(MCParser.RB)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx

    class ExplistContext(ParserRuleContext):

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def exp(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(MCParser.ExpContext)
            else:
                return self.getTypedRuleContext(MCParser.ExpContext,i)


        def CM(self, i:int=None):
            if i is None:
                return self.getTokens(MCParser.CM)
            else:
                return self.getToken(MCParser.CM, i)

        def getRuleIndex(self):
            return MCParser.RULE_explist




    def explist(self):

        localctx = MCParser.ExplistContext(self, self._ctx, self.state)
        self.enterRule(localctx, 68, self.RULE_explist)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 333
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if (((_la) & ~0x3f) == 0 and ((1 << _la) & ((1 << MCParser.LB) | (1 << MCParser.SUB) | (1 << MCParser.NOT) | (1 << MCParser.BOOLLIT) | (1 << MCParser.INTLIT) | (1 << MCParser.FLOATLIT) | (1 << MCParser.ID) | (1 << MCParser.STRINGLIT))) != 0):
                self.state = 325
                self.exp()
                self.state = 330
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                while _la==MCParser.CM:
                    self.state = 326
                    self.match(MCParser.CM)
                    self.state = 327
                    self.exp()
                    self.state = 332
                    self._errHandler.sync(self)
                    _la = self._input.LA(1)



        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx



    def sempred(self, localctx:RuleContext, ruleIndex:int, predIndex:int):
        if self._predicates == None:
            self._predicates = dict()
        self._predicates[24] = self.exp1_sempred
        self._predicates[25] = self.exp2_sempred
        self._predicates[28] = self.exp5_sempred
        self._predicates[29] = self.exp6_sempred
        pred = self._predicates.get(ruleIndex, None)
        if pred is None:
            raise Exception("No predicate with index:" + str(ruleIndex))
        else:
            return pred(localctx, predIndex)

    def exp1_sempred(self, localctx:Exp1Context, predIndex:int):
            if predIndex == 0:
                return self.precpred(self._ctx, 2)
         

    def exp2_sempred(self, localctx:Exp2Context, predIndex:int):
            if predIndex == 1:
                return self.precpred(self._ctx, 2)
         

    def exp5_sempred(self, localctx:Exp5Context, predIndex:int):
            if predIndex == 2:
                return self.precpred(self._ctx, 3)
         

            if predIndex == 3:
                return self.precpred(self._ctx, 2)
         

    def exp6_sempred(self, localctx:Exp6Context, predIndex:int):
            if predIndex == 4:
                return self.precpred(self._ctx, 4)
         

            if predIndex == 5:
                return self.precpred(self._ctx, 3)
         

            if predIndex == 6:
                return self.precpred(self._ctx, 2)
         




