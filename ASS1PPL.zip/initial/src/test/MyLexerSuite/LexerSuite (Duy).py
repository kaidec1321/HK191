import unittest
from TestUtils import TestLexer

class LexerSuite(unittest.TestCase):
      
    def test_lower_identifier(self):
        """test identifiers"""
        self.assertTrue(TestLexer.checkLexeme("abc","abc,<EOF>",101))

    def test_lower_upper_id(self):
        """test id"""
        self.assertTrue(TestLexer.checkLexeme("aCBbdc","aCBbdc,<EOF>",102))

    def test_wrong_token(self):
        """test error token"""
        self.assertTrue(TestLexer.checkLexeme("aA?sVN","aA,Error Token ?",103))

    def test_integer(self):
        """test integers"""
        self.assertTrue(TestLexer.checkLexeme("123a123","123,a123,<EOF>",104))

    def test_unclosed_string(self):
        """test unclose string"""
        self.assertTrue(TestLexer.checkLexeme(""" "le anh duy""","Unclosed String: le anh duy",105))
        
    def test_string(self):
        """test string"""
        self.assertTrue(TestLexer.checkLexeme(""" "le anh duy \\\"" ""","""le anh duy \\\",<EOF>""",106))

    def test_float0(self):
        """test float"""
        self.assertTrue(TestLexer.checkLexeme("-e-12","-,e,-,12,<EOF>", 107))

    def test_float1(self):
        """test float1"""
        self.assertTrue(TestLexer.checkLexeme("128e-42","128e-42,<EOF>", 108))
    
    def test_id(self):
        """test identifier"""
        self.assertTrue(TestLexer.checkLexeme("_\\babc","_,Error Token \\", 109))
    
    def test_illegal_escape(self):
        """test illegal escape"""
        self.assertTrue(TestLexer.checkLexeme(""" "le \\i anh duy ""","Illegal Escape In String: le \\i",110))
    
    def test_comment_line(self):
        """test comment line"""
        self.assertTrue(TestLexer.checkLexeme("//le anh duy BK \n le anh duy","le,anh,duy,<EOF>",111))
    
    def test_float2(self):
        """test float2"""
        self.assertTrue(TestLexer.checkLexeme("0.33E-3","0.33E-3,<EOF>", 112))

    def test_illegal_escape1(self):
        """test illegal escape 1"""
        self.assertTrue(TestLexer.checkLexeme(""" "\\a le anh duy ""","Illegal Escape In String: \\a",113))
    
    def test_unclosed_string1(self):
        """test unclosed string1"""
        self.assertTrue(TestLexer.checkLexeme(""" "le anh duy? ""","Unclosed String: le anh duy? ",114))
    
    def test_id1(self):
        """test id1"""
        self.assertTrue(TestLexer.checkLexeme("_\nabc","_,abc,<EOF>",115))
    
    def test_id2(self):
        """test id2"""
        self.assertTrue(TestLexer.checkLexeme(" \t\n","<EOF>",116))
    
    def test_illegal_escape2(self):
        """test illegal escape 2"""
        self.assertTrue(TestLexer.checkLexeme(""" "\\a le anh \\y duy" ""","""Illegal Escape In String: \\a""",117))
    
    def test_wrong_token1(self):
        """test error token1"""
        self.assertTrue(TestLexer.checkLexeme("duy's book","duy,Error Token '",118))
    
    def test_integer1(self):
        """test integer1"""
        self.assertTrue(TestLexer.checkLexeme("-123","-,123,<EOF>",119))

    def test_float3(self):
        """test float3"""
        self.assertTrue(TestLexer.checkLexeme("12e8","12e8,<EOF>",120))
    
    def test_float4(self):
        """test float4"""
        self.assertTrue(TestLexer.checkLexeme(".1E2",".1E2,<EOF>",121))

    def test_float5(self):
        """test float5"""
        self.assertTrue(TestLexer.checkLexeme("1e12","1e12,<EOF>",122))

    def test_float6(self):
        """test float6"""
        self.assertTrue(TestLexer.checkLexeme(".1",".1,<EOF>",123))
    
    def test_float7(self):
        """test float7"""
        self.assertTrue(TestLexer.checkLexeme("123EFG","123,EFG,<EOF>",124))

    def test_string1(self):
        """test string1"""
        self.assertTrue(TestLexer.checkLexeme(""" "sinh vien BK\\n" ""","""sinh vien BK\\n,<EOF>""",125))

    def test_bool(self):
        """test bool"""
        self.assertTrue(TestLexer.checkLexeme("true","true,<EOF>",126))
    
    def test_float8(self):
        """test float8"""
        self.assertTrue(TestLexer.checkLexeme("1.","1.,<EOF>",127))
    
    def test_string2(self):
        """test string2"""
        self.assertTrue(TestLexer.checkLexeme(""" "a\\tbc" ""","""a\\tbc,<EOF>""",128))

    def test_integer2(self):
        """test integer2"""
        self.assertTrue(TestLexer.checkLexeme("0001","0001,<EOF>",129))
    
    def test_illegal_escape3(self):
        """test illegal escape3"""
        self.assertTrue(TestLexer.checkLexeme(""" "abc\\abc" ""","""Illegal Escape In String: abc\\a""",130))

    def test_bool1(self):
        """test bool1"""
        self.assertTrue(TestLexer.checkLexeme("true false", "true,false,<EOF>", 131))

    def test_keyword(self):
        """test keyword"""
        self.assertTrue(TestLexer.checkLexeme("for","for,<EOF>",132))

    def test_comment_line1(self):
        """test comment line1"""
        self.assertTrue(TestLexer.checkLexeme("// /*abc*/","<EOF>",133))
    
    def test_keyword1(self):
        """test keyword1"""
        self.assertTrue(TestLexer.checkLexeme("dowhile","dowhile,<EOF>",134))
    
    def test_keyword2(self):
        """test keyword2"""
        self.assertTrue(TestLexer.checkLexeme("do while","do,while,<EOF>",135))

    def test_wrong_token2(self):
        """test error token 2"""
        self.assertTrue(TestLexer.checkLexeme("do while","do,while,<EOF>",136))

    def test_string3(self):
        """test string3"""
        self.assertTrue(TestLexer.checkLexeme(""" "ab\\" ""","""Unclosed String: ab\\" """,137))
    
    def test_bool2(self):
        """test bool2"""
        self.assertTrue(TestLexer.checkLexeme("do{}while(true)","do,{,},while,(,true,),<EOF>",138))

    def test_string4(self):
        """test string4"""
        self.assertTrue(TestLexer.checkLexeme(""" "ab\\b" ""","""ab\\b,<EOF>""",139))
    
    def test_string5(self):
        """test string5"""
        self.assertTrue(TestLexer.checkLexeme(""" "\\ab" ""","""Illegal Escape In String: \\a""",140))

    def test_string6(self):
        """test string6"""
        self.assertTrue(TestLexer.checkLexeme(""" "abc\\iabc" ""","""Illegal Escape In String: abc\\i""",141))
    
    def test_string7(self):
        """test string7"""
        self.assertTrue(TestLexer.checkLexeme(""" "abc\\tabc" ""","""abc\\tabc,<EOF>""",142))
    
    def test_string8(self):
        """test string8"""
        self.assertTrue(TestLexer.checkLexeme(""" "abc"adc" ""","""abc,adc,Unclosed String:  """,143))
    
    def test_string9(self):
        """test string9"""
        self.assertTrue(TestLexer.checkLexeme(""" "123a\\n123" ""","""123a\\n123,<EOF>""",144))

    def test_unclose_string2(self):
        """test unclose string2"""
        self.assertTrue(TestLexer.checkLexeme(""" "123a\\n123 ""","""Unclosed String: 123a\\n123 """,145))
        
    def test_illegal_escape4(self):
        """test illegal escape4"""
        self.assertTrue(TestLexer.checkLexeme(""" 123 "123a\\m123" ""","""123,Illegal Escape In String: 123a\\m""",146))
    
    def test_double_slash(self):
        """test double slash"""
        self.assertTrue(TestLexer.checkLexeme(""" 123 "123a\\\\123" ""","""123,123a\\\\123,<EOF>""",147))

    def test_wrong_token3(self):
        self.assertTrue(TestLexer.checkLexeme("abc_123?1E-12","abc_123,Error Token ?",148))

    def test_comment_block(self):
        """test comment block"""
        self.assertTrue(TestLexer.checkLexeme("""/*This a comment
                                                Another comment*/
                                                //Another comment again""", "<EOF>", 149))
    
    def test_wrong_token4(self):
        """test error token4"""
        self.assertTrue(TestLexer.checkLexeme("^123","Error Token ^",150))

    def test_id3(self):
        """test id3"""
        self.assertTrue(TestLexer.checkLexeme("int i,j,k,true","int,i,,,j,,,k,,,true,<EOF>",151))
    
    def test_whitespace(self):
        """test whitespace"""
        self.assertTrue(TestLexer.checkLexeme("abc\r\nabc","abc,abc,<EOF>",152))
    
    def test_whitespace1(self):
        """test whitespace1"""
        self.assertTrue(TestLexer.checkLexeme("aBC\faBC","aBC,aBC,<EOF>", 153))
    
    def test_whitespace2(self):
        """test whitespace2"""
        self.assertTrue(TestLexer.checkLexeme("aBCD\n\taBCD","aBCD,aBCD,<EOF>",154))
    
    def test_id4(self):
        """test id4"""
        self.assertTrue(TestLexer.checkLexeme("ABC","ABC,<EOF>",155))

    def test_wrong_token6(self):
        """test error token6"""
        self.assertTrue(TestLexer.checkLexeme("abc\abc", "abc,Error Token \a",156))
    
    def test_wrong_token7(self):
        """test error token7"""
        self.assertTrue(TestLexer.checkLexeme("abc\\bc", "abc,Error Token \\",157))

    def test_unclose_string3(self):
        """test unclose string 3"""
        self.assertTrue(TestLexer.checkLexeme(""" "abc "def"ghi""","""abc ,def,Unclosed String: ghi""",158))

    def test_unclose_string4(self):
        """test unclose string 4"""
        self.assertTrue(TestLexer.checkLexeme(""" "abc"def" ""","""abc,def,Unclosed String:  """,159))
    
    def test_unclose_string5(self):
        """test unclose string 5"""
        self.assertTrue(TestLexer.checkLexeme(""" "abc
                                                    "def" ""","""Unclosed String: abc""",160))
    def test_string10(self):
        """test string 10"""
        self.assertTrue(TestLexer.checkLexeme(""" "abc\\ " ""","""Illegal Escape In String: abc\\ """,161))
                            
    def test_string11(self):
        """test string 11"""
        self.assertTrue(TestLexer.checkLexeme(""" "abc\\" ""","""Unclosed String: abc\\" """,162))

    def test_string12(self):
        """test string 12"""
        self.assertTrue(TestLexer.checkLexeme(""" "abc\\"" ""","""abc\\",<EOF>""",163))

    def test_string13(self):
        """test string 13"""
        self.assertTrue(TestLexer.checkLexeme(""" "ab\\\\c" ""","""ab\\\\c,<EOF>""",164))

    def test_add_operator(self):
        """test add operator"""
        self.assertTrue(TestLexer.checkLexeme("a+b","a,+,b,<EOF>",165))

    def test_sub_operator(self):
        """test sub operator"""
        self.assertTrue(TestLexer.checkLexeme("a-b","a,-,b,<EOF>",166))

    def test_mul_operator(self):
        """test mul operator"""
        self.assertTrue(TestLexer.checkLexeme("a*b","a,*,b,<EOF>",167))
   
    def test_div_operator(self):
        """test div operator"""
        self.assertTrue(TestLexer.checkLexeme("a/b","a,/,b,<EOF>",168))

    def test_bool_operator(self):
        """test bool operator"""
        self.assertTrue(TestLexer.checkLexeme("!a && b || c","!,a,&&,b,||,c,<EOF>",169))

    def test_comparative_op(self):
        """test comparative op"""
        self.assertTrue(TestLexer.checkLexeme("!a && b || c","!,a,&&,b,||,c,<EOF>",170))

    def test_string14(self):
        """test string 14"""
        self.assertTrue(TestLexer.checkLexeme(""" " " """,""" ,<EOF>""",171))

    def test_string15(self):
        """test string 15"""
        self.assertTrue(TestLexer.checkLexeme(""" "" """,""",<EOF>""",172))
    
    def test_op(self):
        """test op"""
        self.assertTrue(TestLexer.checkLexeme("===","==,=,<EOF>",173))

    def test_op1(self):
        """test op1"""
        self.assertTrue(TestLexer.checkLexeme("<==>>=","<=,=,>,>=,<EOF>",174))

    def test_op2(self):
        """test op2"""
        self.assertTrue(TestLexer.checkLexeme("<==>>=","<=,=,>,>=,<EOF>",175))

    def test_complex(self):
        """test complex"""
        self.assertTrue(TestLexer.checkLexeme(""" 1234.1.1.1e-123 \n"ab\\n" //I'm a comment\n abc ""","""1234.1,.1,.1e-123,ab\\n,abc,<EOF>""",176))

    def test_float9(self):
        """test float 9"""
        self.assertTrue(TestLexer.checkLexeme("1.e-123","1.e-123,<EOF>",177))
    
    def test_comment_line2(self):
        """test comment line 2"""
        self.assertTrue(TestLexer.checkLexeme("""//Line comment /* Comment
                                                block */""","block,*,/,<EOF>",178))

    def test_comment_block1(self):
        """test comment block1"""
        self.assertTrue(TestLexer.checkLexeme("""/*A comment block //Not a comment line 
                                                    Comment block */""","""<EOF>""",179))

    def test_id5(self):
        """test id 5"""
        self.assertTrue(TestLexer.checkLexeme("continueifdowhile","continueifdowhile,<EOF>",180))

    def test_float10(self):
        """test float 10"""
        self.assertTrue(TestLexer.checkLexeme("123e+12","123,e,+,12,<EOF>",181))

    def test_wrong_token8(self):
        """test error token 8"""
        self.assertTrue(TestLexer.checkLexeme("123..e-12","123.,Error Token .",182))

    def test_op3(self):
        """test op3"""
        self.assertTrue(TestLexer.checkLexeme("!!==!=!=","!,!=,=,!=,!=,<EOF>",183))

    def test_string16(self):
        """test string 16"""
        self.assertTrue(TestLexer.checkLexeme(""" "!@#$'abcde123\\\\3" ""","""!@#$'abcde123\\\\3,<EOF>""",184))

    def test_unclose_string6(self):
        """test unclose string 6"""
        self.assertTrue(TestLexer.checkLexeme(""" " ""","""Unclosed String:  """,185))

    def test_id6(self):
        """test id 6"""
        self.assertTrue(TestLexer.checkLexeme("ifif","ifif,<EOF>",186))

    def test_float11(self):
        """test float 11"""
        self.assertTrue(TestLexer.checkLexeme(".0000",".0000,<EOF>",187))
    
    def test_keyword3(self):
        """test keyword 3"""
        self.assertTrue(TestLexer.checkLexeme("booLean For iF", "booLean,For,iF,<EOF>",188))

    def test_comment_block2(self):
        """test comment block 2"""
        self.assertTrue(TestLexer.checkLexeme("/**/", "<EOF>",189))

    def test_bool3(self):
        """test bool 3"""
        self.assertTrue(TestLexer.checkLexeme("boolean b = false","boolean,b,=,false,<EOF>",190))

    def test_wrong_token9(self):
        """test error token 9"""
        self.assertTrue(TestLexer.checkLexeme("abc&cde","abc,Error Token &",191))

    def test_unclose_string7(self):
        """test unclose string 7"""
        self.assertTrue(TestLexer.checkLexeme(""" "" "" " """,""",,Unclosed String:  """,192))

    def test_op4(self):
        """test op4"""
        self.assertTrue(TestLexer.checkLexeme("a%b%c = d","a,%,b,%,c,=,d,<EOF>",193))

    def test_illegal_escape5(self):
        """test illegal escape 5"""
        self.assertTrue(TestLexer.checkLexeme(""" "abc\\?edf" ""","""Illegal Escape In String: abc\\?""",194))

    def test_id7(self):
        """test id 7"""
        self.assertTrue(TestLexer.checkLexeme("abcd1e-12","abcd1e,-,12,<EOF>",195))

    def test_id8(self):
        """test id 8"""
        self.assertTrue(TestLexer.checkLexeme("abcd.1e-12","abcd,.1e-12,<EOF>",196))

    def test_float12(self):
        """test float 12"""
        self.assertTrue(TestLexer.checkLexeme("1234.abcd","1234.,abcd,<EOF>",197))

    def test_id9(self):
        """test id 9"""
        self.assertTrue(TestLexer.checkLexeme("____","____,<EOF>",198))

    def test_float13(self):
        """test float 13"""
        self.assertTrue(TestLexer.checkLexeme("2.1.2.1e-12","2.1,.2,.1e-12,<EOF>",199))

    def test_string17(self):
        """test string 17"""
        self.assertTrue(TestLexer.checkLexeme(""" "leanhduy"abc.""","""leanhduy,abc,Error Token .""",200))
