import unittest
from TestUtils import TestLexer


class LexerSuite(unittest.TestCase):
    def test_identifier(self):
        """test identifiers"""
        self.assertTrue(TestLexer.checkLexeme("abc", "abc,<EOF>", 100))
    def test_identifier1(self):
        self.assertTrue(TestLexer.checkLexeme("aCBbdc", "aCBbdc,<EOF>", 101))
    def test_identifier2(self):
        self.assertTrue(TestLexer.checkLexeme("aAsVN", "aAsVN,<EOF>", 102))
    def test_identifier3(self):
        self.assertTrue(TestLexer.checkLexeme("aAsVN1", "aAsVN1,<EOF>", 103))
    def test_identifier4(self):
        self.assertTrue(TestLexer.checkLexeme("_aAsVN", "_aAsVN,<EOF>", 104))
    def test_identifier5(self):
        self.assertTrue(TestLexer.checkLexeme("a_AsVN", "a_AsVN,<EOF>", 105))
    def test_identifier6(self):
        self.assertTrue(TestLexer.checkLexeme("aAsVN_", "aAsVN_,<EOF>", 106))
    def test_identifier7(self):
        self.assertTrue(
            TestLexer.checkLexeme("abc123 123abc", "abc123,123,abc,<EOF>", 107)
        )
    def test_identifier8(self):
        self.assertTrue(TestLexer.checkLexeme("_abc//aAsVN", "_abc,<EOF>", 108))
    def test_identifier9(self):
        self.assertTrue(TestLexer.checkLexeme("""xaz cmt""", "xaz,cmt,<EOF>", 109))
    def test_identifier10(self):
        self.assertTrue(TestLexer.checkLexeme("foo bar", "foo,bar,<EOF>", 110))
    def test_identifier11(self):
        self.assertTrue(TestLexer.checkLexeme("___", "___,<EOF>", 111))
    def test_identifier12(self):
        self.assertTrue(TestLexer.checkLexeme("_", "_,<EOF>", 112))
    def test_identifier13(self):
        self.assertTrue(TestLexer.checkLexeme("_a_", "_a_,<EOF>", 113))

    def test_integer(self):
        """test integers"""
        self.assertTrue(TestLexer.checkLexeme("123a123", "123,a123,<EOF>", 114))
    def test_integer1(self):
        self.assertTrue(TestLexer.checkLexeme("0123", "0123,<EOF>", 115))
    def test_integer2(self):
        self.assertTrue(TestLexer.checkLexeme("00123", "00123,<EOF>", 116))
    def test_integer3(self):
        self.assertTrue(TestLexer.checkLexeme("0", "0,<EOF>", 117))

    def test_float(self):
        """test float"""
        self.assertTrue(TestLexer.checkLexeme("123E-1", "123E-1,<EOF>", 118))
    def test_float1(self):
        self.assertTrue(TestLexer.checkLexeme("123E1", "123E1,<EOF>", 119))
    def test_float2(self):
        self.assertTrue(TestLexer.checkLexeme("12.3E-1", "12.3E-1,<EOF>", 120))
    def test_float3(self):
        self.assertTrue(TestLexer.checkLexeme(".123E-1", ".123E-1,<EOF>", 121))
    def test_float4(self):
        self.assertTrue(TestLexer.checkLexeme("123.E-1", "123.E-1,<EOF>", 122))
    def test_float5(self):
        self.assertTrue(TestLexer.checkLexeme("123E-1", "123E-1,<EOF>", 123))
    def test_float6(self):
        self.assertTrue(TestLexer.checkLexeme("123.", "123.,<EOF>", 124))
    def test_float7(self):
        self.assertTrue(TestLexer.checkLexeme(".123", ".123,<EOF>", 125))
    def test_float8(self):
        self.assertTrue(TestLexer.checkLexeme("1.123", "1.123,<EOF>", 126))
    def test_float9(self):
        self.assertTrue(TestLexer.checkLexeme("123.", "123.,<EOF>", 127))
    def test_float10(self):
        self.assertTrue(TestLexer.checkLexeme("123e-1", "123e-1,<EOF>", 128))
    def test_float11(self):
        self.assertTrue(TestLexer.checkLexeme("123e1", "123e1,<EOF>", 129))
    def test_float12(self):
        self.assertTrue(TestLexer.checkLexeme("12.3e-1", "12.3e-1,<EOF>", 130))
    def test_float13(self):
        self.assertTrue(TestLexer.checkLexeme("123E", "123,E,<EOF>", 131))
    def test_float14(self):
        self.assertTrue(TestLexer.checkLexeme("E1", "E1,<EOF>", 132))
    def test_float15(self):
        self.assertTrue(TestLexer.checkLexeme(".3e-", ".3,e,-,<EOF>", 133))

    def test_string(self):
        """test string literals"""
        self.assertTrue(TestLexer.checkLexeme('"abc"', "abc,<EOF>", 134))
    def test_string1(self):
        self.assertTrue(TestLexer.checkLexeme('"abc\\n"', "abc\\n,<EOF>", 135))
    def test_string2(self):
        self.assertTrue(TestLexer.checkLexeme('"ab\\n\\tc"', "ab\\n\\tc,<EOF>", 136))
    def test_string3(self):
        self.assertTrue(TestLexer.checkLexeme('"ab\\nc"', "ab\\nc,<EOF>", 137))
    def test_string4(self):
        self.assertTrue(
            TestLexer.checkLexeme(
                """
        ""
        """,
                ",<EOF>",
                138,
            )
        )
    def test_string5(self):
        self.assertTrue(
            TestLexer.checkLexeme(
                """
        "\\u4678"
        """,
                "Illegal Escape In String: \\u",
                139,
            )
        )
    def test_string6(self):
        self.assertTrue(
            TestLexer.checkLexeme(
                """
        "abc\\\\nabc"
        """,
                "abc\\\\nabc,<EOF>",
                140,
            )
        )
    def test_string7(self):
        self.assertTrue(
            TestLexer.checkLexeme(
                """
        r"abc_c1+-~"
        """,
                "r,abc_c1+-~,<EOF>",
                141,
            )
        )
    def test_string8(self):
        self.assertTrue(
            TestLexer.checkLexeme(
                """
        rabc_c1+-~"
        """,
                "rabc_c1,+,-,Error Token ~",
                142,
            )
        )
    def test_string9(self):
        self.assertTrue(
            TestLexer.checkLexeme(
                """
        r""a"bc_"c"1+"-"~"
        """,
                "r,,a,bc_,c,1+,-,~,<EOF>",
                143,
            )
        )
    def test_string10(self):
        self.assertTrue(
            TestLexer.checkLexeme(
                """
        "ab\\""
        """,
                'ab\\",<EOF>',
                144,
            )
        )

    def test_comment(self):
        """test comment"""
        self.assertTrue(TestLexer.checkLexeme("//abc", "<EOF>", 145))
    def test_comment1(self):
        self.assertTrue(TestLexer.checkLexeme("///*abc*/", "<EOF>", 146))
    def test_comment2(self):
        self.assertTrue(TestLexer.checkLexeme("/*//abc*/", "<EOF>", 147))
    def test_comment3(self):
        self.assertTrue(TestLexer.checkLexeme("//a//bc", "<EOF>", 148))
    def test_comment4(self):
        self.assertTrue(TestLexer.checkLexeme("//abc\\\n/*abc*/", "<EOF>", 149))
    def test_comment5(self):
        self.assertTrue(TestLexer.checkLexeme("/*a\\\nb\\\tc*/", "<EOF>", 150))
    def test_comment6(self):
        self.assertTrue(TestLexer.checkLexeme("/*/*abc*/*/", "*,/,<EOF>", 151))
    def test_comment7(self):
        self.assertTrue(
            TestLexer.checkLexeme(
                """
        ///* abc
        */
        """,
                "*,/,<EOF>",
                152,
            )
        )
    def test_comment8(self):
        self.assertTrue(
            TestLexer.checkLexeme(
                """
        /* abc
        */
        """,
                "<EOF>",
                153,
            )
        )
    def test_comment9(self):
        self.assertTrue(
            TestLexer.checkLexeme(
                """
        /* abc
        //*/
        */
        """,
                "*,/,<EOF>",
                154,
            )
        )
    def test_comment10(self):
        self.assertTrue(
            TestLexer.checkLexeme(
                """
        b//a 
        a//b 
        """,
                "b,a,<EOF>",
                155,
            )
        )

    def test_error(self):
        """test error raise"""
        self.assertTrue(
            TestLexer.checkLexeme(
                """
        "abc"
        "abc\."
        """,
                "abc,Illegal Escape In String: abc\.",
                156,
            )
        )
    def test_error1(self):
        self.assertTrue(
            TestLexer.checkLexeme(
                """
        @
        """,
                "Error Token @",
                157,
            )
        )
    def test_error2(self):
        self.assertTrue(
            TestLexer.checkLexeme(
                """
        abcdas"
        """,
                'abcdas,Unclosed String: ',
                158,
            )
        )
    def test_error3(self):
        self.assertTrue(
            TestLexer.checkLexeme(
                """
        */
        """,
                "*,/,<EOF>",
                159,
            )
        )
    def test_error4(self):
        self.assertTrue(
            TestLexer.checkLexeme(
                """
        !2abc22
        """,
                "!,2,abc22,<EOF>",
                160,
            )
        )
    def test_error5(self):
        self.assertTrue(
            TestLexer.checkLexeme(
                """
        aido@noinaodo
        """,
                "aido,Error Token @",
                161,
            )
        )
    def test_error6(self):
        self.assertTrue(
            TestLexer.checkLexeme(
                """
        !2.abc22
        """,
                "!,2.,abc22,<EOF>",
                162,
            )
        )
    def test_error7(self):
        self.assertTrue(
            TestLexer.checkLexeme(
                """
        !2.abc2.2
        """,
                "!,2.,abc2,.2,<EOF>",
                163,
            )
        )
    def test_error8(self):
        self.assertTrue(
            TestLexer.checkLexeme(
                """
        !2.abc2..2
        """,
                "!,2.,abc2,Error Token .",
                164,
            )
        )

    def test_keyword(self):
        """test keyword"""
        self.assertTrue(TestLexer.checkLexeme("int float", "int,float,<EOF>", 165))
    def test_keyword1(self):
        self.assertTrue(
            TestLexer.checkLexeme(
                "boolean return string continue",
                "boolean,return,string,continue,<EOF>",
                166,
            )
        )

    def test_op(self):
        """test operator"""
        self.assertTrue(
            TestLexer.checkLexeme(
                """a+a-a/a*a!a==a=a""", "a,+,a,-,a,/,a,*,a,!,a,==,a,=,a,<EOF>", 167
            )
        )
    def test_op1(self):
        self.assertTrue(TestLexer.checkLexeme("""a!==a""", "a,!=,=,a,<EOF>", 168))
    def test_op2(self):
        self.assertTrue(
            TestLexer.checkLexeme("""a==!=><>=<=a""", "a,==,!=,>,<,>=,<=,a,<EOF>", 169)
        )
    def test_op3(self):
        self.assertTrue(TestLexer.checkLexeme("""&&||!%""", "&&,||,!,%,<EOF>", 170))

    def test_separator(self):
        """test separator"""
        self.assertTrue(
            TestLexer.checkLexeme(
                """a[1];b{a;}a,b(1,2)""",
                "a,[,1,],;,b,{,a,;,},a,,,b,(,1,,,2,),<EOF>",
                171,
            )
        )

    def test_mixed(self):
        """test mixed token"""
        self.assertTrue(
            TestLexer.checkLexeme(
                """int main() {
                    abc();
                    foo(1,2,3);
                }""",
                "int,main,(,),{,abc,(,),;,foo,(,1,,,2,,,3,),;,},<EOF>",
                172,
            )
        )
    def test_mixed1(self):
        self.assertTrue(
            TestLexer.checkLexeme("""int main \b\r\n int void""", "int,main,Error Token \b", 173)
        )
    def test_mixed2(self):
        self.assertTrue(TestLexer.checkLexeme(""" "123a\\n123 ""","""Unclosed String: 123a\\n123 """,174))
    def test_mixed3(self):
        self.assertTrue(TestLexer.checkLexeme(""" 123 "123a\\m123" ""","""123,Illegal Escape In String: 123a\\m""",175))
    def test_mixed4(self):
        self.assertTrue(TestLexer.checkLexeme(""" "123a\\n123" ""","""123a\\n123,<EOF>""",176))
    def test_mixed5(self):
        self.assertTrue(TestLexer.checkLexeme(""" "123a\c123" ""","""Illegal Escape In String: 123a\c""",177))
    def test_mixed6(self):
        self.assertTrue(TestLexer.checkLexeme(""" float integral(float a, float b, float (*f) (float), int n) {
 int i;
	float dx = (b - a) / n;
    float value_of_integral = 0.0;

for (i=0; i<n; i++) {
float si_a = a + (i)*dx;
float si_b = a + (i+1)*dx;
value_of_integral += simpson(si_a, si_b, f, dx);
}

return value_of_integral;
}

float square(float x) {
	return x*x;
}

float simpson(float a, float b, float (*f) (float), float dx) {
	float value_of_interval_integral =
					0.5 * (f(a) + f(b)) / dx;
	return value_of_interval_integral;
}

int main(int argc, char** argv) {
	float twopi = 2 * 3.14;
	float integral_of_f = integral(0.0, 1.0, square, 1e3);
	/*float integral_of_sin = integral(0.0, , sin, 10);*/
	printf(" z  f (0.0 - 1.0) = %g\\n", integral_of_f);
	/*printf(" z sinus (0 - 2pi) = %g\\n", integral_of_sin);*/
	return 0;
} ""","""float,integral,(,float,a,,,float,b,,,float,(,*,f,),(,float,),,,int,n,),{,int,i,;,float,dx,=,(,b,-,a,),/,n,;,float,value_of_integral,=,0.0,;,for,(,i,=,0,;,i,<,n,;,i,+,+,),{,float,si_a,=,a,+,(,i,),*,dx,;,float,si_b,=,a,+,(,i,+,1,),*,dx,;,value_of_integral,+,=,simpson,(,si_a,,,si_b,,,f,,,dx,),;,},return,value_of_integral,;,},float,square,(,float,x,),{,return,x,*,x,;,},float,simpson,(,float,a,,,float,b,,,float,(,*,f,),(,float,),,,float,dx,),{,float,value_of_interval_integral,=,0.5,*,(,f,(,a,),+,f,(,b,),),/,dx,;,return,value_of_interval_integral,;,},int,main,(,int,argc,,,char,*,*,argv,),{,float,twopi,=,2,*,3.14,;,float,integral_of_f,=,integral,(,0.0,,,1.0,,,square,,,1e3,),;,printf,(, z  f (0.0 - 1.0) = %g\\n,,,integral_of_f,),;,return,0,;,},<EOF>""",178))
    def test_mixed7(self):
        self.assertTrue(TestLexer.checkLexeme(r""" "abc\nabc" """,r"""abc\nabc,<EOF>""",179))

    def test_mixed8(self):
        self.assertTrue(TestLexer.checkLexeme(r""" "abc\babc" """,r"""abc\babc,<EOF>""",180))

    def test_mixed9(self):
        self.assertTrue(TestLexer.checkLexeme(r""" "abc\aabc" """,r"""Illegal Escape In String: abc\a""",181))

    def test_mixed10(self):
        self.assertTrue(TestLexer.checkLexeme(r""" a+b-c """,r"""a,+,b,-,c,<EOF>""",182))

    def test_mixed11(self):
        self.assertTrue(TestLexer.checkLexeme(r""" int a[5]; """,r"""int,a,[,5,],;,<EOF>""",183))

    def test_mixed12(self):
        self.assertTrue(TestLexer.checkLexeme("""printf("\\n\\n\\tCoding is Fun !\\n\\n");//really????""","printf,(,\\n\\n\\tCoding is Fun !\\n\\n,),;,<EOF>",184))

    def test_mixed13(self):
        self.assertTrue(TestLexer.checkLexeme("""[67 {fc ak}], gh"bx@" f_34 sd1.5 \f""","[,67,{,fc,ak,},],,,gh,bx@,f_34,sd1,.5,<EOF>",185))

    def test_mixed14(self):
        self.assertTrue(TestLexer.checkLexeme("""\f notif 1.09-34*45e9"#"ehnv# ""","notif,1.09,-,34,*,45e9,#,ehnv,Error Token #",186))

    def test_mixed15(self):
        self.assertTrue(TestLexer.checkLexeme("""/*-+if 6.7 elseif 87.45/5>52<=10 ""","/,*,-,+,if,6.7,elseif,87.45,/,5,>,52,<=,10,<EOF>",187))

    def test_mixed16(self):
        self.assertTrue(TestLexer.checkLexeme("do {ptr = next} while (!next); ","do,{,ptr,=,next,},while,(,!,next,),;,<EOF>",188))

    def test_mixed17(self):
        self.assertTrue(TestLexer.checkLexeme("if (t == 10) flag = false; ","if,(,t,==,10,),flag,=,false,;,<EOF>",189))
    
    def test_mixed18(self):
        self.assertTrue(TestLexer.checkLexeme("int k[3]={1,5,-2}; ","int,k,[,3,],=,{,1,,,5,,,-,2,},;,<EOF>",190))

    def test_mixed19(self):
        self.assertTrue(TestLexer.checkLexeme("void main(argv){}","void,main,(,argv,),{,},<EOF>",191))

    def test_mixed20(self):
        self.assertTrue(TestLexer.checkLexeme("int k = -9, h1, _z; ","int,k,=,-,9,,,h1,,,_z,;,<EOF>",192))

    def test_mixed21(self):
        self.assertTrue(TestLexer.checkLexeme(""" String+Exception took me "lots of time" ""","String,+,Exception,took,me,lots of time,<EOF>",193))

    def test_mixed22(self):
        self.assertTrue(TestLexer.checkLexeme(""" _Hoshi "\\\\kagayaku"_ ""","""_Hoshi,\\\\kagayaku,_,<EOF>""",194))

    def test_mixed23(self):
        self.assertTrue(TestLexer.checkLexeme(r""" toi ten la gi """,r"""toi,ten,la,gi,<EOF>""",195))

    def test_mixed24(self):
        self.assertTrue(TestLexer.checkLexeme(r""" /*toi ten la gi*/ """,r"""<EOF>""",196))

    def test_mixed25(self):
        self.assertTrue(TestLexer.checkLexeme(r""" "abc\\nabc" """,r"""abc\\nabc,<EOF>""",197))

    def test_mixed26(self):
        self.assertTrue(TestLexer.checkLexeme(r""" string a = "test nay khong the sai" """,r"""string,a,=,test nay khong the sai,<EOF>""",198))

    def test_mixed27(self):
        self.assertTrue(TestLexer.checkLexeme(r""" string a = "test nay loi\?" """,r"""string,a,=,Illegal Escape In String: test nay loi\?""",199))
