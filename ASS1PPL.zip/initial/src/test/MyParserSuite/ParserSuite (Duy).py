import unittest
from TestUtils import TestParser

class ParserSuite(unittest.TestCase):

    def test_simple_program(self):
        """Simple program: int main() {} """
        input = """int main() {}"""
        expect = "successful"
        self.assertTrue(TestParser.checkParser(input,expect,201))

    def test_more_complex_program(self):
        """More complex program"""
        input = """int main () {
            putIntLn(4);
        }"""
        expect = "successful"
        self.assertTrue(TestParser.checkParser(input,expect,202))
    
    def test_wrong_miss_close(self):
        """Miss ) int main( {}"""
        input = """int main( {}"""
        expect = "Error on line 1 col 10: {"
        self.assertTrue(TestParser.checkParser(input,expect,203))

    def test_variable(self):
        input = """int i = 5;"""
        expect = "Error on line 1 col 6: ="
        self.assertTrue(TestParser.checkParser(input,expect,204))

    def test_arraytype(self):
        input = """int i[];"""
        expect = "Error on line 1 col 6: ]"
        self.assertTrue(TestParser.checkParser(input,expect,205))

    def test_index_expression(self):
        input = """
        int main(){
            foo(2)[3+x] = a[b[2]] +3;
        }"""
        expect = "successful"
        self.assertTrue(TestParser.checkParser(input,expect,206))

    def test_invocation_express(self):
        input ="""void f(int a[]) { 
            foo(a,b[2]);
        }"""
        expect = "successful"
        self.assertTrue(TestParser.checkParser(input,expect,207))
        
    def test_body(self):
        input = """ void foo ( int i ) {
                        int child_of_foo ( float f ) {

                         }
                    }"""
        expect = "Error on line 2 col 41: ("
        self.assertTrue(TestParser.checkParser(input,expect,208))   
    
    def test_arraytype_1(self):
        input = """int i[6];"""
        expect = "successful"
        self.assertTrue(TestParser.checkParser(input,expect,209))

    def test_arraytype_3(self):
        input = """string i[2.5];"""
        expect = "Error on line 1 col 9: 2.5"
        self.assertTrue(TestParser.checkParser(input,expect,210))

    def test_invocation_express_1(self):
        input ="""void f(int a[10]) { 

        }"""
        expect = "Error on line 1 col 13: 10"
        self.assertTrue(TestParser.checkParser(input,expect,211))
    
    def test_expression(self):
        input ="""
            void test(){
                foo(3)[foo(2)+x] = x - 3 * !y / 2.0;
            }
        """
        expect = "successful"
        self.assertTrue(TestParser.checkParser(input,expect,212))
    
    def test_bool_expression(self):
        input ="""
            int test(){
                return a > b <= c;
            }
        """
        expect = "Error on line 3 col 29: <="
        self.assertTrue(TestParser.checkParser(input,expect,213))

    def test_variable1(self):
        input = """ int i,a,b,k[5];"""
        expect = "successful"
        self.assertTrue(TestParser.checkParser(input,expect,214))
    
    def test_variable2(self):
        input = """ int i,a,b,k[5]"""
        expect = "Error on line 1 col 15: <EOF>"
        self.assertTrue(TestParser.checkParser(input,expect,215))

    def test_if_no_else_stat(self):
        input = """
            void main(){
                if(a>0){
                    printf("Hello world");
                }
            }"""
        expect = "successful"
        self.assertTrue(TestParser.checkParser(input,expect,216))

    def test_for_stat(self):
        input = """ void main(){
            for(i;x;y){

            }
        }"""
        expect = "successful"
        self.assertTrue(TestParser.checkParser(input,expect,217))
    
    def test_do_while_stat(self):
        input = """void main(){
            do{
                x+y = 1; printf("Ok");
            }
            while(x);
        }"""
        expect = "successful"
        self.assertTrue(TestParser.checkParser(input,expect,218))

    def test_block_stat(self):
        input = """int main(){
            {
                {
                    {
                        printf("Number 1");
                    }
                    printf("Number 2");
                }
                printf("Number 3");
            }
        }"""
        expect = "successful"
        self.assertTrue(TestParser.checkParser(input,expect,219))
    
    def test_if_else_stat(self):
        input = """
            void main(){
                if(a>0)
                    printf("Hello world");
                else
                    printf("Hi world");
            }"""
        expect = "successful"
        self.assertTrue(TestParser.checkParser(input,expect,220))

    def test_many_if_else_stat(self):
        input = """
            void main(){
                if(a>0){
                    printf("Hello world");
                    if(b>0)
                        printf("World hello");
                    else
                        printf("Hi world");
                }
                else
                    printf("World hi");
            }"""
        expect = "successful"
        self.assertTrue(TestParser.checkParser(input,expect,221))
    
    def test_nest_for(self):
        input = """ void main(){
            for(x;y;z){
                for(a;b;c){

                }
            }
        }"""
        expect = "successful"
        self.assertTrue(TestParser.checkParser(input,expect,222))
    
    def test_many_if_else_stat1(self):
        input = """void main(){
                        if(a>0)
                            printf("Hello world");
                        else
                            if(b>0)
                                printf("World hello");
                }"""
        expect = "successful"
        self.assertTrue(TestParser.checkParser(input,expect,223))

    def test_expression1(self):
        input = """ void main(){
            a - b = 0;
        }"""
        expect = "successful"
        self.assertTrue(TestParser.checkParser(input,expect,224))
    
    def test_expression2(self):
        input = """ void main(){
            - a - - b - b = 0;
            a / b / c * d + e > f % g == !h;
        }"""
        expect = "successful"
        self.assertTrue(TestParser.checkParser(input,expect,225))
    
    def test_expression3(self):
        input = """ void main(){
            a = b = c ;
        }"""
        expect = "successful"
        self.assertTrue(TestParser.checkParser(input,expect,226))

    def test_do_while_stat1(self):
        input = """void main(){
            do{

            }
            while();
        }"""
        expect = "Error on line 5 col 18: )"
        self.assertTrue(TestParser.checkParser(input,expect,227))

    def test_arr_point_type(self):
        input = """int [ ] foo ( int b [ ] ){}"""
        expect = "successful"
        self.assertTrue(TestParser.checkParser(input,expect,228))
    
    def test_arr_point_type1(self):
        input = """int test(){a%b;}"""
        expect = "successful"
        self.assertTrue(TestParser.checkParser(input,expect,229))

    def test_do_while_stat2(self):
        input = """void main(){
            do{

            }
            {

            }
            while(true);
        }"""
        expect = "successful"
        self.assertTrue(TestParser.checkParser(input,expect,230))

    def test_if_stat(self):
        input = """void main(){
            if(true){
                //This a comment
                abcDEF;
            }
            else{

            }
        }"""
        expect = "successful"
        self.assertTrue(TestParser.checkParser(input,expect,231))

    def test_expression4(self):
        input = """void main(){
                arr[arr[12]] < arr[3];
        }"""
        expect = "successful"
        self.assertTrue(TestParser.checkParser(input, expect, 232))
    
    def test_expression5(self):
        input = """void main(){
                    !--a--b;
        }"""
        expect = "successful"
        self.assertTrue(TestParser.checkParser(input, expect, 233))

    def test_expression6(self):
        input = """void main(){
                    a < b > c <= d;
        }"""
        expect = "Error on line 2 col 26: >"
        self.assertTrue(TestParser.checkParser(input, expect, 234))

    def test_expression7(self):
        input = """void main(){
                    ((a < b) > c) <= d;
        }"""
        expect = "successful"
        self.assertTrue(TestParser.checkParser(input, expect, 235))
    
    def test_nest_for1(self):
        input = """void main(){
                    for(a;b;c)
                        for(c;d;e)
                            abc;
        }"""
        expect = "successful"
        self.assertTrue(TestParser.checkParser(input, expect, 236))

    def test_nest_for2(self):
        input = """void main(){
                    for(a;b;c){
                        abc;
                        for(c;d;e)}
                            abc;
        }"""
        expect = "Error on line 4 col 34: }"
        self.assertTrue(TestParser.checkParser(input, expect, 237))

    def test_many_if_else_stat2(self):
        input = """void main(){ if(abc) if(cde) abc; else def;}"""
        expect = "successful"
        self.assertTrue(TestParser.checkParser(input, expect, 238))

    def test_many_if_else_stat3(self):
        input = """void main( ){ if (a) if (b) if (c) a; else a; else }
        """
        expect = "Error on line 1 col 51: }"
        self.assertTrue(TestParser.checkParser(input, expect, 239))

    def test_many_if_else_stat4(self):
        input = """void main( ){ if (a) if (b) if (c) a; else a; else b;}
        """
        expect = "successful"
        self.assertTrue(TestParser.checkParser(input, expect, 240))

    def test_arraytype_2(self):
        input = """string i[i[3]];"""
        expect = "Error on line 1 col 9: i"
        self.assertTrue(TestParser.checkParser(input,expect,241))

    def test_funcall(self):
        input = """void main(){func[]();}"""
        expect = "Error on line 1 col 17: ]"
        self.assertTrue(TestParser.checkParser(input,expect,242))

    def test_index_expression1(self):
        input = """void main(){ arr[2+x][x+3]; }"""
        expect = "successful"
        self.assertTrue(TestParser.checkParser(input,expect,243))

    def test_index_expression2(self):
        input = """void main(){ a > b[x+3]; }"""
        expect = "successful"
        self.assertTrue(TestParser.checkParser(input,expect,244))

    def test_funcall1(self):
        input = """void main(){ func(func(func())); }"""
        expect = "successful"
        self.assertTrue(TestParser.checkParser(input,expect,245))
    
    def test_index_expression3(self):
        input = """void main(){(b+c)[!a>b];}"""
        expect = "successful"
        self.assertTrue(TestParser.checkParser(input,expect,246))

    def test_do_while_stat3(self):
        input = """void main(){
            do
            while(false);
            while(true);
        }"""
        expect = "Error on line 3 col 12: while"
        self.assertTrue(TestParser.checkParser(input,expect,247))

    def test_return_stat(self):
        input = """void main(){
            return a;
        }"""
        expect = "successful"
        self.assertTrue(TestParser.checkParser(input,expect,248))

    def test_return_stat1(self):
        input = """void main(){
            return while;
        }"""
        expect = "Error on line 2 col 19: while"
        self.assertTrue(TestParser.checkParser(input,expect,249))

    def test_return_stat2(self):
        input = """void main(){
            return
        }"""
        expect = "Error on line 3 col 8: }"
        self.assertTrue(TestParser.checkParser(input,expect,250))

    def test_return_stat3(self):
        input = """void main(){
            return(a+b >c);
        }"""
        expect = "successful"
        self.assertTrue(TestParser.checkParser(input,expect,251))

    def test_funcall2(self):
        input = """void main(){
            app(a+b > c);
        }"""
        expect = "successful"
        self.assertTrue(TestParser.checkParser(input,expect,252))

    def test_funcall3(self):
        input = """void main(){
            app(a+b > c, !c != d, a[2]);
        }"""
        expect = "successful"
        self.assertTrue(TestParser.checkParser(input,expect,253))

    def test_variable3(self):
        input = """float f = 2.3;
        }"""
        expect = "Error on line 1 col 8: ="
        self.assertTrue(TestParser.checkParser(input,expect,254))

    def test_variable4(self):
        input = """string a,b,c[c[3]];
        }"""
        expect = "Error on line 1 col 13: c"
        self.assertTrue(TestParser.checkParser(input,expect,255))

    
    def test_arr_point_type2(self):
        input = """
            string[3] func(int a, int b[]){}
        }"""
        expect = "Error on line 2 col 19: 3"
        self.assertTrue(TestParser.checkParser(input,expect,256))

    def test_many_if_else_stat5(self):
        input = """void main(){
            if(true) a; else if(true) if(false) abc; else cde; else def;
        }"""
        expect = "successful"
        self.assertTrue(TestParser.checkParser(input,expect,257))

    def test_expression8(self):
        input = """void main(){
            a * b * c = d + (e+x)[2];
        }"""
        expect = "successful"
        self.assertTrue(TestParser.checkParser(input,expect,258))

    def test_index_expression4(self):
        input = """void main(){
            arr[x+1][x+2][x+3] < b;
        }"""
        expect = "successful"
        self.assertTrue(TestParser.checkParser(input,expect,259))

    def test_if_return_stat(self):
        input = """void main(){
            if(a) return 1;
            else return 0;
        }"""
        expect = "successful"
        self.assertTrue(TestParser.checkParser(input,expect,260))

    def test_main_func(self):
        input = """void main(int a, int b[]){
        }"""
        expect = "successful"
        self.assertTrue(TestParser.checkParser(input,expect,261))

    def test_funcdecl(self):
        input = """void main{
        }"""
        expect = "Error on line 1 col 9: {"
        self.assertTrue(TestParser.checkParser(input,expect,262))

    def test_funcdecl1(self):
        input = """main(){
        }"""
        expect = "Error on line 1 col 0: main"
        self.assertTrue(TestParser.checkParser(input,expect,263))

    def test_funcdecl2(self):
        input = """ int main()"""
        expect = "Error on line 1 col 11: <EOF>"
        self.assertTrue(TestParser.checkParser(input,expect,264))

    def test_arraytype4(self):
        input = """void arr[5];"""
        expect = "Error on line 1 col 8: ["
        self.assertTrue(TestParser.checkParser(input,expect,265))
    
    def test_if_stat1(self):
        input = """void main(){
            if(func(2) && arr[x+2]) break; else continue;
        }"""
        expect = "successful"
        self.assertTrue(TestParser.checkParser(input,expect,266))

    def test_expression9(self):
        input = """void main(){
            "abc";
            true;
            false;
        }"""
        expect = "successful"
        self.assertTrue(TestParser.checkParser(input,expect,267))

    def test_expression10(self):
        input = """void main(){
            "abc" || true || false;
        }"""
        expect = "successful"
        self.assertTrue(TestParser.checkParser(input,expect,268))

    def test_expression11(self):
        input = """void main(){
           false && 2 && "a";
        }"""
        expect = "successful"
        self.assertTrue(TestParser.checkParser(input,expect,269))

    def test_many_func(self):
        input = """int func1(){

        }
        void main(){

        }
        float func2(){

        }"""
        expect = "successful"
        self.assertTrue(TestParser.checkParser(input,expect,270))

    def test_variable5(self):
        input = """boolean a = true;"""
        expect = "Error on line 1 col 10: ="
        self.assertTrue(TestParser.checkParser(input,expect,271))

    def test_wrong_funcbody(self):
        input = """void main(){
            int main1(){}
        }"""
        expect = "Error on line 2 col 21: ("
        self.assertTrue(TestParser.checkParser(input,expect,272))

    def test_block_stat1(self):
        input = """int main(){
            {
                {int a,b,c;}
                a=b=c=5;
                float a[5];
                if(a == b) f[0] = 1.0;
            }
        }"""
        expect = "successful"
        self.assertTrue(TestParser.checkParser(input,expect,273))

    def test_do_while_stat4(self):
        input = """void a(){
            do
            do{}
            while(1);
            while(1);
        }"""
        expect = "successful"
        self.assertTrue(TestParser.checkParser(input,expect,274))

    def test_continue_stat(self):
        input = """int a(){
            continue;
            continue a;
        }"""
        expect = "Error on line 3 col 21: a"
        self.assertTrue(TestParser.checkParser(input,expect,275))

    def test_funcall4(self):
        input = """void a(){
            foo(1,2,"abc");
        }"""
        expect = "successful"
        self.assertTrue(TestParser.checkParser(input,expect,276))

    def test_funcdecl3(self):
        input = """void a(int i,j){
           
        }"""
        expect = "Error on line 1 col 13: j"
        self.assertTrue(TestParser.checkParser(input,expect,277))

    def test_for_stat1(self):
        input = """void a(){
           for(i;j)abc;
        }"""
        expect = "Error on line 2 col 18: )"
        self.assertTrue(TestParser.checkParser(input,expect,278))

    def test_expression12(self):
        input = """void a(){
           ((a+b)&&(c+d)) > a;
        }"""
        expect = "successful"
        self.assertTrue(TestParser.checkParser(input,expect,279))

    def test_simple_program1(self):
        input = """int i,j,k;
        string arr[2];
        int a(float f){
            foo(a,b,c,arr[a+b+c]);
            return d;
        }"""
        expect = "successful"
        self.assertTrue(TestParser.checkParser(input,expect,280))
    
    def test_simple_program2(self):
        input = """int [ ] foo ( int b [ ] ) {
                    int a [ 1 ] ;
                    if ( true ) return a ;
                    else return b ;
        }"""
        expect = "successful"
        self.assertTrue(TestParser.checkParser(input,expect,281))

    def test_funcall5(self):
        input = """void main(){
            foo(foo(foo(foo(foo(foo(foo(foo(foo(foo(foo(foo(0))))))))))));
        }"""
        expect = "successful"
        self.assertTrue(TestParser.checkParser(input,expect,282))

    def test_index_expression5(self):
        input = """void main(){
            (1.5[a+b+c])[x+y];
        }"""
        expect = "successful"
        self.assertTrue(TestParser.checkParser(input,expect,283))

    def test_index_expression6(self):
        input = """void main(){
           abc[[[x+y]]];
        }"""
        expect = "Error on line 2 col 15: ["
        self.assertTrue(TestParser.checkParser(input,expect,284))
    
    def test_arraytype5(self):
        input = """float myarr[0001];
        int arr[2][3];"""
        expect = "Error on line 2 col 18: ["
        self.assertTrue(TestParser.checkParser(input,expect,285))

    def test_nest_stat(self):
        input = """void main(){
            for(a;b;c)
            do
            if(1)
            if(2)
            if(3)
            a;
            else b;
            while(true);
            return;
        }"""
        expect = "successful"
        self.assertTrue(TestParser.checkParser(input,expect,286))

    def test_variable6(self):
        input = """int[] a,b,c;"""
        expect = "Error on line 1 col 7: ,"
        self.assertTrue(TestParser.checkParser(input,expect,287))

    def test_many_if_else_stat6(self):
        input = """void main(){
            if(1){if(2){a;if(3)b;if(4)c;else d;if(5)e;else f;}else g;}else h;if(6) i ;
        }"""
        expect = "successful"
        self.assertTrue(TestParser.checkParser(input,expect,288))

    def test_for_stat2(self):
        input = """void main(){
            for(;;){
                for(;;)
            }
        }"""
        expect = "Error on line 2 col 16: ;"
        self.assertTrue(TestParser.checkParser(input,expect,289))

    def test_bool_expression1(self):
        input = """void main(){
            a == b != c != d;
        }"""
        expect = "Error on line 2 col 19: !="
        self.assertTrue(TestParser.checkParser(input,expect,290))

    def test_more_complex_program1(self):
        input = """int i;
        int f() {
            return 200;
        }
        void main(){
            int main;
            main = f();
            putIntLn(main);
            {
                int i;
                int main;
                int f;
                main = f = i = 100;
                putIntLn(i);
                putIntLn(main);
                putIntLn(f);
            }
            putIntLn(main);
        }"""
        expect = "successful"
        self.assertTrue(TestParser.checkParser(input,expect,291))
    
    def test_funcdecl4(self):
        input = """void main(int i, int j, int k, int f, int g, int h, int a, int b){}"""
        expect = "successful"
        self.assertTrue(TestParser.checkParser(input,expect,292))
    
    def test_more_complex_program2(self):
        input = """boolean isPrime(int n){
            int divisor;
            divisor = 0;
            if(n == 2) return true;
            else{
                int i;
                for(i = 2;i<sqrt(n);i=i+1){
                    if(n%i==0){
                        divisor = divisor + 1;
                        break;
                    }
                }
                if(divisor) return false;
                else return true;
            }
        }"""
        expect = "successful"
        self.assertTrue(TestParser.checkParser(input,expect,293))

    def test_more_complex_program3(self):
        input = """int i,j,k[3];
        string str;
        int a(int b, float c){
            if(true){
                a+b+c=d;
                b<d == e;
            }
            else{
                if(a>b){
                    a = a+b;
                    print(a);
                }
                else print(b);
            }
        }
        void main(){
            int b;
            float c;
            d = a(b,c);
            print(d);
        }"""
        expect = "successful"
        self.assertTrue(TestParser.checkParser(input,expect,294))

    def test_nest_stat1(self):
        input = """void main(){
            for(a;b;c){
                {
                    do{
                        abc;
                        do{
                            def;
                            do{
                                ghi;
                            }while(false);
                        }while(false);
                    }while(true);
                    {

                    }
                }
            }
        }"""
        expect = "successful"
        self.assertTrue(TestParser.checkParser(input,expect,295))

    def test_arraytype6(self):
        input = """void main(){
            int arr[1];
            arr[1][2] + x = 3;
            arr[1][2][3][4][a>b+c];
        }"""
        expect = "successful"
        self.assertTrue(TestParser.checkParser(input,expect,296))

    def test_more_complex_program4(self):
        input = """float area(float a, float b, float c){
            float p;

            p = (a+b+c)/2;

            float area;

            area = sqrt(p*(p-a)*(p-b)*(p-c));

            return area;
        }
        void main(){
            float a,b,c;
            print("Enter a,b,c");
        	
            get(a,b,c);

            d = area(a,b,c);

            print(d);
        }"""

        expect = "successful"
        self.assertTrue(TestParser.checkParser(input,expect,297))

    def test_more_complex_program5(self):
        input = """void quicksort(int number[],int first,int last){
                    int i, j, pivot, temp;
                    if(first<last){
                    pivot=first;
                    i=first;
                    j=last;
                    while(i<j){
                    while(number[i]<=number[pivot]&&i<last)
                    i=i+1;
                    while(number[j]>number[pivot])
                    j=j-1;
                    if(i<j){
                    temp=number[i];
                    number[i]=number[j];
                    number[j]=temp;
                    }
                    }
                    temp=number[pivot];
                    number[pivot]=number[j];
                    number[j]=temp;
                    quicksort(number,first,j-1);
                    quicksort(number,j+1,last);
                    }
                }"""

        expect = "Error on line 7 col 20: while"
        self.assertTrue(TestParser.checkParser(input,expect,298))

    def test_more_complex_program6(self):
        input = """void main(){
            print("Enter N:");
            get(N);

            int sum;
            sum=0;
            int i;
            for(i=0;i<N;i=i+1){
                sum = sum +i;
            }
            print("Sum = ");
            print(sum);
        }"""
        expect = "successful"
        self.assertTrue(TestParser.checkParser(input,expect,299))
    
    def test_more_complex_program7(self):
        input = """int factorial(int N){
            int fac;
            fac = 1;
            if(N <= 1) return fac;
            else{
                return fac*factorial(N-1)
            }
        }"""
        expect = "Error on line 7 col 12: }"
        self.assertTrue(TestParser.checkParser(input,expect,300))
