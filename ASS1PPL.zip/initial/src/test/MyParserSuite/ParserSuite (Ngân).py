import unittest
from TestUtils import TestParser

class ParserSuite(unittest.TestCase):
   
    def test_simple_program(self):
        """Simple program: int main() {} """
        input = """int main() {\n fooo(1712281);}"""
        expect = "successful"
        self.assertTrue(TestParser.checkParser(input,expect,201))
#VAR DECLARATION
    def test_var_dec_0(self):
        """Var declaration"""
        input = """
            int a;
            float abc, xyz[9];
        """
        expect = "successful"
        self.assertTrue(TestParser.checkParser(input,expect,202))
    def test_var_dec_1(self):
        """Error Var declaration: initialization"""
        input = """
            int a;
            float abc, xyz[9] = 123;
        """
        expect = "Error on line 3 col 30: ="
        self.assertTrue(TestParser.checkParser(input,expect,203))
    def test_var_dec_2(self):
        """Error Var declaration: array size unknown"""
        input = """
            int a;
            float abc, xyz[];
        """
        expect = "Error on line 3 col 27: ]"
        self.assertTrue(TestParser.checkParser(input,expect,204))
    def test_var_dec_3(self):
        """Error Var declaration: Wrong format"""
        input = """
            int a;
            float abc; xyz[9];
        """
        expect = "Error on line 3 col 23: xyz"
        self.assertTrue(TestParser.checkParser(input,expect,205))
    def test_var_dec_4(self):
        """Error Var declaration: Wrong format 2"""
        input = """
            int a;
            float[] abc, xyz[9];
        """
        expect = "Error on line 3 col 23: ,"
        self.assertTrue(TestParser.checkParser(input,expect,206))
    def test_var_dec_5(self):
        """Error Var declaration: Null variable list """
        input = """
            int a;
            float ;
        """
        expect = "Error on line 3 col 18: ;"
        self.assertTrue(TestParser.checkParser(input,expect,207))

#FUNCTION DECLARATION
    def test_func_dec_0(self):
        """Function Declaration - Simple"""
        input = """
            void in(){
                fooo(1712281);
            }
            int[] foo(){}
            int main(){
                fooo("This is assigment 1");
            }
        """
        expect = "successful"
        self.assertTrue(TestParser.checkParser(input,expect,208))
    def test_func_dec_1(self):
        """Function Declaration - More Complex"""
        input = """
            void in(){
                int mssv;
                fooo(1712281);
            }
            arrPointer[] foo(string str[]){
                float _f1;
            }
            int main(){
                fooo("This is assigment 1");
            }
        """
        expect = "Error on line 6 col 12: arrPointer"
        self.assertTrue(TestParser.checkParser(input,expect,209))
    def test_func_dec_2(self):
        """Error Function Declaration - Unclosed func"""
        input = """
            void init(){
                int mssv;
                fooo("1712281");
        """
        expect = "Error on line 5 col 8: <EOF>"
        self.assertTrue(TestParser.checkParser(input,expect,210))
    def test_func_dec_3(self):
        """Error Function Declaration - Wrong format"""
        input = """
            void init({
                int mssv;
                fooo("1712281");
            }
        """
        expect = "Error on line 2 col 22: {"
        self.assertTrue(TestParser.checkParser(input,expect,211))
    def test_func_dec_4(self):
        """Error Function Declaration - Wrong format"""
        input = """
            voId foo(){
                fooo("Wrong void");
            }
        """
        expect = "Error on line 2 col 12: voId"
        self.assertTrue(TestParser.checkParser(input,expect,212))
    def test_var_func_dec_5(self):
        """Var Func Declaration"""
        input = """
            void start(){
                int one;
            }
            boolean _boolVar;
            int main(){
                string str1, str2, str_arr3[5];
            }
        """
        expect = "successful"
        self.assertTrue(TestParser.checkParser(input,expect,213))

#EXPRESSION
    def test_exp_0(self):
        """Expression: Simple"""
        input = """
        int main(){
            boolean a;
            a = ("abc" == "ABC")||("abc" + "456" > "abc");
        }
        """
        expect = "successful"
        self.assertTrue(TestParser.checkParser(input,expect,214))
    def test_exp_1(self):
        """Expression: Simple"""
        input = """
            int foo(){
                return 3;
            }
            int main(){
                boolean b;
                b = x + y > 100 || y <= 10; 
                putInt(foo());
            }
        """
        expect = "successful"
        self.assertTrue(TestParser.checkParser(input,expect,215))
    def test_exp_2(self):
        """Expression: Simple"""
        input = """
            int foo(){
                return 3;
            }
            int main(){
                boolean b;
                b = x + y > 100 || y <= 10; 
                goo(foo());
            }
        """
        expect = "successful"
        self.assertTrue(TestParser.checkParser(input,expect,216))
#INDEX EXPRESSION
    def test_exp_3(self):
        """Index Expression"""
        input = """
            int main(){
                abc [ 3 + x ] = -doo[x-5];
            }
        """
        expect = "successful"
        self.assertTrue(TestParser.checkParser(input,expect,217))
    def test_exp_4(self):
        """Index Expression"""
        input = """
            void foo(){
                is = (.1e18[a<=foo(3)] >= 9e7) ;
            }
        """
        expect = "successful"
        self.assertTrue(TestParser.checkParser(input,expect,218))
    def test_exp_5(self):
        """Index Expression """
        input = """
            boolean foo(){
                foo1[3+x] = goo[(1+a[1])] && doo[x-5] = 5;
            }
        """
        expect = "successful"
        self.assertTrue(TestParser.checkParser(input,expect,219))
    def test_exp_6(self):
        """Index Expression Error"""
        input = """
            boolean foo(){
                foo1[3+x] = goo[(1+a[1]) - doo[x-5];
            }
        """
        expect = "Error on line 3 col 51: ;"
        self.assertTrue(TestParser.checkParser(input,expect,219))
    def test_exp_7(self):
        """Index Expression Error"""
        input = """
            boolean foo(){
                foo(2)[3+x] = a[b[2]] +3;
            }
        """
        expect = "successful"
        self.assertTrue(TestParser.checkParser(input,expect,220))

#INVOCATION EXPRESSION 
    def test_exp_8(self):
        """Invocation Expression """
        input = """
            int foo(int arg1, boolean arg2, string arg3){}
            int main(){
                foo(arg1 = .45e-3, (lightSpeed >= 3e8), "This is string");
            }
        """
        expect = "successful"
        self.assertTrue(TestParser.checkParser(input,expect,221))
    def test_exp_9(self):
        """Invocation Expression """
        input = """
            int foo(int arg, int[] num){}
            int main(){
                foo(arg1 = 13, 14);
            }
        """
        expect = "Error on line 2 col 32: ["
        self.assertTrue(TestParser.checkParser(input,expect,222))
    def test_exp_10(self):
        """Invocation Expression """
        input = """
            void foo(float a[3]){}
        """
        expect = "Error on line 2 col 29: 3"
        self.assertTrue(TestParser.checkParser(input,expect,223))
    def test_exp_11(self):
        """Invocation Expression """
        input = """
            int main(){
                a[m+n] = b[m+1] = foo()[m*1] = a[a / 3];
            }
        """
        expect = "successful"
        self.assertTrue(TestParser.checkParser(input,expect,224))
#EXPRESSION GENERAL AND PRECEDENCE
    def test_exp_12(self):
        """General Expression """
        input = """
            int main(){
                (1>=0)[2] = 2+a[1]+c+("abc"< 0);
                (.25+1e3+(1<0))[10] = 4;
            }
        """
        expect = "successful"
        self.assertTrue(TestParser.checkParser(input,expect,225))
    def test_exp_13(self):
        """General Expression """
        input = """
            "a34"[25] =  foo[32] && !in[30] ;
            int main(){}
        """
        expect = "Error on line 2 col 12: a34"
        self.assertTrue(TestParser.checkParser(input,expect,226))
    def test_exp_14(self):
        """General Expression """
        input = """
            int main(){
            "a34"[25] =  foo[32] && !in[30] ;
            }
        """
        expect = "successful"
        self.assertTrue(TestParser.checkParser(input,expect,227))
    def test_exp_15(self):
        """General Expression """
        input = """
            boolean foo(){
                a = !("abc" == "Abc" == "aBc") && ("1712281" > "0");
            }
        """
        expect = "Error on line 3 col 37: =="
        self.assertTrue(TestParser.checkParser(input,expect,228))
    def test_exp_16(self):
        """General Expression """
        input = """
            boolean foo(){
                me >= 69 == 123 + (1 % 3);
            }
        """
        expect = "successful"
        self.assertTrue(TestParser.checkParser(input,expect,229))
#IF STATEMENT
    def test_if_0(self):
        """If Statement"""
        input = """
            int main(){
                if (tryHard) pass = "true";
                else pass = "false";
            }
        """
        expect = "successful"
        self.assertTrue(TestParser.checkParser(input,expect,230))
    def test_if_1(self):
        """If Statement"""
        input = """
            int main(){
                if (tryHard) pass = "true";
            }
        """
        expect = "successful"
        self.assertTrue(TestParser.checkParser(input,expect,231))
    def test_if_2(self):
        """If Statement"""
        input = """
            int main(){
                if(a>1) a = 1;
                else
                    if ((1!=2)==(3!=4)) x = 1;
                    else foo("foo",3);
            }
        """
        expect = "successful"
        self.assertTrue(TestParser.checkParser(input,expect,232))
    def test_if_3(self):
        """If Statement"""
        input = """
            int main(){
                if(foo(3,2)) a = a%5;
                if ((1!=2)==(3!=4)) x = 1;
                    else foo("foo",3);
            }
        """
        expect = "successful"
        self.assertTrue(TestParser.checkParser(input,expect,233))
    def test_if_4(self):
        """If Statement"""
        input = """
            int _global;
            int main(){
                if(_global % 5) _global = 3;
                if ((1!=2)==(3!=4)) x = 1;
                    else foo("foo",3);
            }
        """
        expect = "successful"
        self.assertTrue(TestParser.checkParser(input,expect,234))
    def test_if_5(self):
        """If Statement"""
        input = """
                if(_global % 5) _global = 3;
                if ((1!=2)==(3!=4)) x = 1;
                    else foo("foo",3);
        """
        expect = "Error on line 2 col 16: if"
        self.assertTrue(TestParser.checkParser(input,expect,235))
    def test_if_6(self):
        """If Statement"""
        input = """
            int main(){
                if(_global % 5) _global = 3; foo("foo",3);
            }
        """
        expect = "successful"
        self.assertTrue(TestParser.checkParser(input,expect,236))
    def test_if_7(self):
        """If Statement"""
        input = """
            int main(){
                if(true) 
                else
            }
        """
        expect = "Error on line 4 col 16: else"
        self.assertTrue(TestParser.checkParser(input,expect,237))
    def test_if_8(self):
        """If Statement"""
        input = """
            int main(){
                if(true) {}
                else {}
            }
        """
        expect = "successful"
        self.assertTrue(TestParser.checkParser(input,expect,238))
    def test_if_9(self):
        """If Statement"""
        input = """
            int main(){
                if(true) {}
                else 
                    if(_global % 5) _global = 3;
                if ((1!=2)==(3!=4)) x = 1;
                else foo("foo",3);
            }
        """
        expect = "successful"
        self.assertTrue(TestParser.checkParser(input,expect,239))
#DO WHILE STATEMENT
    def test_doWhile_0(self):
        """Do While Statement"""
        input = """
            int foo(){
                do 
                    a=30 ;
                    if(true) a= b[1];
                    else b=a[1]= 30;
                while (a!=b) ;
            }
        """
        expect = "successful"
        self.assertTrue(TestParser.checkParser(input,expect,240))
    def test_doWhile_1(self):
        """Do While Statement"""
        input = """
            int foo(){
                do 
                while (a!=b) ;
            }
        """
        expect = "Error on line 4 col 16: while"
        self.assertTrue(TestParser.checkParser(input,expect,241))
    def test_doWhile_2(self):
        """Do While Statement"""
        input = """
            int foo(){
                do 
                    a = a-1;
                    do f = sqrt(a*a + b*b + c*c);
                    while (a>0);
                while (a!=b) ;
            }
        """
        expect = "successful"
        self.assertTrue(TestParser.checkParser(input,expect,242))
    def test_doWhile_3(self):
        """Do While Statement"""
        input = """
            int foo(){
                do 
                    a = a-1;
                    do f = sqrt(a*a + b*b + c*c);
                        if (true) {}
                        else {}
                    while (a>0);
                while (a!=b) ;
            }
        """
        expect = "successful"
        self.assertTrue(TestParser.checkParser(input,expect,243))
    def test_doWhile_4(self):
        """Do While Statement"""
        input = """
            int foo(){
                do 
                    a = a-1;
                    break;
                    do f = sqrt(a*a + b*b + c*c);
                        if (true) { break; }
                        else {}
                    while (a>0);
                while (a!=b) ;
            }
        """
        expect = "successful"
        self.assertTrue(TestParser.checkParser(input,expect,244))
    def test_doWhile_5(self):
        """Do While Statement"""
        input = """
            int main(){
                do 
                    return f[23]%50;
                while (1);
            }
        """
        expect = "successful"
        self.assertTrue(TestParser.checkParser(input,expect,245))
#For Statement
    def test_for_0(self):
        """For Statement"""
        input = """
            int main(){
                for (i=1; i<=5; i=i+1)
                    s = s+i;
            }
        """
        expect = "successful"
        self.assertTrue(TestParser.checkParser(input,expect,246))
    def test_for_1(self):
        """For Statement"""
        input = """
            int main(){
                for (;;)
                    s = "Fighting!";
            }
        """
        expect = "Error on line 3 col 21: ;"
        self.assertTrue(TestParser.checkParser(input,expect,247))
    def test_for_2(self):
        """For Statement"""
        input = """
        int foo(){
            for (i=1; i<m+10; i= i+1) 
                for (j=1; j>m+10; j= j-1)
                    s = s + 1;
        }
        """
        expect = "successful"
        self.assertTrue(TestParser.checkParser(input,expect,248))
    def test_for_3(self):
        """For Statement"""
        input = """
        int foo(){
            for (;i<=2;) 
                for (j=1; j>m+10; j= j-1)
                    s = s + 1;
        }
        """
        expect = "Error on line 3 col 17: ;"
        self.assertTrue(TestParser.checkParser(input,expect,249))
    def test_for_4(self):
        """For Statement"""
        input = """
        int foo(){
            for (i = -20 ;i<=0; i= i + 1) 
                for (j=1; j>m+10; j= j-1){
                    s = s + 1;
                    break;
                }
        }
        """
        expect = "successful"
        self.assertTrue(TestParser.checkParser(input,expect,250))
    def test_for_5(self):
        """For Statement"""
        input = """
        int foo(){
            for (i = -20 ;i<=0; i= i + 1) 
                for (j=1; j>m+10; j= j-1){
                    s = s + 1;
                    if (s > 0) break;
                    else continue;
                }
        }
        """
        expect = "successful"
        self.assertTrue(TestParser.checkParser(input,expect,251))
    def test_for_6(self):
        """For Statement"""
        input = """
        float[] foo(){
           for (i = 0; i > -20; i = i-1)
                do 
                for (j = -20; i == 0; i = i-1)
                while i>1 ;
        }
        """
        expect = "Error on line 6 col 16: while"
        self.assertTrue(TestParser.checkParser(input,expect,252))
    def test_for_7(self):
        """For Statement"""
        input = """
        float[] foo(){
           for (i = 0; i > -20; i = i-1)
                do 
                continue;
                while i>1 ;
        }
        """
        expect = "successful"
        self.assertTrue(TestParser.checkParser(input,expect,253))
    def test_for_8(self):
        """For Statement"""
        input = """
        float[] foo(){
           for (i = 0;; i = i-1)
                do 
                continue;
                while i>1 ;
        }
        """
        expect = "Error on line 3 col 22: ;"
        self.assertTrue(TestParser.checkParser(input,expect,254))
# Break statement
    def test_break_0(self):
        """Break Statement"""
        input = """
        float[] foo(){
           for (i = 0; i <= 5; i = i-1)
                if (a == 3) break;    
        }
        """
        expect = "successful"
        self.assertTrue(TestParser.checkParser(input,expect,255))
    def test_break_1(self):
        """Break Statement"""
        input = """
        float[] foo(){
           for (i = 0; i <= 5; i = i-1)
                if (a == 3) break    
        }
        """
        expect = "Error on line 5 col 8: }"
        self.assertTrue(TestParser.checkParser(input,expect,256))
    def test_break_2(self):
        """Break Statement"""
        input = """
        float[] foo(){
           for (i = 0; i <= 5; i = i-1)
                if (a == 3) bReAk;    
        }
        """
        expect = "successful"
        self.assertTrue(TestParser.checkParser(input,expect,256))
#CONTINUE STATEMENT
    def test_continue_0(self):
        """Continue Statement"""
        input = """
        int main () {
            int a;
            a = 10;
             do {
                if( a == 15) {
                    a = a + 1;
                    continue;
                }
                foo(a);
                a= a+1;
            } while( a < 20 );
            return 0;   
        }
        """
        expect = "successful"
        self.assertTrue(TestParser.checkParser(input,expect,257))
    def test_continue_1(self):
        """Continue Statement"""
        input = """
        int main () {
            int a;
            a = 10;
             do {
                if( a == 15) {
                    a = a + 1;
                    continue
                }
                foo(a);
                a= a+1;
            } while( a < 20 );
            return 0;   
        }
        """
        expect = "Error on line 9 col 16: }"
        self.assertTrue(TestParser.checkParser(input,expect,258))
    def test_continue_2(self):
        """Continue Statement"""
        input = """
        int main () {
            int a;
            a = 10;
             do {
                if( a == 15) {
                    a = a + 1;
                    coNtInuE;
                }
                foo(a);
                a= a+1;
            } while( a < 20 );
            return 0;   
        }
        """
        expect = "successful"
        self.assertTrue(TestParser.checkParser(input,expect,259))
#RETURN STATEMENT
    def test_return_0(self):
        """Return Statement"""
        input = """
        int main () {
             return 1;   
        }
        """
        expect = "successful"
        self.assertTrue(TestParser.checkParser(input,expect,259))
    def test_return_1(self):
        """Return Statement"""
        input = """
        int main () {
             return void;   
        }
        """
        expect = "Error on line 3 col 20: void"
        self.assertTrue(TestParser.checkParser(input,expect,260))
    def test_return_2(self):
        """Return Statement"""
        input = """
        int main () {
             return int;   
        }
        """
        expect = "Error on line 3 col 20: int"
        self.assertTrue(TestParser.checkParser(input,expect,261))
    def test_return_3(self):
        """Return Statement"""
        input = """
        int main () {
             return arr[3];   
        }
        """
        expect = "successful"
        self.assertTrue(TestParser.checkParser(input,expect,262))
    def test_return_4(self):
        """Return Statement"""
        input = """
        int main () {
             return foo(2,3%5);   
        }
        """
        expect = "successful"
        self.assertTrue(TestParser.checkParser(input,expect,264))
#EXPRESSION STATEMENT
    def test_expStatemt_0(self):
        """Expression Statement"""
        input = """
        int main () {
             foo(1,2+1%5);   
        }
        """
        expect = "successful"
        self.assertTrue(TestParser.checkParser(input,expect,265))
    def test_expStatemt_1(self):
        """Expression Statement"""
        input = """
        int main () {
             foo(1,2+1%5) 
        }
        """
        expect = "Error on line 4 col 8: }"
        self.assertTrue(TestParser.checkParser(input,expect,266))
    def test_expStatemt_2(self):
        """Expression Statement"""
        input = """
        int main () {
             1.68e-32;
             abcd;
             arr[7] == 3e8;
        }
        """
        expect = "successful"
        self.assertTrue(TestParser.checkParser(input,expect,267))
    def test_expStatemt_3(self):
        """Expression Statement"""
        input = """
        int goo () { 
            int a,b;
            (ab==c) && (!true);
        }
        """
        expect = "successful"
        self.assertTrue(TestParser.checkParser(input,expect,268))
#BLOCK STATEMENT
    def test_blockStatement_0(self):
        """Block Statement"""
        input = """
        int main () { 
            int a ,b, c ; 
            a=b=c=5; 
            float f [ 5 ] ; 
            if (a==b) f [0] = 1.0; 
        }
        """
        expect = "successful"
        self.assertTrue(TestParser.checkParser(input,expect,269))
#MULTI 
    def test_mix_0(self):
        """Mix"""
        input = """
        int main(){
                 a[b[2]] = 10;
                 name();
                 return;
            }
        """
        expect = "successful"
        self.assertTrue(TestParser.checkParser(input,expect,270))
    def test_mix_1(self):
        """Mix"""
        input = """
        int main(){
			int j;
			j = arr[10 / 5];
        """
        expect = "Error on line 5 col 8: <EOF>"
        self.assertTrue(TestParser.checkParser(input,expect,271))
    def test_mix_2(self):
        """Mix """
        input = """
        int main(){
			int x;
			float[] nah(){
				int s;
                float[] a;
                {
                    if (s > 10) return a;
					else do
                        a = a + 1;
                        while(true);
                }
			}
        """
        expect = "Error on line 4 col 8: ["
        self.assertTrue(TestParser.checkParser(input,expect,272))
    def test_mix_3(self):
        """Mix """
        input = """
			float[] nah(){
				int s;
                float[] a;
                {
                    if (s > 10) return a;
					else do
                        a = a + 1;
                        while(true);
                }
        """
        expect = "Error on line 4 col 21: ["
        self.assertTrue(TestParser.checkParser(input,expect,273))
    def test_mix_4(self):
        """Mix """
        input = """
			float[] nah(){
				int s;
                {
                    if (s > 10) break;
					else do
                        a = a + 1;
                        while(true);
                }
            }
        """
        expect = "successful"
        self.assertTrue(TestParser.checkParser(input,expect,274))
    def test_mix_5(self):
        """Mix """
        input = """
			float[] nah(){
				int s;
                {
                    if (s > 10) continue;
					else do
                        a = a + 1;
                        while(true);
                }
            }
        """
        expect = "successful"
        self.assertTrue(TestParser.checkParser(input,expect,275))
    def test_mix_6(self):
        """Mix """
        input = """
			float[] nah(){
				int s;
                {
                    if (s > 10) continue;
					else do
                        a = a + 1;
                        while(true);
                }
            
        """
        expect = "Error on line 11 col 8: <EOF>"
        self.assertTrue(TestParser.checkParser(input,expect,276))
    def test_mix_7(self):
        """Mix """
        input = """
			float[] nah(){
				int s;
                {
                    if (s > 10) continue;
					else do
                        a = a + 1;
                        while(true);
                
            }
            
        """
        expect = "Error on line 12 col 8: <EOF>"
        self.assertTrue(TestParser.checkParser(input,expect,277))
    def test_mix_8(self):
        """Mix """
        input = """
			int main(){
                float[] f;
            }
            
        """
        expect = "Error on line 3 col 21: ["
        self.assertTrue(TestParser.checkParser(input,expect,278))
    def test_mix_9(self):
        """Mix """
        input = """
			int[] fighting(,){}
            
        """
        expect = "Error on line 2 col 18: ,"
        self.assertTrue(TestParser.checkParser(input,expect,279))
    def test_mix_10(self):
        """Mix """
        input = """
			int[] fighting(int i = 2, float a){}
            
        """
        expect = "Error on line 2 col 24: ="
        self.assertTrue(TestParser.checkParser(input,expect,280))
    def test_mix_11(self):
        """Mix """
        input = """
			int[] fighting(int i, float a){}
            if(true) {}
                else {}
        """
        expect = "Error on line 3 col 12: if"
        self.assertTrue(TestParser.checkParser(input,expect,281))
    def test_mix_12(self):
        """Mix """
        input = """
			int[] fighting(int i, float a){}
            if(true) {}
                else {}
            do 
                    a = a-1;
                    break;
                    do f = sqrt(a*a + b*b + c*c);
                        if (true) { break; }
                        else {}
                    while (a>0);
                while (a!=b) ;
        """
        expect = "Error on line 3 col 12: if"
        self.assertTrue(TestParser.checkParser(input,expect,282))
    def test_mix_13(self):
        """Mix """
        input = """
			void swap(int a, int b){ 
                int tmp;
                tmp = a;
                a = b;
                b = tmp;
            }
        """
        expect = "successful"
        self.assertTrue(TestParser.checkParser(input,expect,283))
    def test_mix_14(self):
        """Mix """
        input = """
			void swap(int[] a, int[] b){ 
                int tmp;
                tmp = a;
                a = b;
                b = tmp;
            }
        """
        expect = "Error on line 2 col 16: ["
        self.assertTrue(TestParser.checkParser(input,expect,284))
    def test_mix_15(self):
        """Mix """
        input = """
			void swap(int a, int b){ 
                int[] tmp;
                tmp = a;
                a = b;
                b = tmp;
            }
        """
        expect = "Error on line 3 col 19: ["
        self.assertTrue(TestParser.checkParser(input,expect,285))
#COMMENTS TEST
    def test_comment_0(self):
        """Comment """
        input = """
			void function_name(int a) 
            { 
                {}  //Function Body 
                return;  //Function execution would get terminated 
            }   
        """
        expect = "successful"
        self.assertTrue(TestParser.checkParser(input,expect,286))
    def test_comment_1(self):
        """Comment"""
        input = """
			void function_name(int a) 
            { 
                /*
                {foo
                foo
                foo
                foo
                } */ //Function Body 
                return;  //Function execution would get terminated 
            }   
        """
        expect = "successful"
        self.assertTrue(TestParser.checkParser(input,expect,287))
    def test_comment_2(self):
        """Comment """
        input = """
			void function_name(int a) 
            { 
                /*
                {foo
                foo
                foo
                foo
                }  //Function Body 
                return;  //Function execution would get terminated 
            }   
        """
        expect = "Error on line 4 col 16: /"
        self.assertTrue(TestParser.checkParser(input,expect,288))
    def test_comment_3(self):
        """Comment """
        input = """
			void function_name(int a) 
            { 
                /*
                {foo
                foo
                foo
                foo
                } */ Function Body 
                return;  //Function execution would get terminated 
            }   
        """
        expect = "Error on line 9 col 30: Body"
        self.assertTrue(TestParser.checkParser(input,expect,289))
    def test_comment_4(self):
        """Comment """
        input = """
			void function_name(int a) 
            { 
                int\ta;
                // Function Body 
                return;  //Function execution would get terminated 
            }   
        """
        expect = "successful"
        self.assertTrue(TestParser.checkParser(input,expect,290))
    def test_comment_5(self):
        """Comment """
        input = """
			void function_name(int a) 
            { 
                i\tn\tt a;
                // Function Body 
                return;  //Function execution would get terminated 
            }   
        """
        expect = "Error on line 4 col 18: n"
        self.assertTrue(TestParser.checkParser(input,expect,291))
    def test_comment_6(self):
        """Comment """
        input = """
			void function_name(int a) 
            { 
                int a;
                // Function Body 
                ret\rurn;  //Function execution would get terminated 
            }   
        """
        expect = "Error on line 6 col 20: urn"
        self.assertTrue(TestParser.checkParser(input,expect,292))
    def test_comment_7(self):
        """Comment """
        input = """
			void function_name(int a) 
            { 
                {foo\n
                foo\n
                } //Function Body 
                return;  //Function execution would get terminated 
            }   
        """
        expect = "Error on line 6 col 16: foo"
        self.assertTrue(TestParser.checkParser(input,expect,293))
    def test_comment_8(self):
        """Comment """
        input = """
			void function_name(int a) 
            { 
                {int foo\n;
                }
            }   
        """
        expect = "successful"
        self.assertTrue(TestParser.checkParser(input,expect,294))
#COMPLEX PROGRAM
    def test_simple_program(self):
        """Simple program: int main() {} """
        input = """int main() {}"""
        expect = "successful"
        self.assertTrue(TestParser.checkParser(input,expect,295))
    def test_simple_program_11(self):
        """special program """
        input = """
        int GT(int num){
            int t,s;
            t = 0; s = 0;
            for(i=0;i<=n;i=i+1)
                t=t+i;
            for(j=1;j<=t;j=j+1)
                gt=gt*j;
                s=s+gt;
        }
        """
        expect = "successful"
        self.assertTrue(TestParser.checkParser(input,expect,296))
    def test_special_0(self):
        """special program """
        input = """
			int a;
            a = .1e2;
            string[] str;
        """
        expect = "Error on line 3 col 12: a"
        self.assertTrue(TestParser.checkParser(input,expect,297))
    def test_special_1(self):
        """special program """
        input = """
            int foo(){
                do 
                    a = a-1;
                    break;
                    do f = sqrt(a*a + b*b + c*c);
                        if ((1>=0)[2] = 2+a[1]+c+("abc"< 0)) { break; }
                        else {}
                    while (a>0);
                while (a!=b) ;
            }
        """
        expect = "successful"
        self.assertTrue(TestParser.checkParser(input,expect,298))
    def test_nested_func(self):
        """special program """
        input = """
        void foo ( int i ) {
            int sth ( float f ){}
        }
        """
        expect = "Error on line 3 col 20: ("
        self.assertTrue(TestParser.checkParser(input,expect,299))