import unittest
from TestUtils import TestParser

class ParserSuite(unittest.TestCase):
    def test_simple_program_0(self):
        """Simple program: int main() {} """
        input = """int main() {}"""
        expect = "successful"
        self.assertTrue(TestParser.checkParser(input,expect,200))

    def test_simple_program_1(self):
        """More complex program"""
        input = """int main () {
            putIntLn(4);
        }"""
        expect = "successful"
        self.assertTrue(TestParser.checkParser(input,expect,201))

    def test_simple_program(self):
        """Simple program: int main() {} """
        input = """int main() {
            // line comment
            /* 
            block comment 
            more comment ...
            */ int t;
        }"""
        expect = "successful"
        self.assertTrue(TestParser.checkParser(input,expect,202))
    
    def test_wrong_miss_close(self):
        """Miss ) int main( {}"""
        input = """int main( {}"""
        expect = "Error on line 1 col 10: {"
        self.assertTrue(TestParser.checkParser(input,expect,203))
    
    def test_wrong_miss_semi(self):
        """Miss ; int main( {}"""
        input = """int test"""
        expect = "Error on line 1 col 8: <EOF>"
        self.assertTrue(TestParser.checkParser(input,expect,204))

    def test_wrong_miss_RP(self):
        """Miss ; int main( {}"""
        input = """int main() {
            int tt[5]; 
        """
        expect = "Error on line 3 col 8: <EOF>"
        self.assertTrue(TestParser.checkParser(input,expect,205))

# Variables declaration

    def test_global_vardecl(self):
        """Global_variables_declare"""
        input = """ 
        boolean x;
        int main () {
            int k;
        }
        """
        expect = "successful"
        self.assertTrue(TestParser.checkParser(input,expect,206))

    def test_exprdecl_vardec(self):
        """declare exp in vardecl"""
        input = """ int main () {
            int x = 3;
        }
        """
        expect = "Error on line 2 col 18: ="
        self.assertTrue(TestParser.checkParser(input,expect,207))
    
    def test_list_vardecl_1(self):
        """list vardecl"""
        input = """ int main () {
            boolean x,y;
        }
        """
        expect = "successful"
        self.assertTrue(TestParser.checkParser(input,expect,208))

    def test_list_vardecl_2(self):
        """list vardecl"""
        input = """ int main () {
            float x,y,a[5];
            int b[10];
        }
        """
        expect = "successful"
        self.assertTrue(TestParser.checkParser(input,expect,209))
    
    def test_list_vardecl_3(self):
        """list vardecl"""
        input = """
        int a[1], b[2], c[3]; 
        int main () {
            string _abc;
        }
        """
        expect = "successful"
        self.assertTrue(TestParser.checkParser(input,expect,210))

    def test_list_vardecl_4(self):
        """wrong_type_vardecl"""
        input = """
        int c, _sum[2];
        void null; 
        int main () {
            string _abc;
        }
        """
        expect = "Error on line 3 col 17: ;"
        self.assertTrue(TestParser.checkParser(input,expect,211))
    
    def test_list_vardecl_5(self):
        """wrong_id_type_match"""
        input = """
        int a[5],l,n;
        float float; 
        int main () {
           return;
        }
        """
        expect = "Error on line 3 col 14: float"
        self.assertTrue(TestParser.checkParser(input,expect,212))

    def test_list_vardecl_6(self):
        """test_vardecl"""
        input = """
        string str[7], arr;
        float _124; 
        int main () {
            int text[5], if;
            return;
        }
        """
        expect = "Error on line 5 col 25: if"
        self.assertTrue(TestParser.checkParser(input,expect,213))
    
#Function declaration

    def test_function_decl_1(self):
        """ wrong_input_function """
        input = """
        void f(int a[10]){
            return;
        }
        int main() {
            return;
        }"""
        expect = "Error on line 2 col 21: 10"
        self.assertTrue(TestParser.checkParser(input,expect,214))

    def test_function_decl_2(self):
        """ wrong_function_declare """
        input = """
        string arr(a[]);
        int main() {
        }"""
        expect = "Error on line 2 col 19: a"
        self.assertTrue(TestParser.checkParser(input,expect,215))

    def test_function_decl_3(self):
        """ wrong_location_declare """
        input = """
        int main() {
            int foo(){}
        }"""
        expect = "Error on line 3 col 19: ("
        self.assertTrue(TestParser.checkParser(input,expect,216))

    def test_function_decl_4(self):
        """ wrong_seperator """
        input = """
        float f(int t, boolean t[]; float n){}
        int main() {
            return;
        }"""
        expect = "Error on line 2 col 34: ;"
        self.assertTrue(TestParser.checkParser(input,expect,217))

    def test_function_decl_5(self):
        """ wrong_miss_{} """
        input = """
        float f(int t, float n)
        int main() {
            return;
        }"""
        expect = "Error on line 3 col 8: int"
        self.assertTrue(TestParser.checkParser(input,expect,218))

    def test_function_decl_6(self):
        """ wrong_type_void """
        input = """
        float call(string n[], void n){}
        int main() {
            return;
        }"""
        expect = "Error on line 2 col 31: void"
        self.assertTrue(TestParser.checkParser(input,expect,219))

    def test_funcdecl_1(self):
        """test_function_declare"""
        input = """
        void cal_sum(){} 
        int main () {
            int x[9];
        }
        """
        expect = "successful"
        self.assertTrue(TestParser.checkParser(input,expect,220))
    
    def test_funcdecl_2(self):
        """test_function_declare"""
        input = """
        void cal_sum(int num) {
            int a;
            int c;
        } 
        int main () {
            int x[9];
        }
        """
        expect = "successful"
        self.assertTrue(TestParser.checkParser(input,expect,221))

    def test_funcdecl_3(self):
        """test_function_declare"""
        input = """
        void cal_array(int t[], int k_arr) {
            float t, k, m[10];
        } 
        int main () {
            int n;
            n = 1 + 2;
        }
        """
        expect = "successful"
        self.assertTrue(TestParser.checkParser(input,expect,222))

    def test_funcdecl_4(self):
        """test_function_declare_wrong"""
        input = """
        void cal_sum(int num[3], float b) {
            num[0] = 1;
        } 
        int main () {
            int x[9];
        }
        """
        expect = "Error on line 2 col 29: 3"
        self.assertTrue(TestParser.checkParser(input,expect,223))

    def test_funcdecl_5(self):
        """test_function_declare"""
        input = """
        void cal_array(float a, string b) {
            return a - b;
        } 
        int main () {
            int n;
            n = 1 + 2;
            cal_array();
        }
        """
        expect = "successful"
        self.assertTrue(TestParser.checkParser(input,expect,224))

    def test_funcdecl_6(self):
        """test_function_declare"""
        input = """
        float cal_mul(int a, float b) {
            return a*b;
        } 
        string a[4];
        int cal_sum(float b, int a){
            return a + b;
        }
        int main () {
            cal_sum();
            return;
        }
        """
        expect = "successful"
        self.assertTrue(TestParser.checkParser(input,expect,225))

    def test_funcdecl_7(self):
        """test_function_declare"""
        input = """
        float[] foo(float a[], float b){
            int a, b, c[7];
            string b;
        }
        boolean t;
        int main () {
            int n;
            n = 1 + 2;
            return 0;
        }
        """
        expect = "successful"
        self.assertTrue(TestParser.checkParser(input,expect,226))
    
    def test_funcdecl_8(self):
        """test_function_declare"""
        input = """
        string[] call(int a[], float n) {
            return call(b, c);
        } 
        boolean foo(boolean d){
            return type_bool[];
        }
        """
        expect = "successful"
        self.assertTrue(TestParser.checkParser(input,expect,227))

# Expressions "priority"
    def test_expression_1(self):
        """ test_expression """
        input = """int main() {
            int a;
            a = 1 + 2;
        }"""
        expect = "successful"
        self.assertTrue(TestParser.checkParser(input,expect,228))
    
    def test_expression_2(self):
        """ wrong_expression_out_function"""
        input = """
        int global_var;
        global_var = 1 + 2;
        int main() {
            int local_var;
            a = 1 + 2;
        }"""
        expect = "Error on line 3 col 8: global_var"
        self.assertTrue(TestParser.checkParser(input,expect,229))
    
    def test_expression_3(self):
        """ test_expression """
        input = """
        float[] cal(int a){
            return a + 3 * 4;
        }
        int main() {
            int local_var;
            3 + 4 = 2 * 6 + (1 - 3);
            return local_var + 1;
        }"""
        expect = "successful"
        self.assertTrue(TestParser.checkParser(input,expect,230))

    def test_expression_4(self):
        """ test_expression """
        input = """
        int main() {
            int local_var;
            local_var = local[1 + x] - 4 * 5;
            min == 15 >= 123 + (1 + 3);
            return local_var + 1;
        }"""
        expect = "successful"
        self.assertTrue(TestParser.checkParser(input,expect,231))
    
    def test_expression_5(self):
        """ test_expression """
        input = """
        int main() {
            int local_var;
            local_var = -56 + 49 % 23 * 4;
            str = 1 || 8 != 2 && (3 / 19);
            return _local && 34;
        }"""
        expect = "successful"
        self.assertTrue(TestParser.checkParser(input,expect,232))

    def test_expression_6(self):
        """ test_expression """
        input = """
        int main() {
            int local_var;
            local = 1 * 4 - 3 - (45 = 34);
            return local_var + 1;
        }"""
        expect = "successful"
        self.assertTrue(TestParser.checkParser(input,expect,233))

    def test_expression_7(self):
        """ test_expression """
        input = """
        int main() {
            int local_var;
            a = !abc + -45 && arr == (3 != 5) > !out;
            return local_var >= 6;
        }"""
        expect = "successful"
        self.assertTrue(TestParser.checkParser(input,expect,234))

    def test_expression_8(self):
        """ test_expression """
        input = """
        int main() {
            (a + b) = !!--!!34 + -!-!(a + b);
            return -local_var;
        }"""
        expect = "successful"
        self.assertTrue(TestParser.checkParser(input,expect,235))
    
    def test_expression_9(self):
        """ wrong_operator_loop """
        input = """
        int main() {
            int local_var[5];
            a >= 3 >= 5;
            return --1 = local_var[] ;
        }"""
        expect = "Error on line 4 col 19: >="
        self.assertTrue(TestParser.checkParser(input,expect,236))

    def test_expression_10(self):
        """ test_expression """
        input = """
        int main() {
            -123 > !(-1 >= 789) == 456;
        }"""
        expect = "successful"
        self.assertTrue(TestParser.checkParser(input,expect,237))

    def test_expression_11(self):
        """ test_expression """
        input = """
        int main() {
            -abc = 12 + true*2 - false % 4;
            return func(12 + 1) >= -!local_var ;
        }"""
        expect = "successful"
        self.assertTrue(TestParser.checkParser(input,expect,238))

    def test_expression_12(self):
        """ test_expression """
        input = """
        int main() {
            int a,c,d[3];
            d[-1 * 34 >= (1 && 1)] == 1;
            return func(12, 4 + 1) >= a[4] ;
        }"""
        expect = "successful"
        self.assertTrue(TestParser.checkParser(input,expect,239))

    def test_expression_13(self):
        """ wrong_order_operator """
        input = """
        int main() {
            int abd123;
            (1 && 33) != -45 + false == 19;
            return func(12, 4 + 1) >= a[4];
        }"""
        expect = "Error on line 4 col 37: =="
        self.assertTrue(TestParser.checkParser(input,expect,240))

    def test_expression_14(self):
        """ wrong_location_expression """
        input = """
        int t;
        t = 10;
        int main() {
            return true;
        }"""
        expect = "Error on line 3 col 8: t"
        self.assertTrue(TestParser.checkParser(input,expect,241))

#Index Expression
    def test_index_expression_1(self):
        """ test_index_expression """
        input = """
        int main() {
            a[1*-3 == 3] = 1 >= !abc[];
        }"""
        expect = "successful"
        self.assertTrue(TestParser.checkParser(input,expect,242))

    def test_index_expression_2(self):
        """ test_index_expression """
        input = """
        int main() {
            foo(2)[3+x] = a[b[2]] + 3;
        }"""
        expect = "successful"
        self.assertTrue(TestParser.checkParser(input,expect,243))

    def test_index_expression_3(self):
        """ test_index_expression """
        input = """
        int main() {
            sum = foo()[5 * foo()] - !tran(5,4)[5 % tran()] + -foo(a[3*b[c]]);
        }"""
        expect = "successful"
        self.assertTrue(TestParser.checkParser(input,expect,244))

    def test_index_expression_4(self):
        """ test_index_expression """
        input = """
        int main() {
            test = arr[1 + foo()] - arr[1 + arr[1]];
        }"""
        expect = "successful"
        self.assertTrue(TestParser.checkParser(input,expect,245))

    def test_index_expression_5(self):
        """ wrong_miss_] """
        input = """
        int main() {
            test[1 + 4*a[3];
        }"""
        expect = "Error on line 3 col 27: ;"
        self.assertTrue(TestParser.checkParser(input,expect,246))

    def test_index_expression_6(self):
        """ wrong_miss_] """
        input = """
        int main() {
            foo] = str()[1];
        }"""
        expect = "Error on line 3 col 15: ]"
        self.assertTrue(TestParser.checkParser(input,expect,247))

    def test_index_expression_7(self):
        """ test_index_expression """
        input = """
        int main() {
            float t;
            t = (a + b)[1 + 3];
        }"""
        expect = "successful"
        self.assertTrue(TestParser.checkParser(input,expect,248))

    def test_index_expression_8(self):
        """ test_index_expression """
        input = """
        int main() {
            string trend; 
            trend = (foo(1) + foo(2))[1+ 5][1 + 9];
        }"""
        expect = "successful"
        self.assertTrue(TestParser.checkParser(input,expect,249))

    def test_index_expression_9(self):
        """ test_index_expression """
        input = """
        int main() {
            float n[6];
            n = foo()[fod(1)][];
            continue;
            break;
        }"""
        expect = "successful"
        self.assertTrue(TestParser.checkParser(input,expect,250))

# Invocation Expression

    def test_invocation_expression_1(self):
        """ test_invocation_expression """
        input = """
        int main() {
            b = poor(-3, a, 1 + b[6]);
        }"""
        expect = "successful"
        self.assertTrue(TestParser.checkParser(input,expect,251))

    def test_invocation_expression_2(self):
        """ test_invocation_expression """
        input = """
        int main() {
            d = poor(-1) + poor()[1 / 3];
        }"""
        expect = "successful"
        self.assertTrue(TestParser.checkParser(input,expect,252))
    
    def test_invocation_expression_3(self):
        """ test_invocation_expression """
        input = """
        string name(int a, float c){}
        int main() {
            name(1, 4 + 3.5) = true;
            return name(1 + b[4])[];
        }"""
        expect = "successful"
        self.assertTrue(TestParser.checkParser(input,expect,253))

    def test_invocation_expression_4(self):
        """ test_invocation_expression """
        input = """
        string call(int a, float c){}
        int main() {
            // test call
            call(1, -3, "string", a);
            return "string";
        }"""
        expect = "successful"
        self.assertTrue(TestParser.checkParser(input,expect,254))

    def test_invocation_expression_5(self):
        """ test_invocation_expression """
        input = """
        float[] float_lit(int a[], string k){}
        int main() {
            int c;
            c = call(1.e3, "string", 1 == 3);
            return false;
        }"""
        expect = "successful"
        self.assertTrue(TestParser.checkParser(input,expect,255))
    
#Statements 

    def test_statement_if(self):
        """ test_statement_if """
        input = """
        int main() {
            if (false) 
                // commemt
                1 + 4 = 5;
            else
                /* comment again
                foo();
                */
                return true;
        }"""
        expect = "successful"
        self.assertTrue(TestParser.checkParser(input,expect,256))

    def test_statement_if_0(self):
        """ test_statement_if """
        input = """
        int main() {
            if () 
                1 = a;
        }"""
        expect = "Error on line 3 col 16: )"
        self.assertTrue(TestParser.checkParser(input,expect,257))

    def test_statement_if_1(self):
        """ test_statement_if """
        input = """
        int main() {
            if (1 + 3 == 4)
                x = 4 + 1;
            else
                x = 1 + 4;
        }"""
        expect = "successful"
        self.assertTrue(TestParser.checkParser(input,expect,258))

    def test_statement_if_2(self):
        """ test_statement_if """
        input = """
        int main() {
            if (a[3] >= 4)
                x = 4 + 1;
        }"""
        expect = "successful"
        self.assertTrue(TestParser.checkParser(input,expect,259))

    def test_statement_if_3(self):
        """ test_statement_if """
        input = """
        int main() {
            if (1 + 3 == 4)
            {
                int t,a[5];
                x = x + 5;
            }
            else
                x = 1 + 4;
        }"""
        expect = "successful"
        self.assertTrue(TestParser.checkParser(input,expect,260))

    def test_statement_if_4(self):
        """ test_statement_if """
        input = """
        int main() {
            if (true == false){

            }
            else
            {

            }
        }"""
        expect = "successful"
        self.assertTrue(TestParser.checkParser(input,expect,261))

    def test_statement_if_5(self):
        """ test_statement_if """
        input = """
        int main() {
            if (call(4)){
                if (call(3)){
                    int t;
                    t = 1 * 3;
                }
            }
            else
            {
                if (false){
                    call(3);
                }
            }
        }"""
        expect = "successful"
        self.assertTrue(TestParser.checkParser(input,expect,262))

    def test_statement_if_6(self):
        """ test_statement_if """
        input = """
        int main() {
            if (true == false){
                return true;
            }
            else
                call(6,7);
        }"""
        expect = "successful"
        self.assertTrue(TestParser.checkParser(input,expect,263))

    def test_statement_if_7(self):
        """ wrong_miss_) """
        input = """
        int main() {
            if (1 + 3 == 4
                return true;
            else
                return false;
        }"""
        expect = "Error on line 4 col 16: return"
        self.assertTrue(TestParser.checkParser(input,expect,264))

    def test_statement_if_8(self):
        """ test_statement_if """
        input = """
        int main() {
            if (true == false)
                return true;
            else
                return false;
        }"""
        expect = "successful"
        self.assertTrue(TestParser.checkParser(input,expect,265))\

    def test_statement_if_9(self):
        """ test_statement_if """
        input = """
        int main() {
            if (main_c()){
                if (x == 4){
                    x = 3;
                }
                else{
                    x = 5;
                }
            }
            else
            {   
                if (x == 9){
                    x = 7;
                }
                else{
                    x = 9;
                }
            }
        }"""
        expect = "successful"
        self.assertTrue(TestParser.checkParser(input,expect,266))

    def test_statement_if_10(self):
        """ test_statement_if """
        input = """
        int main() {
            if (true == false){

            }
            else{

            }
            if (false == true){

            }
            else {

            }
            return false;
        }"""
        expect = "successful"
        self.assertTrue(TestParser.checkParser(input,expect,267))

    def test_statement_if_11(self):
        """ test_statement_if """
        input = """
        int main() {
            if (true == false){

            }
            t = 1 * 1;
            if (main){
                check = 0;
            } else {
                return main;
            }
        }"""
        expect = "successful"
        self.assertTrue(TestParser.checkParser(input,expect,268))

    def test_statement_if_12(self):
        """ test_statement_if """
        input = """
        int main() {
            if (1 + 3)
                return;
            else 
                return 1;
            else 
                return true;
        }"""
        expect = "Error on line 7 col 12: else"
        self.assertTrue(TestParser.checkParser(input,expect,269))
    
    def test_statement_if_13(self):
        """ test_statement_if """
        input = """
        int main() {
            if (1 + 3)
                {
                    {
                        {
                            int a[4];
                            return false;
                        }
                    }
                }
            else 
                {
                    {
                        if (1)
                            return;
                    }
                }
        }"""
        expect = "successful"
        self.assertTrue(TestParser.checkParser(input,expect,270))

    def test_statement_if_14(self):
        """ test_statement_if """
        input = """
        int main() {
            if (1 + 3)
                t = 1 + 2;
                n = 3 + 4;
            else 
                return;
        }"""
        expect = "Error on line 6 col 12: else"
        self.assertTrue(TestParser.checkParser(input,expect,271))

    def test_statement_do_while_1(self):
        """ test_statement_do_while """
        input = """
        int main() {
            do {
                int t;
                t = 1;
            } while true;
        }"""
        expect = "successful"
        self.assertTrue(TestParser.checkParser(input,expect,272))

    def test_statement_do_while_2(self):
        """ test_statement_do_while """
        input = """
        int main() {
            do t = t + 1;
            while true;
        }"""
        expect = "successful"
        self.assertTrue(TestParser.checkParser(input,expect,273))
    
    def test_statement_do_while_3(self):
        """ test_statement_do_while """
        input = """
        int main() {
            do {
            } while true;
        }"""
        expect = "successful"
        self.assertTrue(TestParser.checkParser(input,expect,274))

    def test_statement_do_while_4(self):
        """ test_statement_do_while """
        input = """
        int main() {
            do {
                return 0;
            } while (true);
        }"""
        expect = "successful"
        self.assertTrue(TestParser.checkParser(input,expect,275))
    
    def test_statement_do_while_5(self):
        """ test_statement_do_while """
        input = """
        int main() {
            do {int t;} {t = 1 + 2;} {} 
            while true;
        }"""
        expect = "successful"
        self.assertTrue(TestParser.checkParser(input,expect,276))

    def test_statement_do_while_6(self):
        """ test_statement_do_while """
        input = """
        int main() {
            do {
                if (true)
                    breaks;
                else
                    continue;
            } while true;
        }"""
        expect = "successful"
        self.assertTrue(TestParser.checkParser(input,expect,277))

    def test_statement_do_while_7(self):
        """ test_statement_do_while """
        input = """
        int main() {
            do {
                if (true)
                    do t = t + 1;
                    while false;
                else 
                    return 0;
            } while true;
        }"""
        expect = "successful"
        self.assertTrue(TestParser.checkParser(input,expect,278))

    def test_statement_do_while_8(self):
        """ test_statement_do_while """
        input = """
        int main() {
            do 
                t = 1 + 1;
                int k, n[5];
                string arr;
                call(arrs); 
            while true;
        }"""
        expect = "Error on line 5 col 16: int"
        self.assertTrue(TestParser.checkParser(input,expect,279))
    
    def test_statement_do_while_9(self):
        """ test_statement_do_while """
        input = """
        int main() {
            do 
                train();
                // comment
                train(1);
                if ((1 + 3) == 3 + 1)
                    return;
                else
                    // comment
                    t = 2 + 1;
            while false;
        }"""
        expect = "successful"
        self.assertTrue(TestParser.checkParser(input,expect,280))

    def test_statement_do_while_10(self):
        """ test_statement_do_while """
        input = """
        int main() {
            do
                t =  1 % 1;
                {
                    int t;
                    if (true)
                        return false;
                } 
                break;
            while true;
        }"""
        expect = "successful"
        self.assertTrue(TestParser.checkParser(input,expect,281))

    def test_statement_do_while_11(self):
        """ test_statement_do_while """
        input = """
        int main() {
            do 
            // comment
            break;

            while true;
        }"""
        expect = "successful"
        self.assertTrue(TestParser.checkParser(input,expect,282))

    def test_statement_for_0(self):
        """ test_statement_for """
        input = """
        int main() {
            for (t = 0; t < 10; t = t + 1)
                t = 1;
        }"""
        expect = "successful"
        self.assertTrue(TestParser.checkParser(input,expect,283))
    
    def test_statement_for_1(self):
        """ test_statement_for """
        input = """
        int main() {
            for (1 + 1; 2 + 3; 4 + 4)
                /* block comment
                comment
                comment*/
                continue;
        }"""
        expect = "successful"
        self.assertTrue(TestParser.checkParser(input,expect,284))

    def test_statement_for_2(self):
        """ test_statement_for """
        input = """
        int main() {
            for (t = 0; t < 10; t = t + 1)
                {}
        }"""
        expect = "successful"
        self.assertTrue(TestParser.checkParser(input,expect,285))

    def test_statement_for_3(self):
        """ test_statement_for """
        input = """
        int main() {
            for (t = 0; t < 10; t = t + 1){
                int type;
                type = type + arr[t];
                continue;
            }
        }"""
        expect = "successful"
        self.assertTrue(TestParser.checkParser(input,expect,286))

    def test_statement_for_4(self):
        """ test_statement_for """
        input = """
        int main() {
            for (t = 0; t < call(1), t = t + 1)
                arr[t] = 0;
            return 0;
        }"""
        expect = "Error on line 3 col 35: ,"
        self.assertTrue(TestParser.checkParser(input,expect,287))

    def test_statement_for_5(self):
        """ test_statement_for """
        input = """
        int main() {
            for (i = 0; i < 10 ;)
                arr[i] = i * 1.0;
            return 0;
        }"""
        expect = "Error on line 3 col 32: )"
        self.assertTrue(TestParser.checkParser(input,expect,288))

    def test_statement_for_6(self):
        """ test_statement_for """
        input = """
        int main() {
            for (t = 0; t < 10; t = t + 1){
                for (y == 0; t < 1 + 7; t = t - 1)
                    m = m + y;
            }
        }"""
        expect = "successful"
        self.assertTrue(TestParser.checkParser(input,expect,289))

    def test_statement_for_7(self):
        """ test_statement_for """
        input = """
        int main() {
            for (t = 0; t < 10; t = t + 1){
                do m = m + 1;
                while m != 98;
            }
        }"""
        expect = "successful"
        self.assertTrue(TestParser.checkParser(input,expect,290))

    def test_statement_for_8(self):
        """ test_statement_for """
        input = """
        int main() {
            for (t = 0; t < 10; t = t + 1){
                int y;
                for (y = 9; y < 10; y = y + 1){
                    int k;
                    call(1.8);
                }
            }
        }"""
        expect = "successful"
        self.assertTrue(TestParser.checkParser(input,expect,291))

    def test_statement_for_9(self):
        """ test_statement_for """
        input = """
        int main() {
            for (t = 0; t < 10; t = t + 1){
                if (t >= 0)
                    return true;
                else
                    return false;
                int t;
                call(56);
            }
        }"""
        expect = "successful"
        self.assertTrue(TestParser.checkParser(input,expect,292))

    def test_statement_for_10(self):
        """ test_statement_for """
        input = """
        int main() {
            for (t = 0;; t = t + 1){
                int type;
                type = type + arr[t];
                continue;
            }
        }"""
        expect = "Error on line 3 col 23: ;"
        self.assertTrue(TestParser.checkParser(input,expect,293))
    
    def test_statement_for_11(self):
        """ test_statement_for """
        input = """
        int main() {
            for (t = 0; t < 10; t = t + 1){
                int type;
                type = type + arr[t];
                continue;
            }
        }"""
        expect = "successful"
        self.assertTrue(TestParser.checkParser(input,expect,294))
    
# Complex program
    def test_complex_program_1(self):
        """ test_complex_program """
        input = """
        int foo(int a, float b[])
        {
            boolean c;
            int i;
            i = a + 3;
            if (i > 0){
                int d;
                d = i + 3;
                putInt(d);
            }
            return i;
        }
        """
        expect = "successful"
        self.assertTrue(TestParser.checkParser(input,expect,295))

    def test_complex_program_2(self):
        """ test_complex_program """
        input = """
        void foo(float a[]){}
        void goo(float x[]){
            float y[10];
            int z[10];
            foo(x);
            foo(y);
            foo(z);
            do 
                if (1 > 3) 
                    foo(x) = 1 || 3;
                else
                    for (i = 0; i = 0; i = 1)
                        return true;
            while true;
        }
        """
        expect = "successful"
        self.assertTrue(TestParser.checkParser(input,expect,296))

    def test_complex_program_3(self):
        """ test_complex_program """
        input = """
        int foo(int a, float b[])
        {
            boolean c;
            int i;
            i = a + 3;
            if (i > 0){
                int d;
                d = i + 3;
                putInt(d);
            }
            return i;
        }
        """
        expect = "successful"
        self.assertTrue(TestParser.checkParser(input,expect,297))

    def test_complex_program_4(self):
        """ test_complex_program """
        input = """
        int global;
        int f(){
            return 200;
        }
        int foo(){
            return global;
        }
        int print(int local){
            // comment
            return local;
        }
        void main(){
            for (i = 0; i < 10; i = i + 1){
                int arr[10];
                arr[i] = arr[i] + 1;
            }
            do {
                print(arr[i]);
            } while (arr[i] % 2 == 0);
            return 0;
        }
        """
        expect = "successful"
        self.assertTrue(TestParser.checkParser(input,expect,298))

    def test_complex_program_5(self):
        """ test_complex_program """
        input = """
        int arr[10];
        float arr_float[20];
        string[] text(string ch, string arr_char[]){
            return arr_char;
        }
        void main(){
            int i;
            for (i = 0; i < 10; i = i + 1){
                arr_float[i] = arr[i] * 1;
                if (arr_float[i] == 0){
                    arr_float[i] = 0;
                    break;
                }
            }
            do
                arr_float[i] = 0;
                i = i + 1;
            while i < 10;
        }
        """
        expect = "successful"
        self.assertTrue(TestParser.checkParser(input,expect,299))
    