import unittest
from TestUtils import TestParser


class ParserSuite(unittest.TestCase):
    def test_func_decl_return_fail1(self):
        input= """
        int[] A(boolean a[], int b[]) {

        }
        strin b(boolean a) {

        }
        int main() {
            int a,b,c[5];
        }"""
        expect = "Error on line 5 col 8: strin"
        self.assertTrue(TestParser.checkParser(input, expect, 200))

    def test_simple_program(self):
        """Simple program: int main() {} """
        input = """int main() {int a;}"""
        expect = "successful"
        self.assertTrue(TestParser.checkParser(input, expect, 201))

    def test_more_complex_program(self):
        """More complex program"""
        input = """int main () {
            putIntLn(4);
        }"""
        expect = "successful"
        self.assertTrue(TestParser.checkParser(input, expect, 202))

    def test_wrong_miss_close(self):
        """Miss ) int main( {}"""
        input = """int main( {}"""
        expect = "Error on line 1 col 10: {"
        self.assertTrue(TestParser.checkParser(input, expect, 203))

    def test_variable_declaration(self):
        """Test variable declare"""
        input = """int main(){
            int abc;
        }"""
        expect = "successful"
        self.assertTrue(TestParser.checkParser(input, expect, 204))

    def test_no_function_declare(self):
        """Test no function declare"""
        input = """int a;"""
        expect = "successful"
        self.assertTrue(TestParser.checkParser(input, expect, 205))
    
    def test_no_function_declare_array(self):
        """Test no function declare array"""
        input = """int a[5];"""
        expect = "successful"
        self.assertTrue(TestParser.checkParser(input, expect, 206))

    def test_empty(self):
        """Test empty"""
        input = """"""
        expect = "Error on line 1 col 0: <EOF>"
        self.assertTrue(TestParser.checkParser(input, expect, 207))

    def test_no_id_var_decl(self):
        input= """int ;"""
        expect = "Error on line 1 col 4: ;"
        self.assertTrue(TestParser.checkParser(input, expect, 208))

    def test_statement_no_func(self):
        input= """if (a) {} else {}"""
        expect = "Error on line 1 col 0: if"
        self.assertTrue(TestParser.checkParser(input, expect, 209))

    def test_missing_bracket(self):
        input= """void main() {
            """
        expect = "Error on line 2 col 12: <EOF>"
        self.assertTrue(TestParser.checkParser(input, expect, 210))

    def test_initialize_decl_fail(self):
        input= """void main() {
                string s = "abc\\n";
            }"""
        expect = "Error on line 2 col 25: ="
        self.assertTrue(TestParser.checkParser(input, expect, 211))

    def test_decl(self):
        input= """void main() {
                string s;
                s = "abc\\n";
            }"""
        expect = "successful"
        self.assertTrue(TestParser.checkParser(input, expect, 212))

    def test_unclose(self):
        input= """void main() {
                string s;
                s = "abc\\n;
            }"""
        expect = "abc\\n;"
        self.assertTrue(TestParser.checkParser(input, expect, 213))

    def test_illegal(self):
        input= """void main() {
                string s;
                s = "abc\\a";
            }"""
        expect = "abc\\a"
        self.assertTrue(TestParser.checkParser(input, expect, 214))

    def test_decl_array_error(self):
        input= """void main() {
                int a[];
            }"""
        expect = "Error on line 2 col 22: ]"
        self.assertTrue(TestParser.checkParser(input, expect, 215))

    def test_decl_array_succ(self):
        input= """void main() {
                int a[5];
            }"""
        expect = "successful"
        self.assertTrue(TestParser.checkParser(input, expect, 216))

    def test_multi_bracket(self):
        input= """
        int main() {
            ba = ((((((((((((((((((((((((a))))))))))))))))))))))));
        }"""
        expect = "successful"
        self.assertTrue(TestParser.checkParser(input, expect, 217))

    def test_missing_multi_bracket(self):
        input= """
        int main() {
            ba = ((((((((((((((((((((((((a)))))))))))))))))))))));
        }"""
        expect = "Error on line 3 col 65: ;"
        self.assertTrue(TestParser.checkParser(input, expect, 218))

    def test_multi_bracket1(self):
        input= """
        int main() {
            {{{{{{{{{{{{{{{{ba = ((((((((((((((((((((((((a))))))))))))))))))))))));}}}}}}}}}}}}}}}}
        }"""
        expect = "successful"
        self.assertTrue(TestParser.checkParser(input, expect, 219))

    def test_multi_variable_decl(self):
        input= """
        int main() {
            int a,b,c[5];
        }"""
        expect = "successful"
        self.assertTrue(TestParser.checkParser(input, expect, 220))

    def test_decl_array_error1(self):
        input= """
        int main() {
            int a,b,c[a+b];
        }"""
        expect = "Error on line 3 col 22: a"
        self.assertTrue(TestParser.checkParser(input, expect, 221))

    def test_func_decl(self):
        input= """
        void A() {

        }
        string b(boolean a) {

        }
        int main() {
            int a,b,c[5];
        }"""
        expect = "successful"
        self.assertTrue(TestParser.checkParser(input, expect, 222))

    def test_func_decl_multi_param_error(self):
        input= """
        void A(boolean a,b) {

        }
        string b(boolean a) {

        }
        int main() {
            int a,b,c[5];
        }"""
        expect = "Error on line 2 col 25: b"
        self.assertTrue(TestParser.checkParser(input, expect, 223))

    def test_func_decl_multi_param(self):
        input= """
        void A(boolean a, int b) {

        }
        string b(boolean a) {

        }
        int main() {
            int a,b,c[5];
        }"""
        expect = "successful"
        self.assertTrue(TestParser.checkParser(input, expect, 224))

    def test_func_decl_multi_param1(self):
        input= """
        void A(boolean a[], int b[]) {

        }
        string b(boolean a) {

        }
        int main() {
            int a,b,c[5];
        }"""
        expect = "successful"
        self.assertTrue(TestParser.checkParser(input, expect, 225))

    def test_func_decl_return_fail(self):
        input= """
        void[] A(boolean a[], int b[]) {

        }
        string b(boolean a) {

        }
        int main() {
            int a,b,c[5];
        }"""
        expect = "Error on line 2 col 12: ["
        self.assertTrue(TestParser.checkParser(input, expect, 226))

    def test_func_decl_return(self):
        input= """
        int[] A(boolean a[], int b[]) {

        }
        string b(boolean a) {

        }
        int main() {
            int a,b,c[5];
        }"""
        expect = "successful"
        self.assertTrue(TestParser.checkParser(input, expect, 227))

    def test_func_decl_multiblock(self):
        input= """
        int[] A(boolean a[], int b[]) {{{{{{{{{{{{{

        }}}}}}}}}}}}}
        string b(boolean a) {

        }
        int main() {
            int a,b,c[5];
        }"""
        expect = "successful"
        self.assertTrue(TestParser.checkParser(input, expect, 228))

    def test_func_decl_in_func(self):
        input= """
        int[] A(boolean a[], int b[]) {{{{{{{{{{{{{

        }}}}}}}}}}}}}
        string b(boolean a) {
            int a(){

            }
        }
        int main() {
            int a,b,c[5];
        }"""
        expect = "Error on line 6 col 17: ("
        self.assertTrue(TestParser.checkParser(input, expect, 229))

    def test_func_decl_in_func1(self):
        input= """
        string b(boolean a) {
            (foo(3)-goo(0))[2]; 
            a==b<c;
        }
        int main() {
            int a,b,c[5];
        }"""
        expect = "successful"
        self.assertTrue(TestParser.checkParser(input, expect, 230))

    def test_func_decl_logic_expression(self):
        input= """
        string b(boolean a) {
            (foo(3)-goo(0))[2]; 
            a==b<c;
        }
        int main() {
            int a,b,c[5];
        }"""
        expect = "successful"
        self.assertTrue(TestParser.checkParser(input, expect, 231))

    def test_func_decl_logic_add_expr(self):
        input= """
        string b(boolean a) {
            2<3+5;
        }
        int main() {
            int a,b,c[5];
        }"""
        expect = "successful"
        self.assertTrue(TestParser.checkParser(input, expect, 232))
    
    def test_func_decl_multi_bracket(self):
        input= """
        string b(boolean a) {
            (foo(foo(foo(foo(foo(0))))));
        }
        int main() {
            int a,b,c[5];
        }"""
        expect = "successful"
        self.assertTrue(TestParser.checkParser(input, expect, 233))

    def test_func_decl_ignore_escape(self):
        input= """
        string b(boolean a) {\f \r \n
            (foo(foo(foo(foo(foo(0))))));
        }
        int main() {
            int a,b,c[5];
        }"""
        expect = "successful"
        self.assertTrue(TestParser.checkParser(input, expect, 234))

    def test_func_decl_with_comment(self):
        input= """
        string b(boolean a) {\f \r \n
            (foo(foo(foo(foo(foo(0))))));
            //this is comment
        }
        int main() {
            int a,b,c[5];
        }"""
        expect = "successful"
        self.assertTrue(TestParser.checkParser(input, expect, 235))

    def test_func_decl_with_comment1(self):
        input= """
        string b(boolean a) {\f \r \n
            (foo(foo(foo(foo(foo(0))))));
            //this is comment
        //}
        int main() {
            int a,b,c[5];
        }"""
        expect = "Error on line 7 col 16: ("
        self.assertTrue(TestParser.checkParser(input, expect, 236))

    def test_func_decl_with_comment2(self):
        input= """
        string b(boolean a) {\f \r \n
            (foo(foo(foo(foo(foo(0))))));
            //this is comment
        //}
        /*int main() {
            int a,b,c[5];*/
        }"""
        expect = "successful"
        self.assertTrue(TestParser.checkParser(input, expect, 237))

    def test_func_decl_with_comment3(self):
        input= """
        string b(boolean a) {\f \r \n
            (foo(foo(foo(foo(foo(0))))));
            //this is comment
        //}
        /*int main() {
        //    int a,b,c[5];*/
        }"""
        expect = "successful"
        self.assertTrue(TestParser.checkParser(input, expect, 238))

    def test_func_decl_with_comment4(self):
        input= """
        string b(boolean a) {\f \r \n
            (foo(foo(foo(foo(foo(0))))));
            //this is comment
        //}
        ///*int main() {
            int a,b,c[5];*/
        }"""
        expect = "Error on line 8 col 25: *"
        self.assertTrue(TestParser.checkParser(input, expect, 239))

    def test_string_lit(self):
        input= """
        string b(boolean a) {
            string a = "ab\\c";
        }"""
        expect = "ab\c"
        self.assertTrue(TestParser.checkParser(input, expect, 240))

    def test_string_lit1(self):
        input= """
        string b(boolean a) {
            string a = "ab\c";
        }"""
        expect = "ab\c"
        self.assertTrue(TestParser.checkParser(input, expect, 241))

    def test_string_lit2(self):
        input= """
        string b(boolean a) {
            string a;
            a = "ab\\c"
        }"""
        expect = "ab\c"
        self.assertTrue(TestParser.checkParser(input, expect, 242))

    def test_string_lit3(self):
        input= """
        string b(boolean a) {
            string a;
            a = "ab\\r\\n";
        }"""
        expect = "successful"
        self.assertTrue(TestParser.checkParser(input, expect, 243))

    def test_string_lit4(self):
        input= """
        string b(boolean a) {
            string a;
            a = "ab\\r\\n
            ";
        }"""
        expect = "ab\\r\\n"
        self.assertTrue(TestParser.checkParser(input, expect, 244))

    def test_string_lit5(self):
        input= """
        string b(boolean a) {
            string a;
            a = "ab\\r\\n
            ";
        }"""
        expect = "ab\\r\\n"
        self.assertTrue(TestParser.checkParser(input, expect, 245))

    def test_decl_with_init(self):
        input= """
        string b(boolean a) {
            boolean a[2] = {true,false};
        }"""
        expect = "Error on line 3 col 25: ="
        self.assertTrue(TestParser.checkParser(input, expect, 246))

    def test_expr(self):
        input= """
        string b(boolean a) {
            a[2];
        }"""
        expect = "successful"
        self.assertTrue(TestParser.checkParser(input, expect, 247))

    def test_expr1(self):
        input= """
        string b(boolean a) {
            -a[2];
        }"""
        expect = "successful"
        self.assertTrue(TestParser.checkParser(input, expect, 248))

    def test_expr2(self):
        input= """
        string b(boolean a) {
            -!a[2];
        }"""
        expect = "successful"
        self.assertTrue(TestParser.checkParser(input, expect, 249))

    def test_expr3(self):
        input= """
        string b(boolean a) {
            -!a[2] + a - a / a * a % (a < a) + (a <= a) + (a >= a) + (a > a) == a != a && a || a = a;
        }"""
        expect = "Error on line 3 col 82: !="
        self.assertTrue(TestParser.checkParser(input, expect, 250))

    def test_expr4(self):
        input= """
        string b(boolean a) {
            -!a[2] + a - a / a * a % (a < a) + (a <= a) + (a >= a) + ((a > a) == a) + (a != a) && a || a = a;
        }"""
        expect = "successful"
        self.assertTrue(TestParser.checkParser(input, expect, 251))

    def test_expr5(self):
        input= """
        string b(boolean a) {
            -!a[2] + a(a(a(a(2))))[2] - a / a * a % (a < a) + (a <= a) + (a >= a) + ((a > a) == a) + (a != a) && a || a = a;
        }"""
        expect = "successful"
        self.assertTrue(TestParser.checkParser(input, expect, 252))

    def test_expr6(self):
        input= """
        string b(boolean a) {
            -!a[2] + a(a(a(a(2))))[2] - a / a * a % (a < a) + (a <= a) + (a >= a) + ((a > a) == a) + (a != a) && a || a = a;
            fo[fo[fo[fo[fo[fo[fo[fo[3]]]]]]]];
        }"""
        expect = "successful"
        self.assertTrue(TestParser.checkParser(input, expect, 253))
    
    def test_expr7(self):
        input= """
        string b(boolean a) {
            -!a[2] + a(a(a(a(2))))[2] - a / a * a % (a < a) + (a <= a) + (a >= a) + ((a > a) == a) + (a != a) && a || a = a;
            fo[fo[fo[fo[fo[fo[fo[fo[]]]]]]]];
        }"""
        expect = "Error on line 4 col 36: ]"
        self.assertTrue(TestParser.checkParser(input, expect, 254))

    def test_expr8(self):
        input= """
        string b(boolean a) {
            -!a[2] + a(a(a(a(2))))[2] - a / a * a % (a < a) + (a <= a) + (a >= a) + ((a > a) == a) + (a != a) && a || a = a;
            fo[fo[fo[fo[fo[fo[fo[fo[a(2)+b(3)]]]]]]]];
        }"""
        expect = "successful"
        self.assertTrue(TestParser.checkParser(input, expect, 255))

    def test_expr9(self):
        input= """
        string b(boolean a) {
            -!a[2] + a(a(a(a(2))))[2] - a / a * a % (a < a) + (a <= a) + (a >= a) + ((a > a) == a) + (a != a) && a || a = a;
            fo[fo[fo[fo[fo[fo[fo[fo[a(2)+b(3)]]]]]]]];
            a(((((((((((((((((((((((((((((((((((((((((((((((((((((((a)))))))))))))))))))))))))))))))))))))))))))))))))))))));
        }"""
        expect = "successful"
        self.assertTrue(TestParser.checkParser(input, expect, 256))

    def test_expr10(self):
        input= """
        string b(boolean a) {
            -!a[2] + a(a(a(a(2))))[2] - a / a * a % (a < a) + (a <= a) + (a >= a) + ((a > a) == a) + (a != a) && a || a = a;
            fo[fo[fo[fo[fo[fo[fo[fo[a(2)+b(3)]]]]]]]];
            a(((((((((((((((((((((((((((((((((((((((((((((((((((((((a)))))))))))))))))))))))))))))))))))))))))))))))))))))));
        }"""
        expect = "successful"
        self.assertTrue(TestParser.checkParser(input, expect, 257))

    def test_func_decl1(self):
        input= """
        string b(boolean a[2]) {
            -!a[2] + a(a(a(a(2))))[2] - a / a * a % (a < a) + (a <= a) + (a >= a) + ((a > a) == a) + (a != a) && a || a = a;
            fo[fo[fo[fo[fo[fo[fo[fo[a(2)+b(3)]]]]]]]];
            a(((((((((((((((((((((((((((((((((((((((((((((((((((((((a)))))))))))))))))))))))))))))))))))))))))))))))))))))));
        }"""
        expect = "Error on line 2 col 27: 2"
        self.assertTrue(TestParser.checkParser(input, expect, 258))

    def test_func_call(self):
        input= """
        string b(boolean a[]) {
            f();
        }"""
        expect = "successful"
        self.assertTrue(TestParser.checkParser(input, expect, 259))

    def test_func_call1(self):
        input= """
        string b(boolean a[]) {
            f(a+2);
        }"""
        expect = "successful"
        self.assertTrue(TestParser.checkParser(input, expect, 260))

    def test_func_call2(self):
        input= """
        string b(boolean a[]) {
            f(a+2,);
        }"""
        expect = "Error on line 3 col 18: )"
        self.assertTrue(TestParser.checkParser(input, expect, 261))

    def test_func_call3(self):
        input= """
        string b(boolean a[]) {
            f(a+2,a);
        }"""
        expect = "successful"
        self.assertTrue(TestParser.checkParser(input, expect, 262))

    def test_statement_return(self):
        input= """
        string b(boolean a[]) {
            f(a+2,a);
            return a;
        }"""
        expect = "successful"
        self.assertTrue(TestParser.checkParser(input, expect, 263))

    def test_statement_if(self):
        input= """
        string b(boolean a[]) {
            f(a+2,a);
            return a;
            if (a) {}
        }"""
        expect = "successful"
        self.assertTrue(TestParser.checkParser(input, expect, 264))

    def test_statement_if_else(self):
        input= """
        string b(boolean a[]) {
            f(a+2,a);
            return a;
            if (a) {}
            else {}
        }"""
        expect = "successful"
        self.assertTrue(TestParser.checkParser(input, expect, 265))

    def test_statement_if_else_nest(self):
        input= """
        string b(boolean a[]) {
            f(a+2,a);
            return a;
            if (a) {}
                if (a) {}
                else {}
        }"""
        expect = "successful"
        self.assertTrue(TestParser.checkParser(input, expect, 266))

    def test_statement_if_else_nest_complete_fail(self):
        input= """
        string b(boolean a[]) {
            f(a+2,a);
            return a;
            if (a) {}
                if (a) {}
                else {}
            else {}
        }"""
        expect = "Error on line 8 col 12: else"
        self.assertTrue(TestParser.checkParser(input, expect, 267))

    def test_statement_if_else_nest_complete(self):
        input= """
        string b(boolean a[]) {
            f(a+2,a);
            return a;
            if (a) 
                if (a) {}
                else {}
            else {}
        }"""
        expect = "successful"
        self.assertTrue(TestParser.checkParser(input, expect, 268))

    def test_statement_if_else_nest_incomplete(self):
        input= """
        string b(boolean a[]) {
            f(a+2,a);
            return a;
            if (a) {
                if (a) {}
            }    
            else {}
        }"""
        expect = "successful"
        self.assertTrue(TestParser.checkParser(input, expect, 269))

    def test_statement_do_while_nobody(self):
        input= """
        string b(boolean a[]) {
            do
            
            while (1);
        }"""
        expect = "Error on line 5 col 12: while"
        self.assertTrue(TestParser.checkParser(input, expect, 270))

    def test_statement_do_while(self):
        input= """
        string b(boolean a[]) {
            do
            a;
            while (1);
        }"""
        expect = "successful"
        self.assertTrue(TestParser.checkParser(input, expect, 271))

    def test_statement_do_while1(self):
        input= """
        string b(boolean a[]) {
            do
            a;
            b;
            while (1);
        }"""
        expect = "successful"
        self.assertTrue(TestParser.checkParser(input, expect, 272))

    def test_statement_do_while2(self):
        input= """
        string b(boolean a[]) {
            do
            {}
            {}
            {}
            while (1);
        }"""
        expect = "successful"
        self.assertTrue(TestParser.checkParser(input, expect, 273))

    def test_statement_for(self):
        input= """
        string b(boolean a[]) {
            for (a;a;a) {}
        }"""
        expect = "successful"
        self.assertTrue(TestParser.checkParser(input, expect, 274))

    def test_statement_for_missing_expr(self):
        input= """
        string b(boolean a[]) {
            for (a;;a) {}
        }"""
        expect = "Error on line 3 col 19: ;"
        self.assertTrue(TestParser.checkParser(input, expect, 275))

    def test_statement_for_init_var(self):
        input= """
        string b(boolean a[]) {
            for (int a=0;a;a) {}
        }"""
        expect = "Error on line 3 col 17: int"
        self.assertTrue(TestParser.checkParser(input, expect, 276))

    def test_statement_break(self):
        input= """
        string b(boolean a[]) {
            for (a;a;a) {break;}
        }"""
        expect = "successful"
        self.assertTrue(TestParser.checkParser(input, expect, 277))

    def test_statement_continue(self):
        input= """
        string b(boolean a[]) {
            for (a;a;a) {continue;}
        }"""
        expect = "successful"
        self.assertTrue(TestParser.checkParser(input, expect, 278))

    def test_statement_block(self):
        input= """
        string b(boolean a[]) {
            for (a;a;a) {{{{{{{{{continue;{{{{{{{{{{}{{{{{{}}}}}}}}}}}}}}}}}}}}}}}}
        }"""
        expect = "successful"
        self.assertTrue(TestParser.checkParser(input, expect, 279))

    def test_mixed(self):
        input= """
        string b(boolean a[]) {
            for (a;a;a) {{{{{{{{{continue;{{{{{{{{{{}{{{{{{}}}}}}}}}}}}}}}}}}}}}}}}
        }
        string b(boolean a[]) {
            for (a;a;a) {continue;}
        }"""
        expect = "successful"
        self.assertTrue(TestParser.checkParser(input, expect, 280))

    def test_mixed1(self):
        input= """
        string b(boolean a[]) {
            for (a;a;a) {{{{{{{{{continue;{{{{{{{{{{}{{{{{{}}}}}}}}}}}}}}}}}}}}}}}}
        }
        string b(boolean a[]) {
            for (a;a;a) {continue;}
        }
        string b(boolean a[]) {
            for (a;a;a) {break;}
        }"""
        expect = "successful"
        self.assertTrue(TestParser.checkParser(input, expect, 281))

    def test_mixed2(self):
        input= """
        string b(boolean a[]) {
            for (a;a;a) {{{{{{{{{continue;{{{{{{{{{{}{{{{{{}}}}}}}}}}}}}}}}}}}}}}}}
        }
        string b(boolean a[]) {
            for (a;a;a) {continue;}
        }
        string b(boolean a[]) {
            for (a;a;a) {break;}
        }
        string b(boolean a[]) {
            for (int a=0;a;a) {}
        }
        """
        expect = "Error on line 12 col 17: int"
        self.assertTrue(TestParser.checkParser(input, expect, 282))

    def test_mixed3(self):
        input= """
        string b(boolean a[]) {
            for (a;a;a) {{{{{{{{{continue;{{{{{{{{{{}{{{{{{}}}}}}}}}}}}}}}}}}}}}}}}
        }
        string b(boolean a[]) {
            for (a;a;a) {continue;}
        }
        string b(boolean a[]) {
            for (a;a;a) {break;}
        }
        string b(boolean a[]) {
            for (a=0;a;a) {}
        }
        string b(boolean a[]) {
            for (a;;a) {}
        }
        """
        expect = "Error on line 15 col 19: ;"
        self.assertTrue(TestParser.checkParser(input, expect, 283))

    def test_mixed4(self):
        input= """
        string b(boolean a[]) {
            for (a;a;a) {{{{{{{{{continue;{{{{{{{{{{}{{{{{{}}}}}}}}}}}}}}}}}}}}}}}}
        }
        string b(boolean a[]) {
            for (a;a;a) {continue;}
        }
        string b(boolean a[]) {
            for (a;a;a) {break;}
        }
        string b(boolean a[]) {
            for (a=0;a;a) {}
        }
        string b(boolean a[]) {
            for (a;a<a;a) {}
        }
        """
        expect = "successful"
        self.assertTrue(TestParser.checkParser(input, expect, 284))

    def test_mixed5(self):
        input= """
        string b(boolean a[]) {
            for (a;a;a) {{{{{{{{{continue;{{{{{{{{{{}{{{{{{}}}}}}}}}}}}}}}}}}}}}}}}
        }
        string b(boolean a[]) {
            for (a;a;a) {continue;}
        }
        string b(boolean a[]) {
            for (a;a;a) {break;}
        }
        string b(boolean a[]) {
            for (a=0;a;a) {}
        }
        string b(boolean a[]) {
            for (a;a<a;a) {}
        }
        string b(boolean a[]) {
            do
            {}
            {}
            {}
            while (1);
        }
        """
        expect = "successful"
        self.assertTrue(TestParser.checkParser(input, expect, 285))

    def test_mixed6(self):
        input= """
        string b(boolean a[]) {
            for (a;a;a) {{{{{{{{{continue;{{{{{{{{{{}{{{{{{}}}}}}}}}}}}}}}}}}}}}}}}
        }
        string b(boolean a[]) {
            for (a;a;a) {continue;}
        }
        string b(boolean a[]) {
            for (a;a;a) {break;}
        }
        string b(boolean a[]) {
            for (a=0;a;a) {}
        }
        string b(boolean a[]) {
            for (a;a<a;a) {}
        }
        string b(boolean a[]) {
            do
            {}
            {}
            {}
            while (1);
        }
        string b(boolean a[]) {
            f(a+2,a);
            return a;
            if (a) 
                if (a) {}
                else {}
            else {}
        }
        """
        expect = "successful"
        self.assertTrue(TestParser.checkParser(input, expect, 286))

    def test_mixed7(self):
        input= """
        string b(boolean a[]) {
            for (a;a;a) {{{{{{{{{continue;{{{{{{{{{{}{{{{{{}}}}}}}}}}}}}}}}}}}}}}}}
        }
        string b(boolean a[]) {
            for (a;a;a) {continue;}
        }
        string b(boolean a[]) {
            for (a;a;a) {break;}
        }
        string b(boolean a[]) {
            for (a=0;a;a) {}
        }
        string b(boolean a[]) {
            for (a;a<a;a) {}
        }
        string b(boolean a[]) {
            do
            {}
            {}
            {}
            while (1);
        }
        string b(boolean a[]) {
            f(a+2,a);
            return a;
            if (a) 
                if (a) {}
                else {}
            else {}
        }
        string b(boolean a[]) {
            f(a+2,a);
        }
        """
        expect = "successful"
        self.assertTrue(TestParser.checkParser(input, expect, 287))
    
    def test_mixed8(self):
        input= """
        string b(boolean a[]) {
            for (a;a;a) {{{{{{{{{continue;{{{{{{{{{{}{{{{{{}}}}}}}}}}}}}}}}}}}}}}}}
        }
        string b(boolean a[]) {
            for (a;a;a) {continue;}
        }
        string b(boolean a[]) {
            for (a;a;a) {break;}
        }
        string b(boolean a[]) {
            for (a=0;a;a) {}
        }
        string b(boolean a[]) {
            for (a;a<a;a) {}
        }
        string b(boolean a[]) {
            do
            {}
            {}
            {}
            while (1);
        }
        string b(boolean a[]) {
            f(a+2,a);
            return a;
            if (a) 
                if (a) {}
                else {}
            else {}
        }
        string b(boolean a[]) {
            f(a+2,a);
        }
        string b(boolean a) {
            string a;
            a = "ab\\r\\n";
        }
        """
        expect = "successful"
        self.assertTrue(TestParser.checkParser(input, expect, 288))

    def test_mixed9(self):
        input= """
        string b(boolean a[]) {
            for (a;a;a) {{{{{{{{{continue;{{{{{{{{{{}{{{{{{}}}}}}}}}}}}}}}}}}}}}}}}
        }
        string b(boolean a[]) {
            for (a;a;a) {continue;}
        }
        string b(boolean a[]) {
            for (a;a;a) {break;}
        }
        string b(boolean a[]) {
            for (a=0;a;a) {}
        }
        string b(boolean a[]) {
            for (a;a<a;a) {}
        }
        string b(boolean a[]) {
            do
            {}
            {}
            {}
            while (1);
        }
        string b(boolean a[]) {
            f(a+2,a);
            return a;
            if (a) 
                if (a) {}
                else {}
            else {}
        }
        string b(boolean a[]) {
            f(a+2,a);
        }
        string b(boolean a) {
            string a;
            a = "ab\\r\\n";
            f(((((((((((((((((((((((((((((((((((((((1)))))))))))))))))))))))))))))))))))))));
        }
        """
        expect = "successful"
        self.assertTrue(TestParser.checkParser(input, expect, 289))

    def test_stress(self):
        input= """
        string b(boolean a[]) {
            for (a;a;a) {{{{{{{{{continue;{{{{{{{{{{}{{{{{{}}}}}}}}}}}}}}}}}}}}}}}}
        }
        string b(boolean a[]) {
            for (a;a;a) {continue;}
        }
        string b(boolean a[]) {
            for (a;a;a) {break;}
        }
        string b(boolean a[]) {
            for (a=0;a;a) {}
        }
        string b(boolean a[]) {
            for (a;a<a;a) {}
        }
        string b(boolean a[]) {
            do
            {}
            {}
            {}
            while (1);
        }
        string b(boolean a[]) {
            f(a+2,a);
            return a;
            if (a) 
                if (a) {}
                else {}
            else {}
        }
        string b(boolean a[]) {
            f(a+2,a);
        }
        string b(boolean a) {
            string a;
            a = "ab\\r\\n";
            f(((((((((((((((((((((((((((((((((((((((1)))))))))))))))))))))))))))))))))))))));
        }
        string b(boolean a[]) {
            for (a;a;a) {{{{{{{{{continue;{{{{{{{{{{}{{{{{{}}}}}}}}}}}}}}}}}}}}}}}}
        }
        string b(boolean a[]) {
            for (a;a;a) {continue;}
        }
        string b(boolean a[]) {
            for (a;a;a) {break;}
        }
        string b(boolean a[]) {
            for (a=0;a;a) {}
        }
        string b(boolean a[]) {
            for (a;a<a;a) {}
        }
        string b(boolean a[]) {
            do
            {}
            {}
            {}
            while (1);
        }
        string b(boolean a[]) {
            f(a+2,a);
            return a;
            if (a) 
                if (a) {}
                else {}
            else {}
        }
        string b(boolean a[]) {
            f(a+2,a);
        }
        string b(boolean a) {
            string a;
            a = "ab\\r\\n";
            f(((((((((((((((((((((((((((((((((((((((1)))))))))))))))))))))))))))))))))))))));
        }
        """
        expect = "successful"
        self.assertTrue(TestParser.checkParser(input, expect, 290))

    def test_stress1(self):
        input= """
        string b(boolean a[]) {
            for (a;a;a) {{{{{{{{{continue;{{{{{{{{{{}{{{{{{}}}}}}}}}}}}}}}}}}}}}}}}
        }
        string b(boolean a[]) {
            for (a;a;a) {continue;}
        }
        string b(boolean a[]) {
            for (a;a;a) {break;}
        }
        string b(boolean a[]) {
            for (a=0;a;a) {}
        }
        string b(boolean a[]) {
            for (a;a<a;a) {}
        }
        string b(boolean a[]) {
            do
            {}
            {}
            {}
            while (1);
        }
        string b(boolean a[]) {
            f(a+2,a);
            return a;
            if (a) 
                if (a) {}
                else {}
            else {}
        }
        string b(boolean a[]) {
            f(a+2,a);
        }
        string b(boolean a) {
            string a;
            a = "ab\\r\\n";
            f(((((((((((((((((((((((((((((((((((((((1)))))))))))))))))))))))))))))))))))))));
        }
        string b(boolean a[]) {
            for (a;a;a) {{{{{{{{{continue;{{{{{{{{{{}{{{{{{}}}}}}}}}}}}}}}}}}}}}}}}
        }
        string b(boolean a[]) {
            for (a;a;a) {continue;}
        }
        string b(boolean a[]) {
            for (a;a;a) {break;}
        }
        string b(boolean a[]) {
            for (a=0;a;a) {}
        }
        string b(boolean a[]) {
            for (a;a<a;a) {}
        }
        string b(boolean a[]) {
            do
            {}
            {}
            {}
            while (1);
        }
        string b(boolean a[]) {
            f(a+2,a);
            return a;
            if (a) 
                if (a) {}
                else {}
            else {}
        }
        string b(boolean a[]) {
            f(a+2,a);
        }
        string b(boolean a) {
            string a;
            a = "ab\\r\\n";
            f(((((((((((((((((((((((((((((((((((((((1)))))))))))))))))))))))))))))))))))))));
        }
        string b(boolean a[]) {
            for (a;a;a) {{{{{{{{{continue;{{{{{{{{{{}{{{{{{}}}}}}}}}}}}}}}}}}}}}}}}
        }
        string b(boolean a[]) {
            for (a;a;a) {continue;}
        }
        string b(boolean a[]) {
            for (a;a;a) {break;}
        }
        string b(boolean a[]) {
            for (a=0;a;a) {}
        }
        string b(boolean a[]) {
            for (a;a<a;a) {}
        }
        string b(boolean a[]) {
            do
            {}
            {}
            {}
            while (1);
        }
        string b(boolean a[]) {
            f(a+2,a);
            return a;
            if (a) 
                if (a) {}
                else {}
            else {}
        }
        string b(boolean a[]) {
            f(a+2,a);
        }
        string b(boolean a) {
            string a;
            a = "ab\\r\\n";
            f(((((((((((((((((((((((((((((((((((((((1)))))))))))))))))))))))))))))))))))))));
        }
        string b(boolean a[]) {
            for (a;a;a) {{{{{{{{{continue;{{{{{{{{{{}{{{{{{}}}}}}}}}}}}}}}}}}}}}}}}
        }
        string b(boolean a[]) {
            for (a;a;a) {continue;}
        }
        string b(boolean a[]) {
            for (a;a;a) {break;}
        }
        string b(boolean a[]) {
            for (a=0;a;a) {}
        }
        string b(boolean a[]) {
            for (a;a<a;a) {}
        }
        string b(boolean a[]) {
            do
            {}
            {}
            {}
            while (1);
        }
        string b(boolean a[]) {
            f(a+2,a);
            return a;
            if (a) 
                if (a) {}
                else {}
            else {}
        }
        string b(boolean a[]) {
            f(a+2,a);
        }
        string b(boolean a) {
            string a;
            a = "ab\\r\\n";
            f(((((((((((((((((((((((((((((((((((((((1)))))))))))))))))))))))))))))))))))))));
        }
        """
        expect = "successful"
        self.assertTrue(TestParser.checkParser(input, expect, 291))

    def test_stress2(self):
        input= """
        string b(boolean a[]) {
            for (a;a;a) {{{{{{{{{continue;{{{{{{{{{{}{{{{{{}}}}}}}}}}}}}}}}}}}}}}}}
        }
        string b(boolean a[]) {
            for (a;a;a) {continue;}
        }
        string b(boolean a[]) {
            for (a;a;a) {break;}
        }
        string b(boolean a[]) {
            for (a=0;a;a) {}
        }
        string b(boolean a[]) {
            for (a;a<a;a) {}
        }
        string b(boolean a[]) {
            do
            {}
            {}
            {}
            while (1);
        }
        string b(boolean a[]) {
            f(a+2,a);
            return a;
            if (a) 
                if (a) {}
                else {}
            else {}
        }
        string b(boolean a[]) {
            f(a+2,a);
        }
        string b(boolean a) {
            string a;
            a = "ab\\r\\n";
            f(((((((((((((((((((((((((((((((((((((((1)))))))))))))))))))))))))))))))))))))));
        }
        string b(boolean a[]) {
            for (a;a;a) {{{{{{{{{continue;{{{{{{{{{{}{{{{{{}}}}}}}}}}}}}}}}}}}}}}}}
        }
        string b(boolean a[]) {
            for (a;a;a) {continue;}
        }
        string b(boolean a[]) {
            for (a;a;a) {break;}
        }
        string b(boolean a[]) {
            for (a=0;a;a) {}
        }
        string b(boolean a[]) {
            for (a;a<a;a) {}
        }
        string b(boolean a[]) {
            do
            {}
            {}
            {}
            while (1);
        }
        string b(boolean a[]) {
            f(a+2,a);
            return a;
            if (a) 
                if (a) {}
                else {}
            else {}
        }
        string b(boolean a[]) {
            f(a+2,a);
        }
        string b(boolean a) {
            string a;
            a = "ab\\r\\n";
            f(((((((((((((((((((((((((((((((((((((((1)))))))))))))))))))))))))))))))))))))));
        }
        string b(boolean a[]) {
            for (a;a;a) {{{{{{{{{continue;{{{{{{{{{{}{{{{{{}}}}}}}}}}}}}}}}}}}}}}}}
        }
        string b(boolean a[]) {
            for (a;a;a) {continue;}
        }
        string b(boolean a[]) {
            for (a;a;a) {break;}
        }
        string b(boolean a[]) {
            for (a=0;a;a) {}
        }
        string b(boolean a[]) {
            for (a;a<a;a) {}
        }
        string b(boolean a[]) {
            do
            {}
            {}
            {}
            while (1);
        }
        string b(boolean a[]) {
            f(a+2,a);
            return a;
            if (a) 
                if (a) {}
                else {}
            else {}
        }
        string b(boolean a[]) {
            f(a+2,a);
        }
        string b(boolean a) {
            string a;
            a = "ab\\r\\n";
            f(((((((((((((((((((((((((((((((((((((((1)))))))))))))))))))))))))))))))))))))));
        }
        string b(boolean a[]) {
            for (a;a;a) {{{{{{{{{continue;{{{{{{{{{{}{{{{{{}}}}}}}}}}}}}}}}}}}}}}}}
        }
        string b(boolean a[]) {
            for (a;a;a) {continue;}
        }
        string b(boolean a[]) {
            for (a;a;a) {break;}
        }
        string b(boolean a[]) {
            for (a=0;a;a) {}
        }
        string b(boolean a[]) {
            for (a;a<a;a) {}
        }
        string b(boolean a[]) {
            do
            {}
            {}
            {}
            while (1);
        }
        string b(boolean a[]) {
            f(a+2,a);
            return a;
            if (a) 
                if (a) {}
                else {}
            else {}
        }
        string b(boolean a[]) {
            f(a+2,a);
        }
        string b(boolean a) {
            string a;
            a = "ab\\r\\n";
            f(((((((((((((((((((((((((((((((((((((((1)))))))))))))))))))))))))))))))))))))));
        }
        string b(boolean a[]) {
            for (a;a;a) {{{{{{{{{continue;{{{{{{{{{{}{{{{{{}}}}}}}}}}}}}}}}}}}}}}}}
        }
        string b(boolean a[]) {
            for (a;a;a) {continue;}
        }
        string b(boolean a[]) {
            for (a;a;a) {break;}
        }
        string b(boolean a[]) {
            for (a=0;a;a) {}
        }
        string b(boolean a[]) {
            for (a;a<a;a) {}
        }
        string b(boolean a[]) {
            do
            {}
            {}
            {}
            while (1);
        }
        string b(boolean a[]) {
            f(a+2,a);
            return a;
            if (a) 
                if (a) {}
                else {}
            else {}
        }
        string b(boolean a[]) {
            f(a+2,a);
        }
        string b(boolean a) {
            string a;
            a = "ab\\r\\n";
            f(((((((((((((((((((((((((((((((((((((((1)))))))))))))))))))))))))))))))))))))));
        }
        string b(boolean a[]) {
            for (a;a;a) {{{{{{{{{continue;{{{{{{{{{{}{{{{{{}}}}}}}}}}}}}}}}}}}}}}}}
        }
        string b(boolean a[]) {
            for (a;a;a) {continue;}
        }
        string b(boolean a[]) {
            for (a;a;a) {break;}
        }
        string b(boolean a[]) {
            for (a=0;a;a) {}
        }
        string b(boolean a[]) {
            for (a;a<a;a) {}
        }
        string b(boolean a[]) {
            do
            {}
            {}
            {}
            while (1);
        }
        string b(boolean a[]) {
            f(a+2,a);
            return a;
            if (a) 
                if (a) {}
                else {}
            else {}
        }
        string b(boolean a[]) {
            f(a+2,a);
        }
        string b(boolean a) {
            string a;
            a = "ab\\r\\n";
            f(((((((((((((((((((((((((((((((((((((((1)))))))))))))))))))))))))))))))))))))));
        }
        string b(boolean a[]) {
            for (a;a;a) {{{{{{{{{continue;{{{{{{{{{{}{{{{{{}}}}}}}}}}}}}}}}}}}}}}}}
        }
        string b(boolean a[]) {
            for (a;a;a) {continue;}
        }
        string b(boolean a[]) {
            for (a;a;a) {break;}
        }
        string b(boolean a[]) {
            for (a=0;a;a) {}
        }
        string b(boolean a[]) {
            for (a;a<a;a) {}
        }
        string b(boolean a[]) {
            do
            {}
            {}
            {}
            while (1);
        }
        string b(boolean a[]) {
            f(a+2,a);
            return a;
            if (a) 
                if (a) {}
                else {}
            else {}
        }
        string b(boolean a[]) {
            f(a+2,a);
        }
        string b(boolean a) {
            string a;
            a = "ab\\r\\n";
            f(((((((((((((((((((((((((((((((((((((((1)))))))))))))))))))))))))))))))))))))));
        }
        string b(boolean a[]) {
            for (a;a;a) {{{{{{{{{continue;{{{{{{{{{{}{{{{{{}}}}}}}}}}}}}}}}}}}}}}}}
        }
        string b(boolean a[]) {
            for (a;a;a) {continue;}
        }
        string b(boolean a[]) {
            for (a;a;a) {break;}
        }
        string b(boolean a[]) {
            for (a=0;a;a) {}
        }
        string b(boolean a[]) {
            for (a;a<a;a) {}
        }
        string b(boolean a[]) {
            do
            {}
            {}
            {}
            while (1);
        }
        string b(boolean a[]) {
            f(a+2,a);
            return a;
            if (a) 
                if (a) {}
                else {}
            else {}
        }
        string b(boolean a[]) {
            f(a+2,a);
        }
        string b(boolean a) {
            string a;
            a = "ab\\r\\n";
            f(((((((((((((((((((((((((((((((((((((((1)))))))))))))))))))))))))))))))))))))));
        }
        string b(boolean a[]) {
            for (a;a;a) {{{{{{{{{continue;{{{{{{{{{{}{{{{{{}}}}}}}}}}}}}}}}}}}}}}}}
        }
        string b(boolean a[]) {
            for (a;a;a) {continue;}
        }
        string b(boolean a[]) {
            for (a;a;a) {break;}
        }
        string b(boolean a[]) {
            for (a=0;a;a) {}
        }
        string b(boolean a[]) {
            for (a;a<a;a) {}
        }
        string b(boolean a[]) {
            do
            {}
            {}
            {}
            while (1);
        }
        string b(boolean a[]) {
            f(a+2,a);
            return a;
            if (a) 
                if (a) {}
                else {}
            else {}
        }
        string b(boolean a[]) {
            f(a+2,a);
        }
        string b(boolean a) {
            string a;
            a = "ab\\r\\n";
            f(((((((((((((((((((((((((((((((((((((((1)))))))))))))))))))))))))))))))))))))));
        }
        string b(boolean a[]) {
            for (a;a;a) {{{{{{{{{continue;{{{{{{{{{{}{{{{{{}}}}}}}}}}}}}}}}}}}}}}}}
        }
        string b(boolean a[]) {
            for (a;a;a) {continue;}
        }
        string b(boolean a[]) {
            for (a;a;a) {break;}
        }
        string b(boolean a[]) {
            for (a=0;a;a) {}
        }
        string b(boolean a[]) {
            for (a;a<a;a) {}
        }
        string b(boolean a[]) {
            do
            {}
            {}
            {}
            while (1);
        }
        string b(boolean a[]) {
            f(a+2,a);
            return a;
            if (a) 
                if (a) {}
                else {}
            else {}
        }
        string b(boolean a[]) {
            f(a+2,a);
        }
        string b(boolean a) {
            string a;
            a = "ab\\r\\n";
            f(((((((((((((((((((((((((((((((((((((((1)))))))))))))))))))))))))))))))))))))));
        }
        string b(boolean a[]) {
            for (a;a;a) {{{{{{{{{continue;{{{{{{{{{{}{{{{{{}}}}}}}}}}}}}}}}}}}}}}}}
        }
        string b(boolean a[]) {
            for (a;a;a) {continue;}
        }
        string b(boolean a[]) {
            for (a;a;a) {break;}
        }
        string b(boolean a[]) {
            for (a=0;a;a) {}
        }
        string b(boolean a[]) {
            for (a;a<a;a) {}
        }
        string b(boolean a[]) {
            do
            {}
            {}
            {}
            while (1);
        }
        string b(boolean a[]) {
            f(a+2,a);
            return a;
            if (a) 
                if (a) {}
                else {}
            else {}
        }
        string b(boolean a[]) {
            f(a+2,a);
        }
        string b(boolean a) {
            string a;
            a = "ab\\r\\n";
            f(((((((((((((((((((((((((((((((((((((((1)))))))))))))))))))))))))))))))))))))));
        }
        string b(boolean a[]) {
            for (a;a;a) {{{{{{{{{continue;{{{{{{{{{{}{{{{{{}}}}}}}}}}}}}}}}}}}}}}}}
        }
        string b(boolean a[]) {
            for (a;a;a) {continue;}
        }
        string b(boolean a[]) {
            for (a;a;a) {break;}
        }
        string b(boolean a[]) {
            for (a=0;a;a) {}
        }
        string b(boolean a[]) {
            for (a;a<a;a) {}
        }
        string b(boolean a[]) {
            do
            {}
            {}
            {}
            while (1);
        }
        string b(boolean a[]) {
            f(a+2,a);
            return a;
            if (a) 
                if (a) {}
                else {}
            else {}
        }
        string b(boolean a[]) {
            f(a+2,a);
        }
        string b(boolean a) {
            string a;
            a = "ab\\r\\n";
            f(((((((((((((((((((((((((((((((((((((((1)))))))))))))))))))))))))))))))))))))));
        }
        string b(boolean a[]) {
            for (a;a;a) {{{{{{{{{continue;{{{{{{{{{{}{{{{{{}}}}}}}}}}}}}}}}}}}}}}}}
        }
        string b(boolean a[]) {
            for (a;a;a) {continue;}
        }
        string b(boolean a[]) {
            for (a;a;a) {break;}
        }
        string b(boolean a[]) {
            for (a=0;a;a) {}
        }
        string b(boolean a[]) {
            for (a;a<a;a) {}
        }
        string b(boolean a[]) {
            do
            {}
            {}
            {}
            while (1);
        }
        string b(boolean a[]) {
            f(a+2,a);
            return a;
            if (a) 
                if (a) {}
                else {}
            else {}
        }
        string b(boolean a[]) {
            f(a+2,a);
        }
        string b(boolean a) {
            string a;
            a = "ab\\r\\n";
            f(((((((((((((((((((((((((((((((((((((((1)))))))))))))))))))))))))))))))))))))));
        }
        string b(boolean a[]) {
            for (a;a;a) {{{{{{{{{continue;{{{{{{{{{{}{{{{{{}}}}}}}}}}}}}}}}}}}}}}}}
        }
        string b(boolean a[]) {
            for (a;a;a) {continue;}
        }
        string b(boolean a[]) {
            for (a;a;a) {break;}
        }
        string b(boolean a[]) {
            for (a=0;a;a) {}
        }
        string b(boolean a[]) {
            for (a;a<a;a) {}
        }
        string b(boolean a[]) {
            do
            {}
            {}
            {}
            while (1);
        }
        string b(boolean a[]) {
            f(a+2,a);
            return a;
            if (a) 
                if (a) {}
                else {}
            else {}
        }
        string b(boolean a[]) {
            f(a+2,a);
        }
        string b(boolean a) {
            string a;
            a = "ab\\r\\n";
            f(((((((((((((((((((((((((((((((((((((((1)))))))))))))))))))))))))))))))))))))));
        }
        string b(boolean a[]) {
            for (a;a;a) {{{{{{{{{continue;{{{{{{{{{{}{{{{{{}}}}}}}}}}}}}}}}}}}}}}}}
        }
        string b(boolean a[]) {
            for (a;a;a) {continue;}
        }
        string b(boolean a[]) {
            for (a;a;a) {break;}
        }
        string b(boolean a[]) {
            for (a=0;a;a) {}
        }
        string b(boolean a[]) {
            for (a;a<a;a) {}
        }
        string b(boolean a[]) {
            do
            {}
            {}
            {}
            while (1);
        }
        string b(boolean a[]) {
            f(a+2,a);
            return a;
            if (a) 
                if (a) {}
                else {}
            else {}
        }
        string b(boolean a[]) {
            f(a+2,a);
        }
        string b(boolean a) {
            string a;
            a = "ab\\r\\n";
            f(((((((((((((((((((((((((((((((((((((((1)))))))))))))))))))))))))))))))))))))));
        }
        string b(boolean a[]) {
            for (a;a;a) {{{{{{{{{continue;{{{{{{{{{{}{{{{{{}}}}}}}}}}}}}}}}}}}}}}}}
        }
        string b(boolean a[]) {
            for (a;a;a) {continue;}
        }
        string b(boolean a[]) {
            for (a;a;a) {break;}
        }
        string b(boolean a[]) {
            for (a=0;a;a) {}
        }
        string b(boolean a[]) {
            for (a;a<a;a) {}
        }
        string b(boolean a[]) {
            do
            {}
            {}
            {}
            while (1);
        }
        string b(boolean a[]) {
            f(a+2,a);
            return a;
            if (a) 
                if (a) {}
                else {}
            else {}
        }
        string b(boolean a[]) {
            f(a+2,a);
        }
        string b(boolean a) {
            string a;
            a = "ab\\r\\n";
            f(((((((((((((((((((((((((((((((((((((((1)))))))))))))))))))))))))))))))))))))));
        }
        string b(boolean a[]) {
            for (a;a;a) {{{{{{{{{continue;{{{{{{{{{{}{{{{{{}}}}}}}}}}}}}}}}}}}}}}}}
        }
        string b(boolean a[]) {
            for (a;a;a) {continue;}
        }
        string b(boolean a[]) {
            for (a;a;a) {break;}
        }
        string b(boolean a[]) {
            for (a=0;a;a) {}
        }
        string b(boolean a[]) {
            for (a;a<a;a) {}
        }
        string b(boolean a[]) {
            do
            {}
            {}
            {}
            while (1);
        }
        string b(boolean a[]) {
            f(a+2,a);
            return a;
            if (a) 
                if (a) {}
                else {}
            else {}
        }
        string b(boolean a[]) {
            f(a+2,a);
        }
        string b(boolean a) {
            string a;
            a = "ab\\r\\n";
            f(((((((((((((((((((((((((((((((((((((((1)))))))))))))))))))))))))))))))))))))));
        }
        string b(boolean a[]) {
            for (a;a;a) {{{{{{{{{continue;{{{{{{{{{{}{{{{{{}}}}}}}}}}}}}}}}}}}}}}}}
        }
        string b(boolean a[]) {
            for (a;a;a) {continue;}
        }
        string b(boolean a[]) {
            for (a;a;a) {break;}
        }
        string b(boolean a[]) {
            for (a=0;a;a) {}
        }
        string b(boolean a[]) {
            for (a;a<a;a) {}
        }
        string b(boolean a[]) {
            do
            {}
            {}
            {}
            while (1);
        }
        string b(boolean a[]) {
            f(a+2,a);
            return a;
            if (a) 
                if (a) {}
                else {}
            else {}
        }
        string b(boolean a[]) {
            f(a+2,a);
        }
        string b(boolean a) {
            string a;
            a = "ab\\r\\n";
            f(((((((((((((((((((((((((((((((((((((((1)))))))))))))))))))))))))))))))))))))));
        }
        string b(boolean a[]) {
            for (a;a;a) {{{{{{{{{continue;{{{{{{{{{{}{{{{{{}}}}}}}}}}}}}}}}}}}}}}}}
        }
        string b(boolean a[]) {
            for (a;a;a) {continue;}
        }
        string b(boolean a[]) {
            for (a;a;a) {break;}
        }
        string b(boolean a[]) {
            for (a=0;a;a) {}
        }
        string b(boolean a[]) {
            for (a;a<a;a) {}
        }
        string b(boolean a[]) {
            do
            {}
            {}
            {}
            while (1);
        }
        string b(boolean a[]) {
            f(a+2,a);
            return a;
            if (a) 
                if (a) {}
                else {}
            else {}
        }
        string b(boolean a[]) {
            f(a+2,a);
        }
        string b(boolean a) {
            string a;
            a = "ab\\r\\n";
            f(((((((((((((((((((((((((((((((((((((((1)))))))))))))))))))))))))))))))))))))));
        }
        string b(boolean a[]) {
            for (a;a;a) {{{{{{{{{continue;{{{{{{{{{{}{{{{{{}}}}}}}}}}}}}}}}}}}}}}}}
        }
        string b(boolean a[]) {
            for (a;a;a) {continue;}
        }
        string b(boolean a[]) {
            for (a;a;a) {break;}
        }
        string b(boolean a[]) {
            for (a=0;a;a) {}
        }
        string b(boolean a[]) {
            for (a;a<a;a) {}
        }
        string b(boolean a[]) {
            do
            {}
            {}
            {}
            while (1);
        }
        string b(boolean a[]) {
            f(a+2,a);
            return a;
            if (a) 
                if (a) {}
                else {}
            else {}
        }
        string b(boolean a[]) {
            f(a+2,a);
        }
        string b(boolean a) {
            string a;
            a = "ab\\r\\n";
            f(((((((((((((((((((((((((((((((((((((((1)))))))))))))))))))))))))))))))))))))));
        }
        string b(boolean a[]) {
            for (a;a;a) {{{{{{{{{continue;{{{{{{{{{{}{{{{{{}}}}}}}}}}}}}}}}}}}}}}}}
        }
        string b(boolean a[]) {
            for (a;a;a) {continue;}
        }
        string b(boolean a[]) {
            for (a;a;a) {break;}
        }
        string b(boolean a[]) {
            for (a=0;a;a) {}
        }
        string b(boolean a[]) {
            for (a;a<a;a) {}
        }
        string b(boolean a[]) {
            do
            {}
            {}
            {}
            while (1);
        }
        string b(boolean a[]) {
            f(a+2,a);
            return a;
            if (a) 
                if (a) {}
                else {}
            else {}
        }
        string b(boolean a[]) {
            f(a+2,a);
        }
        string b(boolean a) {
            string a;
            a = "ab\\r\\n";
            f(((((((((((((((((((((((((((((((((((((((1)))))))))))))))))))))))))))))))))))))));
        }
        string b(boolean a[]) {
            for (a;a;a) {{{{{{{{{continue;{{{{{{{{{{}{{{{{{}}}}}}}}}}}}}}}}}}}}}}}}
        }
        string b(boolean a[]) {
            for (a;a;a) {continue;}
        }
        string b(boolean a[]) {
            for (a;a;a) {break;}
        }
        string b(boolean a[]) {
            for (a=0;a;a) {}
        }
        string b(boolean a[]) {
            for (a;a<a;a) {}
        }
        string b(boolean a[]) {
            do
            {}
            {}
            {}
            while (1);
        }
        string b(boolean a[]) {
            f(a+2,a);
            return a;
            if (a) 
                if (a) {}
                else {}
            else {}
        }
        string b(boolean a[]) {
            f(a+2,a);
        }
        string b(boolean a) {
            string a;
            a = "ab\\r\\n";
            f(((((((((((((((((((((((((((((((((((((((1)))))))))))))))))))))))))))))))))))))));
        }
        string b(boolean a[]) {
            for (a;a;a) {{{{{{{{{continue;{{{{{{{{{{}{{{{{{}}}}}}}}}}}}}}}}}}}}}}}}
        }
        string b(boolean a[]) {
            for (a;a;a) {continue;}
        }
        string b(boolean a[]) {
            for (a;a;a) {break;}
        }
        string b(boolean a[]) {
            for (a=0;a;a) {}
        }
        string b(boolean a[]) {
            for (a;a<a;a) {}
        }
        string b(boolean a[]) {
            do
            {}
            {}
            {}
            while (1);
        }
        string b(boolean a[]) {
            f(a+2,a);
            return a;
            if (a) 
                if (a) {}
                else {}
            else {}
        }
        string b(boolean a[]) {
            f(a+2,a);
        }
        string b(boolean a) {
            string a;
            a = "ab\\r\\n";
            f(((((((((((((((((((((((((((((((((((((((1)))))))))))))))))))))))))))))))))))))));
        }
        string b(boolean a[]) {
            for (a;a;a) {{{{{{{{{continue;{{{{{{{{{{}{{{{{{}}}}}}}}}}}}}}}}}}}}}}}}
        }
        string b(boolean a[]) {
            for (a;a;a) {continue;}
        }
        string b(boolean a[]) {
            for (a;a;a) {break;}
        }
        string b(boolean a[]) {
            for (a=0;a;a) {}
        }
        string b(boolean a[]) {
            for (a;a<a;a) {}
        }
        string b(boolean a[]) {
            do
            {}
            {}
            {}
            while (1);
        }
        string b(boolean a[]) {
            f(a+2,a);
            return a;
            if (a) 
                if (a) {}
                else {}
            else {}
        }
        string b(boolean a[]) {
            f(a+2,a);
        }
        string b(boolean a) {
            string a;
            a = "ab\\r\\n";
            f(((((((((((((((((((((((((((((((((((((((1)))))))))))))))))))))))))))))))))))))));
        }
        """
        expect = "successful"
        self.assertTrue(TestParser.checkParser(input, expect, 292))

    def test_mixed10(self):
        input = """
        int main(){
                int i;
                for(i=0;1<127;i=i+1){
                    printf("%d: %c\\n",i,i);
                    fflush(stdin);getchar();}
        }
        """
        expect = "successful"
        self.assertTrue(TestParser.checkParser(input, expect, 293))

    def test_mixed11(self):
        input = """
        int main() {
            a[5][5];
        }
        """
        expect = "Error on line 3 col 16: ["
        self.assertTrue(TestParser.checkParser(input, expect, 294))

    def test_mixed12(self):
        input = """
        int main(){
            int cri, met, deu, liv;
            printf("Inserisci il costo attuale del prossimo livello\\nMetallo: ");
            scanf("%d",&met);
            printf("\\nCristallo: ");
            scanf("%d",&cri);
            printf("\\nDeuterio: ");
            scanf("%d",&deu);
            printf("\\n\\ninserisci il numero di livelli: ");
            scanf("%d",&liv);
            for(liv-=1;liv>0;liv--){
                            met*=3;cri*=3;deu*=3;
                            }
            printf("L'infrastruttura costa\\nMetallo: %d\\nCristallo: %d\\nDeuterio: %d\\n\\n",met,cri,deu);
            system("pause");
        }
        """
        expect = "&"
        self.assertTrue(TestParser.checkParser(input, expect, 295))

    def test_mixed13(self):
        input = """
        float integral(float a, float b, float (*f) (float), int n) {
 int i;
	float dx = (b - a) / n;
    float value_of_integral = 0.0;

for (i=0; i<n; i++) {
float si_a = a + (i)*dx;
float si_b = a + (i+1)*dx;
value_of_integral += simpson(si_a, si_b, f, dx);
}

return value_of_integral;
}

float square(float x) {
	return x*x;
}

float simpson(float a, float b, float (*f) (float), float dx) {
	float value_of_interval_integral =
					0.5 * (f(a) + f(b)) / dx;
	return value_of_interval_integral;
}

int main(int argc, char** argv) {
	float twopi = 2 * 3.14;
	float integral_of_f = integral(0.0, 1.0, square, 1e3);
	/*float integral_of_sin = integral(0.0, , sin, 10);*/
	printf(" z  f (0.0 - 1.0) = %g\\n", integral_of_f);
	/*printf(" z sinus (0 - 2pi) = %g\\n", integral_of_sin);*/
	return 0;
}
        """
        expect = "Error on line 2 col 47: ("
        self.assertTrue(TestParser.checkParser(input, expect, 296))

    def test_mixed14(self):
        input = """
        int main(string arg[]) {
            int a,b;
            a = 1+10&&2;
            b = 1+10||2;
            for (i = 1; i < 10; i = i+1) {
                printf(a,b,c);
            }
            //alo alo
        }
        """
        expect = "successful"
        self.assertTrue(TestParser.checkParser(input, expect, 297))

    def test_mixed15(self):
        input = """
        string b(boolean a) {
            int a[5;
        }
        """
        expect = "Error on line 3 col 19: ;"
        self.assertTrue(TestParser.checkParser(input, expect, 298))

    def test_mixed16(self):
        input = """
        int main(string arg[]) {
            a < a < a;
        }
        """
        expect = "Error on line 3 col 18: <"
        self.assertTrue(TestParser.checkParser(input, expect, 299))