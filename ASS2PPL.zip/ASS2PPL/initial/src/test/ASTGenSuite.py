import unittest
from TestUtils import TestAST
from AST import *

class ASTGenSuite(unittest.TestCase):
							#CONTENTS:
							#TEST_DECL 			- 10
							#TEST_EXP 			- 15
							#TEST_IFSTMT 		- 05
							#TEST_FORSTMT 		- 05
							#TEST_BLOCKSTMT 	- 05
							#TEST_DOWHILESTMT 	- 05
							#TEST_OTHERSTMT		- 10
							#TEST_STMTEXPCOMBINE- 15
							#TEST_ALL			- 10
							#TEST_SIMPLEPROGRAM	- 10
							#TEST_COMPLEXPROGRAM- 10
							#========================
							#TOTAL				- 100

#TEST_EXP===========================================================================================(15)

	def test_exp_0(self):
		input = """int main(){
			a = b + c - d + 5.5;
		}"""
		expect = str(Program([FuncDecl(Id("main"),[],IntType(),Block([BinaryOp("=",Id("a"),BinaryOp("+",BinaryOp("-",BinaryOp("+",Id("b"),Id("c")),Id("d")),FloatLiteral(5.5)))]))]))
		self.assertTrue(TestAST.checkASTGen(input,expect,310))

	
