import unittest
from TestUtils import TestAST
from AST import *

# CHANGE LOG
# - ArrayType(IntLiteral() not ArrayType(IntLiteral(IntLiteral())
# - VarDecl(Id(str,.. not VarDecl(Id(Id,..
# - Type() not Type 
# - activate ArrayCell

class ASTGenSuite(unittest.TestCase):
    def test_simple_program(self):
        """Simple program: int main() {} """
        input = """int main() {}"""
        expect = str(Program([FuncDecl(Id("main"),[],IntType(),Block([]))]))
        self.assertTrue(TestAST.checkASTGen(input,expect,301))

    def test_more_complex_program(self):
        """More complex program"""
        input = """int main() {
            putIntLn(4);
        }"""
        expect = str(Program([FuncDecl(Id("main"),[],IntType(),Block([CallExpr(Id("putIntLn"),[IntLiteral(4)])]))]))
        self.assertTrue(TestAST.checkASTGen(input,expect,302))
    
    def test_call_without_parameter(self):
        """More complex program"""
        input = """int main(){
            getIntLn();
        }"""
        expect = str(Program([FuncDecl(Id("main"),[],IntType(),Block([CallExpr(Id("getIntLn"),[])]))]))
        self.assertTrue(TestAST.checkASTGen(input,expect,303))


    def test_simple_var_decl(self):
        input = """int a;"""
        expect = str(Program([VarDecl("a",IntType())]))
        self.assertTrue(TestAST.checkASTGen(input,expect,304))        
   
    def test_more_vardecl(self):
        input = """float arr,iNum,complex;"""
        expect = str(Program([VarDecl("arr",FloatType()),
            VarDecl("iNum",FloatType()),
            VarDecl("complex",FloatType())]))
        self.assertTrue(TestAST.checkASTGen(input,expect,305))        

    def test_more_array_vardecl(self):
        input = """float arr,iNum,str[2];"""
        expect = str(Program([VarDecl("arr",FloatType()),
            VarDecl("iNum",FloatType()),
            VarDecl("str", ArrayType(IntLiteral(2),FloatType()))]))
        self.assertTrue(TestAST.checkASTGen(input,expect,306))        

    def test_more_string_vardecl(self):
        input = """string str;
        string arr;
        string arr2D;"""
        expect = str(Program([VarDecl("str",StringType()),
            VarDecl("arr",StringType()),
            VarDecl("arr2D",StringType())]))
        self.assertTrue(TestAST.checkASTGen(input,expect,307))        

    def test_combo_vardecl(self):
        input = """string str;
        int arr;
        float arr2D;
        boolean isTrue;"""
        expect = str(Program([VarDecl("str",StringType()),
            VarDecl("arr",IntType()),
            VarDecl("arr2D",FloatType()),
            VarDecl("isTrue",BoolType())]))
        self.assertTrue(TestAST.checkASTGen(input,expect,308))        

    def test_more_combo_vardecl_array(self):
        input = """string str,a2D[4];
        int arr,brr;
        float arr2D,arr3D[5];
        boolean isTrue,isFact;"""
        expect = str(Program([
            VarDecl("str",StringType()),
            VarDecl("a2D",ArrayType(IntLiteral(4),StringType())),
            VarDecl("arr",IntType()),
            VarDecl("brr",IntType()),
            VarDecl("arr2D",FloatType()),
            VarDecl("arr3D",ArrayType(IntLiteral(5),FloatType())),
            VarDecl("isTrue",BoolType()),
            VarDecl("isFact",BoolType())]))
        self.assertTrue(TestAST.checkASTGen(input,expect,309))        
    
    def test_string_vardecl_more_array_type(self):
        input = """string str,a2D[4];
        string arr,brr;
        string arr2D,arr3D[5];
        string isTrue,isFact;"""
        expect = str(Program([VarDecl("str",StringType()),
            VarDecl("a2D",ArrayType(IntLiteral(4),StringType())),
            VarDecl("arr",StringType()),
            VarDecl("brr",StringType()),
            VarDecl("arr2D",StringType()),
            VarDecl("arr3D",ArrayType(IntLiteral(5),StringType())),
            VarDecl("isTrue",StringType()),
            VarDecl("isFact",StringType())]))
        self.assertTrue(TestAST.checkASTGen(input,expect,310))        

    def test_simple_funcdecl(self):
        input = """boolean foo(){}"""
        expect = str(Program([FuncDecl(Id("foo"),[],BoolType(),Block([]))]))
        self.assertTrue(TestAST.checkASTGen(input,expect,311))        
    
    def test_combo_simple_funcdecl(self):
        input = """int main(){}
        string getText(){}
        boolean isEmptyString(){}
        float isRealNumber(){}"""
        expect = str(Program([FuncDecl(Id("main"),[],IntType(),Block([])),
            FuncDecl(Id("getText"),[],StringType(),Block([])),
            FuncDecl(Id("isEmptyString"),[],BoolType(),Block([])),
            FuncDecl(Id("isRealNumber"),[],FloatType(),Block([]))]))
        self.assertTrue(TestAST.checkASTGen(input,expect,312))        

    def test_more_combo_func_para(self):
        input = """int getSum(int Sum){}
        string getText(string arr){}
        boolean isEmptyString(string arr){}
        float isRealNumber(float fNum){}"""
        expect = str(Program([FuncDecl(Id("getSum"),[VarDecl("Sum",IntType())],IntType(),Block([])),
            FuncDecl(Id("getText"),[VarDecl("arr",StringType())],StringType(),Block([])),
            FuncDecl(Id("isEmptyString"),[VarDecl("arr",StringType())],BoolType(),Block([])),
            FuncDecl(Id("isRealNumber"),[VarDecl("fNum",FloatType())],FloatType(),Block([]))]))
        self.assertTrue(TestAST.checkASTGen(input,expect,313))   

    def test_combo_func_decl_two_para(self):
        input = """int getSum(int Sum, int count){}
        string getText(string arr, int length){}
        boolean isEmptyString(string arr, boolean isTrue){}
        float isRealNumber(float fNum, float dNum, boolean isTrue){}"""
        expect = str(Program([FuncDecl(Id("getSum"),[VarDecl("Sum",IntType()),VarDecl("count",IntType())],IntType(),Block([])),
            FuncDecl(Id("getText"),[VarDecl("arr",StringType()),VarDecl("length",IntType())],StringType(),Block([])),
            FuncDecl(Id("isEmptyString"),[VarDecl("arr",StringType()),VarDecl("isTrue",BoolType())],BoolType(),Block([])),
            FuncDecl(Id("isRealNumber"),[VarDecl("fNum",FloatType()),VarDecl("dNum",FloatType()),VarDecl("isTrue",BoolType())],FloatType(),Block([]))]))
        self.assertTrue(TestAST.checkASTGen(input,expect,314))   

    def test_combo_complex_func(self):
        input = """int getSum(int Sum, int count){}
        string getText(string arr, int length){}
        boolean isEmptyString(string arr, boolean isTrue){}
        float isRealNumber(float fNum, float dNum, boolean isTrue){}"""
        expect = str(Program([FuncDecl(Id("getSum"),[VarDecl("Sum",IntType()),VarDecl("count",IntType())],IntType(),Block([])),
            FuncDecl(Id("getText"),[VarDecl("arr",StringType()),VarDecl("length",IntType())],StringType(),Block([])),
            FuncDecl(Id("isEmptyString"),[VarDecl("arr",StringType()),VarDecl("isTrue",BoolType())],BoolType(),Block([])),
            FuncDecl(Id("isRealNumber"),[VarDecl("fNum",FloatType()),VarDecl("dNum",FloatType()),VarDecl("isTrue",BoolType())],FloatType(),Block([]))]))
        self.assertTrue(TestAST.checkASTGen(input,expect,315))   
    
    def test_morecombo_complex_func(self):
        input = """int getSumSum(int Sum, int count){}
        string getTextText(string arr, int length){}
        boolean isEmptyString(string arr, boolean isTrue){}
        float isRealNumber(float fNum, float dNum, boolean isTrue){}"""
        expect = str(Program([FuncDecl(Id("getSumSum"),[VarDecl("Sum",IntType()),VarDecl("count",IntType())],IntType(),Block([])),
            FuncDecl(Id("getTextText"),[VarDecl("arr",StringType()),VarDecl("length",IntType())],StringType(),Block([])),
            FuncDecl(Id("isEmptyString"),[VarDecl("arr",StringType()),VarDecl("isTrue",BoolType())],BoolType(),Block([])),
            FuncDecl(Id("isRealNumber"),[VarDecl("fNum",FloatType()),VarDecl("dNum",FloatType()),VarDecl("isTrue",BoolType())],FloatType(),Block([]))]))
        self.assertTrue(TestAST.checkASTGen(input,expect,316))   

    def test_func_para_array_type(self):
        input = """int getSum(int Sum[]){}
        string getText(string arr[]){}
        boolean isEmptyString(string arr[]){}
        float isRealNumber(float fNum[]){}"""
        expect = str(Program([FuncDecl(Id("getSum"),[VarDecl("Sum",ArrayPointerType(IntType()))],IntType(),Block([])),
            FuncDecl(Id("getText"),[VarDecl("arr",ArrayPointerType(StringType()))],StringType(),Block([])),
            FuncDecl(Id("isEmptyString"),[VarDecl("arr",ArrayPointerType(StringType()))],BoolType(),Block([])),
            FuncDecl(Id("isRealNumber"),[VarDecl("fNum",ArrayPointerType(FloatType()))],FloatType(),Block([]))]))
        self.assertTrue(TestAST.checkASTGen(input,expect,317))   

    def test_combo_func_two_array_pointer_type_para(self):
        input = """int getSum(int Sum[], int count[]){}
        string getText(string arr[], int length[]){}
        boolean isEmptyString(string arr[], boolean isTrue[]){}
        float isRealNumber(float fNum[], float dNum[], boolean isTrue[]){}"""
        expect = str(Program([FuncDecl(Id("getSum"),[VarDecl("Sum",ArrayPointerType(IntType())),VarDecl("count",ArrayPointerType(IntType()))],IntType(),Block([])),
            FuncDecl(Id("getText"),[VarDecl("arr",ArrayPointerType(StringType())),VarDecl("length",ArrayPointerType(IntType()))],StringType(),Block([])),
            FuncDecl(Id("isEmptyString"),[VarDecl("arr",ArrayPointerType(StringType())),VarDecl("isTrue",ArrayPointerType(BoolType()))],BoolType(),Block([])),
            FuncDecl(Id("isRealNumber"),[VarDecl("fNum",ArrayPointerType(FloatType())),VarDecl("dNum",ArrayPointerType(FloatType())),VarDecl("isTrue",ArrayPointerType(BoolType()))],FloatType(),Block([]))]))
        self.assertTrue(TestAST.checkASTGen(input,expect,318))   

    def test_complex_para_func_array(self):
        input = """int getSum(int Sum[], int count){}
        string getText(string arr[], int length){}
        boolean isEmptyString(string arr[], boolean isTrue){}
        float isRealNumber(float fNum[], float dNum, boolean isTrue[]){}"""
        expect = str(Program([FuncDecl(Id("getSum"),[VarDecl("Sum",ArrayPointerType(IntType())),VarDecl("count",IntType())],IntType(),Block([])),
            FuncDecl(Id("getText"),[VarDecl("arr",ArrayPointerType(StringType())),VarDecl("length",IntType())],StringType(),Block([])),
            FuncDecl(Id("isEmptyString"),[VarDecl("arr",ArrayPointerType(StringType())),VarDecl("isTrue",BoolType())],BoolType(),Block([])),
            FuncDecl(Id("isRealNumber"),[VarDecl("fNum",ArrayPointerType(FloatType())),VarDecl("dNum",FloatType()),VarDecl("isTrue",ArrayPointerType(BoolType()))],FloatType(),Block([]))]))
        self.assertTrue(TestAST.checkASTGen(input,expect,319))   

    def test_array_func(self):
        input = """int[] foo(){}
        string[] getText(){}
        float[] isRealNumber(){}"""
        expect = str(Program([FuncDecl(Id("foo"),[],ArrayPointerType(IntType()),Block([])),
            FuncDecl(Id("getText"),[],ArrayPointerType(StringType()),Block([])),
            FuncDecl(Id("isRealNumber"),[],ArrayPointerType(FloatType()),Block([]))]))
        self.assertTrue(TestAST.checkASTGen(input,expect,320))

    def test_array_func_simple_para(self):
        input = """int[] foo(int number){}
        string[] getText(string arr){}
        float[] isRealNumber(float fNum){}"""
        expect = str(Program([FuncDecl(Id("foo"),[VarDecl("number",IntType())],ArrayPointerType(IntType()),Block([])),
            FuncDecl(Id("getText"),[VarDecl("arr",StringType())],ArrayPointerType(StringType()),Block([])),
            FuncDecl(Id("isRealNumber"),[VarDecl("fNum",FloatType())],ArrayPointerType(FloatType()),Block([]))]))
        self.assertTrue(TestAST.checkASTGen(input,expect,321))   

    def test_array_func_two_para(self):
        input = """int[] foo(int number, int iNum){}
        string[] getText(string arr, string length){}
        float[] isRealNumber(float fNum, boolean isTrue){}"""
        expect = str(Program([FuncDecl(Id("foo"),[VarDecl("number",IntType()),VarDecl("iNum",IntType())],ArrayPointerType(IntType()),Block([])),
            FuncDecl(Id("getText"),[VarDecl("arr",StringType()),VarDecl("length",StringType())],ArrayPointerType(StringType()),Block([])),
            FuncDecl(Id("isRealNumber"),[VarDecl("fNum",FloatType()),VarDecl("isTrue",BoolType())],ArrayPointerType(FloatType()),Block([]))]))
        self.assertTrue(TestAST.checkASTGen(input,expect,322))   

    def test_array_func_para_array_pointer(self):
        input = """int[] foo(int number[]){}
        string[] getText(string arr[]){}
        float[] isRealNumber(float fNum[]){}"""
        expect = str(Program([FuncDecl(Id("foo"),[VarDecl("number",ArrayPointerType(IntType()))],ArrayPointerType(IntType()),Block([])),
            FuncDecl(Id("getText"),[VarDecl("arr",ArrayPointerType(StringType()))],ArrayPointerType(StringType()),Block([])),
            FuncDecl(Id("isRealNumber"),[VarDecl("fNum",ArrayPointerType(FloatType()))],ArrayPointerType(FloatType()),Block([]))]))
        self.assertTrue(TestAST.checkASTGen(input,expect,323))   

    def test_array_func_two_para_array_pointer(self):
        input = """int[] foo(int number[], int iNum[]){}
        string[] getText(string arr[], string length[]){}
        float[] isRealNumber(float fNum[], boolean isTrue[]){}"""
        expect = str(Program([FuncDecl(Id("foo"),[VarDecl("number",ArrayPointerType(IntType())),VarDecl("iNum",ArrayPointerType(IntType()))],ArrayPointerType(IntType()),Block([])),
            FuncDecl(Id("getText"),[VarDecl("arr",ArrayPointerType(StringType())),VarDecl("length",ArrayPointerType(StringType()))],ArrayPointerType(StringType()),Block([])),
            FuncDecl(Id("isRealNumber"),[VarDecl("fNum",ArrayPointerType(FloatType())),VarDecl("isTrue",ArrayPointerType(BoolType()))],ArrayPointerType(FloatType()),Block([]))]))
        self.assertTrue(TestAST.checkASTGen(input,expect,324))   

    def test_array_func_complex_para_array_pointer(self):
        input = """int[] getSum(int Sum[], int count){}
        string[] getText(string arr[], int length){}
        float[] isRealNumber(float fNum[], float dNum, boolean isTrue[]){}"""
        expect = str(Program([FuncDecl(Id("getSum"),[VarDecl("Sum",ArrayPointerType(IntType())),VarDecl("count",IntType())],ArrayPointerType(IntType()),Block([])),
            FuncDecl(Id("getText"),[VarDecl("arr",ArrayPointerType(StringType())),VarDecl("length",IntType())],ArrayPointerType(StringType()),Block([])),
            FuncDecl(Id("isRealNumber"),[VarDecl("fNum",ArrayPointerType(FloatType())),VarDecl("dNum",FloatType()),VarDecl("isTrue",ArrayPointerType(BoolType()))],ArrayPointerType(FloatType()),Block([]))]))
        self.assertTrue(TestAST.checkASTGen(input,expect,325))   

    def test_more_array_funcdecl(self):
        input = """int[] getSum(int Sum){}
        string getText(string arr){}
        float isRealNumber(float fNum){}"""
        expect = str(Program([FuncDecl(Id("getSum"),[VarDecl("Sum",IntType())],ArrayPointerType(IntType()),Block([])),
            FuncDecl(Id("getText"),[VarDecl("arr",StringType())],StringType(),Block([])),
            FuncDecl(Id("isRealNumber"),[VarDecl("fNum",FloatType())],FloatType(),Block([]))]))
        self.assertTrue(TestAST.checkASTGen(input,expect,326))   

    def test_complex_func_complex_para_array(self):
        input = """int[] getSum(int Sum[]){}
        string getText(string arr[]){}
        float isRealNumber(float fNum[]){}
        boolean[] isFact(boolean isTrue[]){}"""
        expect = str(Program([FuncDecl(Id("getSum"),[VarDecl("Sum",ArrayPointerType(IntType()))],ArrayPointerType(IntType()),Block([])),
            FuncDecl(Id("getText"),[VarDecl("arr",ArrayPointerType(StringType()))],StringType(),Block([])),
            FuncDecl(Id("isRealNumber"),[VarDecl("fNum",ArrayPointerType(FloatType()))],FloatType(),Block([])),
            FuncDecl(Id("isFact"),[VarDecl("isTrue",ArrayPointerType(BoolType()))],ArrayPointerType(BoolType()),Block([]))]))
        self.assertTrue(TestAST.checkASTGen(input,expect,327))   

    def test_complex_func_more_complex_para_array_pointer(self):
        input = """int[] getSum(int Sum[], int size){}
        string getText(string arr[], int length){}
        float isRealNumber(float fNum[], boolean isFalse){}
        boolean[] isFact(boolean isTrue[], int size){}"""
        expect = str(Program([FuncDecl(Id("getSum"),[VarDecl("Sum",ArrayPointerType(IntType())),VarDecl("size",IntType())],ArrayPointerType(IntType()),Block([])),
            FuncDecl(Id("getText"),[VarDecl("arr",ArrayPointerType(StringType())),VarDecl("length",IntType())],StringType(),Block([])),
            FuncDecl(Id("isRealNumber"),[VarDecl("fNum",ArrayPointerType(FloatType())),VarDecl("isFalse",BoolType())],FloatType(),Block([])),
            FuncDecl(Id("isFact"),[VarDecl("isTrue",ArrayPointerType(BoolType())),VarDecl("size",IntType())],ArrayPointerType(BoolType()),Block([]))]))
        self.assertTrue(TestAST.checkASTGen(input,expect,328))   

    def test_simple_vardecl_funcdecl(self):
        input = """int iNum;
        string str;
        boolean isTrue;
        void main(){}
        int foo(){}"""
        expect = str(Program([VarDecl("iNum",IntType()),
            VarDecl("str",StringType()),
            VarDecl("isTrue",BoolType()),
            FuncDecl(Id("main"),[],VoidType(),Block([])),
            FuncDecl(Id("foo"),[],IntType(),Block([]))]))
        self.assertTrue(TestAST.checkASTGen(input,expect,329))   

    def test_funcdecl_vardecl(self):
        input = """void main(){}
        int foo(){}
        int iNum;
        string str;
        boolean isTrue;"""
        expect = str(Program([FuncDecl(Id("main"),[],VoidType(),Block([])),
            FuncDecl(Id("foo"),[],IntType(),Block([])),
            VarDecl("iNum",IntType()),
            VarDecl("str",StringType()),
            VarDecl("isTrue",BoolType())]))
        self.assertTrue(TestAST.checkASTGen(input,expect,330))   

    def test_more_var_func(self):
        input = """void main(){}
        int max_size;
        int foo(){}
        int iNum;
        string str;
        boolean isTrue;
        int maxStr(string str){}"""
        expect = str(Program([FuncDecl(Id("main"),[],VoidType(),Block([])),
            VarDecl("max_size",IntType()),
            FuncDecl(Id("foo"),[],IntType(),Block([])),
            VarDecl("iNum",IntType()),
            VarDecl("str",StringType()),
            VarDecl("isTrue",BoolType()),
            FuncDecl(Id("maxStr"),[VarDecl("str",StringType())],IntType(),Block([]))]))
        self.assertTrue(TestAST.checkASTGen(input,expect,331))   

    def test_combo_more_var_func(self):
        input = """int full_size;
        void main(){}
        int max_size;
        int foo(){}
        int iNum;
        string str;
        int maxStr(string str){}
        int min_size;
        string terminal;"""
        expect = str(Program([VarDecl("full_size",IntType()),
            FuncDecl(Id("main"),[],VoidType(),Block([])),
            VarDecl("max_size",IntType()),
            FuncDecl(Id("foo"),[],IntType(),Block([])),
            VarDecl("iNum",IntType()),
            VarDecl("str",StringType()),
            FuncDecl(Id("maxStr"),[VarDecl("str",StringType())],IntType(),Block([])),
            VarDecl("min_size",IntType()),
            VarDecl("terminal",StringType())]))
        self.assertTrue(TestAST.checkASTGen(input,expect,332))   

    def test_combo_var_decl_func_decl(self):
        input = """int iNum, max_level;
        string str,arr;
        boolean isTrue, isFact;
        void main(){}
        int foo(){}"""
        expect = str(Program([VarDecl("iNum",IntType()),
            VarDecl("max_level",IntType()),
            VarDecl("str",StringType()),
            VarDecl("arr",StringType()),
            VarDecl("isTrue",BoolType()),
            VarDecl("isFact",BoolType()),
            FuncDecl(Id("main"),[],VoidType(),Block([])),
            FuncDecl(Id("foo"),[],IntType(),Block([]))]))
        self.assertTrue(TestAST.checkASTGen(input,expect,333))   

    def test_more_array_var_func(self):
        input = """int iNum, max_level[5];
        string str,arr;
        boolean isTrue, isFact[5];
        void main(){}
        int foo(){}"""
        expect = str(Program([VarDecl("iNum",IntType()),
            VarDecl("max_level",ArrayType(IntLiteral(5),IntType())),
            VarDecl("str",StringType()),
            VarDecl("arr",StringType()),
            VarDecl("isTrue",BoolType()),
            VarDecl("isFact",ArrayType(IntLiteral(5),BoolType())),
            FuncDecl(Id("main"),[],VoidType(),Block([])),
            FuncDecl(Id("foo"),[],IntType(),Block([]))]))
        self.assertTrue(TestAST.checkASTGen(input,expect,334))   

    def test_more_array_var_func_para(self):
        input = """int iNum, max_level[5];
        string str,arr;
        boolean isTrue, isFact[5];
        void main(int iNum){}
        int foo(int number){}"""
        expect = str(Program([VarDecl("iNum",IntType()),
            VarDecl("max_level",ArrayType(IntLiteral(5),IntType())),
            VarDecl("str",StringType()),
            VarDecl("arr",StringType()),
            VarDecl("isTrue",BoolType()),
            VarDecl("isFact",ArrayType(IntLiteral(5),BoolType())),
            FuncDecl(Id("main"),[VarDecl("iNum",IntType())],VoidType(),Block([])),
            FuncDecl(Id("foo"),[VarDecl("number",IntType())],IntType(),Block([]))]))
        self.assertTrue(TestAST.checkASTGen(input,expect,335))   

    def test_more_array_var_func_para_array_pointer(self):
        input = """int iNum, max_level[5];
        string str,arr;
        boolean isTrue, isFact[5];
        void main(int iNum[]){}
        int foo(int number[]){}"""
        expect = str(Program([VarDecl("iNum",IntType()),
            VarDecl("max_level",ArrayType(IntLiteral(5),IntType())),
            VarDecl("str",StringType()),
            VarDecl("arr",StringType()),
            VarDecl("isTrue",BoolType()),
            VarDecl("isFact",ArrayType(IntLiteral(5),BoolType())),
            FuncDecl(Id("main"),[VarDecl("iNum",ArrayPointerType(IntType()))],VoidType(),Block([])),
            FuncDecl(Id("foo"),[VarDecl("number",ArrayPointerType(IntType()))],IntType(),Block([]))]))
        self.assertTrue(TestAST.checkASTGen(input,expect,336))   

    def test_more_array_var_func_two_para(self):
        input ="""int iNum, max_level[5];
        string str,arr;
        boolean isTrue, isFact[5];
        void main(int iNum, int size){}
        int foo(int number, int size){}"""
        expect=str(Program([VarDecl("iNum",IntType()),
            VarDecl("max_level",ArrayType(IntLiteral(5),IntType())),
            VarDecl("str",StringType()),
            VarDecl("arr",StringType()),
            VarDecl("isTrue",BoolType()),
            VarDecl("isFact",ArrayType(IntLiteral(5),BoolType())),
            FuncDecl(Id("main"),[VarDecl("iNum",IntType()),VarDecl("size",IntType())],VoidType(),Block([])),
            FuncDecl(Id("foo"),[VarDecl("number",IntType()),VarDecl("size",IntType())],IntType(),Block([]))]))
        self.assertTrue(TestAST.checkASTGen(input,expect,337))   

    def test_more_array_var_func_two_para_array_pointer(self):
        input = """int iNum, max_level[5];
        string str,arr;
        boolean isTrue, isFact[5];
        void main(int iNum[], int size[]){}
        int foo(int number[], int size[]){}"""
        expect = str(Program([VarDecl("iNum",IntType()),
            VarDecl("max_level",ArrayType(IntLiteral(5),IntType())),
            VarDecl("str",StringType()),
            VarDecl("arr",StringType()),
            VarDecl("isTrue",BoolType()),
            VarDecl("isFact",ArrayType(IntLiteral(5),BoolType())),
            FuncDecl(Id("main"),[VarDecl("iNum",ArrayPointerType(IntType())),VarDecl("size",ArrayPointerType(IntType()))],VoidType(),Block([])),
            FuncDecl(Id("foo"),[VarDecl("number",ArrayPointerType(IntType())),VarDecl("size",ArrayPointerType(IntType()))],IntType(),Block([]))]))
        self.assertTrue(TestAST.checkASTGen(input,expect,338))   

    def test_more_vardecl_complex_para_func(self):
        input = """int iNum, max_level[5];
        string str,arr;
        boolean isTrue, isFact[5];
        void main(int iNum, int size[]){}
        int foo(int number[], int size){}"""
        expect = str(Program([VarDecl("iNum",IntType()),
            VarDecl("max_level",ArrayType(IntLiteral(5),IntType())),
            VarDecl("str",StringType()),
            VarDecl("arr",StringType()),
            VarDecl("isTrue",BoolType()),
            VarDecl("isFact",ArrayType(IntLiteral(5),BoolType())),
            FuncDecl(Id("main"),[VarDecl("iNum",IntType()),VarDecl("size",ArrayPointerType(IntType()))],VoidType(),Block([])),
            FuncDecl(Id("foo"),[VarDecl("number",ArrayPointerType(IntType())),VarDecl("size",IntType())],IntType(),Block([]))]))
        self.assertTrue(TestAST.checkASTGen(input,expect,339))   

    def test_more_vardecl_more_complex_para_func_array_type(self):
        input = """int iNum, max_level[5];
        string str,arr;
        boolean isTrue, isFact[5];
        void main(int iNum, int size[]){}
        int[] foo(int number[], int size){}
        int[] maxst(int a, int b, int arr[]){}"""
        expect = str(Program([VarDecl("iNum",IntType()),
            VarDecl("max_level",ArrayType(IntLiteral(5),IntType())),
            VarDecl("str",StringType()),
            VarDecl("arr",StringType()),
            VarDecl("isTrue",BoolType()),
            VarDecl("isFact",ArrayType(IntLiteral(5),BoolType())),
            FuncDecl(Id("main"),[VarDecl("iNum",IntType()),VarDecl("size",ArrayPointerType(IntType()))],VoidType(),Block([])),
            FuncDecl(Id("foo"),[VarDecl("number",ArrayPointerType(IntType())),VarDecl("size",IntType())],ArrayPointerType(IntType()),Block([])),
            FuncDecl(Id("maxst"),[VarDecl("a",IntType()),VarDecl("b",IntType()),VarDecl("arr",ArrayPointerType(IntType()))],ArrayPointerType(IntType()),Block([]))]))
        self.assertTrue(TestAST.checkASTGen(input,expect,340))

    def test_super_complex_var_func_decl(self):
        input = """int iNum, max_level[5];
        string str,arr;
        boolean isTrue, isFact[5];
        void main(int iNum){}
        int[] foo(int number[]){}
        int[] maxst(int a){}
        boolean isFalse;
        int fNumber;
        int getFloat(float fNumber){}"""
        expect = str(Program([VarDecl("iNum",IntType()),
            VarDecl("max_level",ArrayType(IntLiteral(5),IntType())),
            VarDecl("str",StringType()),
            VarDecl("arr",StringType()),
            VarDecl("isTrue",BoolType()),
            VarDecl("isFact",ArrayType(IntLiteral(5),BoolType())),
            FuncDecl(Id("main"),[VarDecl("iNum",IntType())],VoidType(),Block([])),
            FuncDecl(Id("foo"),[VarDecl("number",ArrayPointerType(IntType()))],ArrayPointerType(IntType()),Block([])),
            FuncDecl(Id("maxst"),[VarDecl("a",IntType())],ArrayPointerType(IntType()),Block([])),
            VarDecl("isFalse",BoolType()),
            VarDecl("fNumber",IntType()),
            FuncDecl(Id("getFloat"),[VarDecl("fNumber",FloatType())],IntType(),Block([]))]))
        self.assertTrue(TestAST.checkASTGen(input,expect,341))   

    def test_41(self):
        input = """int iNum, max_level[5];
        string str,arr;
        boolean isTrue, isFact[5];
        void main(int iNum){}
        int[] foo(int number[], int c, int d){}
        int[] maxst(int a, int Number){}
        boolean isFalse;
        int fNumber;
        int getFloat(float fNumber, boolean isFact[]){}"""
        expect = str(Program([VarDecl("iNum",IntType()),
            VarDecl("max_level",ArrayType(IntLiteral(5),IntType())),
            VarDecl("str",StringType()),
            VarDecl("arr",StringType()),
            VarDecl("isTrue",BoolType()),
            VarDecl("isFact",ArrayType(IntLiteral(5),BoolType())),
            FuncDecl(Id("main"),[VarDecl("iNum",IntType())],VoidType(),Block([])),
            FuncDecl(Id("foo"),[VarDecl("number",ArrayPointerType(IntType())),VarDecl("c",IntType()),VarDecl("d",IntType())],ArrayPointerType(IntType()),Block([])),
            FuncDecl(Id("maxst"),[VarDecl("a",IntType()),VarDecl("Number",IntType())],ArrayPointerType(IntType()),Block([])),VarDecl("isFalse",BoolType()),VarDecl("fNumber",IntType()),
            FuncDecl(Id("getFloat"),[VarDecl("fNumber",FloatType()),VarDecl("isFact",ArrayPointerType(BoolType()))],IntType(),Block([]))]))
        self.assertTrue(TestAST.checkASTGen(input,expect,342))   
        
    def test_vardecl_in_function(self):
        input = """int main(){
            int iNum;
        }"""
        expect = str(Program([FuncDecl(Id("main"),[],IntType(),Block([VarDecl("iNum",IntType())]))]))
        self.assertTrue(TestAST.checkASTGen(input,expect,343))   
        
    def test_more_vardecl_in_function(self):
        input = """int main(){
            int iNum, size, length;
        }"""
        expect = str(Program([FuncDecl(Id("main"),[],IntType(),Block([VarDecl("iNum",IntType()),VarDecl("size",IntType()),VarDecl("length",IntType())]))]))
        self.assertTrue(TestAST.checkASTGen(input,expect,344))   
        
    def test_combo_vardecl_in_function(self):
        input = """int main(){
            int iNum, size, length;
            string str;
            boolean isFact;
            float fNum;
        }"""
        expect = str(Program([FuncDecl(Id("main"),[],IntType(),Block([VarDecl("iNum",IntType()),VarDecl("size",IntType()),VarDecl("length",IntType()),VarDecl("str",StringType()),VarDecl("isFact",BoolType()),VarDecl("fNum",FloatType())]))]))
        self.assertTrue(TestAST.checkASTGen(input,expect,345))   
        
    def test_complex_vardecl_in_function(self):
        input = """int main(){
            int iNum, size, length;
            string str[10];
            boolean isFact;
            float fNum, number[5];
            int arr[10];
        }"""
        expect = str(Program([FuncDecl(Id("main"),[],IntType(),Block([VarDecl("iNum",IntType()),VarDecl("size",IntType()),VarDecl("length",IntType()),VarDecl("str",ArrayType(IntLiteral(10),StringType())),VarDecl("isFact",BoolType()),VarDecl("fNum",FloatType()),VarDecl("number",ArrayType(IntLiteral(5),FloatType())),VarDecl("arr",ArrayType(IntLiteral(10),IntType()))]))]))
        self.assertTrue(TestAST.checkASTGen(input,expect,346))
        
    def test_simple_funcall(self):
        input = """void main(){
            foo();
        }"""
        expect = str(Program([FuncDecl(Id("main"),[],VoidType(),Block([CallExpr(Id("foo"),[])]))]))
        self.assertTrue(TestAST.checkASTGen(input,expect,347))   
        
    def test_simple_funcall_para(self):
        input = """void main(){
            foo(25);
        }"""
        expect = str(Program([FuncDecl(Id("main"),[],VoidType(),Block([CallExpr(Id("foo"),[IntLiteral(25)])]))]))
        self.assertTrue(TestAST.checkASTGen(input,expect,348))   
        
    def test_funcall_more_para(self):
        input = """void main(){
            foo(arr, iNum, max, min);
        }"""
        expect = str(Program([FuncDecl(Id("main"),[],VoidType(),Block([CallExpr(Id("foo"),[Id("arr"),Id("iNum"),Id("max"),Id("min")])]))]))
        self.assertTrue(TestAST.checkASTGen(input,expect,349))   
        
    def test_funcall_array_pointer_para(self):
        input = """void main(){
            compare(arr[10]);
        }"""
        expect = str(Program([FuncDecl(Id("main"),[],VoidType(),Block([CallExpr(Id("compare"),[ArrayCell(Id("arr"),IntLiteral(10))])]))]))  
        self.assertTrue(TestAST.checkASTGen(input,expect,350))
    
    def test_simple_dowhile_stmt(self):
        input = """void main(){
            do{
                int a;
            }while true;
        }"""
        expect = str(Program([FuncDecl(Id("main"),[],VoidType(),Block([Dowhile([Block([VarDecl("a",IntType())])],BooleanLiteral(True))]))]))
        self.assertTrue(TestAST.checkASTGen(input,expect,351))   
        
    def test_more_vardecl_dowhile_stmt(self):
        input = """void main(){
            do{
                int a;
                string arr[10];
                int lengthStr, size;
            }while(a!=b);
        }"""
        expect = str(Program([FuncDecl(Id("main"),[],VoidType(),Block([Dowhile([Block([VarDecl("a",IntType()),VarDecl("arr",ArrayType(IntLiteral(10),StringType())),VarDecl("lengthStr",IntType()),VarDecl("size",IntType())])],BinaryOp("!=",Id("a"),Id("b")))]))]))
        self.assertTrue(TestAST.checkASTGen(input,expect,352))   
        
    def test_caculate_dowhile_stmt(self):
        input = """void main(){
            do{
                a = a + 3;
                isTrue = 3 > 5;
                a*(b+5)/15*(9*8*7*arr);
            }while(a!=b);
        }"""
        expect = str(Program([FuncDecl(Id("main"),[],VoidType(),Block([Dowhile([Block([BinaryOp("=",Id("a"),BinaryOp("+",Id("a"),IntLiteral(3))),BinaryOp("=",Id("isTrue"),BinaryOp(">",IntLiteral(3),IntLiteral(5))),BinaryOp("*",BinaryOp("/",BinaryOp("*",Id("a"),BinaryOp("+",Id("b"),IntLiteral(5))),IntLiteral(15)),BinaryOp("*",BinaryOp("*",BinaryOp("*",IntLiteral(9),IntLiteral(8)),IntLiteral(7)),Id("arr")))])],BinaryOp("!=",Id("a"),Id("b")))]))]))
        self.assertTrue(TestAST.checkASTGen(input,expect,353))   
        
    def test_simple_if_stmt(self):
        input = """void main(){
            if(a>5){
                fNum = 1.e-2;
            }
        }"""
        expect = str(Program([FuncDecl(Id("main"),[],VoidType(),Block([If(BinaryOp(">",Id("a"),IntLiteral(5)),Block([BinaryOp("=",Id("fNum"),FloatLiteral(float(0.01)))]),None)]))]))
        self.assertTrue(TestAST.checkASTGen(input,expect,354))   
        
    def test_caculate_if_stmt(self):
        input = """void main(){
            if(a>5){
                fNum = 1.e-2;
                arr[10] = 15+5*2/10;
                foo(2)[20] = 25+arr[10];
            }
        }"""
        expect = str(Program([FuncDecl(Id("main"),[],VoidType(),Block([If(BinaryOp(">",Id("a"),IntLiteral(5)),Block([BinaryOp("=",Id("fNum"),FloatLiteral(float(0.01))),BinaryOp("=",ArrayCell(Id("arr"),IntLiteral(10)),BinaryOp("+",IntLiteral(15),BinaryOp("/",BinaryOp("*",IntLiteral(5),IntLiteral(2)),IntLiteral(10)))),BinaryOp("=",ArrayCell(CallExpr(Id("foo"),[IntLiteral(2)]),IntLiteral(20)),BinaryOp("+",IntLiteral(25),ArrayCell(Id("arr"),IntLiteral(10))))]),None)]))]))
        self.assertTrue(TestAST.checkASTGen(input,expect,355))   
        
    def test_if_stmt_dowhile_stmt(self):
        input = """void main(){
            if(a>5){
                do{
                    a = a+5;
                    foo(2);
                }while (a!=100);
            }
        }"""
        expect = str(Program([FuncDecl(Id("main"),[],VoidType(),Block([If(BinaryOp(">",Id("a"),IntLiteral(5)),Block([Dowhile([Block([BinaryOp("=",Id("a"),BinaryOp("+",Id("a"),IntLiteral(5))),CallExpr(Id("foo"),[IntLiteral(2)])])],BinaryOp("!=",Id("a"),IntLiteral(100)))]),None)]))]))
        self.assertTrue(TestAST.checkASTGen(input,expect,356))   
        
    def test_more_vardecl_if_stmt_dowhile_stmt(self):
        input = """void main(){
            if(a>5){
                int arr[10];
                string str, charStr;
                boolean isTrue, isFact, isFalse;
                float fNum;
                do{
                    a= a+5;
                    foo(2);
                }while (a!=100);
            }
        }"""
        expect = str(Program([FuncDecl(Id("main"),[],VoidType(),Block([If(BinaryOp(">",Id("a"),IntLiteral(5)),Block([VarDecl("arr",ArrayType(IntLiteral(10),IntType())),VarDecl("str",StringType()),VarDecl("charStr",StringType()),VarDecl("isTrue",BoolType()),VarDecl("isFact",BoolType()),VarDecl("isFalse",BoolType()),VarDecl("fNum",FloatType()),Dowhile([Block([BinaryOp("=",Id("a"),BinaryOp("+",Id("a"),IntLiteral(5))),CallExpr(Id("foo"),[IntLiteral(2)])])],BinaryOp("!=",Id("a"),IntLiteral(100)))]),None)]))]))
        self.assertTrue(TestAST.checkASTGen(input,expect,357))   
        
    def test_simple_ifelse_stmt(self):
        input = """void main(){
            if(a>5){
                fNum = 1.e-2;
            }
            else{
                fNum = 2.e-2;
            }
        }"""
        expect = str(Program([FuncDecl(Id("main"),[],VoidType(),Block([If(BinaryOp(">",Id("a"),IntLiteral(5)),Block([BinaryOp("=",Id("fNum"),FloatLiteral(float(0.01)))]),(Block([BinaryOp("=",Id("fNum"),FloatLiteral(float(0.02)))])))]))]))
        self.assertTrue(TestAST.checkASTGen(input,expect,358))   
        
    def test_more_caculate_ifelse_stmt(self):
        input = """void main(){
            if(a>5){
                fNum = 1.e-2;
                arr[10] = 15+5*2/10;
                foo(2)[20] = 25+arr[10];
            }
            else{
                fNum = 2.e-2;
                arr[10] = 0;
                foo(2)[20] = 25+arr[10];
            }
        }"""
        expect = str(Program([FuncDecl(Id("main"),[],VoidType(),Block([If(BinaryOp(">",Id("a"),IntLiteral(5)),Block([BinaryOp("=",Id("fNum"),FloatLiteral(float(0.01))),BinaryOp("=",ArrayCell(Id("arr"),IntLiteral(10)),BinaryOp("+",IntLiteral(15),BinaryOp("/",BinaryOp("*",IntLiteral(5),IntLiteral(2)),IntLiteral(10)))),BinaryOp("=",ArrayCell(CallExpr(Id("foo"),[IntLiteral(2)]),IntLiteral(20)),BinaryOp("+",IntLiteral(25),ArrayCell(Id("arr"),IntLiteral(10))))]),Block([BinaryOp("=",Id("fNum"),FloatLiteral(float(0.02))),BinaryOp("=",ArrayCell(Id("arr"),IntLiteral(10)),IntLiteral(0)),BinaryOp("=",ArrayCell(CallExpr(Id("foo"),[IntLiteral(2)]),IntLiteral(20)),BinaryOp("+",IntLiteral(25),ArrayCell(Id("arr"),IntLiteral(10))))]))]))]))
        self.assertTrue(TestAST.checkASTGen(input,expect,359))   
        
    def test_ifelse_stmt_dowhile_stmt(self):
        input = """void main(){
            if(a>5){
                do{
                    a = a+5;
                    foo(2);
                }while(a!=100);
            }
            else{
                do{
                    a = a * 2;
                    compare(a,max);
                }while(a!=144);
            }
        }"""
        expect = str(Program([FuncDecl(Id("main"),[],VoidType(),Block([If(BinaryOp(">",Id("a"),IntLiteral(5)),Block([Dowhile([Block([BinaryOp("=",Id("a"),BinaryOp("+",Id("a"),IntLiteral(5))),CallExpr(Id("foo"),[IntLiteral(2)])])],BinaryOp("!=",Id("a"),IntLiteral(100)))]),Block([Dowhile([Block([BinaryOp("=",Id("a"),BinaryOp("*",Id("a"),IntLiteral(2))),CallExpr(Id("compare"),[Id("a"),Id("max")])])],BinaryOp("!=",Id("a"),IntLiteral(144)))]))]))]))
        self.assertTrue(TestAST.checkASTGen(input,expect,360))

    def test_complex_ifelse_stmt_vardecl_dowhile_stmt(self):
        input = """void main(){
            if(a>5){
                int arr[10];
                string str, charStr;
                boolean isTrue, isFact, isFalse;
                float fNum;
                do{
                    a= a+5;
                    foo(2);
                }while(a!=100);
            }
            else{
                int arr[10];
                string str, charStr;
                boolean isTrue, isFact, isFalse;
                do{
                a= a*2;
                compare(a, max);
                }while (a!=144);
            }
        }"""
        expect = str(Program([FuncDecl(Id("main"),[],VoidType(),Block([If(BinaryOp(">",Id("a"),IntLiteral(5)),Block([VarDecl("arr",ArrayType(IntLiteral(10),IntType())),VarDecl("str",StringType()),VarDecl("charStr",StringType()),VarDecl("isTrue",BoolType()),VarDecl("isFact",BoolType()),VarDecl("isFalse",BoolType()),VarDecl("fNum",FloatType()),Dowhile([Block([BinaryOp("=",Id("a"),BinaryOp("+",Id("a"),IntLiteral(5))),CallExpr(Id("foo"),[IntLiteral(2)])])],BinaryOp("!=",Id("a"),IntLiteral(100)))]),Block([VarDecl("arr",ArrayType(IntLiteral(10),IntType())),VarDecl("str",StringType()),VarDecl("charStr",StringType()),VarDecl("isTrue",BoolType()),VarDecl("isFact",BoolType()),VarDecl("isFalse",BoolType()),Dowhile([Block([BinaryOp("=",Id("a"),BinaryOp("*",Id("a"),IntLiteral(2))),CallExpr(Id("compare"),[Id("a"),Id("max")])])],BinaryOp("!=",Id("a"),IntLiteral(144)))]))]))]))
        self.assertTrue(TestAST.checkASTGen(input,expect,361))   
        
    def test_nest_if_stmt(self):
        input = """void main(){
            if(a>5){
                if(a!=prime){
                    foo(a);
                }
            }
        }"""
        expect = str(Program([FuncDecl(Id("main"),[],VoidType(),Block([If(BinaryOp(">",Id("a"),IntLiteral(5)),Block([If(BinaryOp("!=",Id("a"),Id("prime")),Block([CallExpr(Id("foo"),[Id("a")])]),None)]),None)]))]))
        self.assertTrue(TestAST.checkASTGen(input,expect,362))   
        
    def test_more_nest_if_stmt_funcall(self):
        input = """void main(){
          if(a>5)
            if(a!=prime)
              if(a%15==1)
                if(a<100)
                  foo(a,max);
        }"""
        expect = str(Program([FuncDecl(Id("main"),[],VoidType(),Block([If(BinaryOp(">",Id("a"),IntLiteral(5)),If(BinaryOp("!=",Id("a"),Id("prime")),If(BinaryOp("==",BinaryOp("%",Id("a"),IntLiteral(15)),IntLiteral(1)),If(BinaryOp("<",Id("a"),IntLiteral(100)),CallExpr(Id("foo"),[Id("a"),Id("max")]),None),None),None),None)]))]))
        self.assertTrue(TestAST.checkASTGen(input,expect,363))   
        
    def test_more_ifelse_stmt_funcall(self):
        input = """void main(){
            if(a>5){
                if(a!=prime){
                    foo(a);
                }
            }
            else{
                if(a==fact(10)){
                    foo(fact(10));
                }
            }
        }"""
        expect = str(Program([FuncDecl(Id("main"),[],VoidType(),Block([If(BinaryOp(">",Id("a"),IntLiteral(5)),Block([If(BinaryOp("!=",Id("a"),Id("prime")),Block([CallExpr(Id("foo"),[Id("a")])]),None)]),Block([If(BinaryOp("==",Id("a"),CallExpr(Id("fact"),[IntLiteral(10)])),Block([CallExpr(Id("foo"),[CallExpr(Id("fact"),[IntLiteral(10)])])]),None)]))]))]))
        self.assertTrue(TestAST.checkASTGen(input,expect,364))   
        
    def test_super_nest_ifelse_stmt_more_funcall(self):
        input = """ void main(){
            if(a>5){
                if(a!=prime){
                    foo(a);
                }
                else{
                    foo(5);
                }
            }
            else{
                if(a==fact(10)){
                    foo(fact(10));
                }
                else{
                    foo(a*15);
                }
            }
        }"""
        expect = str(Program([FuncDecl(Id("main"),[],VoidType(),Block([If(BinaryOp(">",Id("a"),IntLiteral(5)),Block([If(BinaryOp("!=",Id("a"),Id("prime")),Block([CallExpr(Id("foo"),[Id("a")])]),Block([CallExpr(Id("foo"),[IntLiteral(5)])]))]),Block([If(BinaryOp("==",Id("a"),CallExpr(Id("fact"),[IntLiteral(10)])),Block([CallExpr(Id("foo"),[CallExpr(Id("fact"),[IntLiteral(10)])])]),Block([CallExpr(Id("foo"),[BinaryOp("*",Id("a"),IntLiteral(15))])]))]))]))]))
        self.assertTrue(TestAST.checkASTGen(input,expect,365))   
        
    def test_super_nest_ifelse_stmt_super_more_funcall_para_array_pointer(self):
        input = """void main(){
            if(a>5){
                if(a!=prime){
                    foo(a);
                }
                else{
                    foo(5);
                }
                if(arr[5]<a){
                    compare(arr[4],a);
                }
            }
            else{
                if(a==fact(10)){
                    foo(fact(10));
                }
                else{
                    foo(a*15);
                }
                if(arr[5]>a){
                    compare(arr[0],a);
                }
            }
        }"""
        expect = str(Program([FuncDecl(Id("main"),[],VoidType(),Block([If(BinaryOp(">",Id("a"),IntLiteral(5)),Block([If(BinaryOp("!=",Id("a"),Id("prime")),Block([CallExpr(Id("foo"),[Id("a")])]),Block([CallExpr(Id("foo"),[IntLiteral(5)])])),If(BinaryOp("<",ArrayCell(Id("arr"),IntLiteral(5)),Id("a")),Block([CallExpr(Id("compare"),[ArrayCell(Id("arr"),IntLiteral(4)),Id("a")])]),None)]),Block([If(BinaryOp("==",Id("a"),CallExpr(Id("fact"),[IntLiteral(10)])),Block([CallExpr(Id("foo"),[CallExpr(Id("fact"),[IntLiteral(10)])])]),Block([CallExpr(Id("foo"),[BinaryOp("*",Id("a"),IntLiteral(15))])])),If(BinaryOp(">",ArrayCell(Id("arr"),IntLiteral(5)),Id("a")),Block([CallExpr(Id("compare"),[ArrayCell(Id("arr"),IntLiteral(0)),Id("a")])]),None)]))]))]))
        self.assertTrue(TestAST.checkASTGen(input,expect,366))   
        
    def test_simple_for_stmt(self):
        input = """int main(){
            for(i=0;i<iNum;i=i+2){
            }
        }"""
        expect = str(Program([FuncDecl(Id("main"),[],IntType(),Block([For(BinaryOp("=",Id("i"),IntLiteral(0)),BinaryOp("<",Id("i"),Id("iNum")),BinaryOp("=",Id("i"),BinaryOp("+",Id("i"),IntLiteral(2))),Block([]))]))]))
        self.assertTrue(TestAST.checkASTGen(input,expect,367))   
        
    def test_for_stmt_more_funcall(self):
        input = """int main(){
            for(i=0;i<iNum;i=i+2){
                max(i);
                min(iNum);
                compare(max(i), min(iNum));
                foo(max(min(i)));
            }
        }"""
        expect = str(Program([FuncDecl(Id("main"),[],IntType(),Block([For(BinaryOp("=",Id("i"),IntLiteral(0)),BinaryOp("<",Id("i"),Id("iNum")),BinaryOp("=",Id("i"),BinaryOp("+",Id("i"),IntLiteral(2))),Block([CallExpr(Id("max"),[Id("i")]),CallExpr(Id("min"),[Id("iNum")]),CallExpr(Id("compare"),[CallExpr(Id("max"),[Id("i")]),CallExpr(Id("min"),[Id("iNum")])]),CallExpr(Id("foo"),[CallExpr(Id("max"),[CallExpr(Id("min"),[Id("i")])])])]))]))]))
        self.assertTrue(TestAST.checkASTGen(input,expect,368))   
        
    def test_for_stmt_ifelse_stmt(self):
        input = """int main(){
            for(i=0;i<iNum;i=i+2){
                if(i%2==0){
                    println(i);
                }
                else{
                    do{
                        iNum = iNum - i;
                        foo(iNum%i);
                        println(iNum);
                    }while (iNum > pow(i,4));
                }
            }
        }"""
        expect = str(Program([FuncDecl(Id("main"),[],IntType(),Block([For(BinaryOp("=",Id("i"),IntLiteral(0)),BinaryOp("<",Id("i"),Id("iNum")),BinaryOp("=",Id("i"),BinaryOp("+",Id("i"),IntLiteral(2))),Block([If(BinaryOp("==",BinaryOp("%",Id("i"),IntLiteral(2)),IntLiteral(0)),Block([CallExpr(Id("println"),[Id("i")])]),Block([Dowhile([Block([BinaryOp("=",Id("iNum"),BinaryOp("-",Id("iNum"),Id("i"))),CallExpr(Id("foo"),[BinaryOp("%",Id("iNum"),Id("i"))]),CallExpr(Id("println"),[Id("iNum")])])],BinaryOp(">",Id("iNum"),CallExpr(Id("pow"),[Id("i"),IntLiteral(4)])))]))]))]))]))
        self.assertTrue(TestAST.checkASTGen(input,expect,369))   
        
    def test_nest_for_stmt(self):
        input = """int main(){
            for(i=0;i<iNum;i=i+2){
                for(j=0;j<i;j=j+1){
                    foo(i,j,max(i*j,iNum));
                }
            }
        }"""
        expect = str(Program([FuncDecl(Id("main"),[],IntType(),Block([For(BinaryOp("=",Id("i"),IntLiteral(0)),BinaryOp("<",Id("i"),Id("iNum")),BinaryOp("=",Id("i"),BinaryOp("+",Id("i"),IntLiteral(2))),Block([For(BinaryOp("=",Id("j"),IntLiteral(0)),BinaryOp("<",Id("j"),Id("i")),BinaryOp("=",Id("j"),BinaryOp("+",Id("j"),IntLiteral(1))),Block([CallExpr(Id("foo"),[Id("i"),Id("j"),CallExpr(Id("max"),[BinaryOp("*",Id("i"),Id("j")),Id("iNum")])])]))]))]))]))
        self.assertTrue(TestAST.checkASTGen(input,expect,370))
    
    def test_more_nest_for_stmt(self):
        input = """int main(){
            for(i=0;i<iNum;i=i+2){
                for(j=0;j<i;j=j+1){
                    for(k=0;k<j; k= k+1){
                        for(l=0;l<k;l=l+2){
                            getText(i,j,k,l);
                        }
                    }
                }
            }
        }"""
        expect = str(Program([FuncDecl(Id("main"),[],IntType(),Block([For(BinaryOp("=",Id("i"),IntLiteral(0)),BinaryOp("<",Id("i"),Id("iNum")),BinaryOp("=",Id("i"),BinaryOp("+",Id("i"),IntLiteral(2))),Block([For(BinaryOp("=",Id("j"),IntLiteral(0)),BinaryOp("<",Id("j"),Id("i")),BinaryOp("=",Id("j"),BinaryOp("+",Id("j"),IntLiteral(1))),Block([For(BinaryOp("=",Id("k"),IntLiteral(0)),BinaryOp("<",Id("k"),Id("j")),BinaryOp("=",Id("k"),BinaryOp("+",Id("k"),IntLiteral(1))),Block([For(BinaryOp("=",Id("l"),IntLiteral(0)),BinaryOp("<",Id("l"),Id("k")),BinaryOp("=",Id("l"),BinaryOp("+",Id("l"),IntLiteral(2))),Block([CallExpr(Id("getText"),[Id("i"),Id("j"),Id("k"),Id("l")])]))]))]))]))]))]))
        self.assertTrue(TestAST.checkASTGen(input,expect,371))   
        
    def test_71(self):
        input = """int main(){
            for(i=0;i<iNum;i=i+2){
                k = foo(i,pow(i,3));
                if(k>144){
                    break;
                }
                else{
                    continue;
                }
                println(k);
            }
        }"""
        expect = str(Program([FuncDecl(Id("main"),[],IntType(),Block([For(BinaryOp("=",Id("i"),IntLiteral(0)),BinaryOp("<",Id("i"),Id("iNum")),BinaryOp("=",Id("i"),BinaryOp("+",Id("i"),IntLiteral(2))),Block([BinaryOp("=",Id("k"),CallExpr(Id("foo"),[Id("i"),CallExpr(Id("pow"),[Id("i"),IntLiteral(3)])])),If(BinaryOp(">",Id("k"),IntLiteral(144)),Block([Break()]),Block([Continue()])),CallExpr(Id("println"),[Id("k")])]))]))]))
        self.assertTrue(TestAST.checkASTGen(input,expect,372))   
        
    def test_simple_return_exp(self):
        input = """int main(){
            for(i=0;i<iNum;i=i+2){
                k = foo(i,pow(i,3));
                if(k>144){
                    break;
                }
                else{
                    continue;
                }
                if(i==prime){
                    return 0;
                }
                println(k);
            }
        }"""
        expect = str(Program([FuncDecl(Id("main"),[],IntType(),Block([For(BinaryOp("=",Id("i"),IntLiteral(0)),BinaryOp("<",Id("i"),Id("iNum")),BinaryOp("=",Id("i"),BinaryOp("+",Id("i"),IntLiteral(2))),Block([BinaryOp("=",Id("k"),CallExpr(Id("foo"),[Id("i"),CallExpr(Id("pow"),[Id("i"),IntLiteral(3)])])),If(BinaryOp(">",Id("k"),IntLiteral(144)),Block([Break()]),Block([Continue()])),If(BinaryOp("==",Id("i"),Id("prime")),Block([Return(IntLiteral(0))]),None),CallExpr(Id("println"),[Id("k")])]))]))]))
        self.assertTrue(TestAST.checkASTGen(input,expect,373))   
        
    def test_simple_return_none_exp_stmt(self):
        input = """void main(){
            int i;
            ramdon(i);
            if(i>10){
                break;
            }
            else{
                println(i);
                goto(ramdon(i));
            }
            return;
        }"""
        expect = str(Program([FuncDecl(Id("main"),[],VoidType(),Block([VarDecl("i",IntType()),CallExpr(Id("ramdon"),[Id("i")]),If(BinaryOp(">",Id("i"),IntLiteral(10)),Block([Break()]),Block([CallExpr(Id("println"),[Id("i")]),CallExpr(Id("goto"),[CallExpr(Id("ramdon"),[Id("i")])])])),Return(None)]))]))
        self.assertTrue(TestAST.checkASTGen(input,expect,374))   
        
    def test_return_stmt_funcall(self):
        input = """void main(){
            int i;
            ramdon(i);
            if(i>10){
                break;
            }
            else{
                println(i);
                goto(ramdon(i));
            }
            return pow(i,i);
        }"""
        expect = str(Program([FuncDecl(Id("main"),[],VoidType(),Block([VarDecl("i",IntType()),CallExpr(Id("ramdon"),[Id("i")]),If(BinaryOp(">",Id("i"),IntLiteral(10)),Block([Break()]),Block([CallExpr(Id("println"),[Id("i")]),CallExpr(Id("goto"),[CallExpr(Id("ramdon"),[Id("i")])])])),Return(CallExpr(Id("pow"),[Id("i"),Id("i")]))]))]))
        self.assertTrue(TestAST.checkASTGen(input,expect,375))   
        
    def test_simple_assign_stmt(self):
        input = """int foo(int arr, int iNum, boolean isTrue){
            isTrue = iNum %2;
        }"""
        expect = str(Program([FuncDecl(Id("foo"),[VarDecl("arr",IntType()),VarDecl("iNum",IntType()),VarDecl("isTrue",BoolType())],IntType(),Block([BinaryOp("=",Id("isTrue"),BinaryOp("%",Id("iNum"),IntLiteral(2)))]))]))
        self.assertTrue(TestAST.checkASTGen(input,expect,376))   
        
    def test_more_assign_stmt(self):
        input = """int foo(int arr[], int iNum, boolean isTrue){
            isTrue = iNum %2;
            arr[0] = iNum %6;
            iNum = iNum + 19;
            arr[1] = arr[0] + iNum;
            foo(arr, iNum, isTrue);
            return iNum;
        }"""
        expect = str(Program([FuncDecl(Id("foo"),[VarDecl("arr",ArrayPointerType(IntType())),VarDecl("iNum",IntType()),VarDecl("isTrue",BoolType())],IntType(),Block([BinaryOp("=",Id("isTrue"),BinaryOp("%",Id("iNum"),IntLiteral(2))),BinaryOp("=",ArrayCell(Id("arr"),IntLiteral(0)),BinaryOp("%",Id("iNum"),IntLiteral(6))),BinaryOp("=",Id("iNum"),BinaryOp("+",Id("iNum"),IntLiteral(19))),BinaryOp("=",ArrayCell(Id("arr"),IntLiteral(1)),BinaryOp("+",ArrayCell(Id("arr"),IntLiteral(0)),Id("iNum"))),CallExpr(Id("foo"),[Id("arr"),Id("iNum"),Id("isTrue")]),Return(Id("iNum"))]))]))
        self.assertTrue(TestAST.checkASTGen(input,expect,377))   
        
    def test_test_more_return_stmt_assign_stmt_funcall(self):
        input = """int foo(int arr[], int iNum, boolean isTrue){
            return isTrue;
            return arr[0] == iNum %6;
            return iNum == iNum + 19;
            return arr[1] == arr[0] + iNum;
            return foo(arr, iNum, isTrue);
            return iNum;
        }"""
        expect = str(Program([FuncDecl(Id("foo"),[VarDecl("arr",ArrayPointerType(IntType())),VarDecl("iNum",IntType()),VarDecl("isTrue",BoolType())],IntType(),Block([Return(Id("isTrue")),Return(BinaryOp("==",ArrayCell(Id("arr"),IntLiteral(0)),BinaryOp("%",Id("iNum"),IntLiteral(6)))),Return(BinaryOp("==",Id("iNum"),BinaryOp("+",Id("iNum"),IntLiteral(19)))),Return(BinaryOp("==",ArrayCell(Id("arr"),IntLiteral(1)),BinaryOp("+",ArrayCell(Id("arr"),IntLiteral(0)),Id("iNum")))),Return(CallExpr(Id("foo"),[Id("arr"),Id("iNum"),Id("isTrue")])),Return(Id("iNum"))]))]))
        self.assertTrue(TestAST.checkASTGen(input,expect,378))   
        
    def test_simple_block_stmt_in_function_foo(self):
        input = """int foo(int arr[], int iNum, boolean isTrue){
            {}
        }"""
        expect = str(Program([FuncDecl(Id("foo"),[VarDecl("arr",ArrayPointerType(IntType())),VarDecl("iNum",IntType()),VarDecl("isTrue",BoolType())],IntType(),Block([Block([])]))]))
        self.assertTrue(TestAST.checkASTGen(input,expect,379))   
        
    def test_nest_block_stmt_in_function_foo(self):
        input = """int foo(int arr[], int iNum, boolean isTrue){
            {{{{}}}}
        }"""
        expect = str(Program([FuncDecl(Id("foo"),[VarDecl("arr",ArrayPointerType(IntType())),VarDecl("iNum",IntType()),VarDecl("isTrue",BoolType())],IntType(),Block([Block([Block([Block([Block([])])])])]))]))
        self.assertTrue(TestAST.checkASTGen(input,expect,380))

    def test_nest_block_stmt_simple_vardecl(self):
        input = """int foo(int arr[], int iNum, boolean isTrue){
            {{{{int iNum;}}}}
        }"""
        expect = str(Program([FuncDecl(Id("foo"),[VarDecl("arr",ArrayPointerType(IntType())),VarDecl("iNum",IntType()),VarDecl("isTrue",BoolType())],IntType(),Block([Block([Block([Block([Block([VarDecl("iNum",IntType())])])])])]))]))
        self.assertTrue(TestAST.checkASTGen(input,expect,381))   
        
    def test_nest_block_stmt_assign_stmt(self):
        input = """int foo(int arr[], int iNum, boolean isTrue){
            {{{{iNum = iNum + 10;}}}}
        }"""
        expect = str(Program([FuncDecl(Id("foo"),[VarDecl("arr",ArrayPointerType(IntType())),VarDecl("iNum",IntType()),VarDecl("isTrue",BoolType())],IntType(),Block([Block([Block([Block([Block([BinaryOp("=",Id("iNum"),BinaryOp("+",Id("iNum"),IntLiteral(10)))])])])])]))]))
        self.assertTrue(TestAST.checkASTGen(input,expect,382))   
        
    def test_method_putIntLn(self):
        input = """int i;
            int f(){
                return 200;
            }
            void main(){
                int main;
                main = f();
                putIntLn(i);
                {
                   int i;
                   int main;
                   int f;
                   main = f = i = 100;
                   putIntLn(i);
                   putIntLn(main);
                   putIntLn(f);
                }
                   putIntLn(main);
            }"""
        expect = str(Program([VarDecl("i",IntType()),FuncDecl(Id("f"),[],IntType(),Block([Return(IntLiteral(200))])),FuncDecl(Id("main"),[],VoidType(),Block([VarDecl("main",IntType()),BinaryOp("=",Id("main"),CallExpr(Id("f"),[])),CallExpr(Id("putIntLn"),[Id("i")]),Block([VarDecl("i",IntType()),VarDecl("main",IntType()),VarDecl("f",IntType()),BinaryOp("=",Id("main"),BinaryOp("=",Id("f"),BinaryOp("=",Id("i"),IntLiteral(100)))),CallExpr(Id("putIntLn"),[Id("i")]),CallExpr(Id("putIntLn"),[Id("main")]),CallExpr(Id("putIntLn"),[Id("f")])]),CallExpr(Id("putIntLn"),[Id("main")])]))]))
        self.assertTrue(TestAST.checkASTGen(input,expect,383))   
        
    def test_more_stmt_caculate(self):
        input = """int main(){
            int a, b, arr[10];
            boolean isTrue, isFact;
            string str;
            float fNum;
            a = b = 10;
            isTrue = isTrue || isFact;
            arr[1] = isFact && a;
            arr[2] = a == b;
            arr[3] = a != 4;
        }"""
        expect = str(Program([FuncDecl(Id("main"),[],IntType(),Block([VarDecl("a",IntType()),VarDecl("b",IntType()),VarDecl("arr",ArrayType(IntLiteral(10),IntType())),VarDecl("isTrue",BoolType()),VarDecl("isFact",BoolType()),VarDecl("str",StringType()),VarDecl("fNum",FloatType()),BinaryOp("=",Id("a"),BinaryOp("=",Id("b"),IntLiteral(10))),BinaryOp("=",Id("isTrue"),BinaryOp("||",Id("isTrue"),Id("isFact"))),BinaryOp("=",ArrayCell(Id("arr"),IntLiteral(1)),BinaryOp("&&",Id("isFact"),Id("a"))),BinaryOp("=",ArrayCell(Id("arr"),IntLiteral(2)),BinaryOp("==",Id("a"),Id("b"))),BinaryOp("=",ArrayCell(Id("arr"),IntLiteral(3)),BinaryOp("!=",Id("a"),IntLiteral(4)))]))]))
        self.assertTrue(TestAST.checkASTGen(input,expect,384))   
        
    def test_complex_stmt_cacualting(self):
        input = """int main(){
            int a, b, arr[10];
            boolean isTrue, isFact;
            string str;
            float fNum;
            a = b = 10;
            isTrue = isTrue >= isFact;
            arr[1] = isFact > a;
            arr[2] = a < b;
            arr[3] = a <= 4;
        }"""
        expect = str(Program([FuncDecl(Id("main"),[],IntType(),Block([VarDecl("a",IntType()),VarDecl("b",IntType()),VarDecl("arr",ArrayType(IntLiteral(10),IntType())),VarDecl("isTrue",BoolType()),VarDecl("isFact",BoolType()),VarDecl("str",StringType()),VarDecl("fNum",FloatType()),BinaryOp("=",Id("a"),BinaryOp("=",Id("b"),IntLiteral(10))),BinaryOp("=",Id("isTrue"),BinaryOp(">=",Id("isTrue"),Id("isFact"))),BinaryOp("=",ArrayCell(Id("arr"),IntLiteral(1)),BinaryOp(">",Id("isFact"),Id("a"))),BinaryOp("=",ArrayCell(Id("arr"),IntLiteral(2)),BinaryOp("<",Id("a"),Id("b"))),BinaryOp("=",ArrayCell(Id("arr"),IntLiteral(3)),BinaryOp("<=",Id("a"),IntLiteral(4)))]))]))
        self.assertTrue(TestAST.checkASTGen(input,expect,385)) 
        
    def test_combo_var_complex_stmt(self):
        input = """int main(){
            int a, b, arr[10];
            boolean isTrue, isFact;
            string str;
            float fNum;
            a = b = 10;
            str = "binhtu";
            isTrue = a != 10;
            arr[1] = a + 10 + b * 15;
            arr[2] = a - b + b / 25;
            arr[3] = a / 2 - 10 - str;
            arr[4] = b*a;
            arr[5] = (a%10)%2;
        }"""
        expect = str(Program([FuncDecl(Id("main"),[],IntType(),Block([VarDecl("a",IntType()),VarDecl("b",IntType()),VarDecl("arr",ArrayType(IntLiteral(10),IntType())),VarDecl("isTrue",BoolType()),VarDecl("isFact",BoolType()),VarDecl("str",StringType()),VarDecl("fNum",FloatType()),BinaryOp("=",Id("a"),BinaryOp("=",Id("b"),IntLiteral(10))),BinaryOp("=",Id("str"),StringLiteral("binhtu")),BinaryOp("=",Id("isTrue"),BinaryOp("!=",Id("a"),IntLiteral(10))),BinaryOp("=",ArrayCell(Id("arr"),IntLiteral(1)),BinaryOp("+",BinaryOp("+",Id("a"),IntLiteral(10)),BinaryOp("*",Id("b"),IntLiteral(15)))),BinaryOp("=",ArrayCell(Id("arr"),IntLiteral(2)),BinaryOp("+",BinaryOp("-",Id("a"),Id("b")),BinaryOp("/",Id("b"),IntLiteral(25)))),BinaryOp("=",ArrayCell(Id("arr"),IntLiteral(3)),BinaryOp("-",BinaryOp("-",BinaryOp("/",Id("a"),IntLiteral(2)),IntLiteral(10)),Id("str"))),BinaryOp("=",ArrayCell(Id("arr"),IntLiteral(4)),BinaryOp("*",Id("b"),Id("a"))),BinaryOp("=",ArrayCell(Id("arr"),IntLiteral(5)),BinaryOp("%",BinaryOp("%",Id("a"),IntLiteral(10)),IntLiteral(2)))]))]))
        self.assertTrue(TestAST.checkASTGen(input,expect,386))   
        
    def test_UnaryOp(self):
        input = """int main(){
            int a, b, arr[10];
            boolean isTrue, isFact;
            string str;
            float fNum;
            isFact = -isTrue;
            isFact = !isFact;
            isTrue = ----isFact;
            isTrue = isTrue = !!isTrue = -!-!isTrue;
        }"""
        expect = str(Program([FuncDecl(Id("main"),[],IntType(),Block([VarDecl("a",IntType()),VarDecl("b",IntType()),VarDecl("arr",ArrayType(IntLiteral(10),IntType())),VarDecl("isTrue",BoolType()),VarDecl("isFact",BoolType()),VarDecl("str",StringType()),VarDecl("fNum",FloatType()),BinaryOp("=",Id("isFact"),UnaryOp("-",Id("isTrue"))),BinaryOp("=",Id("isFact"),UnaryOp("!",Id("isFact"))),BinaryOp("=",Id("isTrue"),UnaryOp("-",UnaryOp("-",UnaryOp("-",UnaryOp("-",Id("isFact")))))),BinaryOp("=",Id("isTrue"),BinaryOp("=",Id("isTrue"),BinaryOp("=",UnaryOp("!",UnaryOp("!",Id("isTrue"))),UnaryOp("-",UnaryOp("!",UnaryOp("-",UnaryOp("!",Id("isTrue"))))))))]))]))
        self.assertTrue(TestAST.checkASTGen(input,expect,387))   
        
    def test_complex_funcall_assign_stmt_in_func(self):
        input = """int main(){
            int a, b, arr[10];
            boolean isTrue, isFact;
            string str;
            (arr[0])[10] = arr[5]*2;
            foo(2)[10] = foo(2) + a + b;
        }"""
        expect = str(Program([FuncDecl(Id("main"),[],IntType(),Block([VarDecl("a",IntType()),VarDecl("b",IntType()),VarDecl("arr",ArrayType(IntLiteral(10),IntType())),VarDecl("isTrue",BoolType()),VarDecl("isFact",BoolType()),VarDecl("str",StringType()),BinaryOp("=",ArrayCell(ArrayCell(Id("arr"),IntLiteral(0)),IntLiteral(10)),BinaryOp("*",ArrayCell(Id("arr"),IntLiteral(5)),IntLiteral(2))),BinaryOp("=",ArrayCell(CallExpr(Id("foo"),[IntLiteral(2)]),IntLiteral(10)),BinaryOp("+",BinaryOp("+",CallExpr(Id("foo"),[IntLiteral(2)]),Id("a")),Id("b")))]))]))
        self.assertTrue(TestAST.checkASTGen(input,expect,388)) 
        
    def test_super_complex_funcall_array_pointer_combo_var_assign_stmt(self):
        input = """int main(){
            int a, b, arr[10];
            boolean isTrue, isFact;
            string str;
            foo(2)[foo(2)[foo(2)]] = compare(a,b)[arr[foo(2)[15]]];
            foo(arr, arr)[compare(a,b)[25]+ compare(b,a)[29]] = foo(a,b,c,arrp[1])[2];
        }"""
        expect = str(Program([FuncDecl(Id("main"),[],IntType(),Block([VarDecl("a",IntType()),VarDecl("b",IntType()),VarDecl("arr",ArrayType(IntLiteral(10),IntType())),VarDecl("isTrue",BoolType()),VarDecl("isFact",BoolType()),VarDecl("str",StringType()),BinaryOp("=",ArrayCell(CallExpr(Id("foo"),[IntLiteral(2)]),ArrayCell(CallExpr(Id("foo"),[IntLiteral(2)]),CallExpr(Id("foo"),[IntLiteral(2)]))),ArrayCell(CallExpr(Id("compare"),[Id("a"),Id("b")]),ArrayCell(Id("arr"),ArrayCell(CallExpr(Id("foo"),[IntLiteral(2)]),IntLiteral(15))))),BinaryOp("=",ArrayCell(CallExpr(Id("foo"),[Id("arr"),Id("arr")]),BinaryOp("+",ArrayCell(CallExpr(Id("compare"),[Id("a"),Id("b")]),IntLiteral(25)),ArrayCell(CallExpr(Id("compare"),[Id("b"),Id("a")]),IntLiteral(29)))),ArrayCell(CallExpr(Id("foo"),[Id("a"),Id("b"),Id("c"),ArrayCell(Id("arrp"),IntLiteral(1))]),IntLiteral(2)))]))]))
        self.assertTrue(TestAST.checkASTGen(input,expect,389))   
        
    def test_combor_var_and_more_funcall_more_para(self):
        input = """int main(){
            int a, b, arr[10];
            boolean isTrue, isFact;
            string str;
            fact(a,10);
            foo(str, isTrue);
            compare(a,b,isTrue);
            getChar(str, isFact);
        }"""
        expect = str(Program([FuncDecl(Id("main"),[],IntType(),Block([VarDecl("a",IntType()),VarDecl("b",IntType()),VarDecl("arr",ArrayType(IntLiteral(10),IntType())),VarDecl("isTrue",BoolType()),VarDecl("isFact",BoolType()),VarDecl("str",StringType()),CallExpr(Id("fact"),[Id("a"),IntLiteral(10)]),CallExpr(Id("foo"),[Id("str"),Id("isTrue")]),CallExpr(Id("compare"),[Id("a"),Id("b"),Id("isTrue")]),CallExpr(Id("getChar"),[Id("str"),Id("isFact")])]))]))
        self.assertTrue(TestAST.checkASTGen(input,expect,390))

    def test_combor_var_and_more_funcall_more_para_BinaryOP(self):
        input = """int main(){
            int a, b, arr[10];
            boolean isTrue, isFact;
            string str;
            fact(foo(2) + a + b,10);
            foo(str, a + 10 + b * 15);
            compare(a,a + 10 + b * 15,isTrue);
            getChar(str, a + 10 + b * 15);
        }"""
        expect = str(Program([FuncDecl(Id("main"),[],IntType(),Block([VarDecl("a",IntType()),VarDecl("b",IntType()),VarDecl("arr",ArrayType(IntLiteral(10),IntType())),VarDecl("isTrue",BoolType()),VarDecl("isFact",BoolType()),VarDecl("str",StringType()),CallExpr(Id("fact"),[BinaryOp("+",BinaryOp("+",CallExpr(Id("foo"),[IntLiteral(2)]),Id("a")),Id("b")),IntLiteral(10)]),CallExpr(Id("foo"),[Id("str"),BinaryOp("+",BinaryOp("+",Id("a"),IntLiteral(10)),BinaryOp("*",Id("b"),IntLiteral(15)))]),CallExpr(Id("compare"),[Id("a"),BinaryOp("+",BinaryOp("+",Id("a"),IntLiteral(10)),BinaryOp("*",Id("b"),IntLiteral(15))),Id("isTrue")]),CallExpr(Id("getChar"),[Id("str"),BinaryOp("+",BinaryOp("+",Id("a"),IntLiteral(10)),BinaryOp("*",Id("b"),IntLiteral(15)))])]))]))
        self.assertTrue(TestAST.checkASTGen(input,expect,391))   
        
    def test_combor_var_and_more_funcall_complex_para_BinaryOP(self):
        input = """int main(){
            int a, b, arr[10];
            boolean isTrue, isFact;
            string str;
            fact(foo(2)[10] + a + b,arr[10]);
            foo(str[10], a + 10 + b[0] * 15);
            compare(a[3],a + 10 + b[2] * 15,isTrue);
            getChar(str[10], a + 10 + b[15] * 15);
        }"""
        expect = str(Program([FuncDecl(Id("main"),[],IntType(),Block([VarDecl("a",IntType()),VarDecl("b",IntType()),VarDecl("arr",ArrayType(IntLiteral(10),IntType())),VarDecl("isTrue",BoolType()),VarDecl("isFact",BoolType()),VarDecl("str",StringType()),CallExpr(Id("fact"),[BinaryOp("+",BinaryOp("+",ArrayCell(CallExpr(Id("foo"),[IntLiteral(2)]),IntLiteral(10)),Id("a")),Id("b")),ArrayCell(Id("arr"),IntLiteral(10))]),CallExpr(Id("foo"),[ArrayCell(Id("str"),IntLiteral(10)),BinaryOp("+",BinaryOp("+",Id("a"),IntLiteral(10)),BinaryOp("*",ArrayCell(Id("b"),IntLiteral(0)),IntLiteral(15)))]),CallExpr(Id("compare"),[ArrayCell(Id("a"),IntLiteral(3)),BinaryOp("+",BinaryOp("+",Id("a"),IntLiteral(10)),BinaryOp("*",ArrayCell(Id("b"),IntLiteral(2)),IntLiteral(15))),Id("isTrue")]),CallExpr(Id("getChar"),[ArrayCell(Id("str"),IntLiteral(10)),BinaryOp("+",BinaryOp("+",Id("a"),IntLiteral(10)),BinaryOp("*",ArrayCell(Id("b"),IntLiteral(15)),IntLiteral(15)))])]))]))
        self.assertTrue(TestAST.checkASTGen(input,expect,392))   
        
    def test_program_swap_number(self):
        input = """int MAX_SIZE;
        int sum;
        void swap(int a, int b){
            int c;
            c = a;
            a = b;
            b = c;  
        }
        int main(){
            int a, b;
            swap(a,b);
            println(a,b);
        }"""
        expect = str(Program([VarDecl("MAX_SIZE",IntType()),VarDecl("sum",IntType()),FuncDecl(Id("swap"),[VarDecl("a",IntType()),VarDecl("b",IntType())],VoidType(),Block([VarDecl("c",IntType()),BinaryOp("=",Id("c"),Id("a")),BinaryOp("=",Id("a"),Id("b")),BinaryOp("=",Id("b"),Id("c"))])),FuncDecl(Id("main"),[],IntType(),Block([VarDecl("a",IntType()),VarDecl("b",IntType()),CallExpr(Id("swap"),[Id("a"),Id("b")]),CallExpr(Id("println"),[Id("a"),Id("b")])]))]))
        self.assertTrue(TestAST.checkASTGen(input,expect,393))   
        
    def test_program_compare_string(self):
        input = """int compareString(string str1, string str2){
            int result;
            if(strlen(str1) >= strlen(str2)){
                for (i = 0; i < strlen(str2); i =i+1)
                    result = abs(str1[i] - str2[i]);
                for (i = strlen(str2); i < strlen(str1); i=i+1)
                    result =str1[i];
            }
            else{
                for(i=0;i<strlen(str1);i=i+1)
                    for (i = strlen(str1); i < strlen(str2); i=i+1)
                        result = str2[i];
            }
            return result;
        }"""
        expect = str(Program([FuncDecl(Id("compareString"),[VarDecl("str1",StringType()),VarDecl("str2",StringType())],IntType(),Block([VarDecl("result",IntType()),If(BinaryOp(">=",CallExpr(Id("strlen"),[Id("str1")]),CallExpr(Id("strlen"),[Id("str2")])),Block([For(BinaryOp("=",Id("i"),IntLiteral(0)),BinaryOp("<",Id("i"),CallExpr(Id("strlen"),[Id("str2")])),BinaryOp("=",Id("i"),BinaryOp("+",Id("i"),IntLiteral(1))),BinaryOp("=",Id("result"),CallExpr(Id("abs"),[BinaryOp("-",ArrayCell(Id("str1"),Id("i")),ArrayCell(Id("str2"),Id("i")))]))),For(BinaryOp("=",Id("i"),CallExpr(Id("strlen"),[Id("str2")])),BinaryOp("<",Id("i"),CallExpr(Id("strlen"),[Id("str1")])),BinaryOp("=",Id("i"),BinaryOp("+",Id("i"),IntLiteral(1))),BinaryOp("=",Id("result"),ArrayCell(Id("str1"),Id("i"))))]),Block([For(BinaryOp("=",Id("i"),IntLiteral(0)),BinaryOp("<",Id("i"),CallExpr(Id("strlen"),[Id("str1")])),BinaryOp("=",Id("i"),BinaryOp("+",Id("i"),IntLiteral(1))),For(BinaryOp("=",Id("i"),CallExpr(Id("strlen"),[Id("str1")])),BinaryOp("<",Id("i"),CallExpr(Id("strlen"),[Id("str2")])),BinaryOp("=",Id("i"),BinaryOp("+",Id("i"),IntLiteral(1))),BinaryOp("=",Id("result"),ArrayCell(Id("str2"),Id("i")))))])),Return(Id("result"))]))]))
        self.assertTrue(TestAST.checkASTGen(input,expect,394))   
        
    def test_program_quicksort(self):
        input = """void quickSort(int arr[], int left, int right){
            int i,j;
            int tmp;
            int pivot; 
            i = left;
            j = right;
            pivot = arr[(left + right) / 2];
            if((i > j)){
                continue;
            }
            do{
                if (i <= j){
                    tmp = arr[i];
                    arr[i] = arr[j];
                    arr[j] = tmp;
                    i = i + 1;
                    j = j - 1;
                }
            }while(i <= j);
            if (left < j)
                quickSort(arr, left, j);
            if (i < right)
                quickSort(arr, i, right);
        }"""
        expect = str(Program([FuncDecl(Id("quickSort"),[VarDecl("arr",ArrayPointerType(IntType())),VarDecl("left",IntType()),VarDecl("right",IntType())],VoidType(),Block([VarDecl("i",IntType()),VarDecl("j",IntType()),VarDecl("tmp",IntType()),VarDecl("pivot",IntType()),BinaryOp("=",Id("i"),Id("left")),BinaryOp("=",Id("j"),Id("right")),BinaryOp("=",Id("pivot"),ArrayCell(Id("arr"),BinaryOp("/",BinaryOp("+",Id("left"),Id("right")),IntLiteral(2)))),If(BinaryOp(">",Id("i"),Id("j")),Block([Continue()]),None),Dowhile([Block([If(BinaryOp("<=",Id("i"),Id("j")),Block([BinaryOp("=",Id("tmp"),ArrayCell(Id("arr"),Id("i"))),BinaryOp("=",ArrayCell(Id("arr"),Id("i")),ArrayCell(Id("arr"),Id("j"))),BinaryOp("=",ArrayCell(Id("arr"),Id("j")),Id("tmp")),BinaryOp("=",Id("i"),BinaryOp("+",Id("i"),IntLiteral(1))),BinaryOp("=",Id("j"),BinaryOp("-",Id("j"),IntLiteral(1)))]),None)])],BinaryOp("<=",Id("i"),Id("j"))),If(BinaryOp("<",Id("left"),Id("j")),CallExpr(Id("quickSort"),[Id("arr"),Id("left"),Id("j")]),None),If(BinaryOp("<",Id("i"),Id("right")),CallExpr(Id("quickSort"),[Id("arr"),Id("i"),Id("right")]),None)]))]))
        self.assertTrue(TestAST.checkASTGen(input,expect,395))   
        
    def test_check_prime_number(self):
        input = """int main(){
            int n, i, flag;
            flag = 0;
            printf("Enter a positive integer: ");
            scanf("%d",n);
            for(i=2; i<=n/2; i=i+1){
                if(n%i==0){
                    flag=1;
                    break;
                }
            }
            if(flag==0)
                printf("%d is a prime number.",n);
            else
                printf("%d is not a prime number.",n);
            return 0;
        }"""
        expect = str(Program([FuncDecl(Id("main"),[],IntType(),Block([VarDecl("n",IntType()),VarDecl("i",IntType()),VarDecl("flag",IntType()),BinaryOp("=",Id("flag"),IntLiteral(0)),CallExpr(Id("printf"),[StringLiteral("Enter a positive integer: ")]),CallExpr(Id("scanf"),[StringLiteral("%d"),Id("n")]),For(BinaryOp("=",Id("i"),IntLiteral(2)),BinaryOp("<=",Id("i"),BinaryOp("/",Id("n"),IntLiteral(2))),BinaryOp("=",Id("i"),BinaryOp("+",Id("i"),IntLiteral(1))),Block([If(BinaryOp("==",BinaryOp("%",Id("n"),Id("i")),IntLiteral(0)),Block([BinaryOp("=",Id("flag"),IntLiteral(1)),Break()]),None)])),If(BinaryOp("==",Id("flag"),IntLiteral(0)),CallExpr(Id("printf"),[StringLiteral("%d is a prime number."),Id("n")]),CallExpr(Id("printf"),[StringLiteral("%d is not a prime number."),Id("n")])),Return(IntLiteral(0))]))]))
        self.assertTrue(TestAST.checkASTGen(input,expect,396))   
        
    def test_program_TowerOfHanoi(self):
        input = """void towerOfHanoi(int n, string from_rod, string to_rod, string aux_rod){
            if (n == 1){
                printf("n Move disk 1 from rod %c to rod %c", from_rod, to_rod);
                return;
            }
            towerOfHanoi(n-1, from_rod, aux_rod, to_rod);
            printf("n Move disk %d from rod %c to rod %c", n, from_rod, to_rod);
            towerOfHanoi(n-1, aux_rod, to_rod, from_rod);
        }
        int main(){
            int n;
            n=4;
            towerOfHanoi(n, "A", "B", "C");
            return 0;
        }"""
        expect = str(Program([FuncDecl(Id("towerOfHanoi"),[VarDecl("n",IntType()),VarDecl("from_rod",StringType()),VarDecl("to_rod",StringType()),VarDecl("aux_rod",StringType())],VoidType(),Block([If(BinaryOp("==",Id("n"),IntLiteral(1)),Block([CallExpr(Id("printf"),[StringLiteral("n Move disk 1 from rod %c to rod %c"),Id("from_rod"),Id("to_rod")]),Return(None)]),None),CallExpr(Id("towerOfHanoi"),[BinaryOp("-",Id("n"),IntLiteral(1)),Id("from_rod"),Id("aux_rod"),Id("to_rod")]),CallExpr(Id("printf"),[StringLiteral("n Move disk %d from rod %c to rod %c"),Id("n"),Id("from_rod"),Id("to_rod")]),CallExpr(Id("towerOfHanoi"),[BinaryOp("-",Id("n"),IntLiteral(1)),Id("aux_rod"),Id("to_rod"),Id("from_rod")])])),FuncDecl(Id("main"),[],IntType(),Block([VarDecl("n",IntType()),BinaryOp("=",Id("n"),IntLiteral(4)),CallExpr(Id("towerOfHanoi"),[Id("n"),StringLiteral("A"),StringLiteral("B"),StringLiteral("C")]),Return(IntLiteral(0))]))]))
        self.assertTrue(TestAST.checkASTGen(input,expect,397))   
        
    def test_program_bublesort(self):
        input = """int[] bubble(int array[], int n){
            int i, j, swap;
            for(i=0; i<n-1; i=i+1){
                for (j=0; j<n-i-1; j=j+1){
                    if(array[j]>array[j+1]){
                        swap=array[j];
                        array[j]=array[j+1];
                        array[j+1]=swap;
                    }
                }
            }
        }"""
        expect = str(Program([FuncDecl(Id("bubble"),[VarDecl("array",ArrayPointerType(IntType())),VarDecl("n",IntType())],ArrayPointerType(IntType()),Block([VarDecl("i",IntType()),VarDecl("j",IntType()),VarDecl("swap",IntType()),For(BinaryOp("=",Id("i"),IntLiteral(0)),BinaryOp("<",Id("i"),BinaryOp("-",Id("n"),IntLiteral(1))),BinaryOp("=",Id("i"),BinaryOp("+",Id("i"),IntLiteral(1))),Block([For(BinaryOp("=",Id("j"),IntLiteral(0)),BinaryOp("<",Id("j"),BinaryOp("-",BinaryOp("-",Id("n"),Id("i")),IntLiteral(1))),BinaryOp("=",Id("j"),BinaryOp("+",Id("j"),IntLiteral(1))),Block([If(BinaryOp(">",ArrayCell(Id("array"),Id("j")),ArrayCell(Id("array"),BinaryOp("+",Id("j"),IntLiteral(1)))),Block([BinaryOp("=",Id("swap"),ArrayCell(Id("array"),Id("j"))),BinaryOp("=",ArrayCell(Id("array"),Id("j")),ArrayCell(Id("array"),BinaryOp("+",Id("j"),IntLiteral(1)))),BinaryOp("=",ArrayCell(Id("array"),BinaryOp("+",Id("j"),IntLiteral(1))),Id("swap"))]),None)]))]))]))]))
        self.assertTrue(TestAST.checkASTGen(input,expect,398))   
        
    def test_program_fibonaci(self):
        input = """int fibo(int n){
            if(n==0) 
                return 0;
            if(n==1)
                return 1;
            else 
                return fibo(n-1)+fibo(n-2);
        }
        int main(){
            int i;
            for(i=0;i<10;i=i+1) 
                print(fibo(i));
        }"""
        expect = str(Program([FuncDecl(Id("fibo"),[VarDecl("n",IntType())],IntType(),Block([If(BinaryOp("==",Id("n"),IntLiteral(0)),Return(IntLiteral(0)),None),If(BinaryOp("==",Id("n"),IntLiteral(1)),Return(IntLiteral(1)),Return(BinaryOp("+",CallExpr(Id("fibo"),[BinaryOp("-",Id("n"),IntLiteral(1))]),CallExpr(Id("fibo"),[BinaryOp("-",Id("n"),IntLiteral(2))]))))])),FuncDecl(Id("main"),[],IntType(),Block([VarDecl("i",IntType()),For(BinaryOp("=",Id("i"),IntLiteral(0)),BinaryOp("<",Id("i"),IntLiteral(10)),BinaryOp("=",Id("i"),BinaryOp("+",Id("i"),IntLiteral(1))),CallExpr(Id("print"),[CallExpr(Id("fibo"),[Id("i")])]))]))]))
        self.assertTrue(TestAST.checkASTGen(input,expect,399))   
        
    def test_ProgramBinToGray(self):
        input = """int main(){
            int bin, gray;
            printf("Enter a binary number: ");
            scanf("%d", bin);
            gray = bintogray(bin);
            printf("The gray code of %d is %d", bin, gray);
            return 0;
        }
        int bintogray(int bin){
            int a, b, result, i;
            result=0;
            i=0;
            do{
                a = bin % 10;
                bin = bin / 10;
                b = bin % 10;
                if ((a && !b) || (!a && b)){
                    result = result + pow(10, i);
                }
                i=i+1;
            }while (bin != 0);
            return result;
        }"""
        expect = str(Program([FuncDecl(Id("main"),[],IntType(),Block([VarDecl("bin",IntType()),VarDecl("gray",IntType()),CallExpr(Id("printf"),[StringLiteral("Enter a binary number: ")]),CallExpr(Id("scanf"),[StringLiteral("%d"),Id("bin")]),BinaryOp("=",Id("gray"),CallExpr(Id("bintogray"),[Id("bin")])),CallExpr(Id("printf"),[StringLiteral("The gray code of %d is %d"),Id("bin"),Id("gray")]),Return(IntLiteral(0))])),FuncDecl(Id("bintogray"),[VarDecl("bin",IntType())],IntType(),Block([VarDecl("a",IntType()),VarDecl("b",IntType()),VarDecl("result",IntType()),VarDecl("i",IntType()),BinaryOp("=",Id("result"),IntLiteral(0)),BinaryOp("=",Id("i"),IntLiteral(0)),Dowhile([Block([BinaryOp("=",Id("a"),BinaryOp("%",Id("bin"),IntLiteral(10))),BinaryOp("=",Id("bin"),BinaryOp("/",Id("bin"),IntLiteral(10))),BinaryOp("=",Id("b"),BinaryOp("%",Id("bin"),IntLiteral(10))),If(BinaryOp("||",BinaryOp("&&",Id("a"),UnaryOp("!",Id("b"))),BinaryOp("&&",UnaryOp("!",Id("a")),Id("b"))),Block([BinaryOp("=",Id("result"),BinaryOp("+",Id("result"),CallExpr(Id("pow"),[IntLiteral(10),Id("i")])))]),None),BinaryOp("=",Id("i"),BinaryOp("+",Id("i"),IntLiteral(1)))])],BinaryOp("!=",Id("bin"),IntLiteral(0))),Return(Id("result"))]))]))
        self.assertTrue(TestAST.checkASTGen(input,expect,400))