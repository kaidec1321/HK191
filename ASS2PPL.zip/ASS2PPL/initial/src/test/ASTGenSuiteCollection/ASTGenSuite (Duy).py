import unittest
from TestUtils import TestAST
from AST import *

class ASTGenSuite(unittest.TestCase):
    def test_simple_program(self):
        """Simple program: int main() {} """
        input = """int main() {}"""
        expect = str(Program([FuncDecl(Id("main"),[],IntType(),Block([]))]))
        self.assertTrue(TestAST.checkASTGen(input,expect,300))

    def test_more_complex_program(self):
        """More complex program"""
        input = """int main () {
            putIntLn(4);
        }"""
        expect = str(Program([FuncDecl(Id("main"),[],IntType(),Block([CallExpr(Id("putIntLn"),[IntLiteral(4)])]))]))
        self.assertTrue(TestAST.checkASTGen(input,expect,301))
    
    def test_call_without_parameter(self):
        """More complex program"""
        input = """int main () {
            getIntLn();
        }"""
        expect = str(Program([FuncDecl(Id("main"),[],IntType(),Block([CallExpr(Id("getIntLn"),[])]))]))
        self.assertTrue(TestAST.checkASTGen(input,expect,302))

    def test_var_decl(self):
        """Simple Var Decl"""
        input = """int a;
        int b;
        int c;
        float c[1];"""
        expect = str(Program([VarDecl("a",IntType()),VarDecl("b",IntType()),VarDecl("c",IntType()),VarDecl("c",ArrayType(1,FloatType()))]))
        self.assertTrue(TestAST.checkASTGen(input,expect,303))
   
    def test_list_var_decl(self):
        """List Vardecl"""
        input = """int a,b,c,d[1],e[2];"""
        expect = str(Program([VarDecl("a",IntType()),VarDecl("b",IntType()),VarDecl("c",IntType()),VarDecl("d",ArrayType(1,IntType())),VarDecl("e",ArrayType(2,IntType()))]))
        self.assertTrue(TestAST.checkASTGen(input,expect,304))

    def test_list_var_decl_1(self):
        """List Var Decl"""
        input = """float a,b,c,d[2];
        int x[1],y[2],z[3];
        string abc;
        float efg;"""
        expect = str(Program([VarDecl("a",FloatType()),VarDecl("b",FloatType()),VarDecl("c",FloatType()),VarDecl("d",ArrayType(2,FloatType())),VarDecl("x",ArrayType(1,IntType())),VarDecl("y",ArrayType(2,IntType())),VarDecl("z",ArrayType(3,IntType())),VarDecl("abc",StringType()),VarDecl("efg",FloatType())]))
        self.assertTrue(TestAST.checkASTGen(input,expect,305))

    def test_func_decl(self):
        """Test simple function declaration"""
        input = """int main(int a, int b[], float aBC123){
            {
                {
                    int a,b,c;
                    float abcEDF;
                }
            }
        }"""
        expect = str(Program([FuncDecl(Id("main"),[VarDecl("a",IntType()),VarDecl("b",ArrayPointerType(IntType())),VarDecl("aBC123",FloatType())],IntType(),Block([Block([Block([VarDecl("a",IntType()),VarDecl("b",IntType()),VarDecl("c",IntType()),VarDecl("abcEDF",FloatType())])])]))]))
        self.assertTrue(TestAST.checkASTGen(input,expect,306))

    def test_many_func_decls(self):
        """Test program with many fucntion declaration"""
        input = """
        void main(){

        }
        
        int func1(float a, float b[], float c){
            {

            }
        }
        
        int[] func2(int d, int e, int f[]){
            int a;
            {
                int a;
            }
            float a;
        }"""
    
        expect = str(Program([FuncDecl(Id("main"),[],VoidType(),Block([])),FuncDecl(Id("func1"),[VarDecl("a",FloatType()),VarDecl("b",ArrayPointerType(FloatType())),VarDecl("c",FloatType())],IntType(),Block([Block([])])),FuncDecl(Id("func2"),[VarDecl("d",IntType()),VarDecl("e",IntType()),VarDecl("f",ArrayPointerType(IntType()))],ArrayPointerType(IntType()),Block([VarDecl("a",IntType()),Block([VarDecl("a",IntType())]),VarDecl("a",FloatType())]))]))
        self.assertTrue(TestAST.checkASTGen(input,expect,307))

    def test_func_decl_without_paradecl(self):
        """Test fucntion decl without parameters"""
        input = """
        void main(){
            {

            }
        }
        
        float main1(){

        }
        
        int main2(){

        }"""

        expect = str(Program([FuncDecl(Id("main"),[],VoidType(),Block([Block([])])),FuncDecl(Id("main1"),[],FloatType(),Block([])),FuncDecl(Id("main2"),[],IntType(),Block([]))]))
        self.assertTrue(TestAST.checkASTGen(input, expect, 308))

    def test_var_func_decl(self):
        """Combine var decl and func decl together"""
        input = """
        int a,b,c;
        float def123[123];
        
        int main(float a[], int b[], float c){
            
        }
        
        int[] foo(int a){
            boolean a,b,c;
        }"""

        expect = str(Program([VarDecl("a",IntType()),VarDecl("b",IntType()),VarDecl("c",IntType()),VarDecl("def123",ArrayType(123,FloatType())),FuncDecl(Id("main"),[VarDecl("a",ArrayPointerType(FloatType())),VarDecl("b",ArrayPointerType(IntType())),VarDecl("c",FloatType())],IntType(),Block([])),FuncDecl(Id("foo"),[VarDecl("a",IntType())],ArrayPointerType(IntType()),Block([VarDecl("a",BoolType()),VarDecl("b",BoolType()),VarDecl("c",BoolType())]))]))
        self.assertTrue(TestAST.checkASTGen(input, expect, 309))

    def test_expr_stmt_1(self):
        """Test simple expression statements 1"""
        input = """
        void main(){
            abc = cde + def;
            duy = anh + le;
            "iron man is legend" = true;
            (tonystark > brucewayne) > (billgate > mark);
        }"""

        expect = str(Program([FuncDecl(Id("main"),[],VoidType(),Block([BinaryOp("=",Id("abc"),BinaryOp("+",Id("cde"),Id("def"))),BinaryOp("=",Id("duy"),BinaryOp("+",Id("anh"),Id("le"))),BinaryOp("=",StringLiteral("iron man is legend"),BooleanLiteral(True)),BinaryOp(">",BinaryOp(">",Id("tonystark"),Id("brucewayne")),BinaryOp(">",Id("billgate"),Id("mark")))]))]))
        self.assertTrue(TestAST.checkASTGen(input, expect, 310))

    def test_expr_stmt_2(self):
        """Test simple expression statements 2"""
        input = """
            void main(){
                abc != duyanhle;
                loinhuan = doanhthu - kinhphi;
                n = n/2;
                ngaytrongnam <= 366;
                namnhuan / 4 == 0;
            }
        """
        
        expect = str(Program([FuncDecl(Id("main"),[],VoidType(),Block([BinaryOp("!=",Id("abc"),Id("duyanhle")),BinaryOp("=",Id("loinhuan"),BinaryOp("-",Id("doanhthu"),Id("kinhphi"))),BinaryOp("=",Id("n"),BinaryOp("/",Id("n"),IntLiteral(2))),BinaryOp("<=",Id("ngaytrongnam"),IntLiteral(366)),BinaryOp("==",BinaryOp("/",Id("namnhuan"),IntLiteral(4)),IntLiteral(0))]))]))
        self.assertTrue(TestAST.checkASTGen(input, expect, 311))

    def test_expr_stmt_3(self):
        """Test simple expression statements with associaty"""
        input = """
        float foo(){
            a + b - c * d / 2 = 0;
            -a + !b + d == 2;
            (duy + anh >= le - bk) <= khoamt;
            tiengiang[chauthanh + huyen] == 1;
        }
        """

        expect = str(Program([FuncDecl(Id("foo"),[],FloatType(),Block([BinaryOp("=",BinaryOp("-",BinaryOp("+",Id("a"),Id("b")),BinaryOp("/",BinaryOp("*",Id("c"),Id("d")),IntLiteral(2))),IntLiteral(0)),BinaryOp("==",BinaryOp("+",BinaryOp("+",UnaryOp("-",Id("a")),UnaryOp("!",Id("b"))),Id("d")),IntLiteral(2)),BinaryOp("<=",BinaryOp(">=",BinaryOp("+",Id("duy"),Id("anh")),BinaryOp("-",Id("le"),Id("bk"))),Id("khoamt")),BinaryOp("==",ArrayCell(Id("tiengiang"),BinaryOp("+",Id("chauthanh"),Id("huyen"))),IntLiteral(1))]))]))
        self.assertTrue(TestAST.checkASTGen(input, expect, 312))

    def test_expr_stmt_4(self):
        """Test simple funccall expression"""
        input = """
        int foo1(){
            foo(a,b,c,"duyanhle",x+y+z);
            foo2() + foo3() = foo4();
            foo5 = foo6(foo7(), foo8());
        }"""

        expect = str(Program([FuncDecl(Id("foo1"),[],IntType(),Block([CallExpr(Id("foo"),[Id("a"),Id("b"),Id("c"),StringLiteral("duyanhle"),BinaryOp("+",BinaryOp("+",Id("x"),Id("y")),Id("z"))]),BinaryOp("=",BinaryOp("+",CallExpr(Id("foo2"),[]),CallExpr(Id("foo3"),[])),CallExpr(Id("foo4"),[])),BinaryOp("=",Id("foo5"),CallExpr(Id("foo6"),[CallExpr(Id("foo7"),[]),CallExpr(Id("foo8"),[])]))]))]))
        self.assertTrue(TestAST.checkASTGen(input, expect, 313))

    def test_expr_stmt_5(self):
        """Test simple index expression"""
        input = """
        void main(){
            foo(a,b,c,foo1())[x + 1 * 2] = duy[anh + le + "abc"] + x + y[2];
            foo[foo() + foo1() / foo3()] * goo[goo(goo())];
        }
        """

        expect = str(Program([FuncDecl(Id("main"),[],VoidType(),Block([BinaryOp("=",ArrayCell(CallExpr(Id("foo"),[Id("a"),Id("b"),Id("c"),CallExpr(Id("foo1"),[])]),BinaryOp("+",Id("x"),BinaryOp("*",IntLiteral(1),IntLiteral(2)))),BinaryOp("+",BinaryOp("+",ArrayCell(Id("duy"),BinaryOp("+",BinaryOp("+",Id("anh"),Id("le")),StringLiteral("abc"))),Id("x")),ArrayCell(Id("y"),IntLiteral(2)))),BinaryOp("*",ArrayCell(Id("foo"),BinaryOp("+",CallExpr(Id("foo"),[]),BinaryOp("/",CallExpr(Id("foo1"),[]),CallExpr(Id("foo3"),[])))),ArrayCell(Id("goo"),CallExpr(Id("goo"),[CallExpr(Id("goo"),[])])))]))]))
        self.assertTrue(TestAST.checkASTGen(input, expect, 314))

    def test_if_stmt(self):
        """Test func with if stmt"""
        input = """
        void main(){
            if(hoclai >= 1 && monhoc == "ppl"){
                print("ppl is difficult");
            }
            else{
                print("ppl is so easy");
            }
        }"""
        
        expect = str(Program([FuncDecl(Id("main"),[],VoidType(),Block([If(BinaryOp("&&",BinaryOp(">=",Id("hoclai"),IntLiteral(1)),BinaryOp("==",Id("monhoc"),StringLiteral("ppl"))),Block([CallExpr(Id("print"),[StringLiteral("ppl is difficult")])]),Block([CallExpr(Id("print"),[StringLiteral("ppl is so easy")])]))]))]))
        self.assertTrue(TestAST.checkASTGen(input, expect, 315))

    def test_many_if_stmt(self):
        """Test func with many if-else stmts"""
        input = """
        void foo(){
            int profit;
            boolean spidy_stay;
            if(profit >= 1000000){
                spidy_stay = true;
            }
            else{
                if(marvel_nego_sony == ok){
                    spidy_stay = true;
                }
                else{
                    spidy_stay = false;
                }
            }
        }"""

        expect = str(Program([FuncDecl(Id("foo"),[],VoidType(),Block([VarDecl("profit",IntType()),VarDecl("spidy_stay",BoolType()),If(BinaryOp(">=",Id("profit"),IntLiteral(1000000)),Block([BinaryOp("=",Id("spidy_stay"),BooleanLiteral(True))]),Block([If(BinaryOp("==",Id("marvel_nego_sony"),Id("ok")),Block([BinaryOp("=",Id("spidy_stay"),BooleanLiteral(True))]),Block([BinaryOp("=",Id("spidy_stay"),BooleanLiteral(False))]))]))]))]))
        self.assertTrue(TestAST.checkASTGen(input, expect, 316))

    def test_for_stmt(self):
        """Test function with for stmt"""
        input = """
        float foo(){
            for(duy = 20; duy < 100; duy = duy + 1){
                print("Duy lon them mot tuoi");
                for(hocki = 1; hocki < 3;hocky = hocky + 1){
                    print("Duy hoc xong mot ki");
                }
            }
        }"""

        expect = str(Program([FuncDecl(Id("foo"),[],FloatType(),Block([For(BinaryOp("=",Id("duy"),IntLiteral(20)),BinaryOp("<",Id("duy"),IntLiteral(100)),BinaryOp("=",Id("duy"),BinaryOp("+",Id("duy"),IntLiteral(1))),Block([CallExpr(Id("print"),[StringLiteral("Duy lon them mot tuoi")]),For(BinaryOp("=",Id("hocki"),IntLiteral(1)),BinaryOp("<",Id("hocki"),IntLiteral(3)),BinaryOp("=",Id("hocky"),BinaryOp("+",Id("hocky"),IntLiteral(1))),Block([CallExpr(Id("print"),[StringLiteral("Duy hoc xong mot ki")])]))]))]))]))
        self.assertTrue(TestAST.checkASTGen(input, expect, 317))   
    
    def test_many_for_stmt(self):
        """Test function with many for stmt"""
        input = """
        int[] foo1(){
            for(ngay = 1; ngay <30; ngay = ngay +1){
                for(thang = 1;thang <12; thang = thang +1){
                    for(nam  = 1999; nam < 2999; nam = nam +1){
                        print("Hom nay la ngay moi");
                    }
                }
            }
        }"""

        expect = str(Program([FuncDecl(Id("foo1"),[],ArrayPointerType("IntType"),Block([For(BinaryOp("=",Id("ngay"),IntLiteral(1)),BinaryOp("<",Id("ngay"),IntLiteral(30)),BinaryOp("=",Id("ngay"),BinaryOp("+",Id("ngay"),IntLiteral(1))),Block([For(BinaryOp("=",Id("thang"),IntLiteral(1)),BinaryOp("<",Id("thang"),IntLiteral(12)),BinaryOp("=",Id("thang"),BinaryOp("+",Id("thang"),IntLiteral(1))),Block([For(BinaryOp("=",Id("nam"),IntLiteral(1999)),BinaryOp("<",Id("nam"),IntLiteral(2999)),BinaryOp("=",Id("nam"),BinaryOp("+",Id("nam"),IntLiteral(1))),Block([CallExpr(Id("print"),[StringLiteral("Hom nay la ngay moi")])]))]))]))]))]))
        self.assertTrue(TestAST.checkASTGen(input, expect, 318))    
        
    def test_many_for_stmt_1(self):
        """Test fucntion with many stmt for"""
        input = """
        int main(){
            for(i = 0; i< n; i = i + 1){
                for(j = 0 ; j< m ; j = j +2){
                    for(x;y;z){
                        for(a;b;c){

                        }
                    }
                }
            }
        }"""

        expect = str(Program([FuncDecl(Id("main"),[],IntType(),Block([For(BinaryOp("=",Id("i"),IntLiteral(0)),BinaryOp("<",Id("i"),Id("n")),BinaryOp("=",Id("i"),BinaryOp("+",Id("i"),IntLiteral(1))),Block([For(BinaryOp("=",Id("j"),IntLiteral(0)),BinaryOp("<",Id("j"),Id("m")),BinaryOp("=",Id("j"),BinaryOp("+",Id("j"),IntLiteral(2))),Block([For(Id("x"),Id("y"),Id("z"),Block([For(Id("a"),Id("b"),Id("c"),Block([]))]))]))]))]))]))
        self.assertTrue(TestAST.checkASTGen(input, expect, 319))

    def test_do_while_stmt(self):
        """Test fucntion with do while statement"""
        input = """
        int main(){
            do{
                an;
                code;
                choigame;
                ngu;
            }
            while(dev == true);
        }"""

        expect = str(Program([FuncDecl(Id("main"),[],IntType(),Block([Dowhile([Block([Id("an"),Id("code"),Id("choigame"),Id("ngu")])],BinaryOp("==",Id("dev"),BooleanLiteral(True)))]))]))
        self.assertTrue(TestAST.checkASTGen(input, expect, 320))

    def test_many_do_while_stmts(self):
        """Let's create a func with many dowhile stmts"""
        input = """
        void main(){
            float diemso,diemrenluyen;
            do{
                do{
                    diemrenluyen = diemrenluyen +5;
                }
                while(diseminar == true);
                do{
                    diemso = diemso - 1;
                }
                while(cuphoc == true);
                diemtk = (diemso + diemrenluyen) /2;
            }
            while(hockychuaketthuc);
        }"""
        
        expect = str(Program([FuncDecl(Id("main"),[],VoidType(),Block([VarDecl("diemso",FloatType()),VarDecl("diemrenluyen",FloatType()),Dowhile([Block([Dowhile([Block([BinaryOp("=",Id("diemrenluyen"),BinaryOp("+",Id("diemrenluyen"),IntLiteral(5)))])],BinaryOp("==",Id("diseminar"),BooleanLiteral(True))),Dowhile([Block([BinaryOp("=",Id("diemso"),BinaryOp("-",Id("diemso"),IntLiteral(1)))])],BinaryOp("==",Id("cuphoc"),BooleanLiteral(True))),BinaryOp("=",Id("diemtk"),BinaryOp("/",BinaryOp("+",Id("diemso"),Id("diemrenluyen")),IntLiteral(2)))])],Id("hockychuaketthuc"))]))]))
        self.assertTrue(TestAST.checkASTGen(input, expect, 321))

    def test_bresk_stmt(self):
        """Let's test break statement"""
        input = """
        int f(){
            for(a;b;c){
                if(a){
                    a = b + c;
                    break;
                }
                else{
                    c = a + b;
                    break;
                }
            }
        }"""

        expect = str(Program([FuncDecl(Id("f"),[],IntType(),Block([For(Id("a"),Id("b"),Id("c"),Block([If(Id("a"),Block([BinaryOp("=",Id("a"),BinaryOp("+",Id("b"),Id("c"))),Break()]),Block([BinaryOp("=",Id("c"),BinaryOp("+",Id("a"),Id("b"))),Break()]))]))]))]))
        self.assertTrue(TestAST.checkASTGen(input, expect, 322))

    def test_return_stmt(self):
        """Test return statement without expression"""
        input = """
        void main(){
            for(i = 2; i < sqrt(n); i = i + 1){
                if(n % i == 0){
                    print("n khong la so nguyen to");
                    return;
                }
            }
            print("n la so nguyen to");
        }"""

        expect = str(Program([FuncDecl(Id("main"),[],VoidType(),Block([For(BinaryOp("=",Id("i"),IntLiteral(2)),BinaryOp("<",Id("i"),CallExpr(Id("sqrt"),[Id("n")])),BinaryOp("=",Id("i"),BinaryOp("+",Id("i"),IntLiteral(1))),Block([If(BinaryOp("==",BinaryOp("%",Id("n"),Id("i")),IntLiteral(0)),Block([CallExpr(Id("print"),[StringLiteral("n khong la so nguyen to")]),Return()]))])),CallExpr(Id("print"),[StringLiteral("n la so nguyen to")])]))]))
        self.assertTrue(TestAST.checkASTGen(input, expect, 323))

    def test_return_stmt_1(self):
        """Test return statement contain expression"""
        input = """
        int sum(int n){
            if(n == 0){
                return 0;
            }
            else{
                return n + sum(n-1);
            }
            print(sum(5));
        }
        """

        expect = str(Program([FuncDecl(Id("sum"),[VarDecl("n",IntType())],IntType(),Block([If(BinaryOp("==",Id("n"),IntLiteral(0)),Block([Return(IntLiteral(0))]),Block([Return(BinaryOp("+",Id("n"),CallExpr(Id("sum"),[BinaryOp("-",Id("n"),IntLiteral(1))])))])),CallExpr(Id("print"),[CallExpr(Id("sum"),[IntLiteral(5)])])]))]))
        self.assertTrue(TestAST.checkASTGen(input, expect, 324))
    
    def test_continue_stmt(self):
        """Test continue statement inside a fucntion"""
        input = """
            int main () {

                /* local variable definition */
                int a;

                /* do loop execution */
                do {
   
                    if( a == 15) {
                        /* skip the iteration */
                        a = a + 1;
                        continue;
                    }
                        
                    printf("value of a:", a);
                    a = a + 1;
                
                } 
                while( a < 20 );
                
                return 0;
            }"""
        expect = str(Program([FuncDecl(Id("main"),[],IntType(),Block([VarDecl("a",IntType()),Dowhile([Block([If(BinaryOp("==",Id("a"),IntLiteral(15)),Block([BinaryOp("=",Id("a"),BinaryOp("+",Id("a"),IntLiteral(1))),Continue()])),CallExpr(Id("printf"),[StringLiteral("value of a:"),Id("a")]),BinaryOp("=",Id("a"),BinaryOp("+",Id("a"),IntLiteral(1)))])],BinaryOp("<",Id("a"),IntLiteral(20))),Return(IntLiteral(0))]))]))
        self.assertTrue(TestAST.checkASTGen(input, expect, 325))


    def test_many_do_while_stmts_1(self):
        """Continue to test a fucntion with many do-while statement"""
        input = """
        int main()
        {
            int i,j;
            i = 1;
            do
            {
                j=1;
                do
                {
                    printf("*");
                    j = j + 1;
                }while(j <= i);
                i = i + 1;
                printf("n");
            }while(i <= 5);
            return 0;
        }"""
        
        expect = str(Program([FuncDecl(Id("main"),[],IntType(),Block([VarDecl("i",IntType()),VarDecl("j",IntType()),BinaryOp("=",Id("i"),IntLiteral(1)),Dowhile([Block([BinaryOp("=",Id("j"),IntLiteral(1)),Dowhile([Block([CallExpr(Id("printf"),[StringLiteral("*")]),BinaryOp("=",Id("j"),BinaryOp("+",Id("j"),IntLiteral(1)))])],BinaryOp("<=",Id("j"),Id("i"))),BinaryOp("=",Id("i"),BinaryOp("+",Id("i"),IntLiteral(1))),CallExpr(Id("printf"),[StringLiteral("n")])])],BinaryOp("<=",Id("i"),IntLiteral(5))),Return(IntLiteral(0))]))]))
        self.assertTrue(TestAST.checkASTGen(input, expect, 326))

    def test_block_stmt(self):
        """A program with many block statements"""
        input = """
            float goo(){
                {{{{{{{{{{{{{{{{}}}}}}}}}}}}}}}}
                n = (((((((((((((((((((((((((n)))))))))))))))))))))))))/2;
            }
        """

        expect = str(Program([FuncDecl(Id("goo"),[],FloatType(),Block([Block([Block([Block([Block([Block([Block([Block([Block([Block([Block([Block([Block([Block([Block([Block([Block([])])])])])])])])])])])])])])])]),BinaryOp("=",Id("n"),BinaryOp("/",Id("n"),IntLiteral(2)))]))]))
        self.assertTrue(TestAST.checkASTGen(input, expect, 327))

    def test_expr_stmt_6(self):
        """Test operands of expression"""
        input = """
        void main(){
            float a,b,c;
            a = 1.23;
            b = 1.E-12;
            c = .000001;

            if( a > b ){
                arr[xyz + abc + foo()] = Do(c);
            }
            else{
                Do("something")  = true;
            }
        }
        """

        expect = str(Program([FuncDecl(Id("main"),[],VoidType(),Block([VarDecl("a",FloatType()),VarDecl("b",FloatType()),VarDecl("c",FloatType()),BinaryOp("=",Id("a"),FloatLiteral(1.23)),BinaryOp("=",Id("b"),FloatLiteral(1e-12)),BinaryOp("=",Id("c"),FloatLiteral(1e-06)),If(BinaryOp(">",Id("a"),Id("b")),Block([BinaryOp("=",ArrayCell(Id("arr"),BinaryOp("+",BinaryOp("+",Id("xyz"),Id("abc")),CallExpr(Id("foo"),[]))),CallExpr(Id("Do"),[Id("c")]))]),Block([BinaryOp("=",CallExpr(Id("Do"),[StringLiteral("something")]),BooleanLiteral(True))]))]))]))
        self.assertTrue(TestAST.checkASTGen(input, expect, 328))

    def test_expr_stmt_7(self):
        """Test sub expression"""
        input = """
            void main(){
                (((((a+b)+c) - d) * e) / -f);
                (((((((((myarr[arr[arr[1]]])))))))));
            }
        """
        expect = str(Program([FuncDecl(Id("main"),[],VoidType(),Block([BinaryOp("/",BinaryOp("*",BinaryOp("-",BinaryOp("+",BinaryOp("+",Id("a"),Id("b")),Id("c")),Id("d")),Id("e")),UnaryOp("-",Id("f"))),ArrayCell(Id("myarr"),ArrayCell(Id("arr"),ArrayCell(Id("arr"),IntLiteral(1))))]))]))
        self.assertTrue(TestAST.checkASTGen(input, expect, 329))

    def test_program_1(self):
        """Test particular program 1"""
        input = """
        int main()
        {
            int i, n;
            int S;
            S = 0;
            i = 1;
            printf("Nhap n: ");
            scanf(n);

            do{
                S = S + i * i;
                i = i + 1;
            }
            while(i <= n);

            printf("i = ", i);
            printf("Tong 1^2 + 2^2 + ...  la: n,S");
        }
        """
        expect = str(Program([FuncDecl(Id("main"),[],IntType(),Block([VarDecl("i",IntType()),VarDecl("n",IntType()),VarDecl("S",IntType()),BinaryOp("=",Id("S"),IntLiteral(0)),BinaryOp("=",Id("i"),IntLiteral(1)),CallExpr(Id("printf"),[StringLiteral("Nhap n: ")]),CallExpr(Id("scanf"),[Id("n")]),Dowhile([Block([BinaryOp("=",Id("S"),BinaryOp("+",Id("S"),BinaryOp("*",Id("i"),Id("i")))),BinaryOp("=",Id("i"),BinaryOp("+",Id("i"),IntLiteral(1)))])],BinaryOp("<=",Id("i"),Id("n"))),CallExpr(Id("printf"),[StringLiteral("i = "),Id("i")]),CallExpr(Id("printf"),[StringLiteral("Tong 1^2 + 2^2 + ...  la: n,S")])]))]))
        self.assertTrue(TestAST.checkASTGen(input, expect, 330))

    def test_program_2(self):
        """Test particular program 2"""
        input = """
                int main()
                {
                    int n, i;
                    int factorial;
                    factorial = 1;
                    printf("Enter an integer: ");
                    scanf(n);
                    // show error if the user enters a negative integer
                    if (n < 0)
                        printf("Error! Factorial of a negative number doesn't exist.");
                    else
                    {
                        for(i=1; i<=n; i = i + 1)
                        {
                            factorial = factorial * i;              // factorial = factorial*i;
                        }
                        printf("Factorial of  = ", n, factorial);
                    }
                    return 0;
                }
                """

        expect  = str(Program([FuncDecl(Id("main"),[],IntType(),Block([VarDecl("n",IntType()),VarDecl("i",IntType()),VarDecl("factorial",IntType()),BinaryOp("=",Id("factorial"),IntLiteral(1)),CallExpr(Id("printf"),[StringLiteral("Enter an integer: ")]),CallExpr(Id("scanf"),[Id("n")]),If(BinaryOp("<",Id("n"),IntLiteral(0)),CallExpr(Id("printf"),[StringLiteral("Error! Factorial of a negative number doesn't exist.")]),Block([For(BinaryOp("=",Id("i"),IntLiteral(1)),BinaryOp("<=",Id("i"),Id("n")),BinaryOp("=",Id("i"),BinaryOp("+",Id("i"),IntLiteral(1))),Block([BinaryOp("=",Id("factorial"),BinaryOp("*",Id("factorial"),Id("i")))])),CallExpr(Id("printf"),[StringLiteral("Factorial of  = "),Id("n"),Id("factorial")])])),Return(IntLiteral(0))]))]))
        self.assertTrue(TestAST.checkASTGen(input, expect, 331))

    def test_program_3(self):
        """Test particular program 3"""
        input = """
            int main()
            {
                float number;
                printf("Enter a number: ");
                scanf("number =", number);
                if (number <= 0.0)
                {
                    if (number == 0.0)
                        printf("You entered 0.");
                    else
                        printf("You entered a negative number.");
                }
                else
                    printf("You entered a positive number.");
                return 0;
            }
            """

        expect = str(Program([FuncDecl(Id("main"),[],IntType(),Block([VarDecl("number",FloatType()),CallExpr(Id("printf"),[StringLiteral("Enter a number: ")]),CallExpr(Id("scanf"),[StringLiteral("number ="),Id("number")]),If(BinaryOp("<=",Id("number"),FloatLiteral(0.0)),Block([If(BinaryOp("==",Id("number"),FloatLiteral(0.0)),CallExpr(Id("printf"),[StringLiteral("You entered 0.")]),CallExpr(Id("printf"),[StringLiteral("You entered a negative number.")]))]),CallExpr(Id("printf"),[StringLiteral("You entered a positive number.")])),Return(IntLiteral(0))]))]))
        self.assertTrue(TestAST.checkASTGen(input, expect, 332))

    def test_program_4(self):
        """Test particular program 4"""
        input = """
        void fibonacci(int num)
        {
            int a, b, c, i;
            a = 0;
            b = 1;
            if(num == 1)
            printf("a",a);

            if(num >= 2)
            printf("a = b = ",a,b);

            do {
                c = a+b;
                printf("c = ", c);
                a = b;
                b = c;
                i = i + 1;
            }
            while(i <= num);
           
        }"""

        expect = str(Program([FuncDecl(Id("fibonacci"),[VarDecl("num",IntType())],VoidType(),Block([VarDecl("a",IntType()),VarDecl("b",IntType()),VarDecl("c",IntType()),VarDecl("i",IntType()),BinaryOp("=",Id("a"),IntLiteral(0)),BinaryOp("=",Id("b"),IntLiteral(1)),If(BinaryOp("==",Id("num"),IntLiteral(1)),CallExpr(Id("printf"),[StringLiteral("a"),Id("a")])),If(BinaryOp(">=",Id("num"),IntLiteral(2)),CallExpr(Id("printf"),[StringLiteral("a = b = "),Id("a"),Id("b")])),Dowhile([Block([BinaryOp("=",Id("c"),BinaryOp("+",Id("a"),Id("b"))),CallExpr(Id("printf"),[StringLiteral("c = "),Id("c")]),BinaryOp("=",Id("a"),Id("b")),BinaryOp("=",Id("b"),Id("c")),BinaryOp("=",Id("i"),BinaryOp("+",Id("i"),IntLiteral(1)))])],BinaryOp("<=",Id("i"),Id("num")))]))]))
        self.assertTrue(TestAST.checkASTGen(input, expect, 333))

    def test_program_5(self):
        """Test particular program 5"""
        input = """
        int main()
        {
            int array[100], n, c;
        
            printf("Enter number of elements in array");
            scanf("n", n);
        
            printf("Enter elements", n);
        
            for (c = 0; c < n; c = c + 1)
                scanf("array[c]", array[c]);
        
            printf("The array elements are:");
        
            for (c = 0; c < n; c = c + 1)
                printf("array[c]", array[c]);
        
            return 0;
        }
        """

        expect = str(Program([FuncDecl(Id("main"),[],IntType(),Block([VarDecl("array",ArrayType(100,IntType())),VarDecl("n",IntType()),VarDecl("c",IntType()),CallExpr(Id("printf"),[StringLiteral("Enter number of elements in array")]),CallExpr(Id("scanf"),[StringLiteral("n"),Id("n")]),CallExpr(Id("printf"),[StringLiteral("Enter elements"),Id("n")]),For(BinaryOp("=",Id("c"),IntLiteral(0)),BinaryOp("<",Id("c"),Id("n")),BinaryOp("=",Id("c"),BinaryOp("+",Id("c"),IntLiteral(1))),CallExpr(Id("scanf"),[StringLiteral("array[c]"),ArrayCell(Id("array"),Id("c"))])),CallExpr(Id("printf"),[StringLiteral("The array elements are:")]),For(BinaryOp("=",Id("c"),IntLiteral(0)),BinaryOp("<",Id("c"),Id("n")),BinaryOp("=",Id("c"),BinaryOp("+",Id("c"),IntLiteral(1))),CallExpr(Id("printf"),[StringLiteral("array[c]"),ArrayCell(Id("array"),Id("c"))])),Return(IntLiteral(0))]))]))
        self.assertTrue(TestAST.checkASTGen(input, expect, 334))

    def test_many_if_stmt_1(self):
        """Find largest of three numbers"""
        input = """
        int main()
            {
                int a, b, c, big;
                printf("Enter three numbers: ");
                scanf("a,b,c", a, b, c);
                if(a>b)
                {
                    if(b>c)
                        big = a;
                    else
                    {
                        if(c>a)
                            big = c;
                        else
                            big = a;
                    }
                }
                else
                {
                    if(b>c)
                        big = b;
                    else
                        big = c;
                }
                printf("Largest number = ", big);
                return 0;
            }"""

        expect = str(Program([FuncDecl(Id("main"),[],IntType(),Block([VarDecl("a",IntType()),VarDecl("b",IntType()),VarDecl("c",IntType()),VarDecl("big",IntType()),CallExpr(Id("printf"),[StringLiteral("Enter three numbers: ")]),CallExpr(Id("scanf"),[StringLiteral("a,b,c"),Id("a"),Id("b"),Id("c")]),If(BinaryOp(">",Id("a"),Id("b")),Block([If(BinaryOp(">",Id("b"),Id("c")),BinaryOp("=",Id("big"),Id("a")),Block([If(BinaryOp(">",Id("c"),Id("a")),BinaryOp("=",Id("big"),Id("c")),BinaryOp("=",Id("big"),Id("a")))]))]),Block([If(BinaryOp(">",Id("b"),Id("c")),BinaryOp("=",Id("big"),Id("b")),BinaryOp("=",Id("big"),Id("c")))])),CallExpr(Id("printf"),[StringLiteral("Largest number = "),Id("big")]),Return(IntLiteral(0))]))]))
        self.assertTrue(TestAST.checkASTGen(input, expect, 335))

    def test_expr_stmt_8(self):
        """Test many index expression"""
        input = """
        int main(){
            ((le + anh + duy)[duy*anh*le])[bkhcm - mt] = "ktxkhuA"[a + b * c];
            (abc[abc[abc[abc[abc]]]] == cde)[x > y = z];
        }"""

        expect = str(Program([FuncDecl(Id("main"),[],IntType(),Block([BinaryOp("=",ArrayCell(ArrayCell(BinaryOp("+",BinaryOp("+",Id("le"),Id("anh")),Id("duy")),BinaryOp("*",BinaryOp("*",Id("duy"),Id("anh")),Id("le"))),BinaryOp("-",Id("bkhcm"),Id("mt"))),ArrayCell(StringLiteral("ktxkhuA"),BinaryOp("+",Id("a"),BinaryOp("*",Id("b"),Id("c"))))),ArrayCell(BinaryOp("==",ArrayCell(Id("abc"),ArrayCell(Id("abc"),ArrayCell(Id("abc"),ArrayCell(Id("abc"),Id("abc"))))),Id("cde")),BinaryOp("=",BinaryOp(">",Id("x"),Id("y")),Id("z")))]))]))
        self.assertTrue(TestAST.checkASTGen(input, expect, 336))

    def test_if_stmt_1(self):
        """Check number is odd or even"""
        input = """
        int main()
        {
            int num;
            printf("Enter any number: ");
            scanf("num = ", num);
            if(num%2 == 0)
                printf("It's an even number.");
            else
                printf("It's an odd number.");
            getch();
            return 0;
        }"""

        expect = str(Program([FuncDecl(Id("main"),[],IntType(),Block([VarDecl("num",IntType()),CallExpr(Id("printf"),[StringLiteral("Enter any number: ")]),CallExpr(Id("scanf"),[StringLiteral("num = "),Id("num")]),If(BinaryOp("==",BinaryOp("%",Id("num"),IntLiteral(2)),IntLiteral(0)),CallExpr(Id("printf"),[StringLiteral("It's an even number.")]),CallExpr(Id("printf"),[StringLiteral("It's an odd number.")])),CallExpr(Id("getch"),[]),Return(IntLiteral(0))]))]))
        self.assertTrue(TestAST.checkASTGen(input, expect, 337))

    def test_many_if_stmt_2(self):
        """Check leap year"""
        input = """
        void main()
        {
            int yr;
            printf("Enter year :");
            scanf("yr = ",yr);
            if((yr%4==0) && (yr%100!=0))
            {
                printf("This is a Leap Year");
            }
            if((yr%100==0) && (yr%400==0))
            {
                printf("This is a Leap Year");
            }
            if(yr%400==0)
            {
                printf("This is a Leap Year");
            }
            else
            {
                printf("This is not a Leap Year");
            }
            getch();
        }"""

        expect = str(Program([FuncDecl(Id("main"),[],VoidType(),Block([VarDecl("yr",IntType()),CallExpr(Id("printf"),[StringLiteral("Enter year :")]),CallExpr(Id("scanf"),[StringLiteral("yr = "),Id("yr")]),If(BinaryOp("&&",BinaryOp("==",BinaryOp("%",Id("yr"),IntLiteral(4)),IntLiteral(0)),BinaryOp("!=",BinaryOp("%",Id("yr"),IntLiteral(100)),IntLiteral(0))),Block([CallExpr(Id("printf"),[StringLiteral("This is a Leap Year")])])),If(BinaryOp("&&",BinaryOp("==",BinaryOp("%",Id("yr"),IntLiteral(100)),IntLiteral(0)),BinaryOp("==",BinaryOp("%",Id("yr"),IntLiteral(400)),IntLiteral(0))),Block([CallExpr(Id("printf"),[StringLiteral("This is a Leap Year")])])),If(BinaryOp("==",BinaryOp("%",Id("yr"),IntLiteral(400)),IntLiteral(0)),Block([CallExpr(Id("printf"),[StringLiteral("This is a Leap Year")])]),Block([CallExpr(Id("printf"),[StringLiteral("This is not a Leap Year")])])),CallExpr(Id("getch"),[])]))]))
        self.assertTrue(TestAST.checkASTGen(input, expect, 338))

    def test_for_stmt_1(self):
        """Simple program with for statement"""
        input = """
        int main () {

            int a;
                
            /* for loop execution */
            for( a = 10; a < 20; a = a + 1 ){
                printf("value of a:", a);
            }
            
            return 0;
        }"""

        expect = str(Program([FuncDecl(Id("main"),[],IntType(),Block([VarDecl("a",IntType()),For(BinaryOp("=",Id("a"),IntLiteral(10)),BinaryOp("<",Id("a"),IntLiteral(20)),BinaryOp("=",Id("a"),BinaryOp("+",Id("a"),IntLiteral(1))),Block([CallExpr(Id("printf"),[StringLiteral("value of a:"),Id("a")])])),Return(IntLiteral(0))]))]))
        self.assertTrue(TestAST.checkASTGen(input, expect, 339))

    def test_do_while_stmt_1(self):
        """Find GCD of a number"""
        input = """
        int gcd(int a, int b)
        {
            do{
                if (a > b)
                {
                    return gcd(a - b, b);
                }
                else
                {
                    return gcd(a, b - a);
                }
            }
            while (a != b);
            
            return a;
        }"""

        expect = str(Program([FuncDecl(Id("gcd"),[VarDecl("a",IntType()),VarDecl("b",IntType())],IntType(),Block([Dowhile([Block([If(BinaryOp(">",Id("a"),Id("b")),Block([Return(CallExpr(Id("gcd"),[BinaryOp("-",Id("a"),Id("b")),Id("b")]))]),Block([Return(CallExpr(Id("gcd"),[Id("a"),BinaryOp("-",Id("b"),Id("a"))]))]))])],BinaryOp("!=",Id("a"),Id("b"))),Return(Id("a"))]))]))
        self.assertTrue(TestAST.checkASTGen(input, expect, 340))

    def test_do_while_stmt_2(self):
        """Number of digit"""
        input = """
        void main()
        {
            int num, temp, digit, sum;
            sum = 0;
            printf("Enter the number");
            scanf("sum = ", num);
            temp = num;
            do{
                digit = num % 10;
                sum  = sum + digit;
                num = num / 10;
            }
            while (num > 0);         
            printf("Given number = ", temp);
            printf("Sum of the digits ", temp, sum);
        }"""

        expect = str(Program([FuncDecl(Id("main"),[],VoidType(),Block([VarDecl("num",IntType()),VarDecl("temp",IntType()),VarDecl("digit",IntType()),VarDecl("sum",IntType()),BinaryOp("=",Id("sum"),IntLiteral(0)),CallExpr(Id("printf"),[StringLiteral("Enter the number")]),CallExpr(Id("scanf"),[StringLiteral("sum = "),Id("num")]),BinaryOp("=",Id("temp"),Id("num")),Dowhile([Block([BinaryOp("=",Id("digit"),BinaryOp("%",Id("num"),IntLiteral(10))),BinaryOp("=",Id("sum"),BinaryOp("+",Id("sum"),Id("digit"))),BinaryOp("=",Id("num"),BinaryOp("/",Id("num"),IntLiteral(10)))])],BinaryOp(">",Id("num"),IntLiteral(0))),CallExpr(Id("printf"),[StringLiteral("Given number = "),Id("temp")]),CallExpr(Id("printf"),[StringLiteral("Sum of the digits "),Id("temp"),Id("sum")])]))]))
        self.assertTrue(TestAST.checkASTGen(input, expect, 341))

    def test_for_stmt_2(self):
        """Find max element in array"""
        input = """
        void main(){
            for (i = 0; i < size; i = i + 1)
                scanf(array[i]);
    
            largest = array[0];
    
            for (i = 1; i < size; i = i + 1) 
            {
                if (largest < array[i])
                    largest = array[i];
            }
        }"""

        expect = str(Program([FuncDecl(Id("main"),[],VoidType(),Block([For(BinaryOp("=",Id("i"),IntLiteral(0)),BinaryOp("<",Id("i"),Id("size")),BinaryOp("=",Id("i"),BinaryOp("+",Id("i"),IntLiteral(1))),CallExpr(Id("scanf"),[ArrayCell(Id("array"),Id("i"))])),BinaryOp("=",Id("largest"),ArrayCell(Id("array"),IntLiteral(0))),For(BinaryOp("=",Id("i"),IntLiteral(1)),BinaryOp("<",Id("i"),Id("size")),BinaryOp("=",Id("i"),BinaryOp("+",Id("i"),IntLiteral(1))),Block([If(BinaryOp("<",Id("largest"),ArrayCell(Id("array"),Id("i"))),BinaryOp("=",Id("largest"),ArrayCell(Id("array"),Id("i"))))]))]))]))
        self.assertTrue(TestAST.checkASTGen(input, expect, 342))

    def test_func_decl_1(self):
        """Test parameters in function"""
        input = """
        void func(float para1, int para2[], string para3, int para4){
            
        }
        
        int[] func_1(){

        }
        
        void main(int para){
            return;
        }"""

        expect = str(Program([FuncDecl(Id("func"),[VarDecl("para1",FloatType()),VarDecl("para2",ArrayPointerType(IntType())),VarDecl("para3",StringType()),VarDecl("para4",IntType())],VoidType(),Block([])),FuncDecl(Id("func_1"),[],ArrayPointerType(IntType()),Block([])),FuncDecl(Id("main"),[VarDecl("para",IntType())],VoidType(),Block([Return()]))]))
        self.assertTrue(TestAST.checkASTGen(input, expect, 343))

    def test_return_stmt_2(self):
        """Calculate power"""
        input = """
        int power (int num, int pow)
        {
            if (pow)
            {
                return (num * power(num, pow - 1));
            }
            return 1;
        }"""

        expect = str(Program([FuncDecl(Id("power"),[VarDecl("num",IntType()),VarDecl("pow",IntType())],IntType(),Block([If(Id("pow"),Block([Return(BinaryOp("*",Id("num"),CallExpr(Id("power"),[Id("num"),BinaryOp("-",Id("pow"),IntLiteral(1))])))])),Return(IntLiteral(1))]))]))
        self.assertTrue(TestAST.checkASTGen(input, expect, 344))

    def test_for_stmt_3(self):
        """Linear Search"""
        input = """
        void main()
        {        
            int i,  keynum, found;
            printf("Enter the element to be searched ");
            scanf("keynum", keynum);
            for (i = 0; i < num ; i = i + 1)
            {
                if (keynum == array[i] )
                {
                    found = 1;
                    break;
                }
            }
            if (found == 1)
                printf("Element is present in the array at position",i+1);
            else
                printf("Element is not present in the array");
        }"""

        expect = str(Program([FuncDecl(Id("main"),[],VoidType(),Block([VarDecl("i",IntType()),VarDecl("keynum",IntType()),VarDecl("found",IntType()),CallExpr(Id("printf"),[StringLiteral("Enter the element to be searched ")]),CallExpr(Id("scanf"),[StringLiteral("keynum"),Id("keynum")]),For(BinaryOp("=",Id("i"),IntLiteral(0)),BinaryOp("<",Id("i"),Id("num")),BinaryOp("=",Id("i"),BinaryOp("+",Id("i"),IntLiteral(1))),Block([If(BinaryOp("==",Id("keynum"),ArrayCell(Id("array"),Id("i"))),Block([BinaryOp("=",Id("found"),IntLiteral(1)),Break()]))])),If(BinaryOp("==",Id("found"),IntLiteral(1)),CallExpr(Id("printf"),[StringLiteral("Element is present in the array at position"),BinaryOp("+",Id("i"),IntLiteral(1))]),CallExpr(Id("printf"),[StringLiteral("Element is not present in the array")]))]))]))
        self.assertTrue(TestAST.checkASTGen(input, expect, 345))

    def test_if_stmt_2(self):
        """Find product of two numbers"""
        input = """
        int product(int a, int b)
        {
            if (a < b)
            {
                return product(b, a);
            }
            if (b != 0)
            {
                return (a + product(a, b - 1));
            }
            else
            {
                return 0;
            }
        }"""

        expect = str(Program([FuncDecl(Id("product"),[VarDecl("a",IntType()),VarDecl("b",IntType())],IntType(),Block([If(BinaryOp("<",Id("a"),Id("b")),Block([Return(CallExpr(Id("product"),[Id("b"),Id("a")]))])),If(BinaryOp("!=",Id("b"),IntLiteral(0)),Block([Return(BinaryOp("+",Id("a"),CallExpr(Id("product"),[Id("a"),BinaryOp("-",Id("b"),IntLiteral(1))])))]),Block([Return(IntLiteral(0))]))]))]))
        self.assertTrue(TestAST.checkASTGen(input, expect, 346))

    def test_program_6(self):
        """Test program using recursion"""
        input = """
        int sum (int num)
        {
            if (num != 0)
            {
                return (num % 10 + sum (num / 10));
            }
            else
            {
            return 0;
            }
        }"""

        expect = str(Program([FuncDecl(Id("sum"),[VarDecl("num",IntType())],IntType(),Block([If(BinaryOp("!=",Id("num"),IntLiteral(0)),Block([Return(BinaryOp("+",BinaryOp("%",Id("num"),IntLiteral(10)),CallExpr(Id("sum"),[BinaryOp("/",Id("num"),IntLiteral(10))])))]),Block([Return(IntLiteral(0))]))]))]))
        self.assertTrue(TestAST.checkASTGen(input, expect, 347))

    def test_var_func_decl_1(self):
        """Program with many var and func decls"""
        input = """
        int a,b,c,d[23];
        float e;
        
        int main(int a[], string a){

        }
        
        void foo(){
            float f;
            f = 1E-12;
        }"""

        expect  = str(Program([VarDecl("a",IntType()),VarDecl("b",IntType()),VarDecl("c",IntType()),VarDecl("d",ArrayType(23,IntType())),VarDecl("e",FloatType()),FuncDecl(Id("main"),[VarDecl("a",ArrayPointerType(IntType())),VarDecl("a",StringType())],IntType(),Block([])),FuncDecl(Id("foo"),[],VoidType(),Block([VarDecl("f",FloatType()),BinaryOp("=",Id("f"),FloatLiteral(1e-12))]))]))
        self.assertTrue(TestAST.checkASTGen(input, expect, 348))

    def test_for_and_if_stmt(self):
        """Sort array"""
        input  = """
        void main(){
            for (i = 0; i < n; i) 
            {
    
                for (j = i + 1; j < n; j)
                {
    
                    if (number[i] > number[j]) 
                    {
    
                        a =  number[i];
                        number[i] = number[j];
                        number[j] = a;
    
                    }
    
                }
    
            }
        }"""

        expect = str(Program([FuncDecl(Id("main"),[],VoidType(),Block([For(BinaryOp("=",Id("i"),IntLiteral(0)),BinaryOp("<",Id("i"),Id("n")),Id("i"),Block([For(BinaryOp("=",Id("j"),BinaryOp("+",Id("i"),IntLiteral(1))),BinaryOp("<",Id("j"),Id("n")),Id("j"),Block([If(BinaryOp(">",ArrayCell(Id("number"),Id("i")),ArrayCell(Id("number"),Id("j"))),Block([BinaryOp("=",Id("a"),ArrayCell(Id("number"),Id("i"))),BinaryOp("=",ArrayCell(Id("number"),Id("i")),ArrayCell(Id("number"),Id("j"))),BinaryOp("=",ArrayCell(Id("number"),Id("j")),Id("a"))]))]))]))]))]))
        self.assertTrue(TestAST.checkASTGen(input, expect, 349))

    def test_funccall_expr(self):
        """Power of x"""
        input = """
        int power(int x, int n)
        {
            if (n == 1)
                return(x);
            if (n % 2 == 0)
                /*  if n is even */
                return (pow(power(x, n/2), 2));
            else
                /*  if n is odd */
                return (x * power(x, n - 1));
        }"""

        expect = str(Program([FuncDecl(Id("power"),[VarDecl("x",IntType()),VarDecl("n",IntType())],IntType(),Block([If(BinaryOp("==",Id("n"),IntLiteral(1)),Return(Id("x"))),If(BinaryOp("==",BinaryOp("%",Id("n"),IntLiteral(2)),IntLiteral(0)),Return(CallExpr(Id("pow"),[CallExpr(Id("power"),[Id("x"),BinaryOp("/",Id("n"),IntLiteral(2))]),IntLiteral(2)])),Return(BinaryOp("*",Id("x"),CallExpr(Id("power"),[Id("x"),BinaryOp("-",Id("n"),IntLiteral(1))]))))]))]))
        self.assertTrue(TestAST.checkASTGen(input, expect, 350))

    def test_complex_program(self):
        """Program with many parts"""
        input = """int i;
        int f() {
            return 200;
        }
        void main(){
            int main;
            main = f();
            putIntLn(main);
            {
                int i;
                int main;
                int f;
                main = f = i = 100;
                putIntLn(i);
                putIntLn(main);
                putIntLn(f);
            }
            putIntLn(main);
        }"""

        expect = str(Program([VarDecl("i",IntType()),FuncDecl(Id("f"),[],IntType(),Block([Return(IntLiteral(200))])),FuncDecl(Id("main"),[],VoidType(),Block([VarDecl("main",IntType()),BinaryOp("=",Id("main"),CallExpr(Id("f"),[])),CallExpr(Id("putIntLn"),[Id("main")]),Block([VarDecl("i",IntType()),VarDecl("main",IntType()),VarDecl("f",IntType()),BinaryOp("=",Id("main"),BinaryOp("=",Id("f"),BinaryOp("=",Id("i"),IntLiteral(100)))),CallExpr(Id("putIntLn"),[Id("i")]),CallExpr(Id("putIntLn"),[Id("main")]),CallExpr(Id("putIntLn"),[Id("f")])]),CallExpr(Id("putIntLn"),[Id("main")])]))]))
        self.assertTrue(TestAST.checkASTGen(input, expect, 351))

    def test_for_stmt_4(self):
        """Sum of N numbers"""
        input = """void main(){
            print("Enter N:");
            get(N);

            int sum;
            sum=0;
            int i;
            for(i=0;i<N;i=i+1){
                sum = sum +i;
            }
            print("Sum = ");
            print(sum);
        }"""

        expect  = str(Program([FuncDecl(Id("main"),[],VoidType(),Block([CallExpr(Id("print"),[StringLiteral("Enter N:")]),CallExpr(Id("get"),[Id("N")]),VarDecl("sum",IntType()),BinaryOp("=",Id("sum"),IntLiteral(0)),VarDecl("i",IntType()),For(BinaryOp("=",Id("i"),IntLiteral(0)),BinaryOp("<",Id("i"),Id("N")),BinaryOp("=",Id("i"),BinaryOp("+",Id("i"),IntLiteral(1))),Block([BinaryOp("=",Id("sum"),BinaryOp("+",Id("sum"),Id("i")))])),CallExpr(Id("print"),[StringLiteral("Sum = ")]),CallExpr(Id("print"),[Id("sum")])]))]))
        self.assertTrue(TestAST.checkASTGen(input, expect, 352))

    def test_expr_stmt_9(self):
        """Area of triangle"""
        input = """
        void main()
        {
            int s, a, b, c, area;
        
            printf("Enter the values of a, b and c");
            scanf("a,b,c", a, b, c);
            /* compute s */
            s = (a + b + c) / 2;
            area = sqrt(s * (s - a) * (s - b) * (s - c));
            printf("Area of a triangle =", area);
        }"""

        expect = str(Program([FuncDecl(Id("main"),[],VoidType(),Block([VarDecl("s",IntType()),VarDecl("a",IntType()),VarDecl("b",IntType()),VarDecl("c",IntType()),VarDecl("area",IntType()),CallExpr(Id("printf"),[StringLiteral("Enter the values of a, b and c")]),CallExpr(Id("scanf"),[StringLiteral("a,b,c"),Id("a"),Id("b"),Id("c")]),BinaryOp("=",Id("s"),BinaryOp("/",BinaryOp("+",BinaryOp("+",Id("a"),Id("b")),Id("c")),IntLiteral(2))),BinaryOp("=",Id("area"),CallExpr(Id("sqrt"),[BinaryOp("*",BinaryOp("*",BinaryOp("*",Id("s"),BinaryOp("-",Id("s"),Id("a"))),BinaryOp("-",Id("s"),Id("b"))),BinaryOp("-",Id("s"),Id("c")))])),CallExpr(Id("printf"),[StringLiteral("Area of a triangle ="),Id("area")])]))]))
        self.assertTrue(TestAST.checkASTGen(input, expect, 353))

    def test_expr_stmt_10(self):
        """Area of circle"""
        input = """
        void main()
        {
            float radius, area;      
            printf("Enter the radius of a circle");
            scanf("radius = ", radius);
            area = PI * pow(radius, 2);
            printf("Area of a circle =", area);
        }"""

        expect = str(Program([FuncDecl(Id("main"),[],VoidType(),Block([VarDecl("radius",FloatType()),VarDecl("area",FloatType()),CallExpr(Id("printf"),[StringLiteral("Enter the radius of a circle")]),CallExpr(Id("scanf"),[StringLiteral("radius = "),Id("radius")]),BinaryOp("=",Id("area"),BinaryOp("*",Id("PI"),CallExpr(Id("pow"),[Id("radius"),IntLiteral(2)]))),CallExpr(Id("printf"),[StringLiteral("Area of a circle ="),Id("area")])]))]))
        self.assertTrue(TestAST.checkASTGen(input, expect, 354))

    def test_if_stmt_3(self):
        """Check two number"""
        input = """
        void main()
        {
            int m, n;
        
            printf("Enter the values for M and N");
            scanf("m,n", m, n);
            if (m == n)
                printf("M and N are equal");
            else
                printf("M and N are not equal");
        }"""

        expect = str(Program([FuncDecl(Id("main"),[],VoidType(),Block([VarDecl("m",IntType()),VarDecl("n",IntType()),CallExpr(Id("printf"),[StringLiteral("Enter the values for M and N")]),CallExpr(Id("scanf"),[StringLiteral("m,n"),Id("m"),Id("n")]),If(BinaryOp("==",Id("m"),Id("n")),CallExpr(Id("printf"),[StringLiteral("M and N are equal")]),CallExpr(Id("printf"),[StringLiteral("M and N are not equal")]))]))]))
        self.assertTrue(TestAST.checkASTGen(input, expect, 355))

    def test_arraytype(self):
        """Test program with array decl"""
        input = """void main(){
            int arr[1];
            arr[a*b*c] = myarr[a-b-c];
            string mystr[3];
        }"""

        expect = str(Program([FuncDecl(Id("main"),[],VoidType(),Block([VarDecl("arr",ArrayType(1,IntType())),BinaryOp("=",ArrayCell(Id("arr"),BinaryOp("*",BinaryOp("*",Id("a"),Id("b")),Id("c"))),ArrayCell(Id("myarr"),BinaryOp("-",BinaryOp("-",Id("a"),Id("b")),Id("c")))),VarDecl("mystr",ArrayType(3,StringType()))]))]))
        self.assertTrue(TestAST.checkASTGen(input, expect, 356))

    def test_for_and_if_stmt_1(self):
        """Another one"""
        input = """
        void main()
        {
            int i, num1, num2, count, sum;
            scanf("num1, num2", num1, num2);
            printf("Integers divisible by 5 are");
            for (i = num1; i < num2; i + 1)
            {
                if (i % 5 == 0)
                {
                    printf("i=", i);
                    count + 1;
                    sum = sum + i;
                }
            }
            printf("Number of integers divisible by 5 between and =", num1, num2, count);
            printf("Sum of all integers that are divisible by 5 = ", sum);
        }"""

        expect = str(Program([FuncDecl(Id("main"),[],VoidType(),Block([VarDecl("i",IntType()),VarDecl("num1",IntType()),VarDecl("num2",IntType()),VarDecl("count",IntType()),VarDecl("sum",IntType()),CallExpr(Id("scanf"),[StringLiteral("num1, num2"),Id("num1"),Id("num2")]),CallExpr(Id("printf"),[StringLiteral("Integers divisible by 5 are")]),For(BinaryOp("=",Id("i"),Id("num1")),BinaryOp("<",Id("i"),Id("num2")),BinaryOp("+",Id("i"),IntLiteral(1)),Block([If(BinaryOp("==",BinaryOp("%",Id("i"),IntLiteral(5)),IntLiteral(0)),Block([CallExpr(Id("printf"),[StringLiteral("i="),Id("i")]),BinaryOp("+",Id("count"),IntLiteral(1)),BinaryOp("=",Id("sum"),BinaryOp("+",Id("sum"),Id("i")))]))])),CallExpr(Id("printf"),[StringLiteral("Number of integers divisible by 5 between and ="),Id("num1"),Id("num2"),Id("count")]),CallExpr(Id("printf"),[StringLiteral("Sum of all integers that are divisible by 5 = "),Id("sum")])]))]))
        self.assertTrue(TestAST.checkASTGen(input, expect, 357))

    def test_program_7(self):
        """Reverse number"""
        input = """
        void main()
        {
            int num, reverse, temp, remainder;
            scanf("num",num);
            temp = num;
            do{
                remainder = num % 10;
                reverse = reverse * 10 + remainder;
                num = num / 10;
            }
            while (num > 0);
            
            printf("Given number = ", temp);
            printf("Its reverse is = ", reverse);
        }"""

        expect = str(Program([FuncDecl(Id("main"),[],VoidType(),Block([VarDecl("num",IntType()),VarDecl("reverse",IntType()),VarDecl("temp",IntType()),VarDecl("remainder",IntType()),CallExpr(Id("scanf"),[StringLiteral("num"),Id("num")]),BinaryOp("=",Id("temp"),Id("num")),Dowhile([Block([BinaryOp("=",Id("remainder"),BinaryOp("%",Id("num"),IntLiteral(10))),BinaryOp("=",Id("reverse"),BinaryOp("+",BinaryOp("*",Id("reverse"),IntLiteral(10)),Id("remainder"))),BinaryOp("=",Id("num"),BinaryOp("/",Id("num"),IntLiteral(10)))])],BinaryOp(">",Id("num"),IntLiteral(0))),CallExpr(Id("printf"),[StringLiteral("Given number = "),Id("temp")]),CallExpr(Id("printf"),[StringLiteral("Its reverse is = "),Id("reverse")])]))]))
        self.assertTrue(TestAST.checkASTGen(input, expect, 358))

    def test_many_stmt(self):
        """Program with many statements"""
        input = """void main(){
            for(a;b;c)
            do
            if(1)
            if(2)
            if(3)
            a;
            else b;
            while(true);
            return;
        }"""

        expect = str(Program([FuncDecl(Id("main"),[],VoidType(),Block([For(Id("a"),Id("b"),Id("c"),Dowhile([If(IntLiteral(1),If(IntLiteral(2),If(IntLiteral(3),Id("a"),Id("b"))))],BooleanLiteral(True))),Return()]))]))
        self.assertTrue(TestAST.checkASTGen(input, expect, 359))

    def test_return_stmt_3(self):
        """Reverse number using recursion"""
        input = """
        int rev(int num, int len)
        {
            if (len == 1)
            {
                return num;
            }
            else
            {
                return (((num % 10) * pow(10, len - 1)) + rev(num / 10, --len));
            }
        }"""

        expect = str(Program([FuncDecl(Id("rev"),[VarDecl("num",IntType()),VarDecl("len",IntType())],IntType(),Block([If(BinaryOp("==",Id("len"),IntLiteral(1)),Block([Return(Id("num"))]),Block([Return(BinaryOp("+",BinaryOp("*",BinaryOp("%",Id("num"),IntLiteral(10)),CallExpr(Id("pow"),[IntLiteral(10),BinaryOp("-",Id("len"),IntLiteral(1))])),CallExpr(Id("rev"),[BinaryOp("/",Id("num"),IntLiteral(10)),UnaryOp("-",UnaryOp("-",Id("len")))])))]))]))]))
        self.assertTrue(TestAST.checkASTGen(input, expect, 360))

    def test_many_if_stmt_3(self):
        """Test many if else stmt 3"""
        input = """void main(){
            if(1){
                if(2){
                    a;
                    if(3)b;
                    if(4)c;
                    else d;
                    if(5)e;
                    else f;
                }
                else 
                g;
            }
            else 
            h;
            if(6) i ;
        }"""

        expect = str(Program([FuncDecl(Id("main"),[],VoidType(),Block([If(IntLiteral(1),Block([If(IntLiteral(2),Block([Id("a"),If(IntLiteral(3),Id("b")),If(IntLiteral(4),Id("c"),Id("d")),If(IntLiteral(5),Id("e"),Id("f"))]),Id("g"))]),Id("h")),If(IntLiteral(6),Id("i"))]))]))
        self.assertTrue(TestAST.checkASTGen(input, expect, 361))

    def test_many_do_while_stmts_2(self):
        """Test many do-while stmts"""
        input = """void main(){
            for(a;b;c){
                {
                    do{
                        abc;
                        do{
                            def;
                            do{
                                ghi;
                            }while(false);
                        }while(false);
                    }while(true);
                    {

                    }
                }
            }
        }"""
        
        expect = str(Program([FuncDecl(Id("main"),[],VoidType(),Block([For(Id("a"),Id("b"),Id("c"),Block([Block([Dowhile([Block([Id("abc"),Dowhile([Block([Id("def"),Dowhile([Block([Id("ghi")])],BooleanLiteral(False))])],BooleanLiteral(False))])],BooleanLiteral(True)),Block([])])]))]))]))
        self.assertTrue(TestAST.checkASTGen(input, expect, 362))

    def test_many_stmt_1(self):
        """Many statements in program"""
        input = """void main(int i){
            if(i>j && j>k){
                for(f;g;h){
                    do{
                        do{
                            {

                            }
                            print(a,b);
                            print("Done");
                        }
                        while("string");
                    }
                    while("string1");
                }
            }
        }"""

        expect = str(Program([FuncDecl(Id("main"),[VarDecl("i",IntType())],VoidType(),Block([If(BinaryOp("&&",BinaryOp(">",Id("i"),Id("j")),BinaryOp(">",Id("j"),Id("k"))),Block([For(Id("f"),Id("g"),Id("h"),Block([Dowhile([Block([Dowhile([Block([Block([]),CallExpr(Id("print"),[Id("a"),Id("b")]),CallExpr(Id("print"),[StringLiteral("Done")])])],StringLiteral("string"))])],StringLiteral("string1"))]))]))]))]))
        self.assertTrue(TestAST.checkASTGen(input, expect, 363))

    def test_do_while_stmt_3(self):
        """Convert bi to oct"""
        input = """
        int main()
        {
            int binarynum, octalnum, j, remainder;
            scanf("binarynum =", binarynum);
            do{
                remainder = binarynum % 10;
                octalnum = octalnum + remainder * j;
                j = j * 2;
                binarynum = binarynum / 10;
            }
            while (binarynum != 0);
            
            printf("Equivalent octal value", octalnum);
            return 0;
        }"""

        expect = str(Program([FuncDecl(Id("main"),[],IntType(),Block([VarDecl("binarynum",IntType()),VarDecl("octalnum",IntType()),VarDecl("j",IntType()),VarDecl("remainder",IntType()),CallExpr(Id("scanf"),[StringLiteral("binarynum ="),Id("binarynum")]),Dowhile([Block([BinaryOp("=",Id("remainder"),BinaryOp("%",Id("binarynum"),IntLiteral(10))),BinaryOp("=",Id("octalnum"),BinaryOp("+",Id("octalnum"),BinaryOp("*",Id("remainder"),Id("j")))),BinaryOp("=",Id("j"),BinaryOp("*",Id("j"),IntLiteral(2))),BinaryOp("=",Id("binarynum"),BinaryOp("/",Id("binarynum"),IntLiteral(10)))])],BinaryOp("!=",Id("binarynum"),IntLiteral(0))),CallExpr(Id("printf"),[StringLiteral("Equivalent octal value"),Id("octalnum")]),Return(IntLiteral(0))]))]))
        self.assertTrue(TestAST.checkASTGen(input, expect, 364))

    def test_expr_stmt_11(self):
        """Test expr stmt 11"""
        input = """void main(){
            (1.5[a+b+c])[x+y];
            (abcd)[x[x[x[x[x[x[abcd+xyzw]]]]]]];
        }"""

        expect = str(Program([FuncDecl(Id("main"),[],VoidType(),Block([ArrayCell(ArrayCell(FloatLiteral(1.5),BinaryOp("+",BinaryOp("+",Id("a"),Id("b")),Id("c"))),BinaryOp("+",Id("x"),Id("y"))),ArrayCell(Id("abcd"),ArrayCell(Id("x"),ArrayCell(Id("x"),ArrayCell(Id("x"),ArrayCell(Id("x"),ArrayCell(Id("x"),ArrayCell(Id("x"),BinaryOp("+",Id("abcd"),Id("xyzw")))))))))]))]))
        self.assertTrue(TestAST.checkASTGen(input, expect, 365))

    def test_program_8(self):
        """Test program 8"""
        input = """
        void main()
        {
        int num, temp, remainder, reverse;
    
        scanf("num = ", num);
        temp = num;
        do {
            remainder = num % 10;
            reverse = reverse * 10 + remainder;
            num = num / 10;
        }
        while (num > 0);       
        if (temp == reverse)
            printf("Number is a palindrome");
        else
            printf("Number is not a palindrome");
        }"""

        expect = str(Program([FuncDecl(Id("main"),[],VoidType(),Block([VarDecl("num",IntType()),VarDecl("temp",IntType()),VarDecl("remainder",IntType()),VarDecl("reverse",IntType()),CallExpr(Id("scanf"),[StringLiteral("num = "),Id("num")]),BinaryOp("=",Id("temp"),Id("num")),Dowhile([Block([BinaryOp("=",Id("remainder"),BinaryOp("%",Id("num"),IntLiteral(10))),BinaryOp("=",Id("reverse"),BinaryOp("+",BinaryOp("*",Id("reverse"),IntLiteral(10)),Id("remainder"))),BinaryOp("=",Id("num"),BinaryOp("/",Id("num"),IntLiteral(10)))])],BinaryOp(">",Id("num"),IntLiteral(0))),If(BinaryOp("==",Id("temp"),Id("reverse")),CallExpr(Id("printf"),[StringLiteral("Number is a palindrome")]),CallExpr(Id("printf"),[StringLiteral("Number is not a palindrome")]))]))]))
        self.assertTrue(TestAST.checkASTGen(input, expect, 366))

    def test_program_9(self):
        """Swap two numbers"""
        input = """
        void swap(int a, int b)
        {
            int temp;
            temp = a;
            a = b;
            b = temp;
        }
        """

        expect = str(Program([FuncDecl(Id("swap"),[VarDecl("a",IntType()),VarDecl("b",IntType())],VoidType(),Block([VarDecl("temp",IntType()),BinaryOp("=",Id("temp"),Id("a")),BinaryOp("=",Id("a"),Id("b")),BinaryOp("=",Id("b"),Id("temp"))]))]))
        self.assertTrue(TestAST.checkASTGen(input, expect, 367))

    def test_program_10(self):
        """Perfect numbers"""
        input = """
        int main()
        {
            int number, rem, sum, i;
            scanf("number", number);
            for (i = 1; i <= (number - 1); i = i + 1)
            {
                rem = number % i;
            if (rem == 0)
                {
                    sum = sum + i;
                }
            }
            if (sum == number)
                printf("Entered Number is perfect number");
            else
                printf("Entered Number is not a perfect number");
            return 0;
        }"""

        expect = str(Program([FuncDecl(Id("main"),[],IntType(),Block([VarDecl("number",IntType()),VarDecl("rem",IntType()),VarDecl("sum",IntType()),VarDecl("i",IntType()),CallExpr(Id("scanf"),[StringLiteral("number"),Id("number")]),For(BinaryOp("=",Id("i"),IntLiteral(1)),BinaryOp("<=",Id("i"),BinaryOp("-",Id("number"),IntLiteral(1))),BinaryOp("=",Id("i"),BinaryOp("+",Id("i"),IntLiteral(1))),Block([BinaryOp("=",Id("rem"),BinaryOp("%",Id("number"),Id("i"))),If(BinaryOp("==",Id("rem"),IntLiteral(0)),Block([BinaryOp("=",Id("sum"),BinaryOp("+",Id("sum"),Id("i")))]))])),If(BinaryOp("==",Id("sum"),Id("number")),CallExpr(Id("printf"),[StringLiteral("Entered Number is perfect number")]),CallExpr(Id("printf"),[StringLiteral("Entered Number is not a perfect number")])),Return(IntLiteral(0))]))]))
        self.assertTrue(TestAST.checkASTGen(input, expect, 368))

    def test_continue_stmt_1(self):
        """Calculate sum"""
        input = """
        int main()
        {
            int i;
            float number, sum;
            for(i=1; i <= 10; i = i + 1)
            {
                scanf("number",number);
                if(number < 0.0)
                {
                    continue;
                }
                sum  =  sum + number;
            }
            printf("Sum = ",sum);
            
            return 0;
        }"""

        expect  = str (Program([FuncDecl(Id("main"),[],IntType(),Block([VarDecl("i",IntType()),VarDecl("number",FloatType()),VarDecl("sum",FloatType()),For(BinaryOp("=",Id("i"),IntLiteral(1)),BinaryOp("<=",Id("i"),IntLiteral(10)),BinaryOp("=",Id("i"),BinaryOp("+",Id("i"),IntLiteral(1))),Block([CallExpr(Id("scanf"),[StringLiteral("number"),Id("number")]),If(BinaryOp("<",Id("number"),FloatLiteral(0.0)),Block([Continue()])),BinaryOp("=",Id("sum"),BinaryOp("+",Id("sum"),Id("number")))])),CallExpr(Id("printf"),[StringLiteral("Sum = "),Id("sum")]),Return(IntLiteral(0))]))]))
        self.assertTrue(TestAST.checkASTGen(input, expect, 369))

    def test_continue_stmt_2(self):
        """Continue statement"""
        input = """
        int main() { 
            // loop from 1 to 10  
            for (int i = 1; i <= 10; i = i + 1) {  
        
                // If i is equals to 6,  
                // continue to next iteration  
                // without printing  
                if (i == 6)  
                    continue;  
        
                else
                    // otherwise print the value of i  
                    printf("i = ", i);  
            }  
        
            return 0;  
        } 
        """
        expect = str(Program([FuncDecl(Id("main"),[],IntType(),Block([For(Id("i"),BinaryOp("<=",Id("i"),IntLiteral(10)),BinaryOp("=",Id("i"),BinaryOp("+",Id("i"),IntLiteral(1))),Block([If(BinaryOp("==",Id("i"),IntLiteral(6)),Continue(),CallExpr(Id("printf"),[StringLiteral("i = "),Id("i")]))])),Return(IntLiteral(0))]))]))
        self.assertTrue(TestAST.checkASTGen(input, expect, 370))

    def test_index_exprs(self):
        """Simple index expression"""
        input = """void main(){ 1234[x+3] + 123.e-12[x+4] - "duy"[x+5];}"""

        expect = str(Program([FuncDecl(Id("main"),[],VoidType(),Block([BinaryOp("-",BinaryOp("+",ArrayCell(IntLiteral(1234),BinaryOp("+",Id("x"),IntLiteral(3))),ArrayCell(FloatLiteral(1.23e-10),BinaryOp("+",Id("x"),IntLiteral(4)))),ArrayCell(StringLiteral("duy"),BinaryOp("+",Id("x"),IntLiteral(5))))]))]))
        self.assertTrue(TestAST.checkASTGen(input, expect, 371))

    def test_program_11(self):
        """Find x in an array"""
        input = """
        boolean Morenooftimes(int array[], int n, int x)
        {
            int i;
            int final_index;
            if( n % 2 ) n / 2; 
            else (n / 2 + 1);
        
            for (i = 0; i < final_index; i = i + 1)
            {
                if (array[i] == x && array[i + n / 2] == x)
                    return 1;
            }
            return 0;
        }"""

        expect = str(Program([FuncDecl(Id("Morenooftimes"),[VarDecl("array",ArrayPointerType(IntType())),VarDecl("n",IntType()),VarDecl("x",IntType())],BoolType(),Block([VarDecl("i",IntType()),VarDecl("final_index",IntType()),If(BinaryOp("%",Id("n"),IntLiteral(2)),BinaryOp("/",Id("n"),IntLiteral(2)),BinaryOp("+",BinaryOp("/",Id("n"),IntLiteral(2)),IntLiteral(1))),For(BinaryOp("=",Id("i"),IntLiteral(0)),BinaryOp("<",Id("i"),Id("final_index")),BinaryOp("=",Id("i"),BinaryOp("+",Id("i"),IntLiteral(1))),Block([If(BinaryOp("&&",BinaryOp("==",ArrayCell(Id("array"),Id("i")),Id("x")),BinaryOp("==",ArrayCell(Id("array"),BinaryOp("+",Id("i"),BinaryOp("/",Id("n"),IntLiteral(2)))),Id("x"))),Return(IntLiteral(1)))])),Return(IntLiteral(0))]))]))
        self.assertTrue(TestAST.checkASTGen(input, expect, 372))

    def test_index_exprs_1(self):
        """Upper to lower"""
        input = """
        int main(){
            int i;
            scanf("str",str);
            
            for(i=0;i<= strlen(str);i = i + 1){
                if(str[i]>=65&&str[i]<=90)
                    str[i]=str[i]+32;
            }
            printf("Lower Case String is:",str);
            return 0;
        }"""

        expect = str(Program([FuncDecl(Id("main"),[],IntType(),Block([VarDecl("i",IntType()),CallExpr(Id("scanf"),[StringLiteral("str"),Id("str")]),For(BinaryOp("=",Id("i"),IntLiteral(0)),BinaryOp("<=",Id("i"),CallExpr(Id("strlen"),[Id("str")])),BinaryOp("=",Id("i"),BinaryOp("+",Id("i"),IntLiteral(1))),Block([If(BinaryOp("&&",BinaryOp(">=",ArrayCell(Id("str"),Id("i")),IntLiteral(65)),BinaryOp("<=",ArrayCell(Id("str"),Id("i")),IntLiteral(90))),BinaryOp("=",ArrayCell(Id("str"),Id("i")),BinaryOp("+",ArrayCell(Id("str"),Id("i")),IntLiteral(32))))])),CallExpr(Id("printf"),[StringLiteral("Lower Case String is:"),Id("str")]),Return(IntLiteral(0))]))]))
        self.assertTrue(TestAST.checkASTGen(input, expect, 373))

    def test_many_for_stmt_2(self):
        """Selection sort"""
        input = """
        void sort(){
            for(i=0;i<count;i = i + 1){
                for(j=i+1;j<count;j = j + 1){
                    if(number[i]>number[j]){
                        temp=number[i];
                        number[i]=number[j];
                        number[j]=temp;
                    }
                }
            }
        }
        """

        expect = str(Program([FuncDecl(Id("sort"),[],VoidType(),Block([For(BinaryOp("=",Id("i"),IntLiteral(0)),BinaryOp("<",Id("i"),Id("count")),BinaryOp("=",Id("i"),BinaryOp("+",Id("i"),IntLiteral(1))),Block([For(BinaryOp("=",Id("j"),BinaryOp("+",Id("i"),IntLiteral(1))),BinaryOp("<",Id("j"),Id("count")),BinaryOp("=",Id("j"),BinaryOp("+",Id("j"),IntLiteral(1))),Block([If(BinaryOp(">",ArrayCell(Id("number"),Id("i")),ArrayCell(Id("number"),Id("j"))),Block([BinaryOp("=",Id("temp"),ArrayCell(Id("number"),Id("i"))),BinaryOp("=",ArrayCell(Id("number"),Id("i")),ArrayCell(Id("number"),Id("j"))),BinaryOp("=",ArrayCell(Id("number"),Id("j")),Id("temp"))]))]))]))]))]))
        self.assertTrue(TestAST.checkASTGen(input, expect, 374))

    def test_many_for_stmt_3(self):
        """Insertion sort"""
        input = """
        void sort(){
            for(i=1;i<count;i = i + 1){
                temp=number[i];
                j=i-1;
                do{
                    number[j+1]=number[j];
                    j=j-1;
                }
                while((temp<number[j])&&(j>=0));
                number[j+1]=temp;
            }
        }
        """

        expect = str(Program([FuncDecl(Id("sort"),[],VoidType(),Block([For(BinaryOp("=",Id("i"),IntLiteral(1)),BinaryOp("<",Id("i"),Id("count")),BinaryOp("=",Id("i"),BinaryOp("+",Id("i"),IntLiteral(1))),Block([BinaryOp("=",Id("temp"),ArrayCell(Id("number"),Id("i"))),BinaryOp("=",Id("j"),BinaryOp("-",Id("i"),IntLiteral(1))),Dowhile([Block([BinaryOp("=",ArrayCell(Id("number"),BinaryOp("+",Id("j"),IntLiteral(1))),ArrayCell(Id("number"),Id("j"))),BinaryOp("=",Id("j"),BinaryOp("-",Id("j"),IntLiteral(1)))])],BinaryOp("&&",BinaryOp("<",Id("temp"),ArrayCell(Id("number"),Id("j"))),BinaryOp(">=",Id("j"),IntLiteral(0)))),BinaryOp("=",ArrayCell(Id("number"),BinaryOp("+",Id("j"),IntLiteral(1))),Id("temp"))]))]))]))
        self.assertTrue(TestAST.checkASTGen(input, expect, 375))

    def test_do_while_stmt_4(self):
        """Armstrong number"""
        input = """
        int main()
        {
        int num,copy_of_num,sum,rem;

        scanf("num = ",num);        
        copy_of_num = num;

        do {
            rem = num % 10;
            sum = sum + (rem*rem*rem);
            num = num / 10;
        }
        while (num != 0);
        if(copy_of_num == sum)
            printf("is an Armstrong Number",copy_of_num);
        else
            printf("is not an Armstrong Number",copy_of_num);
        return(0);
        }"""

        expect = str(Program([FuncDecl(Id("main"),[],IntType(),Block([VarDecl("num",IntType()),VarDecl("copy_of_num",IntType()),VarDecl("sum",IntType()),VarDecl("rem",IntType()),CallExpr(Id("scanf"),[StringLiteral("num = "),Id("num")]),BinaryOp("=",Id("copy_of_num"),Id("num")),Dowhile([Block([BinaryOp("=",Id("rem"),BinaryOp("%",Id("num"),IntLiteral(10))),BinaryOp("=",Id("sum"),BinaryOp("+",Id("sum"),BinaryOp("*",BinaryOp("*",Id("rem"),Id("rem")),Id("rem")))),BinaryOp("=",Id("num"),BinaryOp("/",Id("num"),IntLiteral(10)))])],BinaryOp("!=",Id("num"),IntLiteral(0))),If(BinaryOp("==",Id("copy_of_num"),Id("sum")),CallExpr(Id("printf"),[StringLiteral("is an Armstrong Number"),Id("copy_of_num")]),CallExpr(Id("printf"),[StringLiteral("is not an Armstrong Number"),Id("copy_of_num")])),Return(IntLiteral(0))]))]))
        self.assertTrue(TestAST.checkASTGen(input, expect, 376))

    def test_program_12(self):
        """Largest element in array"""
        input = """
        int largest_element(int arr[], int num)
        {
            int i, max_element;
            max_element = arr[0];
        
            for (i = 1; i < num; i = i + 1)         
                if (arr[i] > max_element)
                    max_element = arr[i];
        
            return max_element;
        }"""

        expect = str(Program([FuncDecl(Id("largest_element"),[VarDecl("arr",ArrayPointerType(IntType())),VarDecl("num",IntType())],IntType(),Block([VarDecl("i",IntType()),VarDecl("max_element",IntType()),BinaryOp("=",Id("max_element"),ArrayCell(Id("arr"),IntLiteral(0))),For(BinaryOp("=",Id("i"),IntLiteral(1)),BinaryOp("<",Id("i"),Id("num")),BinaryOp("=",Id("i"),BinaryOp("+",Id("i"),IntLiteral(1))),If(BinaryOp(">",ArrayCell(Id("arr"),Id("i")),Id("max_element")),BinaryOp("=",Id("max_element"),ArrayCell(Id("arr"),Id("i"))))),Return(Id("max_element"))]))]))
        self.assertTrue(TestAST.checkASTGen(input, expect, 377))

    def test_funccall_expr_1(self):
        """Function call"""
        input = """void main(){
            foo(foo(foo(foo(foo(foo(foo(foo(a,b,c,d))))))));
        }"""

        expect = str(Program([FuncDecl(Id("main"),[],VoidType(),Block([CallExpr(Id("foo"),[CallExpr(Id("foo"),[CallExpr(Id("foo"),[CallExpr(Id("foo"),[CallExpr(Id("foo"),[CallExpr(Id("foo"),[CallExpr(Id("foo"),[CallExpr(Id("foo"),[Id("a"),Id("b"),Id("c"),Id("d")])])])])])])])])]))]))
        self.assertTrue(TestAST.checkASTGen(input, expect, 378))

    def test_program_13(self):
        """Perfect square"""
        input = """
        int main()
        {
            int num;
            int iVar;
            float fVar;
            scanf("num = ",num);
        
            fVar=sqrt(num);
            iVar=fVar;
        
            if(iVar==fVar)
                printf("is a perfect square.",num);
            else
                printf("is not a perfect square.",num);
            
            return 0;
        }"""

        expect = str(Program([FuncDecl(Id("main"),[],IntType(),Block([VarDecl("num",IntType()),VarDecl("iVar",IntType()),VarDecl("fVar",FloatType()),CallExpr(Id("scanf"),[StringLiteral("num = "),Id("num")]),BinaryOp("=",Id("fVar"),CallExpr(Id("sqrt"),[Id("num")])),BinaryOp("=",Id("iVar"),Id("fVar")),If(BinaryOp("==",Id("iVar"),Id("fVar")),CallExpr(Id("printf"),[StringLiteral("is a perfect square."),Id("num")]),CallExpr(Id("printf"),[StringLiteral("is not a perfect square."),Id("num")])),Return(IntLiteral(0))]))]))
        self.assertTrue(TestAST.checkASTGen(input, expect, 379))

    def test_program_14(self):
        """Strong number"""
        input = """
        void main(){
            do {
            
                i=1;fact=1;
            
                r=num%10;
                do{
            
                    fact=fact*i;
            
                    i = i + 1;
            
                }
                while(i<=r);
                         
                sum=sum+fact;
            
                num=num/10;           
            }
            while(num);
                    
        }
        """
        expect = str(Program([FuncDecl(Id("main"),[],VoidType(),Block([Dowhile([Block([BinaryOp("=",Id("i"),IntLiteral(1)),BinaryOp("=",Id("fact"),IntLiteral(1)),BinaryOp("=",Id("r"),BinaryOp("%",Id("num"),IntLiteral(10))),Dowhile([Block([BinaryOp("=",Id("fact"),BinaryOp("*",Id("fact"),Id("i"))),BinaryOp("=",Id("i"),BinaryOp("+",Id("i"),IntLiteral(1)))])],BinaryOp("<=",Id("i"),Id("r"))),BinaryOp("=",Id("sum"),BinaryOp("+",Id("sum"),Id("fact"))),BinaryOp("=",Id("num"),BinaryOp("/",Id("num"),IntLiteral(10)))])],Id("num"))]))]))
        self.assertTrue(TestAST.checkASTGen(input, expect, 380))


    def test_simple_program_1(self):
        """Hello world"""
        input = """
        int main() 
 
        {
        
        if(printf("Hello World")) 
        
        { }
        
        }"""

        expect = str(Program([FuncDecl(Id("main"),[],IntType(),Block([If(CallExpr(Id("printf"),[StringLiteral("Hello World")]),Block([]))]))]))
        self.assertTrue(TestAST.checkASTGen(input, expect, 381))

    def test_recursion_program(self):
        """Recursion"""
        input = """int factorial(int N){
            int fac;
            fac = 1;
            if(N <= 1) return fac;
            else{
                return fac*factorial(N-1);
            }
        }"""

        expect = str(Program([FuncDecl(Id("factorial"),[VarDecl("N",IntType())],IntType(),Block([VarDecl("fac",IntType()),BinaryOp("=",Id("fac"),IntLiteral(1)),If(BinaryOp("<=",Id("N"),IntLiteral(1)),Return(Id("fac")),Block([Return(BinaryOp("*",Id("fac"),CallExpr(Id("factorial"),[BinaryOp("-",Id("N"),IntLiteral(1))])))]))]))]))
        self.assertTrue(TestAST.checkASTGen(input, expect, 382))

    def test_simple_program_2(self):
        """Basic program"""
        input = """
        int main()
        {
        int x;
        
        if (x == 1)
            printf("x is equal to one");
        else
            printf("For comparison use '==' as '=' is the assignment operator");
        
        return 0;
        }"""

        expect = str(Program([FuncDecl(Id("main"),[],IntType(),Block([VarDecl("x",IntType()),If(BinaryOp("==",Id("x"),IntLiteral(1)),CallExpr(Id("printf"),[StringLiteral("x is equal to one")]),CallExpr(Id("printf"),[StringLiteral("For comparison use '==' as '=' is the assignment operator")])),Return(IntLiteral(0))]))]))
        self.assertTrue(TestAST.checkASTGen(input, expect, 383))

    def test_func_decl_and_funccall(self):
        """Func decl and funccall"""
        input = """
        void my_function(){

        } 
 
        int main()
        {
        printf("Main function");
        
        my_function();  // Calling the function
        
        printf("Back in function main");
        
        return 0;
        }"""

        expect = str(Program([FuncDecl(Id("my_function"),[],VoidType(),Block([])),FuncDecl(Id("main"),[],IntType(),Block([CallExpr(Id("printf"),[StringLiteral("Main function")]),CallExpr(Id("my_function"),[]),CallExpr(Id("printf"),[StringLiteral("Back in function main")]),Return(IntLiteral(0))]))]))
        self.assertTrue(TestAST.checkASTGen(input, expect, 384))

    def test_simple_program_3(self):
        """"""
        input = """
        int main(int argc)
        {
        int c;
        
        printf("Number of command line arguments passed:", argc);
        
        for (c = 0; c < argc; c = c + 1)
            printf("argument is", c + 1, argv[c]);
        
        return 0;
        }"""

        expect = str(Program([FuncDecl(Id("main"),[VarDecl("argc",IntType())],IntType(),Block([VarDecl("c",IntType()),CallExpr(Id("printf"),[StringLiteral("Number of command line arguments passed:"),Id("argc")]),For(BinaryOp("=",Id("c"),IntLiteral(0)),BinaryOp("<",Id("c"),Id("argc")),BinaryOp("=",Id("c"),BinaryOp("+",Id("c"),IntLiteral(1))),CallExpr(Id("printf"),[StringLiteral("argument is"),BinaryOp("+",Id("c"),IntLiteral(1)),ArrayCell(Id("argv"),Id("c"))])),Return(IntLiteral(0))]))]))
        self.assertTrue(TestAST.checkASTGen(input, expect, 385))

    def test_many_for_stmt_4(self):
        """Fibonacci Triangle"""
        input = """
        void main(){
            for(i=1;i<=n;i = i + 1)    
            {    
                    a=0;    
                    b=1;    
                    printf("b",b);    
                    for(j=1;j<i;j = j + 1)    
                    {    
                        c=a+b;    
                        printf("c",c);    
                        a=b;    
                        b=c;    
                
                    }    
                    printf("n");    
            }    
        return 0;  
        }  """

        expect = str(Program([FuncDecl(Id("main"),[],VoidType(),Block([For(BinaryOp("=",Id("i"),IntLiteral(1)),BinaryOp("<=",Id("i"),Id("n")),BinaryOp("=",Id("i"),BinaryOp("+",Id("i"),IntLiteral(1))),Block([BinaryOp("=",Id("a"),IntLiteral(0)),BinaryOp("=",Id("b"),IntLiteral(1)),CallExpr(Id("printf"),[StringLiteral("b"),Id("b")]),For(BinaryOp("=",Id("j"),IntLiteral(1)),BinaryOp("<",Id("j"),Id("i")),BinaryOp("=",Id("j"),BinaryOp("+",Id("j"),IntLiteral(1))),Block([BinaryOp("=",Id("c"),BinaryOp("+",Id("a"),Id("b"))),CallExpr(Id("printf"),[StringLiteral("c"),Id("c")]),BinaryOp("=",Id("a"),Id("b")),BinaryOp("=",Id("b"),Id("c"))])),CallExpr(Id("printf"),[StringLiteral("n")])])),Return(IntLiteral(0))]))]))
        self.assertTrue(TestAST.checkASTGen(input, expect, 386))

    def test_do_while_stmt_5(self):
        """Display prime"""
        input = """
        void main(){
            do    {
                flag = 0;
                for(i = 2; i <= low/2; i = i + 1)
                {
                    if(low % i == 0)
                    {
                        flag = 1;
                        break;
                    }
                }
                if (flag == 0)
                    printf("low", low);
                low = low + 1;
            }
            while (low < high);       
        }"""

        expect = str(Program([FuncDecl(Id("main"),[],VoidType(),Block([Dowhile([Block([BinaryOp("=",Id("flag"),IntLiteral(0)),For(BinaryOp("=",Id("i"),IntLiteral(2)),BinaryOp("<=",Id("i"),BinaryOp("/",Id("low"),IntLiteral(2))),BinaryOp("=",Id("i"),BinaryOp("+",Id("i"),IntLiteral(1))),Block([If(BinaryOp("==",BinaryOp("%",Id("low"),Id("i")),IntLiteral(0)),Block([BinaryOp("=",Id("flag"),IntLiteral(1)),Break()]))])),If(BinaryOp("==",Id("flag"),IntLiteral(0)),CallExpr(Id("printf"),[StringLiteral("low"),Id("low")])),BinaryOp("=",Id("low"),BinaryOp("+",Id("low"),IntLiteral(1)))])],BinaryOp("<",Id("low"),Id("high")))]))]))
        self.assertTrue(TestAST.checkASTGen(input, expect, 387))

    def test_func_decl_2(self):
        """"""
        input = """
        float calculateSD(float data[])
        {
            float sum, mean, standardDeviation;
            int i;
            for(i=0; i<10; i + 1)
            {
                sum = sum + data[i];
            }
            mean = sum/10;
            for(i=0; i<10; i + 1)
                standardDeviation = standardDeviation + pow(data[i] - mean, 2);
            return sqrt(standardDeviation/10);
        }"""

        expect = str(Program([FuncDecl(Id("calculateSD"),[VarDecl("data",ArrayPointerType(FloatType()))],FloatType(),Block([VarDecl("sum",FloatType()),VarDecl("mean",FloatType()),VarDecl("standardDeviation",FloatType()),VarDecl("i",IntType()),For(BinaryOp("=",Id("i"),IntLiteral(0)),BinaryOp("<",Id("i"),IntLiteral(10)),BinaryOp("+",Id("i"),IntLiteral(1)),Block([BinaryOp("=",Id("sum"),BinaryOp("+",Id("sum"),ArrayCell(Id("data"),Id("i"))))])),BinaryOp("=",Id("mean"),BinaryOp("/",Id("sum"),IntLiteral(10))),For(BinaryOp("=",Id("i"),IntLiteral(0)),BinaryOp("<",Id("i"),IntLiteral(10)),BinaryOp("+",Id("i"),IntLiteral(1)),BinaryOp("=",Id("standardDeviation"),BinaryOp("+",Id("standardDeviation"),CallExpr(Id("pow"),[BinaryOp("-",ArrayCell(Id("data"),Id("i")),Id("mean")),IntLiteral(2)])))),Return(CallExpr(Id("sqrt"),[BinaryOp("/",Id("standardDeviation"),IntLiteral(10))]))]))]))
        self.assertTrue(TestAST.checkASTGen(input, expect, 388))

    def test_simple_program_4(self):
        """Print number"""
        input = """
        int main()
        {
            int number;
            printf("Enter an integer: ");  
            
            scanf("num", number);  
            
            printf("You entered:", number);
            return 0;
        }"""

        expect = str(Program([FuncDecl(Id("main"),[],IntType(),Block([VarDecl("number",IntType()),CallExpr(Id("printf"),[StringLiteral("Enter an integer: ")]),CallExpr(Id("scanf"),[StringLiteral("num"),Id("number")]),CallExpr(Id("printf"),[StringLiteral("You entered:"),Id("number")]),Return(IntLiteral(0))]))]))
        self.assertTrue(TestAST.checkASTGen(input, expect, 389))

    def test_expr_stmt_12(self):
        """Quote and remainer"""
        input = """
        int main(){
            int dividend, divisor, quotient, remainder;
            scanf("dividend", dividend);
            printf("Enter divisor: ");
            scanf("divisor", divisor);
            quotient = dividend / divisor;
            remainder = dividend % divisor;
            printf("Quotient = ", quotient);
            printf("Remainder = ", remainder);
            return 0;
        }"""

        expect = str(Program([FuncDecl(Id("main"),[],IntType(),Block([VarDecl("dividend",IntType()),VarDecl("divisor",IntType()),VarDecl("quotient",IntType()),VarDecl("remainder",IntType()),CallExpr(Id("scanf"),[StringLiteral("dividend"),Id("dividend")]),CallExpr(Id("printf"),[StringLiteral("Enter divisor: ")]),CallExpr(Id("scanf"),[StringLiteral("divisor"),Id("divisor")]),BinaryOp("=",Id("quotient"),BinaryOp("/",Id("dividend"),Id("divisor"))),BinaryOp("=",Id("remainder"),BinaryOp("%",Id("dividend"),Id("divisor"))),CallExpr(Id("printf"),[StringLiteral("Quotient = "),Id("quotient")]),CallExpr(Id("printf"),[StringLiteral("Remainder = "),Id("remainder")]),Return(IntLiteral(0))]))]))
        self.assertTrue(TestAST.checkASTGen(input, expect, 390))

    def test_simple_program_5(self):
        """Add two integers"""
        input = """
        int main()
        {
            int firstNumber, secondNumber, sumOfTwoNumbers;
            
            printf("Enter two integers: ");
            scanf("a,b", firstNumber, secondNumber);
            sumOfTwoNumbers = firstNumber + secondNumber;
            printf("a + b = c", firstNumber, secondNumber, sumOfTwoNumbers);
            return 0;
        }"""

        expect = str(Program([FuncDecl(Id("main"),[],IntType(),Block([VarDecl("firstNumber",IntType()),VarDecl("secondNumber",IntType()),VarDecl("sumOfTwoNumbers",IntType()),CallExpr(Id("printf"),[StringLiteral("Enter two integers: ")]),CallExpr(Id("scanf"),[StringLiteral("a,b"),Id("firstNumber"),Id("secondNumber")]),BinaryOp("=",Id("sumOfTwoNumbers"),BinaryOp("+",Id("firstNumber"),Id("secondNumber"))),CallExpr(Id("printf"),[StringLiteral("a + b = c"),Id("firstNumber"),Id("secondNumber"),Id("sumOfTwoNumbers")]),Return(IntLiteral(0))]))]))
        self.assertTrue(TestAST.checkASTGen(input, expect, 391))

    def test_simple_program_6(self):
        """a 6-line program"""
        input = """int i,j,k;
        string arr[2];
        int a(float f){
            foo(a,b,c,arr[a+b+c]);
            return d;
        }"""

        expect = str(Program([VarDecl("i",IntType()),VarDecl("j",IntType()),VarDecl("k",IntType()),VarDecl("arr",ArrayType(2,StringType())),FuncDecl(Id("a"),[VarDecl("f",FloatType())],IntType(),Block([CallExpr(Id("foo"),[Id("a"),Id("b"),Id("c"),ArrayCell(Id("arr"),BinaryOp("+",BinaryOp("+",Id("a"),Id("b")),Id("c")))]),Return(Id("d"))]))]))
        self.assertTrue(TestAST.checkASTGen(input, expect, 392))

    def test_do_while_stmt_6(self):
        """Small do-while program"""
        input = """void a(){
            do
            do{}
            while(1);
            while(1);
        }"""

        expect = str(Program([FuncDecl(Id("a"),[],VoidType(),Block([Dowhile([Dowhile([Block([])],IntLiteral(1))],IntLiteral(1))]))]))
        self.assertTrue(TestAST.checkASTGen(input, expect, 393))

    def test_if_stmt_4(self):
        """Test if stmt 4"""
        input = """void main(){
            if(func(2) && arr[x+2]) break; else continue;
        }"""

        expect = str(Program([FuncDecl(Id("main"),[],VoidType(),Block([If(BinaryOp("&&",CallExpr(Id("func"),[IntLiteral(2)]),ArrayCell(Id("arr"),BinaryOp("+",Id("x"),IntLiteral(2)))),Break(),Continue())]))]))
        self.assertTrue(TestAST.checkASTGen(input, expect, 394))

    def test_program_15(self):
        """Find HCF"""
        input = """
        int hcf(int a, int b)
        {
            do {
                if (a > b)
                {
                    return hcf(a - b, b);
                }
                else
                {
                    return hcf(a, b - a);
                }
            }
            while (a != b);

            return a;
        }"""

        expect = str(Program([FuncDecl(Id("hcf"),[VarDecl("a",IntType()),VarDecl("b",IntType())],IntType(),Block([Dowhile([Block([If(BinaryOp(">",Id("a"),Id("b")),Block([Return(CallExpr(Id("hcf"),[BinaryOp("-",Id("a"),Id("b")),Id("b")]))]),Block([Return(CallExpr(Id("hcf"),[Id("a"),BinaryOp("-",Id("b"),Id("a"))]))]))])],BinaryOp("!=",Id("a"),Id("b"))),Return(Id("a"))]))]))
        self.assertTrue(TestAST.checkASTGen(input, expect, 395))

    def test_many_if_stmt_4(self):
        """Binary Search"""
        input = """
        void binary_search(int list[], int lo, int hi, int key)
        {
            int mid;
        
            if (lo > hi)
            {
                return;
            }
            mid = (lo + hi) / 2;
            if (list[mid] == key)
            {
                printf("Key found");
            }
            if (list[mid] > key)
            {
                binary_search(list, lo, mid - 1, key);
            }
            if (list[mid] < key)
            {
                binary_search(list, mid + 1, hi, key);
            }
        }"""

        expect = str(Program([FuncDecl(Id("binary_search"),[VarDecl("list",ArrayPointerType(IntType())),VarDecl("lo",IntType()),VarDecl("hi",IntType()),VarDecl("key",IntType())],VoidType(),Block([VarDecl("mid",IntType()),If(BinaryOp(">",Id("lo"),Id("hi")),Block([Return()])),BinaryOp("=",Id("mid"),BinaryOp("/",BinaryOp("+",Id("lo"),Id("hi")),IntLiteral(2))),If(BinaryOp("==",ArrayCell(Id("list"),Id("mid")),Id("key")),Block([CallExpr(Id("printf"),[StringLiteral("Key found")])])),If(BinaryOp(">",ArrayCell(Id("list"),Id("mid")),Id("key")),Block([CallExpr(Id("binary_search"),[Id("list"),Id("lo"),BinaryOp("-",Id("mid"),IntLiteral(1)),Id("key")])])),If(BinaryOp("<",ArrayCell(Id("list"),Id("mid")),Id("key")),Block([CallExpr(Id("binary_search"),[Id("list"),BinaryOp("+",Id("mid"),IntLiteral(1)),Id("hi"),Id("key")])]))]))]))
        self.assertTrue(TestAST.checkASTGen(input, expect, 396))

    def test_recursion_program_1(self):
        """Tower of HN"""
        input = """
        void towers(int num, int frompeg, int topeg, int auxpeg)
        {
            if (num == 1)
            {
                printf("Move disk 1 from peg  to peg ", frompeg, topeg);
                return;
            }
            towers(num - 1, frompeg, auxpeg, topeg);
            printf("Move disk from peg to peg", num, frompeg, topeg);
            towers(num - 1, auxpeg, topeg, frompeg);
        }"""

        expect = str(Program([FuncDecl(Id("towers"),[VarDecl("num",IntType()),VarDecl("frompeg",IntType()),VarDecl("topeg",IntType()),VarDecl("auxpeg",IntType())],VoidType(),Block([If(BinaryOp("==",Id("num"),IntLiteral(1)),Block([CallExpr(Id("printf"),[StringLiteral("Move disk 1 from peg  to peg "),Id("frompeg"),Id("topeg")]),Return()])),CallExpr(Id("towers"),[BinaryOp("-",Id("num"),IntLiteral(1)),Id("frompeg"),Id("auxpeg"),Id("topeg")]),CallExpr(Id("printf"),[StringLiteral("Move disk from peg to peg"),Id("num"),Id("frompeg"),Id("topeg")]),CallExpr(Id("towers"),[BinaryOp("-",Id("num"),IntLiteral(1)),Id("auxpeg"),Id("topeg"),Id("frompeg")])]))]))
        self.assertTrue(TestAST.checkASTGen(input, expect, 397))

    def test_program_16(self):
        """Calculate nCr"""
        input = """
        void main()
        {
            int i, fact, num;
            scanf("num =", num);
            if (num <= 0)
                fact = 1;
            else
            {
                for (i = 1; i <= num; i + 1)
                {
                    fact = fact * i;
                }
            }
            printf("Factorial of  = ", num, fact);
        }"""

        expect = str(Program([FuncDecl(Id("main"),[],VoidType(),Block([VarDecl("i",IntType()),VarDecl("fact",IntType()),VarDecl("num",IntType()),CallExpr(Id("scanf"),[StringLiteral("num ="),Id("num")]),If(BinaryOp("<=",Id("num"),IntLiteral(0)),BinaryOp("=",Id("fact"),IntLiteral(1)),Block([For(BinaryOp("=",Id("i"),IntLiteral(1)),BinaryOp("<=",Id("i"),Id("num")),BinaryOp("+",Id("i"),IntLiteral(1)),Block([BinaryOp("=",Id("fact"),BinaryOp("*",Id("fact"),Id("i")))]))])),CallExpr(Id("printf"),[StringLiteral("Factorial of  = "),Id("num"),Id("fact")])]))]))
        self.assertTrue(TestAST.checkASTGen(input, expect, 398))

    def test_program_17(self):
        """Area of rectangle"""
        input = """
        void main(){
            print("Enter height");
            scanf(height);
            print("Enter width");
            scanf(width);

            area = height * width;

            print("Area of rectangle is", area);
            return;
        }"""

        expect = str(Program([FuncDecl(Id("main"),[],VoidType(),Block([CallExpr(Id("print"),[StringLiteral("Enter height")]),CallExpr(Id("scanf"),[Id("height")]),CallExpr(Id("print"),[StringLiteral("Enter width")]),CallExpr(Id("scanf"),[Id("width")]),BinaryOp("=",Id("area"),BinaryOp("*",Id("height"),Id("width"))),CallExpr(Id("print"),[StringLiteral("Area of rectangle is"),Id("area")]),Return()]))]))
        self.assertTrue(TestAST.checkASTGen(input, expect, 399))



















  






















