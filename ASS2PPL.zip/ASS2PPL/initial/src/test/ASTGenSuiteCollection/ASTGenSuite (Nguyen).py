import unittest
from TestUtils import TestAST
from AST import *
class ASTGenSuite(unittest.TestCase):
    def test_1(self):
        input = """int main() {}"""
        expect = str(Program([FuncDecl(Id("main"),[],IntType(),Block([]))]))
        self.assertTrue(TestAST.checkASTGen(input,expect,100))
    def test_2(self):
        input = """int main () {
            putIntLn(4);
        }"""
        expect = str(Program([FuncDecl(Id("main"),[],IntType(),Block([CallExpr(Id("putIntLn"),[IntLiteral(4)])]))]))
        self.assertTrue(TestAST.checkASTGen(input,expect,101))
    def test_4(self):
        input = """int main () {
            int a, a[10],b;
        }"""
        expect = str(Program([FuncDecl(Id("main"),[],IntType(),Block([CallExpr(Id("getIntLn"),[])]))]))
        self.assertTrue(TestAST.checkASTGen(input,expect,102))
    def test_3(self):
        input = """ float a; """
        expect = str(Program([VarDecl("a",FloatType())]))
        self.assertTrue(TestAST.checkASTGen(input,expect,103))
    def test_4(self):
        input = """ int main(){
            int i,k ;
            k = 30; }"""
        expect = str(Program([FuncDecl(Id("main"),[],IntType(),Block([VarDecl("i",IntType()),VarDecl("k",IntType()),BinaryOp("=",Id("k"),IntLiteral(30))]))]))
        self.assertTrue(TestAST.checkASTGen(input,expect,104))
    def test_5(self):
        input = """ string str; """
        expect = str(Program([VarDecl("str",StringType())]))
        self.assertTrue(TestAST.checkASTGen(input,expect,105))
    def test_6(self):
        input = """ int a; float b; boolean c; """
        expect = str(Program([VarDecl("a",IntType()),VarDecl("b",FloatType()),VarDecl("c",BoolType())]))
        self.assertTrue(TestAST.checkASTGen(input,expect,106))
    def test_7(self):
        input = """ float a[1]; """
        expect = str(Program([VarDecl("a", ArrayType(1,FloatType()))]))
        self.assertTrue(TestAST.checkASTGen(input,expect,107))
    def test_8(self):
        input = """ string x[3]; int y; string z[10];"""
        expect = str(Program([VarDecl("x",ArrayType(3,StringType())),VarDecl("y",IntType()),VarDecl("z",ArrayType(10,StringType()))]))
        self.assertTrue(TestAST.checkASTGen(input,expect,108))
    def test_9(self):
        input = """ float a[5],b,c[6]; """
        expect = str(Program([VarDecl("a", ArrayType(5,FloatType())),VarDecl("b",FloatType()), VarDecl("c", ArrayType(6,FloatType()))]))
        self.assertTrue(TestAST.checkASTGen(input,expect,109))
    def test_10(self):
        input = """ void main() { 
                        float b;   
                     putFloat(4.0);
                        } """
        expect = str(Program([FuncDecl(Id("main"),[],VoidType(),Block([VarDecl("b",FloatType()),CallExpr(Id("putFloat"),[FloatLiteral(4.0)])]))]))
        self.assertTrue(TestAST.checkASTGen(input,expect,110))
    def test_11(self):
        input = """ void main(){ string a; float b; }"""
        expect = str(Program([FuncDecl(Id("main"),[],VoidType(),Block([VarDecl("a",StringType()),VarDecl("b",FloatType())]))]))
        self.assertTrue(TestAST.checkASTGen(input,expect,111))
    def test_12(self):
        input = """ int a; float b;
                    void main(){} """
        expect = str(Program([VarDecl("a",IntType()),VarDecl("b",FloatType()),FuncDecl(Id("main"),[],VoidType(),Block([]))]))
        self.assertTrue(TestAST.checkASTGen(input,expect,112))
    def test_13(self):
        input = """ int main()
                    {
                    int a;
                    string b[2];
                    }"""
        expect = str(Program([FuncDecl(Id("main"),[],IntType(),Block([VarDecl("a",IntType()),VarDecl("b",ArrayType(2,StringType()))]))]))
        self.assertTrue(TestAST.checkASTGen(input,expect,113))
    def test_14(self):
        input = """ void main() { return; break; }"""
        expect = str(Program([FuncDecl(Id("main"),[],VoidType(),Block([Return(),Break()]))]))
        self.assertTrue(TestAST.checkASTGen(input,expect,114))
    def test_15(self):
        input = """ float a; string str;
                    void main(){
                    putIntLn(1,2,3);}"""
        expect = str(Program([VarDecl("a",FloatType()),VarDecl("str",StringType()),FuncDecl(Id("main"),[],VoidType(),Block([CallExpr(Id("putIntLn"),[IntLiteral(1),IntLiteral(2),IntLiteral(3)])]))]))
        self.assertTrue(TestAST.checkASTGen(input,expect,115))
    def test_16(self):
        input = """ int x; void main(){} float a(){}"""
        expect = str(Program([VarDecl("x",IntType()),FuncDecl(Id("main"),[],VoidType(),Block([])),FuncDecl(Id("a"),[],FloatType(),Block([]))]))
        self.assertTrue(TestAST.checkASTGen(input,expect,116))
    def test_17(self):
        input = """ int x;
                    void ppl(){
                    x=5;
                    }"""
        expect = str(Program([VarDecl("x",IntType()),FuncDecl(Id("ppl"),[],VoidType(),Block([BinaryOp("=",Id("x"),IntLiteral(5))]))]))
        self.assertTrue(TestAST.checkASTGen(input,expect,117))
    def test_18(self):
        input = """ int main(){
                    int a;
                    a = b+2;
                }"""
        expect = str(Program([FuncDecl(Id("main"),[],IntType(),Block([VarDecl("a",IntType()),BinaryOp("=",Id("a"),BinaryOp("+",Id("b"),IntLiteral(2)))]))]))
        self.assertTrue(TestAST.checkASTGen(input,expect,118))
    def test_19(self):
        input = """ int a[5];
                    boolean f(){
                    a[2] = c*9;
                    }"""
        expect = str(Program([VarDecl("a",ArrayType(5,IntType())),FuncDecl(Id("f"),[],BoolType(),Block([BinaryOp("=",ArrayCell(Id("a"),IntLiteral(2)),BinaryOp("*",Id("c"),IntLiteral(9)))]))]))
        self.assertTrue(TestAST.checkASTGen(input,expect,119))
    def test_20(self):
        input = """ void main() { x=y+5 ;}"""
        expect = str(Program([FuncDecl(Id("main"),[],VoidType(),Block([BinaryOp("=",Id("x"),BinaryOp("+",Id("y"),IntLiteral(5)))]))]))
        self.assertTrue(TestAST.checkASTGen(input,expect,120))
    def test_21(self):
        input = """ void main() {break; break; return a;}"""
        expect = str(Program([FuncDecl(Id("main"),[],VoidType(),Block([Break(),Break(),Return(Id("a"))]))]))
        self.assertTrue(TestAST.checkASTGen(input,expect,121))
    def test_22(self):
        input = """ int main() {
                      int a;
                      for( i = 0 ; a < 10 ; i + 1 ) {
                         if(2) continue;
                        }
                      }"""
        expect = str(Program([FuncDecl(Id("main"),[],IntType(),Block([VarDecl("a",IntType()),For(BinaryOp("=",Id("i"),IntLiteral(0)),BinaryOp("<",Id("a"),IntLiteral(10)),BinaryOp("+",Id("i"),IntLiteral(1)),Block([If(IntLiteral(2),Continue())]))]))]))
        self.assertTrue(TestAST.checkASTGen(input,expect,122))
    def test_23(self):
        input = """ int func(){
                    float a[10];
                    x[0]="123";
                    x[1]=123;
                    }"""
        expect = str(Program([FuncDecl(Id("func"),[],IntType(),Block([VarDecl("a",ArrayType(10,FloatType())),BinaryOp("=",ArrayCell(Id("x"),IntLiteral(0)),StringLiteral("123")),BinaryOp("=",ArrayCell(Id("x"),IntLiteral(1)),IntLiteral(123))]))]))
        self.assertTrue(TestAST.checkASTGen(input,expect,123))
    def test_24(self):
        input = """ int main(){
        int a;
        if (a) b = a[10]*9;
        }"""
        expect = str(Program([FuncDecl(Id("main"),[],IntType(),Block([VarDecl("a",IntType()),If(Id("a"),BinaryOp("=",Id("b"),BinaryOp("*",ArrayCell(Id("a"),IntLiteral(10)),IntLiteral(9))))]))]))
        self.assertTrue(TestAST.checkASTGen(input,expect,124))
    def test_25(self):
        input = """ int main(){
            int a,b;
            for(i = 0;i<10;i+1)
            {
                a = b * 2;
            }
            if(a>b) k = i;
          }"""
        expect = str(Program([FuncDecl(Id("main"),[],IntType(),Block([VarDecl("a",IntType()),VarDecl("b",IntType()),For(BinaryOp("=",Id("i"),IntLiteral(0)),BinaryOp("<",Id("i"),IntLiteral(10)),BinaryOp("+",Id("i"),IntLiteral(1)),Block([BinaryOp("=",Id("a"),BinaryOp("*",Id("b"),IntLiteral(2)))])),If(BinaryOp(">",Id("a"),Id("b")),BinaryOp("=",Id("k"),Id("i")))]))]))
        self.assertTrue(TestAST.checkASTGen(input,expect,125))
    def test_26(self):
        input = """ void main() 
        {
        1+2.e3 * 4;
        }"""
        expect = str(Program([FuncDecl(Id("main"),[],VoidType(),Block([BinaryOp("+",IntLiteral(1),BinaryOp("*",FloatLiteral(2.e3),IntLiteral(4)))]))]))
        self.assertTrue(TestAST.checkASTGen(input,expect,126)) 
    def test_27(self):
        input = """ int foo(int a, float b){
                        if(b == 1) return a = true;
                        else return a = false;
                    }"""
        expect= str(Program([FuncDecl(Id("foo"),[VarDecl("a",IntType()),VarDecl("b",FloatType())],IntType(),Block([If(BinaryOp("==",Id("b"),IntLiteral(1)),Return(BinaryOp("=",Id("a"),BooleanLiteral(True))),Return(BinaryOp("=",Id("a"),BooleanLiteral(False))))]))]))
        self.assertTrue(TestAST.checkASTGen(input,expect,127))
    def test_28(self):
        input = """ void hamfoo(int a, float b){} """
        expect = str(Program([FuncDecl(Id("hamfoo"),[VarDecl("a",IntType()),VarDecl("b",FloatType())],VoidType(),Block([]))]))
        self.assertTrue(TestAST.checkASTGen(input,expect,128))
    def test_29(self):
        input = """int foo(int a, int b){
                    int a;
                    if(a==1) break;
                    else continue;
        }"""
        expect = str(Program([FuncDecl(Id("foo"),[VarDecl("a",IntType()),VarDecl("b",IntType())],IntType(),Block([VarDecl("a",IntType()),If(BinaryOp("==",Id("a"),IntLiteral(1)),Break(),Continue())]))]))
        self.assertTrue(TestAST.checkASTGen(input,expect,129))
    def test_30(self):
        input = """ boolean funcbool(){
            true;
            false;
            return true;
        }"""
        expect = str(Program([FuncDecl(Id("funcbool"),[],BoolType(),Block([BooleanLiteral(True),BooleanLiteral(False),Return(BooleanLiteral(True))]))]))
        self.assertTrue(TestAST.checkASTGen(input,expect,130))
    def test_31(self):
        input = """int a, b;
        int main(){
        do
        {
            a = b * 2;
            if (a == b)
                continue;
        } while a < 10;
        } """ 
        expect = str(Program([VarDecl("a",IntType()),VarDecl("b",IntType()),FuncDecl(Id("main"),[],IntType(),Block([Dowhile([Block([BinaryOp("=",Id("a"),BinaryOp("*",Id("b"),IntLiteral(2))),If(BinaryOp("==",Id("a"),Id("b")),Continue())])],BinaryOp("<",Id("a"),IntLiteral(10)))]))]))
        self.assertTrue(TestAST.checkASTGen(input,expect,131))
    def test_32(self):
        input = """ int main() 
        { 
        if (3)
        a[1] < -(2+b);
        } """
        expect = str(Program([FuncDecl(Id("main"),[],IntType(),Block([If(IntLiteral(3),BinaryOp("<",ArrayCell(Id("a"),IntLiteral(1)),UnaryOp("-",BinaryOp("+",IntLiteral(2),Id("b")))))]))]))
        self.assertTrue(TestAST.checkASTGen(input,expect,132))
    def test_33(self):
        input =""" int main(){
         a = 1 || a = b -3 ;
         } """
        expect = str(Program([FuncDecl(Id("main"),[],IntType(),Block([BinaryOp("=",Id("a"),BinaryOp("=",BinaryOp("||",IntLiteral(1),Id("a")),BinaryOp("-",Id("b"),IntLiteral(3))))]))]))
        self.assertTrue(TestAST.checkASTGen(input,expect,133))
    def test_34(self):
        input = """         
        int nguyen;
        void main(){
           a=a*c-b/d/e+f-g*h!=g;
        } """ 
        expect = str(Program([VarDecl("nguyen",IntType()),FuncDecl(Id("main"),[],VoidType(),Block([BinaryOp("=",Id("a"),BinaryOp("!=",BinaryOp("-",BinaryOp("+",BinaryOp("-",BinaryOp("*",Id("a"),Id("c")),BinaryOp("/",BinaryOp("/",Id("b"),Id("d")),Id("e"))),Id("f")),BinaryOp("*",Id("g"),Id("h"))),Id("g")))]))]))
        self.assertTrue(TestAST.checkASTGen(input,expect,134))
    def test_35(self):
        input = """ int main(){
                        int a;
                        if(a == 0) a = 2*b;
                        else if(a == 3) a = b/c+5;
                        else return true;
                    } """
        expect = str( Program([FuncDecl(Id("main"),[],IntType(),Block([VarDecl("a",IntType()),If(BinaryOp("==",Id("a"),IntLiteral(0)),BinaryOp("=",Id("a"),BinaryOp("*",IntLiteral(2),Id("b"))),If(BinaryOp("==",Id("a"),IntLiteral(3)),BinaryOp("=",Id("a"),BinaryOp("+",BinaryOp("/",Id("b"),Id("c")),IntLiteral(5))),Return(BooleanLiteral(True))))]))]))
        self.assertTrue(TestAST.checkASTGen(input,expect,135)) 
    def test_36(self):
        input = """ void main(int a, string b[]){
            (ppl/dsa)==(a*b);
        }"""
        expect = str(Program([FuncDecl(Id("main"),[VarDecl("a",IntType()),VarDecl("b",ArrayPointerType(StringType()))],VoidType(),Block([BinaryOp("==",BinaryOp("/",Id("ppl"),Id("dsa")),BinaryOp("*",Id("a"),Id("b")))]))]))
        self.assertTrue(TestAST.checkASTGen(input,expect,136)) 
    def test_37(self):
        input = """ int foo(int a, string b, float c){
        for(a;a<10;a + 1)
        {
         a + 1;
         break;
        }
        return;
        continue;
        } """
        expect = str(Program([FuncDecl(Id("foo"),[VarDecl("a",IntType()),VarDecl("b",StringType()),VarDecl("c",FloatType())],IntType(),Block([For(Id("a"),BinaryOp("<",Id("a"),IntLiteral(10)),BinaryOp("+",Id("a"),IntLiteral(1)),Block([BinaryOp("+",Id("a"),IntLiteral(1)),Break()])),Return(),Continue()]))]))
        self.assertTrue(TestAST.checkASTGen(input,expect,137)) 
    def test_38(self):
        input = """ void func(){}
        int main()
        {
            x= 1234;
        } """
        expect = str(Program([FuncDecl(Id("func"),[],VoidType(),Block([])),FuncDecl(Id("main"),[],IntType(),Block([BinaryOp("=",Id("x"),IntLiteral(1234))]))]))
        self.assertTrue(TestAST.checkASTGen(input,expect,138)) 
    def test_39(self):
        input = """
        int main()
        {
            func(a[6+5])[x-9] = a[b+a[10]];
        } """
        expect = str(Program([FuncDecl(Id("main"),[],IntType(),Block([BinaryOp("=",ArrayCell(CallExpr(Id("func"),[ArrayCell(Id("a"),BinaryOp("+",IntLiteral(6),IntLiteral(5)))]),BinaryOp("-",Id("x"),IntLiteral(9))),ArrayCell(Id("a"),BinaryOp("+",Id("b"),ArrayCell(Id("a"),IntLiteral(10)))))]))]))
        self.assertTrue(TestAST.checkASTGen(input,expect,139)) 
    def test_40(self):
        input = """        
        int main()
        {
            nguyen(4)[3*abc] = a[b[1]]+2;
        }"""
        expect = str( Program([FuncDecl(Id("main"),[],IntType(),Block([BinaryOp("=",ArrayCell(CallExpr(Id("nguyen"),[IntLiteral(4)]),BinaryOp("*",IntLiteral(3),Id("abc"))),BinaryOp("+",ArrayCell(Id("a"),ArrayCell(Id("b"),IntLiteral(1))),IntLiteral(2)))]))]))
        self.assertTrue(TestAST.checkASTGen(input,expect,140))  
    def test_41(self):
        input = """int main()
        {
        if (1) a=5;
        else if (true) a=false;
        else break;  
        }"""
        expect = str(Program([FuncDecl(Id("main"),[],IntType(),Block([If(IntLiteral(1),BinaryOp("=",Id("a"),IntLiteral(5)),If(BooleanLiteral(True),BinaryOp("=",Id("a"),BooleanLiteral(False)),Break()))]))]))
        self.assertTrue(TestAST.checkASTGen(input,expect,141)) 
    def test_42(self):
        input = """int main()
        {  
        if(a[1]) if (b) if (foo(1,2)) if (true) return 1; 
        }"""
        expect = str(Program([FuncDecl(Id("main"),[],IntType(),Block([If(ArrayCell(Id("a"),IntLiteral(1)),If(Id("b"),If(CallExpr(Id("foo"),[IntLiteral(1),IntLiteral(2)]),If(BooleanLiteral(True),Return(IntLiteral(1))))))]))]))
        self.assertTrue(TestAST.checkASTGen(input,expect,142))
    def test_43(self):
        input = """void main() 
        { 
        if (a) if (b) c; 
        else break; 
        continue;
        }"""
        expect = str(Program([FuncDecl(Id("main"),[],VoidType(),Block([If(Id("a"),If(Id("b"),Id("c"),Break())),Continue()]))]))
        self.assertTrue(TestAST.checkASTGen(input,expect,143))
    def test_44(self):
        input = """int main() 
        { 
        if (1) a;
        {
        if (2) b;         
        else continue; 
        }
        }"""
        expect = str(Program([FuncDecl(Id("main"),[],IntType(),Block([If(IntLiteral(1),Id("a")),Block([If(IntLiteral(2),Id("b"),Continue())])]))]))
        self.assertTrue(TestAST.checkASTGen(input,expect,144))
    def test_45(self):
        input = """        
        int main()
        {
            if (a!=(b==c)) a=b*c+z-2;
        }"""
        expect = str(Program([FuncDecl(Id("main"),[],IntType(),Block([If(BinaryOp("!=",Id("a"),BinaryOp("==",Id("b"),Id("c"))),BinaryOp("=",Id("a"),BinaryOp("-",BinaryOp("+",BinaryOp("*",Id("b"),Id("c")),Id("z")),IntLiteral(2))))]))]))
        self.assertTrue(TestAST.checkASTGen(input,expect,145))
    def test_46(self):
        input = """        
        int main()
        {
            if (a!=(b==c)) {return 0;}
        }"""
        expect = str(Program([FuncDecl(Id("main"),[],IntType(),Block([If(BinaryOp("!=",Id("a"),BinaryOp("==",Id("b"),Id("c"))),Block([Return(IntLiteral(0))]))]))]))
        self.assertTrue(TestAST.checkASTGen(input,expect,146))
    def test_47(self):
        input = """
        int main(){
        int a;
        for(i = 0; i<5;a+ 1)
        {
          if(a!=9) return 0;
          break;
        }
        }"""
        expect = str(Program([FuncDecl(Id("main"),[],IntType(),Block([VarDecl("a",IntType()),For(BinaryOp("=",Id("i"),IntLiteral(0)),BinaryOp("<",Id("i"),IntLiteral(5)),BinaryOp("+",Id("a"),IntLiteral(1)),Block([If(BinaryOp("!=",Id("a"),IntLiteral(9)),Return(IntLiteral(0))),Break()]))]))]))
        self.assertTrue(TestAST.checkASTGen(input,expect,147))
    def test_48(self):
        input = """void main(){
        float a;
        do a = a+1;
        while b < 10;
        return a-b;
        }
        """
        expect = str(Program([FuncDecl(Id("main"),[],VoidType(),Block([VarDecl("a",FloatType()),Dowhile([BinaryOp("=",Id("a"),BinaryOp("+",Id("a"),IntLiteral(1)))],BinaryOp("<",Id("b"),IntLiteral(10))),Return(BinaryOp("-",Id("a"),Id("b")))]))]))
        self.assertTrue(TestAST.checkASTGen(input,expect,148))
    def test_49(self):
        input = """        
        int main()
        {
            do {a=b*c;} while a>=0;
            break;
            return 5*b;
        }
        """
        expect = str(Program([FuncDecl(Id("main"),[],IntType(),Block([Dowhile([Block([BinaryOp("=",Id("a"),BinaryOp("*",Id("b"),Id("c")))])],BinaryOp(">=",Id("a"),IntLiteral(0))),Break(),Return(BinaryOp("*",IntLiteral(5),Id("b")))]))]))
        self.assertTrue(TestAST.checkASTGen(input,expect,149))
    def test_50(self):
        input = """void main(int ppl, string dsa[])
        {
            return ppl+dsa[2];
        }"""
        expect = str(Program([FuncDecl(Id("main"),[VarDecl("ppl",IntType()),VarDecl("dsa",ArrayPointerType(StringType()))],VoidType(),Block([Return(BinaryOp("+",Id("ppl"),ArrayCell(Id("dsa"),IntLiteral(2))))]))]))
        self.assertTrue(TestAST.checkASTGen(input,expect,150))
    def test_51(self):
        input = """        
        int main()
        {
            do {a=b*c;}{d=e-g;} while a>0;
        }
        """
        expect = str(Program([FuncDecl(Id("main"),[],IntType(),Block([Dowhile([Block([BinaryOp("=",Id("a"),BinaryOp("*",Id("b"),Id("c")))]),Block([BinaryOp("=",Id("d"),BinaryOp("-",Id("e"),Id("g")))])],BinaryOp(">",Id("a"),IntLiteral(0)))]))]))
        self.assertTrue(TestAST.checkASTGen(input,expect,151))
    def test_52(self):
        input = """
        void main(){
        int a,b,c;
        do{
          if(a<10) b=b+1;
          else break;
        } 
        while(a>=10); 
        }
        """
        expect = str(Program([FuncDecl(Id("main"),[],VoidType(),Block([VarDecl("a",IntType()),VarDecl("b",IntType()),VarDecl("c",IntType()),Dowhile([Block([If(BinaryOp("<",Id("a"),IntLiteral(10)),BinaryOp("=",Id("b"),BinaryOp("+",Id("b"),IntLiteral(1))),Break())])],BinaryOp(">=",Id("a"),IntLiteral(10)))]))]))
        self.assertTrue(TestAST.checkASTGen(input,expect,152))
    def test_53(self):
        input = """        
        int main()
        {
            for (i = 0; i < 100; i=i+1)
            a=a*b;
            break;
        }
        """
        expect = str(Program([FuncDecl(Id("main"),[],IntType(),Block([For(BinaryOp("=",Id("i"),IntLiteral(0)),BinaryOp("<",Id("i"),IntLiteral(100)),BinaryOp("=",Id("i"),BinaryOp("+",Id("i"),IntLiteral(1))),BinaryOp("=",Id("a"),BinaryOp("*",Id("a"),Id("b")))),Break()]))]))
        self.assertTrue(TestAST.checkASTGen(input,expect,153))
    def test_54(self):
        input = """
        void main(int a, string b[]){
            for (i = 0; i < 100; i=i+1)
            a=a-b;
            continue;
        }
        """
        expect = str(Program([FuncDecl(Id("main"),[VarDecl("a",IntType()),VarDecl("b",ArrayPointerType(StringType()))],VoidType(),Block([For(BinaryOp("=",Id("i"),IntLiteral(0)),BinaryOp("<",Id("i"),IntLiteral(100)),BinaryOp("=",Id("i"),BinaryOp("+",Id("i"),IntLiteral(1))),BinaryOp("=",Id("a"),BinaryOp("-",Id("a"),Id("b")))),Continue()]))]))
        self.assertTrue(TestAST.checkASTGen(input,expect,154))
    def test_55(self):
        input = """
        int main()
        {
            int a;
            b = foo(a);
        }
        float e;
        """
        expect = str(Program([FuncDecl(Id("main"),[],IntType(),Block([VarDecl("a",IntType()),BinaryOp("=",Id("b"),CallExpr(Id("foo"),[Id("a")]))])),VarDecl("e",FloatType())]))
        self.assertTrue(TestAST.checkASTGen(input,expect,155))
    def test_56(self):
        input = """void main(){
        float a[3];
        for(a;b;c)
        {
            break;
            continue;
        }
        }"""
        expect = str(Program([FuncDecl(Id("main"),[],VoidType(),Block([VarDecl("a",ArrayType(3,FloatType())),For(Id("a"),Id("b"),Id("c"),Block([Break(),Continue()]))]))]))
        self.assertTrue(TestAST.checkASTGen(input,expect,156))
    def test_57(self):
        input = """        
        int[] foo(int a, float b[])
        {            
            if (a == 0)
                foo(a,b[2]);
            int c[3];
            return c;
        }
        """
        expect = str(Program([FuncDecl(Id("foo"),[VarDecl("a",IntType()),VarDecl("b",ArrayPointerType(FloatType()))],ArrayPointerType(IntType()),Block([If(BinaryOp("==",Id("a"),IntLiteral(0)),CallExpr(Id("foo"),[Id("a"),ArrayCell(Id("b"),IntLiteral(2))])),VarDecl("c",ArrayType(3,IntType())),Return(Id("c"))]))]))
        self.assertTrue(TestAST.checkASTGen(input,expect,157))
    def test_58(self):
        input = """        
        int main()
        {
            b = -a+d/e*5-g[2]*e[5];
        }
        """
        expect = str(Program([FuncDecl(Id("main"),[],IntType(),Block([BinaryOp("=",Id("b"),BinaryOp("-",BinaryOp("+",UnaryOp("-",Id("a")),BinaryOp("*",BinaryOp("/",Id("d"),Id("e")),IntLiteral(5))),BinaryOp("*",ArrayCell(Id("g"),IntLiteral(2)),ArrayCell(Id("e"),IntLiteral(5)))))]))]))
        self.assertTrue(TestAST.checkASTGen(input,expect,158))
    def test_59(self):
        input = """       
        int main()
        {
            a = -"abc"+4/5*6-8;
        }"""
        expect = str(
            Program([FuncDecl(Id("main"),[],IntType(),Block([BinaryOp("=",Id("a"),BinaryOp("-",BinaryOp("+",UnaryOp("-",StringLiteral("abc")),BinaryOp("*",BinaryOp("/",IntLiteral(4),IntLiteral(5)),IntLiteral(6))),IntLiteral(8)))]))]))
        self.assertTrue(TestAST.checkASTGen(input,expect,159))
    def test_60(self):
        input = """        
        int main()
        {
            int a[4], b, c[2];
            a=b=3;
            c=5;
            float f[5];
            if (a != b)
                f[0] = 1.02; 
        }"""
        expect = str(Program([FuncDecl(Id("main"),[],IntType(),Block([VarDecl("a",ArrayType(4,IntType())),VarDecl("b",IntType()),VarDecl("c",ArrayType(2,IntType())),BinaryOp("=",Id("a"),BinaryOp("=",Id("b"),IntLiteral(3))),BinaryOp("=",Id("c"),IntLiteral(5)),VarDecl("f",ArrayType(5,FloatType())),If(BinaryOp("!=",Id("a"),Id("b")),BinaryOp("=",ArrayCell(Id("f"),IntLiteral(0)),FloatLiteral(1.02)))]))]))
        self.assertTrue(TestAST.checkASTGen(input,expect,160))
    def test_61(self):
        input = """
        int main()
        {
            int f[5];
            f[0] = 3;
            return 0;
        }"""
        expect = str(Program([FuncDecl(Id("main"),[],IntType(),Block([VarDecl("f",ArrayType(5,IntType())),BinaryOp("=",ArrayCell(Id("f"),IntLiteral(0)),IntLiteral(3)),Return(IntLiteral(0))]))]))
        self.assertTrue(TestAST.checkASTGen(input,expect,161))
    def test_62(self):
        input = """
        void main()
        {
            float a ;
            do a = a-2;
            while a < b;
            return a+b ;
        }"""
        expect = str(Program([FuncDecl(Id("main"),[],VoidType(),Block([VarDecl("a",FloatType()),Dowhile([BinaryOp("=",Id("a"),BinaryOp("-",Id("a"),IntLiteral(2)))],BinaryOp("<",Id("a"),Id("b"))),Return(BinaryOp("+",Id("a"),Id("b")))]))]))
        self.assertTrue(TestAST.checkASTGen(input,expect,162))
    def test_63(self):
        input = """
        int main()
        {
            int a; float b;
            for(a = 0; a < 5;a= a + 2)
            { 
                putIntLn(6) ;
                if(a==6) getInt();
            }
        }"""
        expect = str(Program([FuncDecl(Id("main"),[],IntType(),Block([VarDecl("a",IntType()),VarDecl("b",FloatType()),For(BinaryOp("=",Id("a"),IntLiteral(0)),BinaryOp("<",Id("a"),IntLiteral(5)),BinaryOp("=",Id("a"),BinaryOp("+",Id("a"),IntLiteral(2))),Block([CallExpr(Id("putIntLn"),[IntLiteral(6)]),If(BinaryOp("==",Id("a"),IntLiteral(6)),CallExpr(Id("getInt"),[]))]))]))]))
        self.assertTrue(TestAST.checkASTGen(input,expect,163))
    def test_64(self):
        input = """
        int main()
        {
            int a;
            float b;
            do
            {
                if(a==b) b + 1;
                else break;
            } 
        while(a<b); 
        }"""
        expect = str(Program([FuncDecl(Id("main"),[],IntType(),Block([VarDecl("a",IntType()),VarDecl("b",FloatType()),Dowhile([Block([If(BinaryOp("==",Id("a"),Id("b")),BinaryOp("+",Id("b"),IntLiteral(1)),Break())])],BinaryOp("<",Id("a"),Id("b")))]))]))
        self.assertTrue(TestAST.checkASTGen(input,expect,164))
    def test_65(self):
        input = """        
        int main()
        {
            str = "1234";
        }
        """
        expect = str(Program([FuncDecl(Id("main"),[],IntType(),Block([BinaryOp("=",Id("str"),StringLiteral("1234"))]))]))
        self.assertTrue(TestAST.checkASTGen(input,expect,165))
    def test_66(self):
        input = """
        void main(int a, string b[])
        {
            1.24567e1;
        }"""
        expect = str(Program([FuncDecl(Id("main"),[VarDecl("a",IntType()),VarDecl("b",ArrayPointerType(StringType()))],VoidType(),Block([FloatLiteral(12.4567)]))]))
        self.assertTrue(TestAST.checkASTGen(input,expect,166))
    def test_67(self):
        input = """
        void main()
        {
            25.e45;
        }"""
        expect = str(Program([FuncDecl(Id("main"),[],VoidType(),Block([FloatLiteral(2.5e+46)]))]))
        self.assertTrue(TestAST.checkASTGen(input,expect,167))
    def test_68(self):
        input = """
        void main()
        {
            "abczyz";
        }"""
        expect = str(Program([FuncDecl(Id("main"),[],VoidType(),Block([StringLiteral("abczyz")]))]))
        self.assertTrue(TestAST.checkASTGen(input,expect,168))
    def test_69(self):
        input = """
        int main()
        {
            true;
        }
        """
        expect = str(Program([FuncDecl(Id("main"),[],IntType(),Block([BooleanLiteral(True)]))]))
        self.assertTrue(TestAST.checkASTGen(input,expect,169))
    def test_70(self):
        input = """int main(int a, float b[])
        {
            false;
        }"""
        expect = str(Program([FuncDecl(Id("main"),[VarDecl("a",IntType()),VarDecl("b",ArrayPointerType(FloatType()))],IntType(),Block([BooleanLiteral(False)]))]))
        self.assertTrue(TestAST.checkASTGen(input,expect,170))
    def test_71(self):
        input = """
        void main(int a)
        {
            return foo(5);
        }"""
        expect = str(Program([FuncDecl(Id("main"),[VarDecl("a",IntType())],VoidType(),Block([Return(CallExpr(Id("foo"),[IntLiteral(5)]))]))]))
        self.assertTrue(TestAST.checkASTGen(input,expect,171))
    def test_72(self):
        input = """
        void main(int argc, string argv[])
        {
            return foo(1,2,b);
        }
        """
        expect = str(Program([FuncDecl(Id("main"),[VarDecl("argc",IntType()),VarDecl("argv",ArrayPointerType(StringType()))],VoidType(),Block([Return(CallExpr(Id("foo"),[IntLiteral(1),IntLiteral(2),Id("b")]))]))]))
        self.assertTrue(TestAST.checkASTGen(input,expect,172))
    def test_73(self):
        input = """
        void main(int argc, string argv[])
        {
            return a+n%z-y;
        }"""
        expect = str(Program([FuncDecl(Id("main"),[VarDecl("argc",IntType()),VarDecl("argv",ArrayPointerType(StringType()))],VoidType(),Block([Return(BinaryOp("-",BinaryOp("+",Id("a"),BinaryOp("%",Id("n"),Id("z"))),Id("y")))]))]))
        self.assertTrue(TestAST.checkASTGen(input,expect,173))
    def test_74(self):
        input = """
        void main(int a)
        {
            x=a-b;
        }"""
        expect = str(Program([FuncDecl(Id("main"),[VarDecl("a",IntType())],VoidType(),Block([BinaryOp("=",Id("x"),BinaryOp("-",Id("a"),Id("b")))]))]))
        self.assertTrue(TestAST.checkASTGen(input,expect,174))
    def test_75(self):
        input = """
        void main(int a)
        {
            ab--cd;
        }"""
        expect = str(Program([FuncDecl(Id("main"),[VarDecl("a",IntType())],VoidType(),Block([BinaryOp("-",Id("ab"),UnaryOp("-",Id("cd")))]))]))
        self.assertTrue(TestAST.checkASTGen(input,expect,175))
    def test_76(self):
        input = """void main(int a)
        {
            a != b; c >= f;
        }"""
        expect = str(Program([FuncDecl(Id("main"),[VarDecl("a",IntType())],VoidType(),Block([BinaryOp("!=",Id("a"),Id("b")),BinaryOp(">=",Id("c"),Id("f"))]))]))
        self.assertTrue(TestAST.checkASTGen(input,expect,176))
    def test_77(self):
        input = """
            int a;
            int foo(){
            float b;
            if(a == b + 1)  
            a = b + 2 ;
            return b;
            }"""
        expect=str(Program([VarDecl("a",IntType()),FuncDecl(Id("foo"),[],IntType(),Block([VarDecl("b",FloatType()),If(BinaryOp("==",Id("a"),BinaryOp("+",Id("b"),IntLiteral(1))),BinaryOp("=",Id("a"),BinaryOp("+",Id("b"),IntLiteral(2)))),Return(Id("b"))]))]))
        self.assertTrue(TestAST.checkASTGen(input,expect,177))
    def test_78(self):
        input = """
        int foo(int a, string b,float c[])
        {
            if(a < b+c) return a;
            else break;
            return b;
        }
        """
        expect=str(Program([FuncDecl(Id("foo"),[VarDecl("a",IntType()),VarDecl("b",StringType()),VarDecl("c",ArrayPointerType(FloatType()))],IntType(),Block([If(BinaryOp("<",Id("a"),BinaryOp("+",Id("b"),Id("c"))),Return(Id("a")),Break()),Return(Id("b"))]))]))
        self.assertTrue(TestAST.checkASTGen(input,expect,178))
    def test_79(self):
        input = """       
        int main()
        {
            string a[5];
            float b[10];
        }"""
        expect=str(Program([FuncDecl(Id("main"),[],IntType(),Block([VarDecl("a",ArrayType(5,StringType())),VarDecl("b",ArrayType(10,FloatType()))]))]))
        self.assertTrue(TestAST.checkASTGen(input,expect,179))
    def test_80(self):
        input = """
        void main()
        {
            int a; float b;
            if(a=1) continue;
            return b ;
        }"""
        expect=str(Program([FuncDecl(Id("main"),[],VoidType(),Block([VarDecl("a",IntType()),VarDecl("b",FloatType()),If(BinaryOp("=",Id("a"),IntLiteral(1)),Continue()),Return(Id("b"))]))]))
        self.assertTrue(TestAST.checkASTGen(input,expect,180))
    def test_81(self):
        input = """        
        int main()
        {
            for (i = 0; i < 10; i=i+1)
            {
                if (i%2==0) return a;
                if (i==3) break;
                a=b+8;
            }
            return a+b/2%3;
        }
        """
        expect=str(Program([FuncDecl(Id("main"),[],IntType(),Block([For(BinaryOp("=",Id("i"),IntLiteral(0)),BinaryOp("<",Id("i"),IntLiteral(10)),BinaryOp("=",Id("i"),BinaryOp("+",Id("i"),IntLiteral(1))),Block([If(BinaryOp("==",BinaryOp("%",Id("i"),IntLiteral(2)),IntLiteral(0)),Return(Id("a"))),If(BinaryOp("==",Id("i"),IntLiteral(3)),Break()),BinaryOp("=",Id("a"),BinaryOp("+",Id("b"),IntLiteral(8)))])),Return(BinaryOp("+",Id("a"),BinaryOp("%",BinaryOp("/",Id("b"),IntLiteral(2)),IntLiteral(3))))]))]))
        self.assertTrue(TestAST.checkASTGen(input,expect,181))
    def test_82(self):
        input = """
        int func(int a,float b)
        {
            if(a >= b) return a;
            else return b;           
        }"""
        expect=str(Program([FuncDecl(Id("func"),[VarDecl("a",IntType()),VarDecl("b",FloatType())],IntType(),Block([If(BinaryOp(">=",Id("a"),Id("b")),Return(Id("a")),Return(Id("b")))]))]))
        self.assertTrue(TestAST.checkASTGen(input,expect,182))
    def test_83(self):
        input = """
            int a[5];
            void init()
            {
                for(i=0;i<5;i=i+1)a[i]=i;
            }
                """
        expect=str(Program([VarDecl("a",ArrayType(5,IntType())),FuncDecl(Id("init"),[],VoidType(),Block([For(BinaryOp("=",Id("i"),IntLiteral(0)),BinaryOp("<",Id("i"),IntLiteral(5)),BinaryOp("=",Id("i"),BinaryOp("+",Id("i"),IntLiteral(1))),BinaryOp("=",ArrayCell(Id("a"),Id("i")),Id("i")))]))]))
        self.assertTrue(TestAST.checkASTGen(input,expect,183))
    def test_84(self):
        input = """
            float a[5];
            void f(int a)
            {
                for(i=0;i<5;i=i+1)
                a[i]=a[i-1];
            }
            int main(int argc, string argv)
            {
                f();
                for(i=0;i<5;i=i+1)
                    {
                    printf("hello world");
                    }
            }"""
        expect=str(Program([VarDecl("a",ArrayType(5,FloatType())),FuncDecl(Id("f"),[VarDecl("a",IntType())],VoidType(),Block([For(BinaryOp("=",Id("i"),IntLiteral(0)),BinaryOp("<",Id("i"),IntLiteral(5)),BinaryOp("=",Id("i"),BinaryOp("+",Id("i"),IntLiteral(1))),BinaryOp("=",ArrayCell(Id("a"),Id("i")),ArrayCell(Id("a"),BinaryOp("-",Id("i"),IntLiteral(1)))))])),FuncDecl(Id("main"),[VarDecl("argc",IntType()),VarDecl("argv",StringType())],IntType(),Block([CallExpr(Id("f"),[]),For(BinaryOp("=",Id("i"),IntLiteral(0)),BinaryOp("<",Id("i"),IntLiteral(5)),BinaryOp("=",Id("i"),BinaryOp("+",Id("i"),IntLiteral(1))),Block([CallExpr(Id("printf"),[StringLiteral("hello world")])]))]))]))
        self.assertTrue(TestAST.checkASTGen(input,expect,184))
    def test_85 (self):
        input = """
        int main()
        {
            i=1;
            foo (x,y); 
            a+b;
            a;
        }
                """
        expect = str(Program([FuncDecl(Id("main"),[],IntType(),Block([BinaryOp("=",Id("i"),IntLiteral(1)),CallExpr(Id("foo"),[Id("x"),Id("y")]),BinaryOp("+",Id("a"),Id("b")),Id("a")]))]))
        self.assertTrue(TestAST.checkASTGen(input,expect,185))
    def test_86(self):
        input = """
        int a;
        float b[3];
        string s;
        boolean trruee, falsssseee;
        """
        expect = str(Program([VarDecl("a",IntType()),VarDecl("b",ArrayType(3,FloatType())),VarDecl("s",StringType()),VarDecl("trruee",BoolType()),VarDecl("falsssseee",BoolType())]))
        self.assertTrue(TestAST.checkASTGen(input,expect,186))
    def test_87(self):
        input = """
        int a(int b){
        if (a == b)
            return b;
        else 
            return a;
        do 
            {
            x=x+3;
            }
        while(exp);
        }
        """
        expect = str(Program([FuncDecl(Id("a"),[VarDecl("b",IntType())],IntType(),Block([If(BinaryOp("==",Id("a"),Id("b")),Return(Id("b")),Return(Id("a"))),Dowhile([Block([BinaryOp("=",Id("x"),BinaryOp("+",Id("x"),IntLiteral(3)))])],Id("exp"))]))]))
        self.assertTrue(TestAST.checkASTGen(input,expect,187))
    def test_88(self):
        input = """
        int main()
        {
            int a;
            printf(a);
            printf("Hello cac ban");
        }"""
        expect = str(Program([FuncDecl(Id("main"),[],IntType(),Block([VarDecl("a",IntType()),CallExpr(Id("printf"),[Id("a")]),CallExpr(Id("printf"),[StringLiteral("Hello cac ban")])]))]))
        self.assertTrue(TestAST.checkASTGen(input,expect,188))
    def test_89(self):
        input = """        
        int a;
        int f(float b[])
        {
            return a+b;
        }
        void main()
        {
            int xyz;
            xyz = f(b);
            putIntLn(f);
        }"""
        expect= str(Program([VarDecl("a",IntType()),FuncDecl(Id("f"),[VarDecl("b",ArrayPointerType(FloatType()))],IntType(),Block([Return(BinaryOp("+",Id("a"),Id("b")))])),FuncDecl(Id("main"),[],VoidType(),Block([VarDecl("xyz",IntType()),BinaryOp("=",Id("xyz"),CallExpr(Id("f"),[Id("b")])),CallExpr(Id("putIntLn"),[Id("f")])]))]))
        self.assertTrue(TestAST.checkASTGen(input,expect,189))
    def test_90(self):
        input = """        
        int a,b ;
        int main()
        {
            do
            {
                a = a +b;
                if (a >= b) break;
                f(a,f());
            } while (a <= 10);
        }"""
        expect=str(Program([VarDecl("a",IntType()),VarDecl("b",IntType()),FuncDecl(Id("main"),[],IntType(),Block([Dowhile([Block([BinaryOp("=",Id("a"),BinaryOp("+",Id("a"),Id("b"))),If(BinaryOp(">=",Id("a"),Id("b")),Break()),CallExpr(Id("f"),[Id("a"),CallExpr(Id("f"),[])])])],BinaryOp("<=",Id("a"),IntLiteral(10)))]))]))
        self.assertTrue(TestAST.checkASTGen(input,expect,190))
    def test_91(self):
        input = """int foo(int a, float b, string str){
            return a+b-"abc";
        }
        int main(){
            return foo(1,2,"abc");
        }"""
        expect=str(Program([FuncDecl(Id("foo"),[VarDecl("a",IntType()),VarDecl("b",FloatType()),VarDecl("str",StringType())],IntType(),Block([Return(BinaryOp("-",BinaryOp("+",Id("a"),Id("b")),StringLiteral("abc")))])),FuncDecl(Id("main"),[],IntType(),Block([Return(CallExpr(Id("foo"),[IntLiteral(1),IntLiteral(2),StringLiteral("abc")]))]))]))
        self.assertTrue(TestAST.checkASTGen(input,expect,191))
    def test_92(self):
        input = """
        int check(int n)
        {
            int i, check1;
            check1 = 1;
            for(i = 2; i <= n/2; i=i+1)
            {
                if(n % i == 0)
                {
                    check1 = 0;
                    break;
                }  
            }
            return check1;
        }"""
        expect= str(Program([FuncDecl(Id("check"),[VarDecl("n",IntType())],IntType(),Block([VarDecl("i",IntType()),VarDecl("check1",IntType()),BinaryOp("=",Id("check1"),IntLiteral(1)),For(BinaryOp("=",Id("i"),IntLiteral(2)),BinaryOp("<=",Id("i"),BinaryOp("/",Id("n"),IntLiteral(2))),BinaryOp("=",Id("i"),BinaryOp("+",Id("i"),IntLiteral(1))),Block([If(BinaryOp("==",BinaryOp("%",Id("n"),Id("i")),IntLiteral(0)),Block([BinaryOp("=",Id("check1"),IntLiteral(0)),Break()]))])),Return(Id("check1"))]))]))
        self.assertTrue(TestAST.checkASTGen(input,expect,192))
    def test_93(self):
        input = """        
        int checkAge()
        {
            printf("Nhap tuoi cua ban: ");
            scanf("%d",i);
            printf("Tuoi cua ban la: %d",i);
        }"""
        expect=str(Program([FuncDecl(Id("checkAge"),[],IntType(),Block([CallExpr(Id("printf"),[StringLiteral("Nhap tuoi cua ban: ")]),CallExpr(Id("scanf"),[StringLiteral("%d"),Id("i")]),CallExpr(Id("printf"),[StringLiteral("Tuoi cua ban la: %d"),Id("i")])]))]))
        self.assertTrue(TestAST.checkASTGen(input,expect,193))
    def test_94(self):
        input = """
        int main()
        {
            for (i = 0; i < 5; i=i+1)
            {
                printf("%d",i);
            }
        }"""
        expect=str(Program([FuncDecl(Id("main"),[],IntType(),Block([For(BinaryOp("=",Id("i"),IntLiteral(0)),BinaryOp("<",Id("i"),IntLiteral(5)),BinaryOp("=",Id("i"),BinaryOp("+",Id("i"),IntLiteral(1))),Block([CallExpr(Id("printf"),[StringLiteral("%d"),Id("i")])]))]))]))
        self.assertTrue(TestAST.checkASTGen(input,expect,194))
    def test_95(self):
        input = """
        void main()
        {
            int n;         
            printf("nhanp so: ");
            scanf("%d", n);
            if (n > 0)
                printf("%d la so duong ", n);
            else if (num < 0)
                printf("%d la so am ", n);
            else
                printf("so 0 ko am cung k duong");
        }"""
        expect=str(Program([FuncDecl(Id("main"),[],VoidType(),Block([VarDecl("n",IntType()),CallExpr(Id("printf"),[StringLiteral("nhanp so: ")]),CallExpr(Id("scanf"),[StringLiteral("%d"),Id("n")]),If(BinaryOp(">",Id("n"),IntLiteral(0)),CallExpr(Id("printf"),[StringLiteral("%d la so duong "),Id("n")]),If(BinaryOp("<",Id("num"),IntLiteral(0)),CallExpr(Id("printf"),[StringLiteral("%d la so am "),Id("n")]),CallExpr(Id("printf"),[StringLiteral("so 0 ko am cung k duong")])))]))]))
        self.assertTrue(TestAST.checkASTGen(input,expect,195))
    def test_96(self):
        input = """int main()
        {
            int y;
            printf("nhap nam: ");
            scanf("%d",y);
            if(y % 4 == 0)
            {
                if( y % 100 == 0)
                {
                    if ( y % 400 == 0)
                        printf("%d la nam nhuan", y);
                    else
                        printf("%d ko phai nam nhuan", y);
                }
                else
                    printf("%d la nam nhuan", y );
            }
            else
                printf("%d ko phai la nam nhuan", y);
            return 0;
        }"""
        expect=str(Program([FuncDecl(Id("main"),[],IntType(),Block([VarDecl("y",IntType()),CallExpr(Id("printf"),[StringLiteral("nhap nam: ")]),CallExpr(Id("scanf"),[StringLiteral("%d"),Id("y")]),If(BinaryOp("==",BinaryOp("%",Id("y"),IntLiteral(4)),IntLiteral(0)),Block([If(BinaryOp("==",BinaryOp("%",Id("y"),IntLiteral(100)),IntLiteral(0)),Block([If(BinaryOp("==",BinaryOp("%",Id("y"),IntLiteral(400)),IntLiteral(0)),CallExpr(Id("printf"),[StringLiteral("%d la nam nhuan"),Id("y")]),CallExpr(Id("printf"),[StringLiteral("%d ko phai nam nhuan"),Id("y")]))]),CallExpr(Id("printf"),[StringLiteral("%d la nam nhuan"),Id("y")]))]),CallExpr(Id("printf"),[StringLiteral("%d ko phai la nam nhuan"),Id("y")])),Return(IntLiteral(0))]))]))
        self.assertTrue(TestAST.checkASTGen(input,expect,196))
    def test_97(self):
        input = """
        int main()
        {
           int n;       
           printf("Nhap so n: ");
           scanf("%d",n);
           if ( n%2 == 0 )
              printf("%d la so chan", n);
           else
              printf("%d la so le", n);       
           return 0;
        }"""
        expect=str(Program([FuncDecl(Id("main"),[],IntType(),Block([VarDecl("n",IntType()),CallExpr(Id("printf"),[StringLiteral("Nhap so n: ")]),CallExpr(Id("scanf"),[StringLiteral("%d"),Id("n")]),If(BinaryOp("==",BinaryOp("%",Id("n"),IntLiteral(2)),IntLiteral(0)),CallExpr(Id("printf"),[StringLiteral("%d la so chan"),Id("n")]),CallExpr(Id("printf"),[StringLiteral("%d la so le"),Id("n")])),Return(IntLiteral(0))]))]))
        self.assertTrue(TestAST.checkASTGen(input,expect,197))
    def test_98(self):
        input = """
        int main()
        {
            do {a=a=1;}{c=c*2;} while a>0;
        }
        """
        expect=str(Program([FuncDecl(Id("main"),[],IntType(),Block([Dowhile([Block([BinaryOp("=",Id("a"),BinaryOp("=",Id("a"),IntLiteral(1)))]),Block([BinaryOp("=",Id("c"),BinaryOp("*",Id("c"),IntLiteral(2)))])],BinaryOp(">",Id("a"),IntLiteral(0)))]))]))
        self.assertTrue(TestAST.checkASTGen(input,expect,198))
    def test_99(self):
        input = """
        int main(int a)
        {
            printf("day la ct cuoi");
        }
        """
        expect=str(Program([FuncDecl(Id("main"),[VarDecl("a",IntType())],IntType(),Block([CallExpr(Id("printf"),[StringLiteral("day la ct cuoi")])]))]))
        self.assertTrue(TestAST.checkASTGen(input,expect,199))
    def test_100(self):
        """More complex program"""
        input = """int a,b;"""
        expect = str(Program([VarDecl("a",IntType()),VarDecl("b",IntType())]))
        self.assertTrue(TestAST.checkASTGen(input,expect,200))