import unittest
from TestUtils import TestAST
from AST import *

class ASTGenSuite(unittest.TestCase):
    def test_num_1(self):
        input="""void main(){}"""
        expect=str(Program([FuncDecl(Id("main"),[],VoidType(),Block([]))]))
        self.assertTrue(TestAST.checkASTGen(input,expect,301))

    def test_num_2(self):
        input="""int i;"""
        expect = str(Program([VarDecl("i",IntType())]))
        self.assertTrue(TestAST.checkASTGen(input,expect,302))

    def test_num_3(self):
        input="""int main()
        {
            int a,b;
        }"""
        expect = str(Program([FuncDecl(Id("main"),[],IntType(),Block([VarDecl("a",IntType()),VarDecl("b",IntType())]))]))
        self.assertTrue(TestAST.checkASTGen(input,expect,303))

    def test_num_4(self):
        input="""int[] main()
        {
            int a;
        }"""
        expect = str(Program([FuncDecl(Id("main"),[],ArrayPointerType(IntType()),Block([VarDecl("a",IntType())]))]))
        self.assertTrue(TestAST.checkASTGen(input,expect,304))

    def test_num_5(self):
        input="""float a,b,c,d;"""
        expect = str(Program([VarDecl("a",FloatType()),VarDecl("b",FloatType()),VarDecl("c",FloatType()),VarDecl("d",FloatType())]))
        self.assertTrue(TestAST.checkASTGen(input,expect,305))

    def test_num_6(self):
        input="""int a[4];"""
        expect = str(Program([VarDecl("a",ArrayType(4,IntType()))]))
        self.assertTrue(TestAST.checkASTGen(input,expect,306))

    def test_num_7(self):
        input="""int main(){}
        boolean foo(){}
        float bar(){}"""
        expect = str(Program([FuncDecl(Id("main"),[],IntType(),Block([])),FuncDecl(Id("foo"),[],BoolType(),Block([])),FuncDecl(Id("bar"),[],FloatType(),Block([]))]))
        self.assertTrue(TestAST.checkASTGen(input,expect,307))

    def test_num_8(self):
        input="""int abc[10], cba[100];
        void main(){}"""
        expect = str(Program([VarDecl("abc",ArrayType(10,IntType())),VarDecl("cba",ArrayType(100,IntType())),FuncDecl(Id("main"),[],VoidType(),Block([]))]))
        self.assertTrue(TestAST.checkASTGen(input,expect,308))

    def test_num_9(self):
        input="""float[] abc(){}"""
        expect = str(Program([FuncDecl(Id("abc"),[],ArrayPointerType(FloatType()),Block([]))]))
        self.assertTrue(TestAST.checkASTGen(input,expect,309))

    def test_num_10(self):
        input="""int a,b,c,d[15],e[50];
        string ab[15];
        float cd[20], ef;
        boolean il, me[11548];
        int main(){}
        float[] cdab(){}
        boolean foo(int a, string b[]){}
        """
        expect = str(Program([VarDecl("a",IntType()),VarDecl("b",IntType()),VarDecl("c",IntType()),VarDecl("d",ArrayType(15,IntType())),VarDecl("e",ArrayType(50,IntType())),VarDecl("ab",ArrayType(15,StringType())),VarDecl("cd",ArrayType(20,FloatType())),VarDecl("ef",FloatType()),VarDecl("il",BoolType()),VarDecl("me",ArrayType(11548,BoolType())),FuncDecl(Id("main"),[],IntType(),Block([])),FuncDecl(Id("cdab"),[],ArrayPointerType(FloatType()),Block([])),FuncDecl(Id("foo"),[VarDecl("a",IntType()),VarDecl("b",ArrayPointerType(StringType()))],BoolType(),Block([]))]))
        self.assertTrue(TestAST.checkASTGen(input,expect,310))

    def test_num_11(self):
        input="""int main()
        {
            int a, b;
            a = 5;
            b = a;
        }"""
        expect = str(Program([FuncDecl(Id("main"),[],IntType(),Block([VarDecl("a",IntType()),VarDecl("b",IntType()),BinaryOp("=",Id("a"),IntLiteral(5)),BinaryOp("=",Id("b"),Id("a"))]))]))
        self.assertTrue(TestAST.checkASTGen(input,expect,311))

    def test_num_12(self):
        input="""int main(string a[])
        {
            float a;
            a = 12.45E-35;
            string b;
            b = "abcdef";
        }"""
        expect = str(Program([FuncDecl(Id("main"),[VarDecl("a",ArrayPointerType(StringType()))],IntType(),Block([VarDecl("a",FloatType()),BinaryOp("=",Id("a"),FloatLiteral(1.245e-34)),VarDecl("b",StringType()),BinaryOp("=",Id("b"),StringLiteral("abcdef"))]))]))
        self.assertTrue(TestAST.checkASTGen(input,expect,312))

    def test_num_13(self):
        input="""int flat()
        {
            string a, b, c;
            int dcba;
            dcba || a;
            b || b;
            getInt(val) || dcba;
        }"""
        expect = str(Program([FuncDecl(Id("flat"),[],IntType(),Block([VarDecl("a",StringType()),VarDecl("b",StringType()),VarDecl("c",StringType()),VarDecl("dcba",IntType()),BinaryOp("||",Id("dcba"),Id("a")),BinaryOp("||",Id("b"),Id("b")),BinaryOp("||",CallExpr(Id("getInt"),[Id("val")]),Id("dcba"))]))]))
        self.assertTrue(TestAST.checkASTGen(input,expect,313))

    def test_num_14(self):
        input="""float abc(){
            abc[15] || bcda[5] || b || ab || putLn();
        }"""
        expect = str(Program([FuncDecl(Id("abc"),[],FloatType(),Block([BinaryOp("||",BinaryOp("||",BinaryOp("||",BinaryOp("||",ArrayCell(Id("abc"),IntLiteral(15)),ArrayCell(Id("bcda"),IntLiteral(5))),Id("b")),Id("ab")),CallExpr(Id("putLn"),[]))]))]))
        self.assertTrue(TestAST.checkASTGen(input,expect,314))

    def test_num_15(self):
        input="""string[] ppl(int ab, boolean abc[]){
            ab = abc[1] && abc[5];
            putStringLn() && ab;
        }"""
        expect = str(Program([FuncDecl(Id("ppl"),[VarDecl("ab",IntType()),VarDecl("abc",ArrayPointerType(BoolType()))],ArrayPointerType(StringType()),Block([BinaryOp("=",Id("ab"),BinaryOp("&&",ArrayCell(Id("abc"),IntLiteral(1)),ArrayCell(Id("abc"),IntLiteral(5)))),BinaryOp("&&",CallExpr(Id("putStringLn"),[]),Id("ab"))]))]))
        self.assertTrue(TestAST.checkASTGen(input,expect,315))

    def test_num_16(self):
        input="""boolean main(){
            abc && adb && cdab;
        }"""
        expect = str(Program([FuncDecl(Id("main"),[],BoolType(),Block([BinaryOp("&&",BinaryOp("&&",Id("abc"),Id("adb")),Id("cdab"))]))]))
        self.assertTrue(TestAST.checkASTGen(input,expect,316))

    def test_num_17(self):
        input="""float plain()
        {
            a == b;
            c[15] == ba;
            p(15) == ac[ac[15]];

        }"""
        expect = str(Program([FuncDecl(Id("plain"),[],FloatType(),Block([BinaryOp("==",Id("a"),Id("b")),BinaryOp("==",ArrayCell(Id("c"),IntLiteral(15)),Id("ba")),BinaryOp("==",CallExpr(Id("p"),[IntLiteral(15)]),ArrayCell(Id("ac"),ArrayCell(Id("ac"),IntLiteral(15))))]))]))
        self.assertTrue(TestAST.checkASTGen(input,expect,317))

    def test_num_18(self):
        input="""string pot(string abc)
        {
            a[1] == (b[c[2]] != (callMe() != (MaybeNot() != (5 != (printMe() == (none != yes))))));
        }"""
        expect = str(Program([FuncDecl(Id("pot"),[VarDecl("abc",StringType())],StringType(),Block([BinaryOp("==",ArrayCell(Id("a"),IntLiteral(1)),BinaryOp("!=",ArrayCell(Id("b"),ArrayCell(Id("c"),IntLiteral(2))),BinaryOp("!=",CallExpr(Id("callMe"),[]),BinaryOp("!=",CallExpr(Id("MaybeNot"),[]),BinaryOp("!=",IntLiteral(5),BinaryOp("==",CallExpr(Id("printMe"),[]),BinaryOp("!=",Id("none"),Id("yes"))))))))]))]))
        self.assertTrue(TestAST.checkASTGen(input,expect,318))

    def test_num_19(self):
        input="""boolean isTrue(){
            a < b;
            bac() < pods(c20);
            b >= c[20];
            poms >= callMeOnce();
        }"""
        expect = str(Program([FuncDecl(Id("isTrue"),[],BoolType(),Block([BinaryOp("<",Id("a"),Id("b")),BinaryOp("<",CallExpr(Id("bac"),[]),CallExpr(Id("pods"),[Id("c20")])),BinaryOp(">=",Id("b"),ArrayCell(Id("c"),IntLiteral(20))),BinaryOp(">=",Id("poms"),CallExpr(Id("callMeOnce"),[]))]))]))
        self.assertTrue(TestAST.checkASTGen(input,expect,319))

    def test_num_20(self):
        input="""string lite(){
            abc <= bcdsa(25);
            acb[1000] <= acbwp();
            ba > 25;
            34 > 92;
        }"""
        expect = str(Program([FuncDecl(Id("lite"),[],StringType(),Block([BinaryOp("<=",Id("abc"),CallExpr(Id("bcdsa"),[IntLiteral(25)])),BinaryOp("<=",ArrayCell(Id("acb"),IntLiteral(1000)),CallExpr(Id("acbwp"),[])),BinaryOp(">",Id("ba"),IntLiteral(25)),BinaryOp(">",IntLiteral(34),IntLiteral(92))]))]))
        self.assertTrue(TestAST.checkASTGen(input,expect,320))

    def test_num_21(self):
        input="""int main(){
            int a,b,c;
            a = 5;
            b = 10;
            c = 15;
            a = a + c;
            b +  b - c;
            c = a + c - b + a - c;
        }"""
        expect = str(Program([FuncDecl(Id("main"),[],IntType(),Block([VarDecl("a",IntType()),VarDecl("b",IntType()),VarDecl("c",IntType()),BinaryOp("=",Id("a"),IntLiteral(5)),BinaryOp("=",Id("b"),IntLiteral(10)),BinaryOp("=",Id("c"),IntLiteral(15)),BinaryOp("=",Id("a"),BinaryOp("+",Id("a"),Id("c"))),BinaryOp("-",BinaryOp("+",Id("b"),Id("b")),Id("c")),BinaryOp("=",Id("c"),BinaryOp("-",BinaryOp("+",BinaryOp("-",BinaryOp("+",Id("a"),Id("c")),Id("b")),Id("a")),Id("c")))]))]))
        self.assertTrue(TestAST.checkASTGen(input,expect,321))

    def test_num_22(self):
        input="""boolean main(){
            float a,b;
            string c,d;
            boolean e;
            a = a + b - c + d - e;
            a = a + b + c + d + e - a -b -c -d -e + 10 - 15.5 - "abc" + true - false;
        }"""
        expect = str(Program([FuncDecl(Id("main"),[],BoolType(),Block([VarDecl("a",FloatType()),VarDecl("b",FloatType()),VarDecl("c",StringType()),VarDecl("d",StringType()),VarDecl("e",BoolType()),BinaryOp("=",Id("a"),BinaryOp("-",BinaryOp("+",BinaryOp("-",BinaryOp("+",Id("a"),Id("b")),Id("c")),Id("d")),Id("e"))),BinaryOp("=",Id("a"),BinaryOp("-",BinaryOp("+",BinaryOp("-",BinaryOp("-",BinaryOp("+",BinaryOp("-",BinaryOp("-",BinaryOp("-",BinaryOp("-",BinaryOp("-",BinaryOp("+",BinaryOp("+",BinaryOp("+",BinaryOp("+",Id("a"),Id("b")),Id("c")),Id("d")),Id("e")),Id("a")),Id("b")),Id("c")),Id("d")),Id("e")),IntLiteral(10)),FloatLiteral(15.5)),StringLiteral("abc")),BooleanLiteral(True)),BooleanLiteral(False)))]))]))
        self.assertTrue(TestAST.checkASTGen(input,expect,322))

    def test_num_23(self):
        input="""int foo()
        {
            int a;
            float b;
            string c;
            a = b * c * d;
            b = 10 / 5 / 2 * 3;
            c = 20 % 5 + 4 / 3 - "abc" * 20;
        }"""
        expect = str(Program([FuncDecl(Id("foo"),[],IntType(),Block([VarDecl("a",IntType()),VarDecl("b",FloatType()),VarDecl("c",StringType()),BinaryOp("=",Id("a"),BinaryOp("*",BinaryOp("*",Id("b"),Id("c")),Id("d"))),BinaryOp("=",Id("b"),BinaryOp("*",BinaryOp("/",BinaryOp("/",IntLiteral(10),IntLiteral(5)),IntLiteral(2)),IntLiteral(3))),BinaryOp("=",Id("c"),BinaryOp("-",BinaryOp("+",BinaryOp("%",IntLiteral(20),IntLiteral(5)),BinaryOp("/",IntLiteral(4),IntLiteral(3))),BinaryOp("*",StringLiteral("abc"),IntLiteral(20))))]))]))
        self.assertTrue(TestAST.checkASTGen(input,expect,323))

    def test_num_24(self):
        input="""float findNum(){
            int a, b,c;
            float d,e,f;
            a = 125e5 * a + b / 25 + c % "asbcd";
            b = "astring" + 453 / 214.58 % 432 + 326e-54;
            d = e + f * 1000.00;
        }"""
        expect = str(Program([FuncDecl(Id("findNum"),[],FloatType(),Block([VarDecl("a",IntType()),VarDecl("b",IntType()),VarDecl("c",IntType()),VarDecl("d",FloatType()),VarDecl("e",FloatType()),VarDecl("f",FloatType()),BinaryOp("=",Id("a"),BinaryOp("+",BinaryOp("+",BinaryOp("*",FloatLiteral(12500000.0),Id("a")),BinaryOp("/",Id("b"),IntLiteral(25))),BinaryOp("%",Id("c"),StringLiteral("asbcd")))),BinaryOp("=",Id("b"),BinaryOp("+",BinaryOp("+",StringLiteral("astring"),BinaryOp("%",BinaryOp("/",IntLiteral(453),FloatLiteral(214.58)),IntLiteral(432))),FloatLiteral(3.26e-52))),BinaryOp("=",Id("d"),BinaryOp("+",Id("e"),BinaryOp("*",Id("f"),FloatLiteral(1000.0))))]))]))
        self.assertTrue(TestAST.checkASTGen(input,expect,324))

    def test_num_25(self):
        input="""int main(){
            float a;
            a = -a;
            a = -254;
            a = -1245.215;
        }"""
        expect = str(Program([FuncDecl(Id("main"),[],IntType(),Block([VarDecl("a",FloatType()),BinaryOp("=",Id("a"),UnaryOp("-",Id("a"))),BinaryOp("=",Id("a"),UnaryOp("-",IntLiteral(254))),BinaryOp("=",Id("a"),UnaryOp("-",FloatLiteral(1245.215)))]))]))
        self.assertTrue(TestAST.checkASTGen(input,expect,325))

    def test_num_26(self):
        input="""string foo()
        {
            boolean n;
            n = true;
            n = !n;
            n = !false;
            n = ! 25;
        }"""
        expect = str(Program([FuncDecl(Id("foo"),[],StringType(),Block([VarDecl("n",BoolType()),BinaryOp("=",Id("n"),BooleanLiteral(True)),BinaryOp("=",Id("n"),UnaryOp("!",Id("n"))),BinaryOp("=",Id("n"),UnaryOp("!",BooleanLiteral(False))),BinaryOp("=",Id("n"),UnaryOp("!",IntLiteral(25)))]))]))
        self.assertTrue(TestAST.checkASTGen(input,expect,326))

    def test_num_27(self):
        input="""float goo(){
            int a[250];
            a[45];
            a[234] = 125;
            a[124 + 200] = a[2] - a[a[95]];
            a[true != false] = a[1 == 2] || a[25 <= 45];
        }"""
        expect = str(Program([FuncDecl(Id("goo"),[],FloatType(),Block([VarDecl("a",ArrayType(250,IntType())),ArrayCell(Id("a"),IntLiteral(45)),BinaryOp("=",ArrayCell(Id("a"),IntLiteral(234)),IntLiteral(125)),BinaryOp("=",ArrayCell(Id("a"),BinaryOp("+",IntLiteral(124),IntLiteral(200))),BinaryOp("-",ArrayCell(Id("a"),IntLiteral(2)),ArrayCell(Id("a"),ArrayCell(Id("a"),IntLiteral(95))))),BinaryOp("=",ArrayCell(Id("a"),BinaryOp("!=",BooleanLiteral(True),BooleanLiteral(False))),BinaryOp("||",ArrayCell(Id("a"),BinaryOp("==",IntLiteral(1),IntLiteral(2))),ArrayCell(Id("a"),BinaryOp("<=",IntLiteral(25),IntLiteral(45)))))]))]))
        self.assertTrue(TestAST.checkASTGen(input,expect,327))

    def test_num_28(self):
        input="""string roo(){
            float abc[125];
            abc[5] = 125.5e3;
            abc[0] = abc[1];
            abc[abc[4] || abc[95]] + abc[45] - abc[88] < abc[abc[5]] - abc[125 % 56];
        }""" 
        expect = str(Program([FuncDecl(Id("roo"),[],StringType(),Block([VarDecl("abc",ArrayType(125,FloatType())),BinaryOp("=",ArrayCell(Id("abc"),IntLiteral(5)),FloatLiteral(125500.0)),BinaryOp("=",ArrayCell(Id("abc"),IntLiteral(0)),ArrayCell(Id("abc"),IntLiteral(1))),BinaryOp("<",BinaryOp("-",BinaryOp("+",ArrayCell(Id("abc"),BinaryOp("||",ArrayCell(Id("abc"),IntLiteral(4)),ArrayCell(Id("abc"),IntLiteral(95)))),ArrayCell(Id("abc"),IntLiteral(45))),ArrayCell(Id("abc"),IntLiteral(88))),BinaryOp("-",ArrayCell(Id("abc"),ArrayCell(Id("abc"),IntLiteral(5))),ArrayCell(Id("abc"),BinaryOp("%",IntLiteral(125),IntLiteral(56)))))]))]))
        self.assertTrue(TestAST.checkASTGen(input,expect,328))

    def test_num_29(self):
        input="""int[] floaat(int array[], float array2[])
        {
            string foo[200];
            foo[5] = "absac";
            foo[55 + 5 + "abcs"] = foo[45] % foo[15] + getIntLn();
        }"""
        expect = str(Program([FuncDecl(Id("floaat"),[VarDecl("array",ArrayPointerType(IntType())),VarDecl("array2",ArrayPointerType(FloatType()))],ArrayPointerType(IntType()),Block([VarDecl("foo",ArrayType(200,StringType())),BinaryOp("=",ArrayCell(Id("foo"),IntLiteral(5)),StringLiteral("absac")),BinaryOp("=",ArrayCell(Id("foo"),BinaryOp("+",BinaryOp("+",IntLiteral(55),IntLiteral(5)),StringLiteral("abcs"))),BinaryOp("+",BinaryOp("%",ArrayCell(Id("foo"),IntLiteral(45)),ArrayCell(Id("foo"),IntLiteral(15))),CallExpr(Id("getIntLn"),[])))]))]))
        self.assertTrue(TestAST.checkASTGen(input,expect,329))

    def test_num_30(self):
        input="""boolean isTrue(){
            boolean notTrue[50];
            notTrue[ab + 54] = abc - false;
            notTrue[30] = True + False % false + (45e-2 + CallEx(25));
        }"""
        expect = str(Program([FuncDecl(Id("isTrue"),[],BoolType(),Block([VarDecl("notTrue",ArrayType(50,BoolType())),BinaryOp("=",ArrayCell(Id("notTrue"),BinaryOp("+",Id("ab"),IntLiteral(54))),BinaryOp("-",Id("abc"),BooleanLiteral(False))),BinaryOp("=",ArrayCell(Id("notTrue"),IntLiteral(30)),BinaryOp("+",BinaryOp("+",Id("True"),BinaryOp("%",Id("False"),BooleanLiteral(False))),BinaryOp("+",FloatLiteral(0.45),CallExpr(Id("CallEx"),[IntLiteral(25)]))))]))]))
        self.assertTrue(TestAST.checkASTGen(input,expect,330))

    def test_num_31(self):
        input="""int main(){
            int a;
            a = a + 5;
            float b;
            1245.48e32;
            b = 3265.125e-9;
        }"""
        expect = str(Program([FuncDecl(Id("main"),[],IntType(),Block([VarDecl("a",IntType()),BinaryOp("=",Id("a"),BinaryOp("+",Id("a"),IntLiteral(5))),VarDecl("b",FloatType()),FloatLiteral(1.24548e+35),BinaryOp("=",Id("b"),FloatLiteral(3.265125e-06))]))]))
        self.assertTrue(TestAST.checkASTGen(input,expect,331))

    def test_num_32(self):
        input="""string getString(){
            getString();
            "thisisastring";
            "thisisanotherstring";
            string a;
            a = "this is the third string";
        }"""
        expect = str(Program([FuncDecl(Id("getString"),[],StringType(),Block([CallExpr(Id("getString"),[]),StringLiteral("thisisastring"),StringLiteral("thisisanotherstring"),VarDecl("a",StringType()),BinaryOp("=",Id("a"),StringLiteral("this is the third string"))]))]))
        self.assertTrue(TestAST.checkASTGen(input,expect,332))

    def test_num_33(self):
        input="""boolean isFalse(){
            boolean a;
            a = false;
            boolean b;
            b = true;
            a && b;
            a = a || b;
            boolean c;
            c = true && false;
        }"""
        expect = str(Program([FuncDecl(Id("isFalse"),[],BoolType(),Block([VarDecl("a",BoolType()),BinaryOp("=",Id("a"),BooleanLiteral(False)),VarDecl("b",BoolType()),BinaryOp("=",Id("b"),BooleanLiteral(True)),BinaryOp("&&",Id("a"),Id("b")),BinaryOp("=",Id("a"),BinaryOp("||",Id("a"),Id("b"))),VarDecl("c",BoolType()),BinaryOp("=",Id("c"),BinaryOp("&&",BooleanLiteral(True),BooleanLiteral(False)))]))]))
        self.assertTrue(TestAST.checkASTGen(input,expect,333))

    def test_num_34(self):
        input="""string calling(){
            callExpr1();
            call_next_expr();
            call_one_param(ab);
            call_two_param(ab, 45);
        }"""
        expect = str(Program([FuncDecl(Id("calling"),[],StringType(),Block([CallExpr(Id("callExpr1"),[]),CallExpr(Id("call_next_expr"),[]),CallExpr(Id("call_one_param"),[Id("ab")]),CallExpr(Id("call_two_param"),[Id("ab"),IntLiteral(45)])]))]))
        self.assertTrue(TestAST.checkASTGen(input,expect,334))

    def test_num_35(self):
        input="""void callmore()
        {
            callthree("abc", true, 1);
            callfour(a[45] + 92, true, "cba", 94e5);
            calloncemore(45 >= 2, yes);
        }"""
        expect = str(Program([FuncDecl(Id("callmore"),[],VoidType(),Block([CallExpr(Id("callthree"),[StringLiteral("abc"),BooleanLiteral(True),IntLiteral(1)]),CallExpr(Id("callfour"),[BinaryOp("+",ArrayCell(Id("a"),IntLiteral(45)),IntLiteral(92)),BooleanLiteral(True),StringLiteral("cba"),FloatLiteral(9400000.0)]),CallExpr(Id("calloncemore"),[BinaryOp(">=",IntLiteral(45),IntLiteral(2)),Id("yes")])]))]))
        self.assertTrue(TestAST.checkASTGen(input,expect,335))

    def test_num_36(self):
        input="""int main(){
            int changing;
            changing = (4 + 6) / 5 - (3 * 2) % 8;
        }"""
        expect = str(Program([FuncDecl(Id("main"),[],IntType(),Block([VarDecl("changing",IntType()),BinaryOp("=",Id("changing"),BinaryOp("-",BinaryOp("/",BinaryOp("+",IntLiteral(4),IntLiteral(6)),IntLiteral(5)),BinaryOp("%",BinaryOp("*",IntLiteral(3),IntLiteral(2)),IntLiteral(8))))]))]))
        self.assertTrue(TestAST.checkASTGen(input,expect,336))

    def test_num_37(self):
        input="""void main(int argc)
        {
            callingin(45 + (9 - (48 % 3)));
            callingout(45 * (3 - 2), (true && false) || (false && true), a[11] * (a[32] - a[48]));
        }"""
        expect = str(Program([FuncDecl(Id("main"),[VarDecl("argc",IntType())],VoidType(),Block([CallExpr(Id("callingin"),[BinaryOp("+",IntLiteral(45),BinaryOp("-",IntLiteral(9),BinaryOp("%",IntLiteral(48),IntLiteral(3))))]),CallExpr(Id("callingout"),[BinaryOp("*",IntLiteral(45),BinaryOp("-",IntLiteral(3),IntLiteral(2))),BinaryOp("||",BinaryOp("&&",BooleanLiteral(True),BooleanLiteral(False)),BinaryOp("&&",BooleanLiteral(False),BooleanLiteral(True))),BinaryOp("*",ArrayCell(Id("a"),IntLiteral(11)),BinaryOp("-",ArrayCell(Id("a"),IntLiteral(32)),ArrayCell(Id("a"),IntLiteral(48))))])]))]))
        self.assertTrue(TestAST.checkASTGen(input,expect,337))

    def test_num_38(self):
        input="""void foo()
        {
            if (a >= b) fooo(abc, cde);
            if (a || true) rooo(123, 456);
        }"""
        expect = str(Program([FuncDecl(Id("foo"),[],VoidType(),Block([If(BinaryOp(">=",Id("a"),Id("b")),CallExpr(Id("fooo"),[Id("abc"),Id("cde")])),If(BinaryOp("||",Id("a"),BooleanLiteral(True)),CallExpr(Id("rooo"),[IntLiteral(123),IntLiteral(456)]))]))]))
        self.assertTrue(TestAST.checkASTGen(input,expect,338))

    def test_num_39(self):
        input="""string goo()
        {
            if (abc) yrs();
            else blc();
        }"""
        expect = str(Program([FuncDecl(Id("goo"),[],StringType(),Block([If(Id("abc"),CallExpr(Id("yrs"),[]),CallExpr(Id("blc"),[]))]))]))
        self.assertTrue(TestAST.checkASTGen(input,expect,339))

    def test_num_40(self):
        input="""boolean isIf(string a)
        {
            if (ab >= c || c + a == d)
            {
                print("RIGHT");
            }
            else
                print("Nothing");
        }"""
        expect = str(Program([FuncDecl(Id("isIf"),[VarDecl("a",StringType())],BoolType(),Block([If(BinaryOp("||",BinaryOp(">=",Id("ab"),Id("c")),BinaryOp("==",BinaryOp("+",Id("c"),Id("a")),Id("d"))),Block([CallExpr(Id("print"),[StringLiteral("RIGHT")])]),CallExpr(Id("print"),[StringLiteral("Nothing")]))]))]))
        self.assertTrue(TestAST.checkASTGen(input,expect,340))

    def test_num_41(self):
        input="""string main()
        {
            if (true)
            {
                print("Another Nothing");
            }
            else if (false)
            {
                print ("Its false");
            }
            else if (true + and + false)
            {
                a = a + c;
                putIntLn();
            }
            else 
                doNothing();
        }"""
        expect = str(Program([FuncDecl(Id("main"),[],StringType(),Block([If(BooleanLiteral(True),Block([CallExpr(Id("print"),[StringLiteral("Another Nothing")])]),If(BooleanLiteral(False),Block([CallExpr(Id("print"),[StringLiteral("Its false")])]),If(BinaryOp("+",BinaryOp("+",BooleanLiteral(True),Id("and")),BooleanLiteral(False)),Block([BinaryOp("=",Id("a"),BinaryOp("+",Id("a"),Id("c"))),CallExpr(Id("putIntLn"),[])]),CallExpr(Id("doNothing"),[]))))]))]))
        self.assertTrue(TestAST.checkASTGen(input,expect,341))

    def test_num_42(self):
        input="""void foo()
        {
            if (abc) abde();
                if (abcde) foo();
                    if (cdbe) goo();
                        if (bcef) loo();
                        else 
                            doNothing();      
        }"""
        expect = str(Program([FuncDecl(Id("foo"),[],VoidType(),Block([If(Id("abc"),CallExpr(Id("abde"),[])),If(Id("abcde"),CallExpr(Id("foo"),[])),If(Id("cdbe"),CallExpr(Id("goo"),[])),If(Id("bcef"),CallExpr(Id("loo"),[]),CallExpr(Id("doNothing"),[]))]))]))
        self.assertTrue(TestAST.checkASTGen(input,expect,342))

    def test_num_43(self):
        input="""void foo(){
            do nothing();
            while(true);
        }"""
        expect = str(Program([FuncDecl(Id("foo"),[],VoidType(),Block([Dowhile([CallExpr(Id("nothing"),[])],BooleanLiteral(True))]))]))
        self.assertTrue(TestAST.checkASTGen(input,expect,343))

    def test_num_44(self):
        input="""float goo(){
            do
                if (a == 1)
                    a = a + 1;
                else
                    a = a- 1;
            while(a != 1);
        }"""
        expect = str(Program([FuncDecl(Id("goo"),[],FloatType(),Block([Dowhile([If(BinaryOp("==",Id("a"),IntLiteral(1)),BinaryOp("=",Id("a"),BinaryOp("+",Id("a"),IntLiteral(1))),BinaryOp("=",Id("a"),BinaryOp("-",Id("a"),IntLiteral(1))))],BinaryOp("!=",Id("a"),IntLiteral(1)))]))]))
        self.assertTrue(TestAST.checkASTGen(input,expect,344))

    def test_num_45(self):
        input="""string loo(boolean a[]){
            do
                foo();
                if (a == 6) a = a * 2;
                b[b[12]] = a * 2 / 4 % 5;
                {
                    free();
                    b = 0;
                    a = 0;
                }
            while (!false);
        }"""
        expect = str(Program([FuncDecl(Id("loo"),[VarDecl("a",ArrayPointerType(BoolType()))],StringType(),Block([Dowhile([CallExpr(Id("foo"),[]),If(BinaryOp("==",Id("a"),IntLiteral(6)),BinaryOp("=",Id("a"),BinaryOp("*",Id("a"),IntLiteral(2)))),BinaryOp("=",ArrayCell(Id("b"),ArrayCell(Id("b"),IntLiteral(12))),BinaryOp("%",BinaryOp("/",BinaryOp("*",Id("a"),IntLiteral(2)),IntLiteral(4)),IntLiteral(5))),Block([CallExpr(Id("free"),[]),BinaryOp("=",Id("b"),IntLiteral(0)),BinaryOp("=",Id("a"),IntLiteral(0))])],UnaryOp("!",BooleanLiteral(False)))]))]))
        self.assertTrue(TestAST.checkASTGen(input,expect,345))

    def test_num_46(self):
        input="""boolean forget(){
            do {
                nothing();
                morenothing = 1;
                i = i + i;
                if (i = 500) break;
            }
            while (true && !false || (a + b == 5));
        }
        """
        expect = str(Program([FuncDecl(Id("forget"),[],BoolType(),Block([Dowhile([Block([CallExpr(Id("nothing"),[]),BinaryOp("=",Id("morenothing"),IntLiteral(1)),BinaryOp("=",Id("i"),BinaryOp("+",Id("i"),Id("i"))),If(BinaryOp("=",Id("i"),IntLiteral(500)),Break())])],BinaryOp("||",BinaryOp("&&",BooleanLiteral(True),UnaryOp("!",BooleanLiteral(False))),BinaryOp("==",BinaryOp("+",Id("a"),Id("b")),IntLiteral(5))))]))]))
        self.assertTrue(TestAST.checkASTGen(input,expect,346))

    def test_num_47(self):
        input="""
        boolean[] forgotten(){
            do {
                if (true) return 1;
                else return 2;
            }
            {
                continue;
                conitnue;
                {
                    if ( a == 5 ) 5;
                }
            }
                whie(a == 5);
            while (true);
        }
        """
        expect = str(Program([FuncDecl(Id("forgotten"),[],ArrayPointerType(BoolType()),Block([Dowhile([Block([If(BooleanLiteral(True),Return(IntLiteral(1)),Return(IntLiteral(2)))]),Block([Continue(),Id("conitnue"),Block([If(BinaryOp("==",Id("a"),IntLiteral(5)),IntLiteral(5))])]),CallExpr(Id("whie"),[BinaryOp("==",Id("a"),IntLiteral(5))])],BooleanLiteral(True))]))]))
        self.assertTrue(TestAST.checkASTGen(input,expect,347))

    def test_num_48(self):
        input="""void fortest(){
            for (i = 0; i < 1; i = i + 1)
            a = a - b;
            b = b - a;
        }"""
        expect = str(Program([FuncDecl(Id("fortest"),[],VoidType(),Block([For(BinaryOp("=",Id("i"),IntLiteral(0)),BinaryOp("<",Id("i"),IntLiteral(1)),BinaryOp("=",Id("i"),BinaryOp("+",Id("i"),IntLiteral(1))),BinaryOp("=",Id("a"),BinaryOp("-",Id("a"),Id("b")))),BinaryOp("=",Id("b"),BinaryOp("-",Id("b"),Id("a")))]))]))
        self.assertTrue(TestAST.checkASTGen(input,expect,348))

    def test_num_49(self):
        input="""boolean fortest(){
            for (a < 5; a = a + 15; a = -500){
                ablock();
                a = !true + (-458) * 15.5;
            }
        }"""
        expect = str(Program([FuncDecl(Id("fortest"),[],BoolType(),Block([For(BinaryOp("<",Id("a"),IntLiteral(5)),BinaryOp("=",Id("a"),BinaryOp("+",Id("a"),IntLiteral(15))),BinaryOp("=",Id("a"),UnaryOp("-",IntLiteral(500))),Block([CallExpr(Id("ablock"),[]),BinaryOp("=",Id("a"),BinaryOp("+",UnaryOp("!",BooleanLiteral(True)),BinaryOp("*",UnaryOp("-",IntLiteral(458)),FloatLiteral(15.5))))]))]))]))
        self.assertTrue(TestAST.checkASTGen(input,expect,349))

    def test_num_50(self):
        input="""string anotherfortest(){
            for (a = 0; a > 54; a = a - 4)
            {
                block();
                {
                    blockinblock();
                    a = a - 1;
                }
                a = a + 100;
            }
        }"""
        expect = str(Program([FuncDecl(Id("anotherfortest"),[],StringType(),Block([For(BinaryOp("=",Id("a"),IntLiteral(0)),BinaryOp(">",Id("a"),IntLiteral(54)),BinaryOp("=",Id("a"),BinaryOp("-",Id("a"),IntLiteral(4))),Block([CallExpr(Id("block"),[]),Block([CallExpr(Id("blockinblock"),[]),BinaryOp("=",Id("a"),BinaryOp("-",Id("a"),IntLiteral(1)))]),BinaryOp("=",Id("a"),BinaryOp("+",Id("a"),IntLiteral(100)))]))]))]))
        self.assertTrue(TestAST.checkASTGen(input,expect,350))

    def test_num_51(self):
        input="""int main(){
            for (i = -1; i > - 400; i = i - 5)
            {
                thesearestatementsinblock();
                a = 0;
                b = "abc";
                true != false;
                a = !(a[45] + 5);
            }
            {
                thisisanunrelatedblock();
            }
        }"""
        expect = str(Program([FuncDecl(Id("main"),[],IntType(),Block([For(BinaryOp("=",Id("i"),UnaryOp("-",IntLiteral(1))),BinaryOp(">",Id("i"),UnaryOp("-",IntLiteral(400))),BinaryOp("=",Id("i"),BinaryOp("-",Id("i"),IntLiteral(5))),Block([CallExpr(Id("thesearestatementsinblock"),[]),BinaryOp("=",Id("a"),IntLiteral(0)),BinaryOp("=",Id("b"),StringLiteral("abc")),BinaryOp("!=",BooleanLiteral(True),BooleanLiteral(False)),BinaryOp("=",Id("a"),UnaryOp("!",BinaryOp("+",ArrayCell(Id("a"),IntLiteral(45)),IntLiteral(5))))])),Block([CallExpr(Id("thisisanunrelatedblock"),[])])]))]))
        self.assertTrue(TestAST.checkASTGen(input,expect,351))

    def test_num_52(self):
        input="""float testfor(){
            for (a; b; c)
            {
                for (c; b; a)
                    for (b; a; c)
                        doNothing();
                a = a + 5;
            }
        }"""
        expect = str(Program([FuncDecl(Id("testfor"),[],FloatType(),Block([For(Id("a"),Id("b"),Id("c"),Block([For(Id("c"),Id("b"),Id("a"),For(Id("b"),Id("a"),Id("c"),CallExpr(Id("doNothing"),[]))),BinaryOp("=",Id("a"),BinaryOp("+",Id("a"),IntLiteral(5)))]))]))]))
        self.assertTrue(TestAST.checkASTGen(input,expect,352))

    def test_num_53(self):
        input="""int amin(){
            break;
        }"""
        expect = str(Program([FuncDecl(Id("amin"),[],IntType(),Block([Break()]))]))
        self.assertTrue(TestAST.checkASTGen(input,expect,353))

    def test_num_54(self):
        input="""int anothermain(){
            for (i = 5; i < 50; i = i * 4)
            {
                break;
                dothingshere();
            }
        }"""
        expect = str(Program([FuncDecl(Id("anothermain"),[],IntType(),Block([For(BinaryOp("=",Id("i"),IntLiteral(5)),BinaryOp("<",Id("i"),IntLiteral(50)),BinaryOp("=",Id("i"),BinaryOp("*",Id("i"),IntLiteral(4))),Block([Break(),CallExpr(Id("dothingshere"),[])]))]))]))
        self.assertTrue(TestAST.checkASTGen(input,expect,354))

    def test_num_55(self):
        input="""float main(){
            do 
                break;
                break;
                break;
            while(true);
        }"""
        expect = str(Program([FuncDecl(Id("main"),[],FloatType(),Block([Dowhile([Break(),Break(),Break()],BooleanLiteral(True))]))]))
        self.assertTrue(TestAST.checkASTGen(input,expect,355))

    def test_num_56(self):
        input="""boolean test(){
            if(test())
            {
                for (a = 5; a > 1; a = a + 4)
                {
                    do
                        break;
                    while (!true);
                }
                break;
            }
        }"""
        expect = str(Program([FuncDecl(Id("test"),[],BoolType(),Block([If(CallExpr(Id("test"),[]),Block([For(BinaryOp("=",Id("a"),IntLiteral(5)),BinaryOp(">",Id("a"),IntLiteral(1)),BinaryOp("=",Id("a"),BinaryOp("+",Id("a"),IntLiteral(4))),Block([Dowhile([Break()],UnaryOp("!",BooleanLiteral(True)))])),Break()]))]))]))
        self.assertTrue(TestAST.checkASTGen(input,expect,356))

    def test_num_57(self):
        input="""float ingpoint(){
            for (nothing; nothing > 1; nothing = nothing - 1)
            {
                if (nothing != !false)  break;
            }
        }"""
        expect = str(Program([FuncDecl(Id("ingpoint"),[],FloatType(),Block([For(Id("nothing"),BinaryOp(">",Id("nothing"),IntLiteral(1)),BinaryOp("=",Id("nothing"),BinaryOp("-",Id("nothing"),IntLiteral(1))),Block([If(BinaryOp("!=",Id("nothing"),UnaryOp("!",BooleanLiteral(False))),Break())]))]))]))
        self.assertTrue(TestAST.checkASTGen(input,expect,357))

    def test_num_58(self):
        input="""int test_continue(){
            continue;
        }"""
        expect = str(Program([FuncDecl(Id("test_continue"),[],IntType(),Block([Continue()]))]))
        self.assertTrue(TestAST.checkASTGen(input,expect,358))

    def test_num_59(self):
        input="""float ingpoint(){
            for (a = 5; a > 1; a = a - 1)
                continue;
        }"""
        expect = str(Program([FuncDecl(Id("ingpoint"),[],FloatType(),Block([For(BinaryOp("=",Id("a"),IntLiteral(5)),BinaryOp(">",Id("a"),IntLiteral(1)),BinaryOp("=",Id("a"),BinaryOp("-",Id("a"),IntLiteral(1))),Continue())]))]))
        self.assertTrue(TestAST.checkASTGen(input,expect,359))

    def test_num_60(self):
        input="""boolean treu(){
            do 
                a = a + 1;
                continue;
                bread();
            while (true && !false || false && !true);
        }"""
        expect = str(Program([FuncDecl(Id("treu"),[],BoolType(),Block([Dowhile([BinaryOp("=",Id("a"),BinaryOp("+",Id("a"),IntLiteral(1))),Continue(),CallExpr(Id("bread"),[])],BinaryOp("||",BinaryOp("&&",BooleanLiteral(True),UnaryOp("!",BooleanLiteral(False))),BinaryOp("&&",BooleanLiteral(False),UnaryOp("!",BooleanLiteral(True)))))]))]))
        self.assertTrue(TestAST.checkASTGen(input,expect,360))

    def test_num_61(self):
        input="""string longlong(){
            for (i = 5; i > 1; i = i)
                do 
                    if (a == 1) do
                                    nothing();
                                    continue;
                                while (notfalse);
                    if (a != 1) continue;
                    break;
                while (nothingagain());
        }"""
        expect = str(Program([FuncDecl(Id("longlong"),[],StringType(),Block([For(BinaryOp("=",Id("i"),IntLiteral(5)),BinaryOp(">",Id("i"),IntLiteral(1)),BinaryOp("=",Id("i"),Id("i")),Dowhile([If(BinaryOp("==",Id("a"),IntLiteral(1)),Dowhile([CallExpr(Id("nothing"),[]),Continue()],Id("notfalse"))),If(BinaryOp("!=",Id("a"),IntLiteral(1)),Continue()),Break()],CallExpr(Id("nothingagain"),[])))]))]))
        self.assertTrue(TestAST.checkASTGen(input,expect,361))

    def test_num_62(self):
        input="""int main(){
            return 0;
        }"""
        expect = str(Program([FuncDecl(Id("main"),[],IntType(),Block([Return(IntLiteral(0))]))]))
        self.assertTrue(TestAST.checkASTGen(input,expect,362))

    def test_num_63(self):
        input="""void foo(){
            if (a == 0) then;
            else return;
            do
                if (b == -a)
                    break;
            while (a > 1);
            return;
        }"""
        expect = str(Program([FuncDecl(Id("foo"),[],VoidType(),Block([If(BinaryOp("==",Id("a"),IntLiteral(0)),Id("then"),Return()),Dowhile([If(BinaryOp("==",Id("b"),UnaryOp("-",Id("a"))),Break())],BinaryOp(">",Id("a"),IntLiteral(1))),Return()]))]))
        self.assertTrue(TestAST.checkASTGen(input,expect,363))

    def test_num_64(self):
        input="""string test(){
            return "abcdefghijklmnopqrstuvwyz";
        }"""
        expect = str(Program([FuncDecl(Id("test"),[],StringType(),Block([Return(StringLiteral("abcdefghijklmnopqrstuvwyz"))]))]))
        self.assertTrue(TestAST.checkASTGen(input,expect,364))

    def test_num_65(self):
        input="""float returning(){
            do
                nothing();
            while (!false);
            return 0.1e3 + 2e-5 * 1.5 * 4e3;
        }"""
        expect = str(Program([FuncDecl(Id("returning"),[],FloatType(),Block([Dowhile([CallExpr(Id("nothing"),[])],UnaryOp("!",BooleanLiteral(False))),Return(BinaryOp("+",FloatLiteral(100.0),BinaryOp("*",BinaryOp("*",FloatLiteral(2e-05),FloatLiteral(1.5)),FloatLiteral(4000.0))))]))]))
        self.assertTrue(TestAST.checkASTGen(input,expect,365))

    def test_num_66(self):
        input="""boolean r(){
            return all;
            return true;
            return !false;
            return -me;
            return "ajas[dajwhelkajw]";
            return;
            return 54e9 - 12015E-54;
            return a - b % c / "abc";
        }"""
        expect = str(Program([FuncDecl(Id("r"),[],BoolType(),Block([Return(Id("all")),Return(BooleanLiteral(True)),Return(UnaryOp("!",BooleanLiteral(False))),Return(UnaryOp("-",Id("me"))),Return(StringLiteral("ajas[dajwhelkajw]")),Return(),Return(BinaryOp("-",FloatLiteral(54000000000.0),FloatLiteral(1.2015e-50))),Return(BinaryOp("-",Id("a"),BinaryOp("/",BinaryOp("%",Id("b"),Id("c")),StringLiteral("abc"))))]))]))
        self.assertTrue(TestAST.checkASTGen(input,expect,366))

    def test_num_67(self):
        input="""int a,b,c;
        int aa(){
            a + b + c;
            a || b - c;
        }"""
        expect = str(Program([VarDecl("a",IntType()),VarDecl("b",IntType()),VarDecl("c",IntType()),FuncDecl(Id("aa"),[],IntType(),Block([BinaryOp("+",BinaryOp("+",Id("a"),Id("b")),Id("c")),BinaryOp("||",Id("a"),BinaryOp("-",Id("b"),Id("c")))]))]))
        self.assertTrue(TestAST.checkASTGen(input,expect,367))

    def test_num_68(self):
        input="""void foo(){
            a = a + 1;
            true && false;
            !(false && nottrue);
        }"""
        expect = str(Program([FuncDecl(Id("foo"),[],VoidType(),Block([BinaryOp("=",Id("a"),BinaryOp("+",Id("a"),IntLiteral(1))),BinaryOp("&&",BooleanLiteral(True),BooleanLiteral(False)),UnaryOp("!",BinaryOp("&&",BooleanLiteral(False),Id("nottrue")))]))]))
        self.assertTrue(TestAST.checkASTGen(input,expect,368))

    def test_num_69(self):
        input="""string goo(){
            a <= b;
            b > c;
            c >= a;
            d > a;
        }"""
        expect = str(Program([FuncDecl(Id("goo"),[],StringType(),Block([BinaryOp("<=",Id("a"),Id("b")),BinaryOp(">",Id("b"),Id("c")),BinaryOp(">=",Id("c"),Id("a")),BinaryOp(">",Id("d"),Id("a"))]))]))
        self.assertTrue(TestAST.checkASTGen(input,expect,369))

    def test_num_70(self):
        input="""boolean foo(){
            a + b - c % d + e / true;
            d % b * e - a + k || false;
        }"""
        expect = str(Program([FuncDecl(Id("foo"),[],BoolType(),Block([BinaryOp("+",BinaryOp("-",BinaryOp("+",Id("a"),Id("b")),BinaryOp("%",Id("c"),Id("d"))),BinaryOp("/",Id("e"),BooleanLiteral(True))),BinaryOp("||",BinaryOp("+",BinaryOp("-",BinaryOp("*",BinaryOp("%",Id("d"),Id("b")),Id("e")),Id("a")),Id("k")),BooleanLiteral(False))]))]))
        self.assertTrue(TestAST.checkASTGen(input,expect,370))

    def test_num_71(self):
        input="""string yes(){
            exp;
            a[24];
            a[a[1] + b[45] - c[2]];
        }"""
        expect = str(Program([FuncDecl(Id("yes"),[],StringType(),Block([Id("exp"),ArrayCell(Id("a"),IntLiteral(24)),ArrayCell(Id("a"),BinaryOp("-",BinaryOp("+",ArrayCell(Id("a"),IntLiteral(1)),ArrayCell(Id("b"),IntLiteral(45))),ArrayCell(Id("c"),IntLiteral(2))))]))]))
        self.assertTrue(TestAST.checkASTGen(input,expect,371))

    def test_num_72(self):
        input="""boolean func(){
            str;
            flase();
            callingfunc1(func1, func2, true, !false);
            a = a + (b - c) * e + e * (e / d);
        }"""
        expect = str(Program([FuncDecl(Id("func"),[],BoolType(),Block([Id("str"),CallExpr(Id("flase"),[]),CallExpr(Id("callingfunc1"),[Id("func1"),Id("func2"),BooleanLiteral(True),UnaryOp("!",BooleanLiteral(False))]),BinaryOp("=",Id("a"),BinaryOp("+",BinaryOp("+",Id("a"),BinaryOp("*",BinaryOp("-",Id("b"),Id("c")),Id("e"))),BinaryOp("*",Id("e"),BinaryOp("/",Id("e"),Id("d")))))]))]))
        self.assertTrue(TestAST.checkASTGen(input,expect,372))

    def test_num_73(self):
        input="""void compo(boolean func, int func2[]){
            func = func2[1] + (getfunc(_) + not_func) * (fl / (pfx + 12.43E9));
        }"""
        expect = str(Program([FuncDecl(Id("compo"),[VarDecl("func",BoolType()),VarDecl("func2",ArrayPointerType(IntType()))],VoidType(),Block([BinaryOp("=",Id("func"),BinaryOp("+",ArrayCell(Id("func2"),IntLiteral(1)),BinaryOp("*",BinaryOp("+",CallExpr(Id("getfunc"),[Id("_")]),Id("not_func")),BinaryOp("/",Id("fl"),BinaryOp("+",Id("pfx"),FloatLiteral(12430000000.0))))))]))]))
        self.assertTrue(TestAST.checkASTGen(input,expect,373))

    def test_num_74(self):
        input="""string weeeeee(){
            weeeeee = weeeeeee - 1;
            heeeeee = reeeeee = weeeeeee;
            a || b || c || d && e && f && (weeee = a - 1);
        }"""
        expect = str(Program([FuncDecl(Id("weeeeee"),[],StringType(),Block([BinaryOp("=",Id("weeeeee"),BinaryOp("-",Id("weeeeeee"),IntLiteral(1))),BinaryOp("=",Id("heeeeee"),BinaryOp("=",Id("reeeeee"),Id("weeeeeee"))),BinaryOp("||",BinaryOp("||",BinaryOp("||",Id("a"),Id("b")),Id("c")),BinaryOp("&&",BinaryOp("&&",BinaryOp("&&",Id("d"),Id("e")),Id("f")),BinaryOp("=",Id("weeee"),BinaryOp("-",Id("a"),IntLiteral(1)))))]))]))
        self.assertTrue(TestAST.checkASTGen(input,expect,374))

    def test_num_75(self):
        input="""void call(){
            return exponent();
            exponent(exponent(1), exponent(2), exponent((fleeee - eeeee) * heeeee));
        }"""
        expect = str(Program([FuncDecl(Id("call"),[],VoidType(),Block([Return(CallExpr(Id("exponent"),[])),CallExpr(Id("exponent"),[CallExpr(Id("exponent"),[IntLiteral(1)]),CallExpr(Id("exponent"),[IntLiteral(2)]),CallExpr(Id("exponent"),[BinaryOp("*",BinaryOp("-",Id("fleeee"),Id("eeeee")),Id("heeeee"))])])]))]))
        self.assertTrue(TestAST.checkASTGen(input,expect,375))

    def test_num_76(self):
        input="""int main(){
            blocktest();
        }
        boolean moreblocktest(){}
        string onemoreblocktest(){}"""
        expect = str(Program([FuncDecl(Id("main"),[],IntType(),Block([CallExpr(Id("blocktest"),[])])),FuncDecl(Id("moreblocktest"),[],BoolType(),Block([])),FuncDecl(Id("onemoreblocktest"),[],StringType(),Block([]))]))
        self.assertTrue(TestAST.checkASTGen(input,expect,376))

    def test_num_77(self):
        input="""float blocktest(){
            _ = _ - 1;
            {
                float a,b,c;
            }
            {
                float c,d,e,f;
            }
            {
                float ingpoint;
                int eger[12];
            }
        }"""
        expect = str(Program([FuncDecl(Id("blocktest"),[],FloatType(),Block([BinaryOp("=",Id("_"),BinaryOp("-",Id("_"),IntLiteral(1))),Block([VarDecl("a",FloatType()),VarDecl("b",FloatType()),VarDecl("c",FloatType())]),Block([VarDecl("c",FloatType()),VarDecl("d",FloatType()),VarDecl("e",FloatType()),VarDecl("f",FloatType())]),Block([VarDecl("ingpoint",FloatType()),VarDecl("eger",ArrayType(12,IntType()))])]))]))
        self.assertTrue(TestAST.checkASTGen(input,expect,377))

    def test_num_78(self):
        input="""string moreblocktest()
        {
            {
                {
                    blockinblock();
                    {
                        blockinblockinblock();
                    }
                }
            }
        }"""
        expect = str(Program([FuncDecl(Id("moreblocktest"),[],StringType(),Block([Block([Block([CallExpr(Id("blockinblock"),[]),Block([CallExpr(Id("blockinblockinblock"),[])])])])]))]))
        self.assertTrue(TestAST.checkASTGen(input,expect,378))

    def test_num_79(self):
        input="""boolean moremoreblocktest(){
            testone();
            {
                l();
                for (a;b;c){
                    blockinblock;
                    {
                        moreblocktest();
                        {
                            moremoreblocktest();
                            {}
                        }
                        {
                            moremoreblocktest();
                        }
                    }
                }
            }
        }"""
        expect = str(Program([FuncDecl(Id("moremoreblocktest"),[],BoolType(),Block([CallExpr(Id("testone"),[]),Block([CallExpr(Id("l"),[]),For(Id("a"),Id("b"),Id("c"),Block([Id("blockinblock"),Block([CallExpr(Id("moreblocktest"),[]),Block([CallExpr(Id("moremoreblocktest"),[]),Block([])]),Block([CallExpr(Id("moremoreblocktest"),[])])])]))])]))]))
        self.assertTrue(TestAST.checkASTGen(input,expect,379))

    def test_num_80(self):
        input="""void alotofblocks(){
            {
                {
                    {
                        {}
                    }
                }
                {
                    {
                        {}
                    }
                }
                {}
            }
        }"""
        expect = str(Program([FuncDecl(Id("alotofblocks"),[],VoidType(),Block([Block([Block([Block([Block([])])]),Block([Block([Block([])])]),Block([])])]))]))
        self.assertTrue(TestAST.checkASTGen(input,expect,380))

    def test_num_81(self):
        input="""void blocksinloops(){
            for (a = 1; 1 >= a; a + 2)
            {
                firstblock;
                {
                    break;
                    {
                        do {
                            float a,b;
                            b = a + 1250.4e3;
                        }
                        {
                            boolean a,b,c;
                            c = a || b && false;
                        }
                        {
                            blockandblock();
                            {
                                a && b;
                                {
                                    b || a;
                                    return 1;
                                }
                            }
                        }
                        while(nothing);
                    }
                }
            }
        }"""
        expect = str(Program([FuncDecl(Id("blocksinloops"),[],VoidType(),Block([For(BinaryOp("=",Id("a"),IntLiteral(1)),BinaryOp(">=",IntLiteral(1),Id("a")),BinaryOp("+",Id("a"),IntLiteral(2)),Block([Id("firstblock"),Block([Break(),Block([Dowhile([Block([VarDecl("a",FloatType()),VarDecl("b",FloatType()),BinaryOp("=",Id("b"),BinaryOp("+",Id("a"),FloatLiteral(1250400.0)))]),Block([VarDecl("a",BoolType()),VarDecl("b",BoolType()),VarDecl("c",BoolType()),BinaryOp("=",Id("c"),BinaryOp("||",Id("a"),BinaryOp("&&",Id("b"),BooleanLiteral(False))))]),Block([CallExpr(Id("blockandblock"),[]),Block([BinaryOp("&&",Id("a"),Id("b")),Block([BinaryOp("||",Id("b"),Id("a")),Return(IntLiteral(1))])])])],Id("nothing"))])])]))]))]))
        self.assertTrue(TestAST.checkASTGen(input,expect,381))

    def test_num_82(self):
        input="""void forblocks(){
            for (a;b;c){
                blockofFor();
                {
                    for (c;b;a)
                    {
                        blockofFor();
                        {
                            moreblocks();
                        }
                    }
                }
                for (true;true;true)
                {
                    blocks();
                    {
                        moreblocks();
                    }
                }
            }
        }"""
        expect = str(Program([FuncDecl(Id("forblocks"),[],VoidType(),Block([For(Id("a"),Id("b"),Id("c"),Block([CallExpr(Id("blockofFor"),[]),Block([For(Id("c"),Id("b"),Id("a"),Block([CallExpr(Id("blockofFor"),[]),Block([CallExpr(Id("moreblocks"),[])])]))]),For(BooleanLiteral(True),BooleanLiteral(True),BooleanLiteral(True),Block([CallExpr(Id("blocks"),[]),Block([CallExpr(Id("moreblocks"),[])])]))]))]))]))
        self.assertTrue(TestAST.checkASTGen(input,expect,382))

    def test_num_83(self):
        input="""void iftestwithblock(){
            if (blocks())
            {
                thendoblocks();
                {
                    andmoreblocks();
                    {
                        {}
                    }
                }
            }
            else
            {
                blocksinblocks();
                {
                    donothing();
                    {}
                }
                {}
            }
        }"""
        expect = str(Program([FuncDecl(Id("iftestwithblock"),[],VoidType(),Block([If(CallExpr(Id("blocks"),[]),Block([CallExpr(Id("thendoblocks"),[]),Block([CallExpr(Id("andmoreblocks"),[]),Block([Block([])])])]),Block([CallExpr(Id("blocksinblocks"),[]),Block([CallExpr(Id("donothing"),[]),Block([])]),Block([])]))]))]))
        self.assertTrue(TestAST.checkASTGen(input,expect,383))

    def test_num_84(self):
        input="""int main(){
            for (a;b;c)
            {
                do 
                {
                    {}
                }
                {
                    {}
                }
                {{{{}}}}
                while(true);
            }
            {
                {}
            }
        }"""
        expect = str(Program([FuncDecl(Id("main"),[],IntType(),Block([For(Id("a"),Id("b"),Id("c"),Block([Dowhile([Block([Block([])]),Block([Block([])]),Block([Block([Block([Block([])])])])],BooleanLiteral(True))])),Block([Block([])])]))]))
        self.assertTrue(TestAST.checkASTGen(input,expect,384))

    def test_num_85(self):
        input="""void allblocks()
        {
            {
                {{{}{}}{{}}}
            }
        }
        boolean moreblocks(){
            do {{}}{{{}}}{{}}
            while (true);
            for (b;c;a)
            {
                {{0;}}
            }
            {{
                {}
            }}
        }"""
        expect = str(Program([FuncDecl(Id("allblocks"),[],VoidType(),Block([Block([Block([Block([Block([]),Block([])]),Block([Block([])])])])])),FuncDecl(Id("moreblocks"),[],BoolType(),Block([Dowhile([Block([Block([])]),Block([Block([Block([])])]),Block([Block([])])],BooleanLiteral(True)),For(Id("b"),Id("c"),Id("a"),Block([Block([Block([IntLiteral(0)])])])),Block([Block([Block([])])])]))]))
        self.assertTrue(TestAST.checkASTGen(input,expect,385))

    def test_num_86(self):
        input="""int a,b,c,d[123];
        void foo(string arg[], boolean isTrue){
            float k[15],l,m,n[1000],o,p,q;
        }
        string ab,cd,ef[124],gh[1245];
        string[] gpp(float ab[], int cpn[])
        {
            string a,b,c,d[123];
        }"""
        expect = str(Program([VarDecl("a",IntType()),VarDecl("b",IntType()),VarDecl("c",IntType()),VarDecl("d",ArrayType(123,IntType())),FuncDecl(Id("foo"),[VarDecl("arg",ArrayPointerType(StringType())),VarDecl("isTrue",BoolType())],VoidType(),Block([VarDecl("k",ArrayType(15,FloatType())),VarDecl("l",FloatType()),VarDecl("m",FloatType()),VarDecl("n",ArrayType(1000,FloatType())),VarDecl("o",FloatType()),VarDecl("p",FloatType()),VarDecl("q",FloatType())])),VarDecl("ab",StringType()),VarDecl("cd",StringType()),VarDecl("ef",ArrayType(124,StringType())),VarDecl("gh",ArrayType(1245,StringType())),FuncDecl(Id("gpp"),[VarDecl("ab",ArrayPointerType(FloatType())),VarDecl("cpn",ArrayPointerType(IntType()))],ArrayPointerType(StringType()),Block([VarDecl("a",StringType()),VarDecl("b",StringType()),VarDecl("c",StringType()),VarDecl("d",ArrayType(123,StringType()))]))]))
        self.assertTrue(TestAST.checkASTGen(input,expect,386))

    def test_num_87(self):
        input="""void main(){}
        int floo(){}
        float a,b,e,d,g[123],p[542],o[523723];
        void foo(){}
        boolean right,wrong[12];
        float a[15],b,d,e[135];
        int floooo(){}"""
        expect = str(Program([FuncDecl(Id("main"),[],VoidType(),Block([])),FuncDecl(Id("floo"),[],IntType(),Block([])),VarDecl("a",FloatType()),VarDecl("b",FloatType()),VarDecl("e",FloatType()),VarDecl("d",FloatType()),VarDecl("g",ArrayType(123,FloatType())),VarDecl("p",ArrayType(542,FloatType())),VarDecl("o",ArrayType(523723,FloatType())),FuncDecl(Id("foo"),[],VoidType(),Block([])),VarDecl("right",BoolType()),VarDecl("wrong",ArrayType(12,BoolType())),VarDecl("a",ArrayType(15,FloatType())),VarDecl("b",FloatType()),VarDecl("d",FloatType()),VarDecl("e",ArrayType(135,FloatType())),FuncDecl(Id("floooo"),[],IntType(),Block([]))]))
        self.assertTrue(TestAST.checkASTGen(input,expect,387))

    def test_num_88(self):
        input="""float almost(string boo[], boolean str[])
        {
            if (ab)
                do 
                    putStringLn(1234);
                    getLn(1);
                    putIntLn(1234512);
                    removeFloat(123.548E-4);
                while (false);
            else
            {
                break;
            }
        }
        int a,b[34],c,e,f[5];
        string goo(){
            return;
            return "abcd";
            return 1 || e || 12.4e11 && (3 + (58 - 92)) % e12 >= 1;
        }"""
        expect = str(Program([FuncDecl(Id("almost"),[VarDecl("boo",ArrayPointerType(StringType())),VarDecl("str",ArrayPointerType(BoolType()))],FloatType(),Block([If(Id("ab"),Dowhile([CallExpr(Id("putStringLn"),[IntLiteral(1234)]),CallExpr(Id("getLn"),[IntLiteral(1)]),CallExpr(Id("putIntLn"),[IntLiteral(1234512)]),CallExpr(Id("removeFloat"),[FloatLiteral(0.0123548)])],BooleanLiteral(False)),Block([Break()]))])),VarDecl("a",IntType()),VarDecl("b",ArrayType(34,IntType())),VarDecl("c",IntType()),VarDecl("e",IntType()),VarDecl("f",ArrayType(5,IntType())),FuncDecl(Id("goo"),[],StringType(),Block([Return(),Return(StringLiteral("abcd")),Return(BinaryOp("||",BinaryOp("||",IntLiteral(1),Id("e")),BinaryOp("&&",FloatLiteral(1240000000000.0),BinaryOp(">=",BinaryOp("%",BinaryOp("+",IntLiteral(3),BinaryOp("-",IntLiteral(58),IntLiteral(92))),Id("e12")),IntLiteral(1)))))]))]))
        self.assertTrue(TestAST.checkASTGen(input,expect,388))

    def test_num_89(self):
        input="""void main()
        {
            if (everythingsfine)
                return 0;
            else 
            {
                do 
                    yourbest();
                while (youcan);
            }
            return 0;
        }
        float right,wrong,yes,no;
        string a,b,d,e;
        boolean c[123], e[45];
        void fooo(){
            for (a = 1; a > -5; a = a - 1)
            {
                if (a != isgood)
                {
                    continue;
                    {{}}
                }
                else
                    break;
                {{}}
            }
            a = a - 15;
            if (a >= -40)
                printf("Nice");
            else
                nothing;
        }"""
        expect = str(Program([FuncDecl(Id("main"),[],VoidType(),Block([If(Id("everythingsfine"),Return(IntLiteral(0)),Block([Dowhile([CallExpr(Id("yourbest"),[])],Id("youcan"))])),Return(IntLiteral(0))])),VarDecl("right",FloatType()),VarDecl("wrong",FloatType()),VarDecl("yes",FloatType()),VarDecl("no",FloatType()),VarDecl("a",StringType()),VarDecl("b",StringType()),VarDecl("d",StringType()),VarDecl("e",StringType()),VarDecl("c",ArrayType(123,BoolType())),VarDecl("e",ArrayType(45,BoolType())),FuncDecl(Id("fooo"),[],VoidType(),Block([For(BinaryOp("=",Id("a"),IntLiteral(1)),BinaryOp(">",Id("a"),UnaryOp("-",IntLiteral(5))),BinaryOp("=",Id("a"),BinaryOp("-",Id("a"),IntLiteral(1))),Block([If(BinaryOp("!=",Id("a"),Id("isgood")),Block([Continue(),Block([Block([])])]),Break()),Block([Block([])])])),BinaryOp("=",Id("a"),BinaryOp("-",Id("a"),IntLiteral(15))),If(BinaryOp(">=",Id("a"),UnaryOp("-",IntLiteral(40))),CallExpr(Id("printf"),[StringLiteral("Nice")]),Id("nothing"))]))]))
        self.assertTrue(TestAST.checkASTGen(input,expect,389))

    def test_num_90(self):
        input="""int i ;
        int f ( ) {
            return 200;
        }
        void main ( ) {
            int ain ;
            ain = f ( ) ;
            putIntLn (ain ) ;
            {
                int i ;
                int f ;
                ain = f = i = 100;
                putIntLn ( i ) ;
                putLn() ;
                putIntLn ( f ) ;
            }
            putIntLn (ain ) ;
        }"""
        expect = str(Program([VarDecl("i",IntType()),FuncDecl(Id("f"),[],IntType(),Block([Return(IntLiteral(200))])),FuncDecl(Id("main"),[],VoidType(),Block([VarDecl("ain",IntType()),BinaryOp("=",Id("ain"),CallExpr(Id("f"),[])),CallExpr(Id("putIntLn"),[Id("ain")]),Block([VarDecl("i",IntType()),VarDecl("f",IntType()),BinaryOp("=",Id("ain"),BinaryOp("=",Id("f"),BinaryOp("=",Id("i"),IntLiteral(100)))),CallExpr(Id("putIntLn"),[Id("i")]),CallExpr(Id("putLn"),[]),CallExpr(Id("putIntLn"),[Id("f")])]),CallExpr(Id("putIntLn"),[Id("ain")])]))]))
        self.assertTrue(TestAST.checkASTGen(input,expect,390))

    def test_num_91(self):
        input="""/* A lot of comments are comming up
        Twinkle, twinkle, little star
        How I wonder what you are
        Up above the world so high
        Like a diamond in the sky
        Twinkle, twinkle little star
        How I wonder what you are
        */ 
        int main(){
            /*
            When the blazing sun is gone
            When he nothing shines upon
            Then you show your little light
            Twinkle, twinkle, all the night
            Twinkle, twinkle, little star
            How I wonder what you are */
        }"""
        expect = str(Program([FuncDecl(Id("main"),[],IntType(),Block([]))]))
        self.assertTrue(TestAST.checkASTGen(input,expect,391))

    def test_num_92(self):
        input="""void printFibonacci(int n){    
            int n1,n2,n3;
            n1 = 0; n2 = 1;
            if(n>0){    
                n3 = n1 + n2;    
                n1 = n2;    
                n2 = n3;  
                printFibonacci(n-1);    
            }
        }    
        int main(){    
            int n;
            printFibonacci(n-2); //n-2 because 2 numbers are already printed
            return 0;
        }"""
        expect = str(Program([FuncDecl(Id("printFibonacci"),[VarDecl("n",IntType())],VoidType(),Block([VarDecl("n1",IntType()),VarDecl("n2",IntType()),VarDecl("n3",IntType()),BinaryOp("=",Id("n1"),IntLiteral(0)),BinaryOp("=",Id("n2"),IntLiteral(1)),If(BinaryOp(">",Id("n"),IntLiteral(0)),Block([BinaryOp("=",Id("n3"),BinaryOp("+",Id("n1"),Id("n2"))),BinaryOp("=",Id("n1"),Id("n2")),BinaryOp("=",Id("n2"),Id("n3")),CallExpr(Id("printFibonacci"),[BinaryOp("-",Id("n"),IntLiteral(1))])]))])),FuncDecl(Id("main"),[],IntType(),Block([VarDecl("n",IntType()),CallExpr(Id("printFibonacci"),[BinaryOp("-",Id("n"),IntLiteral(2))]),Return(IntLiteral(0))]))]))
        self.assertTrue(TestAST.checkASTGen(input,expect,392))

    def test_num_93(self):
        input="""//////////////////////////////////////////////////////
        float blee()
        {
            ////////////////////////////////////////////////////////////
            return 1;
        }
        //////////////////////////////////////////////
        """
        expect = str(Program([FuncDecl(Id("blee"),[],FloatType(),Block([Return(IntLiteral(1))]))]))
        self.assertTrue(TestAST.checkASTGen(input,expect,393))

    def test_num_94(self):
        input="""float main(){
            if (ab != 4) // Check on comments 1
                if (bc + 5 < 3) // Check on comments 2
                    if (cd > 9 - 4) // Check on comments....
                        return 5e3;
                    else  // COC ///////////////
                        return 4e9;
            else return 1;
        }"""
        expect = str(Program([FuncDecl(Id("main"),[],FloatType(),Block([If(BinaryOp("!=",Id("ab"),IntLiteral(4)),If(BinaryOp("<",BinaryOp("+",Id("bc"),IntLiteral(5)),IntLiteral(3)),If(BinaryOp(">",Id("cd"),BinaryOp("-",IntLiteral(9),IntLiteral(4))),Return(FloatLiteral(5000.0)),Return(FloatLiteral(4000000000.0))),Return(IntLiteral(1))))]))]))
        self.assertTrue(TestAST.checkASTGen(input,expect,394))

    def test_num_95(self):
        input="""int main()    
        {    
            int n,sum,m;
            sum = 0;           
            do
            /* More check on comments
            .
            .
            .
            .
            .
            .
            .
            .
            .
            */
                m=n%10;    
                sum=sum+m;    
                n=n/10;    
            while(n > 0);
            return 0;  
        } """
        expect = str(Program([FuncDecl(Id("main"),[],IntType(),Block([VarDecl("n",IntType()),VarDecl("sum",IntType()),VarDecl("m",IntType()),BinaryOp("=",Id("sum"),IntLiteral(0)),Dowhile([BinaryOp("=",Id("m"),BinaryOp("%",Id("n"),IntLiteral(10))),BinaryOp("=",Id("sum"),BinaryOp("+",Id("sum"),Id("m"))),BinaryOp("=",Id("n"),BinaryOp("/",Id("n"),IntLiteral(10)))],BinaryOp(">",Id("n"),IntLiteral(0))),Return(IntLiteral(0))]))]))
        self.assertTrue(TestAST.checkASTGen(input,expect,395))

    def test_num_96(self):
        input="""int main()
        {
            int n, i, flag;           
            for(i = 2; i <= n/2; i = i + 1)
            {
                // condition for i to be a prime number
                if (checkPrime(i) == 1)
                {
                    // condition for n-i to be a prime number
                    if (checkPrime(n-i) == 1)
                    {
                        // n = primeNumber1 + primeNumber2                        
                        flag = 1;
                    }
                }
            }
            if (flag == 0)                
            return 0;
        }
        // Function to check prime number
        int checkPrime(int n)
        {
            int i, isPrime;
            isPrime = 1;
            for(i = 2; i <= n/2; i = i + 1)
            {
                if(n % i == 0)
                {
                    isPrime = 0;
                    break;
                }  
            }
            return isPrime;
        }"""
        expect = str(Program([FuncDecl(Id("main"),[],IntType(),Block([VarDecl("n",IntType()),VarDecl("i",IntType()),VarDecl("flag",IntType()),For(BinaryOp("=",Id("i"),IntLiteral(2)),BinaryOp("<=",Id("i"),BinaryOp("/",Id("n"),IntLiteral(2))),BinaryOp("=",Id("i"),BinaryOp("+",Id("i"),IntLiteral(1))),Block([If(BinaryOp("==",CallExpr(Id("checkPrime"),[Id("i")]),IntLiteral(1)),Block([If(BinaryOp("==",CallExpr(Id("checkPrime"),[BinaryOp("-",Id("n"),Id("i"))]),IntLiteral(1)),Block([BinaryOp("=",Id("flag"),IntLiteral(1))]))]))])),If(BinaryOp("==",Id("flag"),IntLiteral(0)),Return(IntLiteral(0)))])),FuncDecl(Id("checkPrime"),[VarDecl("n",IntType())],IntType(),Block([VarDecl("i",IntType()),VarDecl("isPrime",IntType()),BinaryOp("=",Id("isPrime"),IntLiteral(1)),For(BinaryOp("=",Id("i"),IntLiteral(2)),BinaryOp("<=",Id("i"),BinaryOp("/",Id("n"),IntLiteral(2))),BinaryOp("=",Id("i"),BinaryOp("+",Id("i"),IntLiteral(1))),Block([If(BinaryOp("==",BinaryOp("%",Id("n"),Id("i")),IntLiteral(0)),Block([BinaryOp("=",Id("isPrime"),IntLiteral(0)),Break()]))])),Return(Id("isPrime"))]))]))
        self.assertTrue(TestAST.checkASTGen(input,expect,396))

    def test_num_97(self):
        input="""int main()
        {
            string s1[100], s2[100], i, j;            
            // calculate the length of string s1
            // and store it in i
            for(i = 0; s1[i] != "0"; i = i + 1) {}
            for(j = 0; s2[j] != "0"; j = j + 1)
            {
                s1[i] = s2[j];
            }
            s1[i] = "0";           
            return 0;
        }
        int blooo()
        {
            string s[1000];
            int i;          
            for(i = 0; s[i] != "0"; i = i + 1)
            {
                continue;
            }
            return 0;
        }"""
        expect = str(Program([FuncDecl(Id("main"),[],IntType(),Block([VarDecl("s1",ArrayType(100,StringType())),VarDecl("s2",ArrayType(100,StringType())),VarDecl("i",StringType()),VarDecl("j",StringType()),For(BinaryOp("=",Id("i"),IntLiteral(0)),BinaryOp("!=",ArrayCell(Id("s1"),Id("i")),StringLiteral("0")),BinaryOp("=",Id("i"),BinaryOp("+",Id("i"),IntLiteral(1))),Block([])),For(BinaryOp("=",Id("j"),IntLiteral(0)),BinaryOp("!=",ArrayCell(Id("s2"),Id("j")),StringLiteral("0")),BinaryOp("=",Id("j"),BinaryOp("+",Id("j"),IntLiteral(1))),Block([BinaryOp("=",ArrayCell(Id("s1"),Id("i")),ArrayCell(Id("s2"),Id("j")))])),BinaryOp("=",ArrayCell(Id("s1"),Id("i")),StringLiteral("0")),Return(IntLiteral(0))])),FuncDecl(Id("blooo"),[],IntType(),Block([VarDecl("s",ArrayType(1000,StringType())),VarDecl("i",IntType()),For(BinaryOp("=",Id("i"),IntLiteral(0)),BinaryOp("!=",ArrayCell(Id("s"),Id("i")),StringLiteral("0")),BinaryOp("=",Id("i"),BinaryOp("+",Id("i"),IntLiteral(1))),Block([Continue()])),Return(IntLiteral(0))]))]))
        self.assertTrue(TestAST.checkASTGen(input,expect,397))

    def test_num_98(self):
        input="""void foo(){
            do if (ab != bc)
                for (a = 0; a < "bc"; a + "d")
                    return;
            while (!false);
        } // Giving some comments
        int a,b[60],c[5];
        void goo(int abc[]){
            if (ab != -cd)
                do 
                    for (ab; ab; cd)
                        ab = cd + cda;
                while (a(a));
        } // More comments"""
        expect = str(Program([FuncDecl(Id("foo"),[],VoidType(),Block([Dowhile([If(BinaryOp("!=",Id("ab"),Id("bc")),For(BinaryOp("=",Id("a"),IntLiteral(0)),BinaryOp("<",Id("a"),StringLiteral("bc")),BinaryOp("+",Id("a"),StringLiteral("d")),Return()))],UnaryOp("!",BooleanLiteral(False)))])),VarDecl("a",IntType()),VarDecl("b",ArrayType(60,IntType())),VarDecl("c",ArrayType(5,IntType())),FuncDecl(Id("goo"),[VarDecl("abc",ArrayPointerType(IntType()))],VoidType(),Block([If(BinaryOp("!=",Id("ab"),UnaryOp("-",Id("cd"))),Dowhile([For(Id("ab"),Id("ab"),Id("cd"),BinaryOp("=",Id("ab"),BinaryOp("+",Id("cd"),Id("cda"))))],CallExpr(Id("a"),[Id("a")])))]))]))
        self.assertTrue(TestAST.checkASTGen(input,expect,398))

    def test_num_99(self):
        input="""float boo(){
            do
                do
                    do
                        do
                            do
                                do
                                    nothing();
                                while(1);
                            while(a + c - d % -bc / 2 * b);
                        while (b[5]);
                    while(-false);
                while(((((a >= b)))));
            while ((abc));
        }"""
        expect = str(Program([FuncDecl(Id("boo"),[],FloatType(),Block([Dowhile([Dowhile([Dowhile([Dowhile([Dowhile([Dowhile([CallExpr(Id("nothing"),[])],IntLiteral(1))],BinaryOp("-",BinaryOp("+",Id("a"),Id("c")),BinaryOp("*",BinaryOp("/",BinaryOp("%",Id("d"),UnaryOp("-",Id("bc"))),IntLiteral(2)),Id("b"))))],ArrayCell(Id("b"),IntLiteral(5)))],UnaryOp("-",BooleanLiteral(False)))],BinaryOp(">=",Id("a"),Id("b")))],Id("abc"))]))]))
        self.assertTrue(TestAST.checkASTGen(input,expect,399))

    def test_num_100(self):
        input="""void main(){
            int a,b[1000];

            if (a == 0)
                if (b[1] == 5)
                    if (b[5] == 15)
                        if (b[15] == 30)
                            do 
                                nothing();
                            while(1);
            return;
        }"""
        expect = str(Program([FuncDecl(Id("main"),[],VoidType(),Block([VarDecl("a",IntType()),VarDecl("b",ArrayType(1000,IntType())),If(BinaryOp("==",Id("a"),IntLiteral(0)),If(BinaryOp("==",ArrayCell(Id("b"),IntLiteral(1)),IntLiteral(5)),If(BinaryOp("==",ArrayCell(Id("b"),IntLiteral(5)),IntLiteral(15)),If(BinaryOp("==",ArrayCell(Id("b"),IntLiteral(15)),IntLiteral(30)),Dowhile([CallExpr(Id("nothing"),[])],IntLiteral(1)))))),Return()]))]))
        self.assertTrue(TestAST.checkASTGen(input,expect,400))

