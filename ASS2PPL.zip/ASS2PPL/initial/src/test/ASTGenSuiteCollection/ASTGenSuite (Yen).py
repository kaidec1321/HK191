#1714074
import unittest
from TestUtils import TestAST
from AST import *


class ASTGenSuite(unittest.TestCase):
    def test_1(self):

        input = """
            int main() {
         foo(foo());
         }
        """
        expect = str(
            Program([FuncDecl(Id("main"),[],IntType(),Block([CallExpr(Id("foo"),[CallExpr(Id("foo"),[])])]))])
        )
        self.assertTrue(TestAST.checkASTGen(input,expect,301))
    
    def test_2(self):
        input = """int main () {
                    putIntLn(4);
                }"""
        expect = str(
            Program([FuncDecl(Id("main"),[],IntType(),Block([CallExpr(Id("putIntLn"),[IntLiteral(4)])]))])
        )
        self.assertTrue(TestAST.checkASTGen(input,expect,302))
    
    def test_3(self):
        input = """int main() {}"""
        expect = str(
            Program([FuncDecl(Id("main"),[],IntType(),Block([]))])
        )
        self.assertTrue(TestAST.checkASTGen(input,expect,303))
    
    def test_4(self):
        input = """int ahihi;"""
        expect = str(
            Program([VarDecl("ahihi", IntType())])
        )
        self.assertTrue(TestAST.checkASTGen(input,expect,304))

    def test_5(self):
        input = """float a, b;"""
        expect = str(
            Program([VarDecl("a", FloatType()), VarDecl("b", FloatType())])
        )
        self.assertTrue(TestAST.checkASTGen(input,expect,305))

    def test_6(self):
        input = """int ahihi;
                          float ahaha;
                          string ahoho;
                          boolean ahehe;
                          """
        expect = str(
            Program([VarDecl("ahihi",IntType()),VarDecl("ahaha",FloatType()),VarDecl("ahoho",StringType()),VarDecl("ahehe",BoolType())])
        )
        self.assertTrue(TestAST.checkASTGen(input,expect,306))
    
    def test_7(self):
        input = """
                        int a, b;
                        float c,d;
                        string e;                      
                        boolean g;
                       """
        expect = str(
            Program([VarDecl("a",IntType()),VarDecl("b",IntType()),VarDecl("c",FloatType()),VarDecl("d",FloatType()),VarDecl("e",StringType()),VarDecl("g",BoolType())])
        )
        self.assertTrue(TestAST.checkASTGen(input,expect,307))
    
    def test_8(self):

        input = """int a;"""
        expect = str(
            Program([VarDecl("a", IntType())])
        )
        self.assertTrue(TestAST.checkASTGen(input,expect,308))
    
    def test_9(self):

        input = """float a;"""
        expect = str(
            Program([VarDecl("a",FloatType())])
        )
        self.assertTrue(TestAST.checkASTGen(input,expect,309))

    def test_10(self):
        input = """
                   float ahihi;
                        """
        expect = str(
            Program([VarDecl("ahihi",FloatType())])
        )
        self.assertTrue(TestAST.checkASTGen(input,expect,310))

    def test_11(self):

        input = """boolean ahihi[100];"""
        expect = str(
            Program([VarDecl("ahihi", ArrayType(100,BoolType()))])
        )
        self.assertTrue(TestAST.checkASTGen(input,expect,311))

    def test_12(self):
        input = """
                    int a[9];
                    """
        expect = str(
            Program([VarDecl("a", ArrayType(9,IntType(),))])
        )
        self.assertTrue(TestAST.checkASTGen(input,expect,312))
    
    def test_13(self):

        input = """
            float a[9];
        """
        expect = str(
            Program([VarDecl("a",ArrayType(9,FloatType()))])
        )
        self.assertTrue(TestAST.checkASTGen(input,expect,313))

    def test_14(self):

        input = """
        string a[9];
        """
        expect = str(

                Program([VarDecl("a", ArrayType(9,StringType()))])
        )
        self.assertTrue(TestAST.checkASTGen(input,expect,314))
    
    def test_15(self):

        input = """
        string ahi[7],aha,aho,ahu[3] ;
        void x(){
        int foo[3];               
               }
        
        """
        expect = str(
            Program([VarDecl("ahi", ArrayType(7,StringType())), VarDecl("aha", StringType()), VarDecl("aho", StringType()),
                     VarDecl("ahu", ArrayType(3,StringType())),
                     FuncDecl(Id("x"), [], VoidType(), Block([VarDecl("foo", ArrayType(3,IntType()))]))])
        )
        self.assertTrue(TestAST.checkASTGen(input,expect,315))
    
    def test_16(self):

        input = """
        void foo(int ahihi,float ahaha)
        {
          f[0]=(a!=b*9);
          return a=b;
        }
        
        """
        expect = str(
            Program([FuncDecl(Id("foo"), [VarDecl("ahihi", IntType()), VarDecl("ahaha", FloatType())], VoidType(),
                              Block([BinaryOp( "=", ArrayCell(Id("f"), IntLiteral(0)), BinaryOp( "!=", Id("a"), BinaryOp("*",
                                                                                                                 Id("b"),
                                                                                                                 IntLiteral(
                                                                                                                     9)))), Return(
            BinaryOp( "=", Id("a"), Id("b")))]))])

        )
        self.assertTrue(TestAST.checkASTGen(input,expect,316))

    def test_17(self):

        input = """
         string foo(int z,int x)
        {
          if(a<=b){
           ahihi[100]=(a>=b);
           break;
          }

        }
        
        """
        expect = str(
            Program([FuncDecl(Id("foo"), [VarDecl("z", IntType()), VarDecl("x", IntType())], StringType(),
                              Block([If(BinaryOp( "<=", Id("a"), Id("b")), Block([BinaryOp( "=", ArrayCell(Id("ahihi"),
                                                                                                   IntLiteral(
                                                                                                       100)), BinaryOp( ">=", Id(
            "a"), Id("b"))), Break()]))]))])
        )
        self.assertTrue(TestAST.checkASTGen(input,expect,317))
    
    def test_18(self):

        input = """
        int main()
        {
          if(ac>bc){           
           break;
          }       

        }
        
        """
        expect = str(
            Program([FuncDecl(Id("main"),[],IntType(),Block([If(BinaryOp(">",Id("ac"),Id("bc")),Block([Break()]))]))])
        )
        self.assertTrue(TestAST.checkASTGen(input,expect,318))
    
    def test_19(self):

        input = """
        int main() 
       { 
         int ahihi , ahaha;
         ahi=11;         
         aho=foo(ahah, ahi);      
         return;   
       }
        
        """
        expect = str(

                Program([FuncDecl(Id("main"), [], IntType(),
                                  Block([VarDecl("ahihi", IntType()), VarDecl("ahaha", IntType()), BinaryOp( "=", Id(
            "ahi"), IntLiteral(11)), BinaryOp( "=", Id("aho"), CallExpr(Id("foo"), [Id("ahah"), Id("ahi")])), Return()]))])
        )
        self.assertTrue(TestAST.checkASTGen(input,expect,319))

    def test_20(self):

        input = """
        int main() 
       { 
         int ahihi , ahaha;
         ahi=11;
         aha=22;           
         int aho ;
         aho=foo(ahah, ahi);      
         return;   
       }
        
        """
        expect = str(
            Program([FuncDecl(Id("main"), [], IntType(),
                              Block([VarDecl("ahihi", IntType()), VarDecl("ahaha", IntType()), BinaryOp( "=", Id("ahi"), IntLiteral(
            11)), BinaryOp( "=", Id("aha"), IntLiteral(22)), VarDecl("aho", IntType()), BinaryOp( "=", Id("aho"), CallExpr(Id("foo"),
                                                                                                               [Id(
                                                                                                                   "ahah"),
                                                                                                                Id(
                                                                                                                    "ahi")])), Return()]))])
        )
        self.assertTrue(TestAST.checkASTGen(input,expect,320))
    
    def test_21(self):

        input = """
        void foo() 
          { 
          int a ; 
          int b ;
          int c;
          }
        
        """
        expect = str(
            Program([FuncDecl(Id("foo"), [], VoidType(),
                              Block([VarDecl("a", IntType()), VarDecl("b", IntType()), VarDecl("c", IntType())]))])
        )
        self.assertTrue(TestAST.checkASTGen(input,expect,321))
    
    def test_22(self):

        input = """
        void foo() 
          { 
          float a ; 
          float b ;
          int c;
          }
        
        """
        expect = str(
            Program([FuncDecl(Id("foo"), [], VoidType(),
                              Block([VarDecl("a", FloatType()), VarDecl("b", FloatType()), VarDecl("c", IntType())]))])
        )
        self.assertTrue(TestAST.checkASTGen(input,expect,322))

    def test_23(self):

        input = """
        void foo() 
          { 
          string a ; 
         
          int c;
          }
        
        """
        expect = str(
            Program([FuncDecl(Id("foo"), [], VoidType(), Block([VarDecl("a", StringType()),  VarDecl("c", IntType())]))])
        )
        self.assertTrue(TestAST.checkASTGen(input,expect,323))
    
    def test_24(self):

        input = """
        void foo() 
          { 
          
          float b ;
          float c;
          }
        
        """
        expect = str(
            Program([FuncDecl(Id("foo"), [], VoidType(), Block([VarDecl("b", FloatType()), VarDecl("c", FloatType())]))])
        )
        self.assertTrue(TestAST.checkASTGen(input,expect,324))
    
    def test_25(self):

        input = """
        void main() 
          {
           string ahaha;           
          } 
        
        """
        expect = str(
            Program([FuncDecl(Id("main"), [], VoidType(), Block([VarDecl("ahaha", StringType())]))])
        )
        self.assertTrue(TestAST.checkASTGen(input,expect,325))
    
    def test_26(self):

        input = """
         void  foo(float ahaha) 
          {
           int a;        
          }
        """
        expect = str(
            Program([FuncDecl(Id("foo"), [VarDecl("ahaha", FloatType())], VoidType(), Block([VarDecl("a", IntType())]))])
        )
        self.assertTrue(TestAST.checkASTGen(input,expect,326))

    def test_27(self):

        input = """
        float  foo(float ahaha)
        {
        }
        """
        expect = str(
            Program([FuncDecl(Id("foo"),[VarDecl("ahaha",FloatType())],FloatType(),Block([]))])
        )
        self.assertTrue(TestAST.checkASTGen(input,expect,327))

    def test_28(self):

        input = """
        void  foo(int ahaha)
        {
         string a;
        }
        """
        expect = str(
            Program([FuncDecl(Id("foo"), [VarDecl("ahaha", IntType())], VoidType(), Block([VarDecl("a", StringType())]))])
        )
        self.assertTrue(TestAST.checkASTGen(input,expect,328))
    
    def test_29(self):

        input = """
        float ahaha[99];
        
        """
        expect = str(
            Program([VarDecl("ahaha", ArrayType(99,FloatType()))])
        )
        self.assertTrue(TestAST.checkASTGen(input,expect,329))
    
    def test_30(self):

        input = """
        string ahaha[99];
        """
        expect = str(
            Program([VarDecl("ahaha",ArrayType(99,StringType()))])
        )
        self.assertTrue(TestAST.checkASTGen(input,expect,330))
    
    def test_31(self):
        input = """int main() {
                float a;
                float b,c;
                z=x=y=100;
                }
                """
        expect = str(Program([FuncDecl(Id("main"), [], IntType(), Block(
            [VarDecl("a", FloatType()), VarDecl("b", FloatType()), VarDecl("c", FloatType()), BinaryOp("=",Id("z"),BinaryOp("=",Id("x"),BinaryOp("=",Id("y"),IntLiteral(100))))]))]))
    
    def test_32(self):
        input = """int main() {}
               string main() {}
               """
        expect = str(Program(
            [FuncDecl(Id("main"), [], IntType(), Block([])), FuncDecl(Id("main"), [], StringType(), Block([]))]))
        self.assertTrue(TestAST.checkASTGen(input,expect,332))
    
    def test_33(self):
        input = """
               int a,b,c,d[1];
               float e[6],f[4],g;
               """
        expect = str(Program([VarDecl("a", IntType()), VarDecl("b", IntType()), VarDecl("c", IntType()),
                              VarDecl("d", ArrayType(1, IntType())), VarDecl("e", ArrayType(6, FloatType())),
                              VarDecl("f", ArrayType(4, FloatType())), VarDecl("g", FloatType())]))

        self.assertTrue(TestAST.checkASTGen(input,expect,333))
    
    def test_34(self):
        input = """
                int a[1],b[2],c[3],d[4],e[5];
                    float f,g,h;
                    string i,j,f[99];
                    boolean l,m[1],n[2];
                """
        expect = str(Program([VarDecl("a", ArrayType(1, IntType())), VarDecl("b", ArrayType(2, IntType())),
                              VarDecl("c", ArrayType(3, IntType())), VarDecl("d", ArrayType(4, IntType())),
                              VarDecl("e", ArrayType(5, IntType())), VarDecl("f", FloatType()),
                              VarDecl("g", FloatType()), VarDecl("h", FloatType()), VarDecl("i", StringType()),
                              VarDecl("j", StringType()), VarDecl("f", ArrayType(99, StringType())),
                              VarDecl("l", BoolType()), VarDecl("m", ArrayType(1, BoolType())),
                              VarDecl("n", ArrayType(2, BoolType()))]))

        self.assertTrue(TestAST.checkASTGen(input,expect,334))
    
    def test_35(self):
        input = """
                        int a,b,c,d[99];
                        int arr;
                        """
        expect = str(Program([VarDecl("a", IntType()), VarDecl("b", IntType()), VarDecl("c", IntType()),
                              VarDecl("d", ArrayType(99, IntType())), VarDecl("arr", IntType())]))

        self.assertTrue(TestAST.checkASTGen(input,expect,335))
    
    def test_36(self):
        input = """int main() {}"""
        expect = str(Program([FuncDecl(Id("main"), [], IntType(), Block([]))]))
        self.assertTrue(TestAST.checkASTGen(input,expect,336))

    def test_37(self):
        input = """
                                int x,y,z,t[99];
                                int arr;
                                """
        expect = str(Program([VarDecl("x", IntType()), VarDecl("y", IntType()), VarDecl("z", IntType()),
                              VarDecl("t", ArrayType(99, IntType())), VarDecl("arr", IntType())]))
        self.assertTrue(TestAST.checkASTGen(input,expect,337))
    
    def test_38(self):
        input = """
                                int m,n,p,q[99];
                                int arr;
                                """
        expect = str(Program([VarDecl("m", IntType()), VarDecl("n", IntType()), VarDecl("p", IntType()),
                              VarDecl("q", ArrayType(99, IntType())), VarDecl("arr", IntType())]))
        self.assertTrue(TestAST.checkASTGen(input,expect,338))
    
    def test_39(self):
        input = """
                   int foo(int x,float y){}
               """
        expect = str(
            Program(
                [
                    FuncDecl(Id('foo'),
                             [
                                 VarDecl('x', IntType()),
                                 VarDecl('y', FloatType())
                             ],
                             IntType(),
                             Block(
                                 []
                             ))
                ])
        )
        self.assertTrue(TestAST.checkASTGen(input,expect,339))
    
    def test_40(self):
        input = """
                   string x,y,z,foo[99];
               """
        expect = str(
            Program(
                [
                    VarDecl('x', StringType()),
                    VarDecl('y', StringType()),
                    VarDecl('z', StringType()),
                    VarDecl('foo', ArrayType(99, StringType()))
                ])
        )
        self.assertTrue(TestAST.checkASTGen(input,expect,340))
    
    def test_41(self):
        input = """int main(){
                    if (x==y) 
                    y=z;
                    else z=t;
                }"""
        expect = str(Program([FuncDecl(Id('main'), [], IntType(), Block([If(BinaryOp('==', Id('x'), Id('y')),
                                                                            BinaryOp('=', Id('y'), Id('z')),
                                                                            BinaryOp('=', Id('z'), Id('t')))]))]))

        self.assertTrue(TestAST.checkASTGen(input,expect,341))
    
    def test_42(self):
        input = """int main(){
                   if (x<y) z;
               }"""
        expect = str(
            Program([FuncDecl(Id('main'), [], IntType(), Block([If(BinaryOp('<', Id('x'), Id('y')), Id('z'))]))]))
        self.assertTrue(TestAST.checkASTGen(input,expect,342))

    def test_43(self):
        input = """int foo(int  x[]){
                    if (x==y)
                        if (y=z)
                            if(z=99) z=t;
                            else t[yen+99];
                        else "yen"/99;
                    else yen=99/3;
                }"""
        expect = str(Program([FuncDecl(Id('foo'), [VarDecl('x', ArrayPointerType(IntType()))], IntType(), Block([If(
            BinaryOp('==', Id('x'), Id('y')), If(BinaryOp('=', Id('y'), Id('z')),
                                                 If(BinaryOp('=', Id('z'), IntLiteral(99)),
                                                    BinaryOp('=', Id('z'), Id('t')),
                                                    ArrayCell(Id('t'), BinaryOp('+', Id('yen'), IntLiteral(99)))),
                                                 BinaryOp('/', StringLiteral('yen'), IntLiteral(99))),
            BinaryOp('=', Id('yen'), BinaryOp('/', IntLiteral(99), IntLiteral(3))))]))]))

        self.assertTrue(TestAST.checkASTGen(input,expect,343))

    def test_44(self):
        input = """int main(){
                   do{
                       x=y;
                       y=z;
                   }
                   {
                       x=x+99;
                       x>99;
                   }
                   while x!=y;
               }"""
        expect = str(Program([FuncDecl(Id('main'), [], IntType(), Block([Dowhile(
            [Block([BinaryOp('=', Id('x'), Id('y')), BinaryOp('=', Id('y'), Id('z'))]), Block(
                [BinaryOp('=', Id('x'), BinaryOp('+', Id('x'), IntLiteral(99))),
                 BinaryOp('>', Id('x'), IntLiteral(99))])], BinaryOp('!=', Id('x'), Id('y')))]))]))

        self.assertTrue(TestAST.checkASTGen(input,expect,344))

    def test_45(self):
        input ="""int main(){
                    do x=99; while yen;
                }"""
        expect = str(Program([FuncDecl(Id('main'), [], IntType(),
                                       Block([Dowhile([BinaryOp('=', Id('x'), IntLiteral(99))], Id('yen'))]))]))
        self.assertTrue(TestAST.checkASTGen(input,expect,345))
    
    def test_46(self):
        input = """int main(){
                    do return; while yen;
                }"""
        expect = str(Program([FuncDecl(Id('main'), [], IntType(), Block([Dowhile([Return()], Id('yen'))]))]))
        self.assertTrue(TestAST.checkASTGen(input,expect,346))

    def test_47(self):
        input = """int main(){
                    do x;
                     while (x=99);
                }"""
        expect = str(Program(
            [FuncDecl(Id('main'), [], IntType(), Block([Dowhile([Id('x')], BinaryOp('=', Id('x'), IntLiteral(99)))]))]))
        self.assertTrue(TestAST.checkASTGen(input,expect,347))
    
    def test_48(self):
        input = '''int main(){
                   for(i=0;i<99;i=i+1) if (x=y) x=y; else z;
               }'''
        expect = str(Program([FuncDecl(Id('main'), [], IntType(), Block([For(BinaryOp('=', Id('i'), IntLiteral(0)),
                                                                             BinaryOp('<', Id('i'), IntLiteral(99)),
                                                                             BinaryOp('=', Id('i'),
                                                                                      BinaryOp('+', Id('i'),
                                                                                               IntLiteral(1))),
                                                                             If(BinaryOp('=', Id('x'), Id('y')),
                                                                                BinaryOp('=', Id('x'), Id('y')),
                                                                                Id('z')))]))]))

        self.assertTrue(TestAST.checkASTGen(input,expect,348))

    def test_49(self):
        input = '''int main(){
                    for(a=0;a<99;a=a+1) a=b;
                }'''
        expect = str(Program([FuncDecl(Id('main'), [], IntType(), Block([For(BinaryOp('=', Id('a'), IntLiteral(0)),
                                                                             BinaryOp('<', Id('a'), IntLiteral(99)),
                                                                             BinaryOp('=', Id('a'),
                                                                                      BinaryOp('+', Id('a'),
                                                                                               IntLiteral(1))),
                                                                             BinaryOp('=', Id('a'), Id('b')))]))]))

        self.assertTrue(TestAST.checkASTGen(input,expect,349))
    
    def test_50(self):
        input = '''int main(){
                   break;
               }'''
        expect = str(Program([FuncDecl(Id('main'), [], IntType(), Block([Break()]))]))
        self.assertTrue(TestAST.checkASTGen(input,expect,350))
    
    def test_51(self):
        input = '''int main(){
                   break;
               }'''
        expect = str(Program([FuncDecl(Id('main'), [], IntType(), Block([Break()]))]))
        self.assertTrue(TestAST.checkASTGen(input,expect,351))
   
    def test_52(self):
        input = '''int main(){
                    continue;
                }'''
        expect = str(Program([FuncDecl(Id('main'), [], IntType(), Block([Continue()]))]))
        self.assertTrue(TestAST.checkASTGen(input,expect,352))
    
    def test_53(self):
        input = '''int main(){
                    return;
                }'''
        expect = str(Program([FuncDecl(Id('main'), [], IntType(), Block([Return()]))]))
        self.assertTrue(TestAST.checkASTGen(input,expect,353))
    
    def test_54(self):
        input = """int main(){
                            foo(99);
                        }"""
        expect = str(Program(
            [FuncDecl(Id('main'), [], IntType(), Block([CallExpr(Id('foo'), [IntLiteral(99)])]))]))

        self.assertTrue(TestAST.checkASTGen(input,expect,354))

    def test_55(self):
        input = """int main(){
                    foo(99,99);
                }"""
        expect = str(Program(
            [FuncDecl(Id('main'), [], IntType(), Block([CallExpr(Id('foo'), [IntLiteral(99), IntLiteral(99)])]))]))
        self.assertTrue(TestAST.checkASTGen(input,expect,355))
    
    def test_56(self):
        input = '''int main(){
                    do do do do do x; while x; while x; while x; while x; while x;
                }'''
        expect = str(Program([FuncDecl(Id('main'), [], IntType(), Block([Dowhile(
            [Dowhile([Dowhile([Dowhile([Dowhile([Id('x')], Id('x'))], Id('x'))], Id('x'))], Id('x'))], Id('x'))]))]))

        self.assertTrue(TestAST.checkASTGen(input,expect,356))
    
    def test_57(self):
        input = """

                   int main() {

                    for(i=0; i < n; i=i+1)

                        b = b*2;

                   }"""
        expect = str(Program([FuncDecl(Id('main'), [], IntType(), Block([For(BinaryOp('=', Id('i'), IntLiteral(0)),
                                                                             BinaryOp('<', Id('i'), Id('n')),
                                                                             BinaryOp('=', Id('i'),
                                                                                      BinaryOp('+', Id('i'),
                                                                                               IntLiteral(1))),
                                                                             BinaryOp('=', Id('b'),
                                                                                      BinaryOp('*', Id('b'),
                                                                                               IntLiteral(2))))]))]))

        self.assertTrue(TestAST.checkASTGen(input,expect,357))
    
    def test_58(self):
        input = """

                   int main() {

                    for(i=0; i < n; i=i+99)

                        b = b*99;

                   }"""
        expect = str(Program([FuncDecl(Id('main'), [], IntType(), Block([For(BinaryOp('=', Id('i'), IntLiteral(0)),
                                                                             BinaryOp('<', Id('i'), Id('n')),
                                                                             BinaryOp('=', Id('i'),
                                                                                      BinaryOp('+', Id('i'),
                                                                                               IntLiteral(99))),
                                                                             BinaryOp('=', Id('b'),
                                                                                      BinaryOp('*', Id('b'),
                                                                                               IntLiteral(99))))]))]))

        self.assertTrue(TestAST.checkASTGen(input,expect,358))
    
    def test_59(self):
        input = """

                   int main() {

                    break;



                   }"""
        expect = str(Program([FuncDecl(Id('main'), [], IntType(), Block([Break()]))]))
        self.assertTrue(TestAST.checkASTGen(input,expect,359))

    def test_60(self):
        input = """

                   int main() {

                    continue;



                   }"""
        expect = str(Program([FuncDecl(Id('main'), [], IntType(), Block([Continue()]))]))
        self.assertTrue(TestAST.checkASTGen(input,expect,360))
    
    def test_61(self):
        input = """

                  int main() {

                   return;



                  }"""
        expect = str(Program([FuncDecl(Id('main'), [], IntType(), Block([Return()]))]))
        self.assertTrue(TestAST.checkASTGen(input,expect,361))
   
    def test_62(self):
        input = """

                  int main() {

                   return(99);

                  }"""
        expect = str(Program([FuncDecl(Id('main'), [], IntType(), Block([Return(IntLiteral(99))]))]))
        self.assertTrue(TestAST.checkASTGen(input,expect,362))
    
    def test_63(self):
        input = """

                   int main() {

                       a = 9.2e10;

                   }"""
        expect = str(Program(
            [FuncDecl(Id('main'), [], IntType(), Block([BinaryOp('=', Id('a'), FloatLiteral(92000000000.0))]))]))
        self.assertTrue(TestAST.checkASTGen(input,expect,363))
    
    def test_64(self):
        """Simple program: int main() {} """
        input = """

                   int main() {

                       a = 9.2e-10;

                   }"""
        expect = str(
            Program([FuncDecl(Id('main'), [], IntType(), Block([BinaryOp('=', Id('a'), FloatLiteral(9.2e-10))]))]))
        self.assertTrue(TestAST.checkASTGen(input,expect,364))
    
    def test_65(self):
        input = """

                  int main() {

                      a = 9.87e2;

                  }"""
        expect = str(
            Program([FuncDecl(Id('main'), [], IntType(), Block([BinaryOp('=', Id('a'), FloatLiteral(987.0))]))]))
        self.assertTrue(TestAST.checkASTGen(input,expect,365))

    def test_66(self):
        input = """

                  int main() {

                      a = 9.87E2;

                  }"""
        expect = str(
            Program([FuncDecl(Id('main'), [], IntType(), Block([BinaryOp('=', Id('a'), FloatLiteral(987.0))]))]))
        self.assertTrue(TestAST.checkASTGen(input,expect,366))
    
    def test_67(self):
        input = """int main(){
                    int a,b;
                    a = 10;
                    return 99;
                    }
                    """
        expect = str(Program([FuncDecl(Id('main'), [], IntType(), Block(
            [VarDecl('a', IntType()), VarDecl('b', IntType()), BinaryOp('=', Id('a'), IntLiteral(10)),
             Return(IntLiteral(99))]))]))

        self.assertTrue(TestAST.checkASTGen(input,expect,367))

    def test_68(self):
        input = """int main() {
                    int a,b,c,d[10];
                    a = b*c;
                    foo(1)[9+x] = a[b[2]] + 3 ;

                    }"""
        expect = str(Program([FuncDecl(Id('main'), [], IntType(), Block(
            [VarDecl('a', IntType()), VarDecl('b', IntType()), VarDecl('c', IntType()),
             VarDecl('d', ArrayType(10, IntType())), BinaryOp('=', Id('a'), BinaryOp('*', Id('b'), Id('c'))),
             BinaryOp('=', ArrayCell(CallExpr(Id('foo'), [IntLiteral(1)]), BinaryOp('+', IntLiteral('9'), Id('x'))),
                      BinaryOp('+', ArrayCell(Id('a'), ArrayCell(Id('b'), IntLiteral(2))), IntLiteral(3)))]))]))

        self.assertTrue(TestAST.checkASTGen(input,expect,368))
    
    def test_69(self):
        input = """int main() {
                   for(i = 1; i <99; i = i +1)
                       if(i==99)
                       i = 1;

                   }"""
        expect = str(Program([FuncDecl(Id('main'), [], IntType(), Block([For(BinaryOp('=', Id('i'), IntLiteral(1)),
                                                                             BinaryOp('<', Id('i'), IntLiteral(99)),
                                                                             BinaryOp('=', Id('i'),
                                                                                      BinaryOp('+', Id('i'),
                                                                                               IntLiteral(1))),
                                                                             If(BinaryOp('==', Id('i'), IntLiteral(99)),
                                                                                BinaryOp('=', Id('i'),
                                                                                         IntLiteral(1))))]))]))

        self.assertTrue(TestAST.checkASTGen(input,expect,369))

    def test_70(self):
        input = """int main() {
                   do{
                   {
                   }
                   }while( a < 99);
                   }"""
        expect = str(Program([FuncDecl(Id('main'), [], IntType(),
                                       Block([Dowhile([Block([Block([])])], BinaryOp('<', Id('a'), IntLiteral(99)))]))]))
        self.assertTrue(TestAST.checkASTGen(input,expect,370))
    
    def test_71(self):
        input = """int main(){int x[20],y,z,t;}"""
        expect = str(Program([FuncDecl(Id("main"), [], IntType(), Block([VarDecl("x", ArrayType(
            20, IntType())), VarDecl("y", IntType()), VarDecl("z", IntType()), VarDecl("t", IntType())]))]))
        self.assertTrue(TestAST.checkASTGen(input,expect,371))

    def test_72(self):
        input = """int main(){int yen[12];}"""
        expect = str(Program([FuncDecl(Id("main"), [], IntType(), Block(
            [VarDecl("yen", ArrayType(12, IntType()))]))]))
        self.assertTrue(TestAST.checkASTGen(input,expect,372))

    def test_73(self):
        input = """
               int x; float y; string z; boolean t;
               """
        expect = str(Program(
            [VarDecl('x', IntType()), VarDecl('y', FloatType()), VarDecl('z', StringType()), VarDecl('t', BoolType())]))
        self.assertTrue(TestAST.checkASTGen(input,expect,373))

    def test_74(self):
        input = '''int getInt(){}
               void putInt(int i){}              
               void putFloat(float f){}              
               void putBoolLn(boolean b){}
               void putString(string s){}'''
        expect = str(Program([FuncDecl(Id('getInt'), [], IntType(), Block([])),
                              FuncDecl(Id('putInt'), [VarDecl('i', IntType())], VoidType(), Block([])),
                              FuncDecl(Id('putFloat'), [VarDecl('f', FloatType())], VoidType(), Block([])),
                              FuncDecl(Id('putBoolLn'), [VarDecl('b', BoolType())], VoidType(), Block([])),
                              FuncDecl(Id('putString'), [VarDecl('s', StringType())], VoidType(), Block([]))]))

        self.assertTrue(TestAST.checkASTGen(input,expect,374))

    def test_75(self):
        input = '''
               void putFloat(float f){}
               void putFloatLn(float f){}
               void putBool(boolean b){}
               void putBoolLn(boolean b){}
               void putString(string s){}'''
        expect = str(Program([
                              FuncDecl(Id('putFloat'), [VarDecl('f', FloatType())], VoidType(), Block([])),
                              FuncDecl(Id('putFloatLn'), [VarDecl('f', FloatType())], VoidType(), Block([])),
                              FuncDecl(Id('putBool'), [VarDecl('b', BoolType())], VoidType(), Block([])),
                              FuncDecl(Id('putBoolLn'), [VarDecl('b', BoolType())], VoidType(), Block([])),
                              FuncDecl(Id('putString'), [VarDecl('s', StringType())], VoidType(), Block([]))]))

        self.assertTrue(TestAST.checkASTGen(input,expect,375))

    def test_76(self):
        input = '''int getInt(){}
               void putInt(int i){}
               void putIntLn(int i){}
               float getFloat(){}
               '''
        expect = str(Program([FuncDecl(Id('getInt'), [], IntType(), Block([])),
                              FuncDecl(Id('putInt'), [VarDecl('i', IntType())], VoidType(), Block([])),
                              FuncDecl(Id('putIntLn'), [VarDecl('i', IntType())], VoidType(), Block([])),
                              FuncDecl(Id('getFloat'), [], FloatType(), Block([])),
                              ]))

        self.assertTrue(TestAST.checkASTGen(input,expect,376))

    def test_77(self):
        input = """
               int a; float b; string c; boolean d;
               """
        expect = str(Program(
            [VarDecl('a', IntType()), VarDecl('b', FloatType()), VarDecl('c', StringType()), VarDecl('d', BoolType())]))

        self.assertTrue(TestAST.checkASTGen(input,expect,377))
 
    def test_78(self):
        input = """int main(){ boolean checking; checking=true;}"""
        expect = str(Program([FuncDecl(Id("main"), [], IntType(), Block(
            [VarDecl("checking", BoolType()), BinaryOp("=", Id("checking"), BooleanLiteral(True))]))]))

        self.assertTrue(TestAST.checkASTGen(input,expect,378))

    def test_79(self):
        input = """int main(){ a = b!=c;}"""
        expect = str(Program(
            [FuncDecl(Id("main"), [], IntType(), Block([BinaryOp("=", Id("a"), BinaryOp("!=", Id("b"), Id("c")))]))]))
        self.assertTrue(TestAST.checkASTGen(input,expect,379))
    
    def test_80(self):
        input = """int main(){
                   boolean bool; boo[2]=false;
               }"""
        expect = str(Program([FuncDecl(Id("main"), [], IntType(), Block([VarDecl("bool", BoolType(
        )), BinaryOp("=", ArrayCell(Id("boo"), IntLiteral(2)), BooleanLiteral(False))]))]))
        self.assertTrue(TestAST.checkASTGen(input,expect,380))

    def test_81(self):
        input = """int a;
                    float bb;
                    string c;
                    int d[10];
                    void main(){
                        {

                        }
                        return;
                    }"""
        expect = str(Program([VarDecl("a", IntType()), VarDecl("bb", FloatType()), VarDecl("c", StringType()),
                              VarDecl("d", ArrayType(10, IntType())),
                              FuncDecl(Id("main"), [], VoidType(), Block([Block([]), Return()]))]))

        self.assertTrue(TestAST.checkASTGen(input,expect,381))
    
    def test_82(self):
        input = """void main(){
                        int a;
                        {a =1;}
                        if(a==2)
                            return;
                        else                
                            return;
                    }"""
        expect = str(Program([FuncDecl(Id("main"), [], VoidType(), Block([VarDecl("a", IntType()), Block(
            [BinaryOp("=", Id("a"), IntLiteral(1))]), If(BinaryOp("==", Id("a"), IntLiteral(2)), Return(),
                                                         Return())]))]))
        self.assertTrue(TestAST.checkASTGen(input,expect,382))
    
    def test_83(self):
        input = """
                    int foo(){int a;}
                """
        expect = str(
            Program(
                [
                    FuncDecl(Id('foo'),
                             [],
                             IntType(),
                             Block(
                                 [
                                     VarDecl('a', IntType())
                                 ]))
                ])
        )
        self.assertTrue(TestAST.checkASTGen(input,expect,383))

    def test_84(self):
        input = """
                    int[] foo(int a[]){
                        boolean a[5],b; 
                        float c;
                    }
                """
        expect = str(
            Program(
                [
                    FuncDecl(Id('foo'),
                             [
                                 VarDecl('a', ArrayPointerType(IntType()))
                             ],
                             ArrayPointerType(IntType()),
                             Block(
                                 [
                                     VarDecl('a', ArrayType(5, BoolType())),
                                     VarDecl('b', BoolType()),
                                     VarDecl('c', FloatType())
                                 ]
                             )
                             )
                ])
        )
        self.assertTrue(TestAST.checkASTGen(input,expect,384))
    
    def test_85(self):
        input = """
                    int[] foo(int a[]){
                        boolean a[5],b; 
                        float c;
                    }
                """
        expect = str(
            Program(
                [
                    FuncDecl(Id('foo'),
                             [
                                 VarDecl('a', ArrayPointerType(IntType()))
                             ],
                             ArrayPointerType(IntType()),
                             Block(
                                 [
                                     VarDecl('a', ArrayType(5, BoolType())),
                                     VarDecl('b', BoolType()),
                                     VarDecl('c', FloatType())
                                 ]
                             )
                             )
                ])
        )
        self.assertTrue(TestAST.checkASTGen(input,expect,385))
    
    def test_86(self):
        input = """
                    int foo(){
                        if (b>a)
                        {
                            x = y + 1;
                            y = 5 + 1;
                        }           
                        else 
                        {
                            x = y * 2;
                            y = 6 * 3;
                        }
                    }
                """
        expect = str(
            Program(
                [
                    FuncDecl(Id('foo'),
                             [],
                             IntType(),
                             Block(
                                 [
                                     If(
                                         BinaryOp('>', Id('b'), Id('a')),
                                         Block(
                                             [
                                                 BinaryOp('=', Id('x'), BinaryOp('+', Id('y'), IntLiteral(1))),
                                                 BinaryOp('=', Id('y'), BinaryOp('+', IntLiteral(5), IntLiteral(1)))
                                             ]),
                                         Block(
                                             [
                                                 BinaryOp('=', Id('x'), BinaryOp('*', Id('y'), IntLiteral(2))),
                                                 BinaryOp('=', Id('y'), BinaryOp('*', IntLiteral(6), IntLiteral(3)))
                                             ])
                                     )
                                 ]))
                ])
        )
        self.assertTrue(TestAST.checkASTGen(input,expect,386))

    def test_87(self):
        input = """void main() {if(true) print("hello"); else put(5);}"""
        expect = str(Program([FuncDecl(Id("main"),[],VoidType(),Block([If(BooleanLiteral("true"),CallExpr(Id("print"),[StringLiteral("hello")]),CallExpr(Id("put"),[IntLiteral(5)]))]))])       )
        self.assertTrue(TestAST.checkASTGen(input,expect,387))
    
    def test_88(self):
        input = """void main() {
                    boolean x;
                    int y;
                    x = true;
                    y = getInt();
                    if (y > 10)
                        if ( y > 15)
                            x = !x && (y>20);
                        else
                            x = x && (y >15 );
                    else x = x && (y > 7);
                    foo(x);
                }
                """
        expect = str(Program([FuncDecl(Id("main"), [], VoidType(), Block(
            [VarDecl("x", BoolType()), VarDecl("y", IntType()), BinaryOp("=", Id("x"), BooleanLiteral("true")),
             BinaryOp("=", Id("y"), CallExpr(Id("getInt"), [])), If(BinaryOp(">", Id("y"), IntLiteral(10)),
                                                                    If(BinaryOp(">", Id("y"), IntLiteral(15)),
                                                                       BinaryOp("=", Id("x"),
                                                                                BinaryOp("&&", UnaryOp("!", Id("x")),
                                                                                         BinaryOp(">", Id("y"),
                                                                                                  IntLiteral(20)))),
                                                                       BinaryOp("=", Id("x"), BinaryOp("&&", Id("x"),
                                                                                                       BinaryOp(">",
                                                                                                                Id("y"),
                                                                                                                IntLiteral(
                                                                                                                    15))))),
                                                                    BinaryOp("=", Id("x"), BinaryOp("&&", Id("x"),
                                                                                                    BinaryOp(">",
                                                                                                             Id("y"),
                                                                                                             IntLiteral(
                                                                                                                 7))))),
             CallExpr(Id("foo"), [Id("x")])]))]))

        self.assertTrue(TestAST.checkASTGen(input,expect,388))
    
    def test_89(self):
        input = """
                   int main() {
                        float a,b,c;
                       a <=1;
                       a+2= b || c;
                   }"""
        expect = str(Program([FuncDecl(Id("main"), [], IntType(), Block(
            [VarDecl("a", FloatType()), VarDecl("b", FloatType()), VarDecl("c", FloatType()),
             BinaryOp("<=", Id("a"), IntLiteral(1)),
             BinaryOp("=", BinaryOp("+", Id("a"), IntLiteral(2)), BinaryOp("||", Id("b"), Id("c")))]))]))

        self.assertTrue(TestAST.checkASTGen(input,expect,389))

    def test_90(self):
        input = """int i ;
                    int f() {
                        return 200;
                    }
                    """
        expect = str(
            Program([VarDecl("i", IntType()), FuncDecl(Id("f"), [], IntType(), Block([Return(IntLiteral(200))]))]))
        self.assertTrue(TestAST.checkASTGen(input,expect,390))
    
    def test_91(self):
        input = """int main() {
               if(x == 0) a = 0;
               if(true) b=5;
               if(a > 5) a = s = f; else x = 0; 
               }
               """
        expect = str(Program([FuncDecl(Id("main"), [], IntType(), Block(
            [If(BinaryOp("==", Id("x"), IntLiteral(0)), BinaryOp("=", Id("a"), IntLiteral(0))),
             If(BooleanLiteral("true"), BinaryOp("=", Id("b"), IntLiteral(5))),
             If(BinaryOp(">", Id("a"), IntLiteral(5)), BinaryOp("=", Id("a"), BinaryOp("=", Id("s"), Id("f"))),
                BinaryOp("=", Id("x"), IntLiteral(0)))]))]))

        self.assertTrue(TestAST.checkASTGen(input,expect,391))
    
    def test_92(self):
        input = """int main() {
                if(x = 5) 
                if (x == 6) 
                if (x != 7) 
                a = 0;
                else a=1;
                else a+2;
                }
                """
        expect = str(Program([FuncDecl(Id("main"), [], IntType(), Block([If(BinaryOp("=", Id("x"), IntLiteral(5)),
                                                                            If(BinaryOp("==", Id("x"), IntLiteral(6)),
                                                                               If(BinaryOp("!=", Id("x"),
                                                                                           IntLiteral(7)),
                                                                                  BinaryOp("=", Id("a"), IntLiteral(0))),
                                                                                  BinaryOp("=", Id("a"),
                                                                                           IntLiteral(1))),
                                                                               BinaryOp("+", Id("a"),
                                                                                        IntLiteral(2)))]))]))

        self.assertTrue(TestAST.checkASTGen(input,expect,392))

    def test_93(self):
        input = """boolean[] main(int a,float b[]){  
                do {for(i=1;a+3;foo(a[9]))
                    continue;
                break;
                } while(5E-1);
                }
                """
        expect = str(Program([FuncDecl(Id("main"),
                                       [VarDecl("a", IntType()), VarDecl("b", ArrayPointerType(FloatType()))],
                                       ArrayPointerType(BoolType()), Block([Dowhile([Block([For(
                BinaryOp("=", Id("i"), IntLiteral(1)), BinaryOp("+", Id("a"), IntLiteral(3)),
                CallExpr(Id("foo"), [ArrayCell(Id("a"), IntLiteral(9))]), Continue()), Break()])],
                                                                                    FloatLiteral(0.5))]))]))

        self.assertTrue(TestAST.checkASTGen(input,expect,393))

    def test_94(self):
        input = """void main(){
               do print("a",b=4,a[5]);
               while (true);

               }
                       """
        expect = str(Program([FuncDecl(Id("main"), [], VoidType(), Block([Dowhile([CallExpr(Id("print"),
                                                                                            [StringLiteral("a"),
                                                                                             BinaryOp("=", Id("b"),
                                                                                                      IntLiteral(4)),
                                                                                             ArrayCell(Id("a"),
                                                                                                       IntLiteral(
                                                                                                           5))])],
                                                                                  BooleanLiteral("true"))]))]))

        self.assertTrue(TestAST.checkASTGen(input,expect,394))

    def test_95(self):
        input = """int main() {}
                float func(int a){
                for(a=1;b=2;c=3) a=1;
                }
                """
        expect = str(Program([FuncDecl(Id("main"), [], IntType(), Block([])),
                              FuncDecl(Id("func"), [VarDecl("a", IntType())], FloatType(), Block([For(
                                  BinaryOp("=", Id("a"), IntLiteral(1)), BinaryOp("=", Id("b"), IntLiteral(2)),
                                  BinaryOp("=", Id("c"), IntLiteral(3)), BinaryOp("=", Id("a"), IntLiteral(1)))]))]))

        self.assertTrue(TestAST.checkASTGen(input,expect,395))

    def test_96(self):
        input = """int main() {}
                float func(int a){
                for(a=1;b=2;c=3) {a==3; int a; b=c=6<=a=1;}
                }
                """
        expect = str(Program([FuncDecl(Id("main"), [], IntType(), Block([])),
                              FuncDecl(Id("func"), [VarDecl("a", IntType())], FloatType(), Block([For(
                                  BinaryOp("=", Id("a"), IntLiteral(1)), BinaryOp("=", Id("b"), IntLiteral(2)),
                                  BinaryOp("=", Id("c"), IntLiteral(3)), Block(
                                      [BinaryOp("==", Id("a"), IntLiteral(3)), VarDecl("a", IntType()),
                                       BinaryOp("=", Id("b"), BinaryOp("=", Id("c"), BinaryOp("=", BinaryOp("<=",
                                                                                                            IntLiteral(
                                                                                                                6),
                                                                                                            Id("a")),
                                                                                              IntLiteral(1))))]))]))]))

        self.assertTrue(TestAST.checkASTGen(input,expect,396))
    
    def test_97(self):
        input = """int main() {}
               float func(int a){
               for(a=1;b=2;c=3) {a==3; int a; b=c=6<=a=1;}
               if(x=y) if(!r) {} (a==1);
               }
               """
        expect = str(Program([FuncDecl(Id("main"), [], IntType(), Block([])),
                              FuncDecl(Id("func"), [VarDecl("a", IntType())], FloatType(), Block([For(
                                  BinaryOp("=", Id("a"), IntLiteral(1)), BinaryOp("=", Id("b"), IntLiteral(2)),
                                  BinaryOp("=", Id("c"), IntLiteral(3)), Block(
                                      [BinaryOp("==", Id("a"), IntLiteral(3)), VarDecl("a", IntType()),
                                       BinaryOp("=", Id("b"), BinaryOp("=", Id("c"), BinaryOp("=", BinaryOp("<=",
                                                                                                            IntLiteral(
                                                                                                                6),
                                                                                                            Id("a")),
                                                                                              IntLiteral(1))))])), If(
                                  BinaryOp("=", Id("x"), Id("y")), If(UnaryOp("!", Id("r")), Block([]))), BinaryOp("==",
                                                                                                                   Id(
                                                                                                                       "a"),
                                                                                                                   IntLiteral(
                                                                                                                       1))]))]))

        self.assertTrue(TestAST.checkASTGen(input,expect,397))
    
    def test_98(self):
        input = """
               int main() {
                   int i,j;
                   for(i=0; i<=10 ; i=i+1)
                       if (i%2 == 0) break; else continue;
               }"""
        expect = str(Program([FuncDecl(Id("main"), [], IntType(), Block(
            [VarDecl("i", IntType()), VarDecl("j", IntType()),
             For(BinaryOp("=", Id("i"), IntLiteral(0)), BinaryOp("<=", Id("i"), IntLiteral(10)),
                 BinaryOp("=", Id("i"), BinaryOp("+", Id("i"), IntLiteral(1))),
                 If(BinaryOp("==", BinaryOp("%", Id("i"), IntLiteral(2)), IntLiteral(0)), Break(), Continue()))]))]))
        self.assertTrue(TestAST.checkASTGen(input, expect, 357))
        self.assertTrue(TestAST.checkASTGen(input,expect,398))

    def test_99(self):
        input = """
               int main() {
                   set(doc);

                   return 0;
               }
               int func(){ 
                   int a;
                   a = main();
                   }
               """
        expect = str(Program(
            [FuncDecl(Id("main"), [], IntType(), Block([CallExpr(Id("set"), [Id("doc")]), Return(IntLiteral(0))])),
             FuncDecl(Id("func"), [], IntType(),
                      Block([VarDecl("a", IntType()), BinaryOp("=", Id("a"), CallExpr(Id("main"), []))]))]))

        self.assertTrue(TestAST.checkASTGen(input,expect,399))
    
    def test_100(self):
        input = """boolean[] func() {
                foo(foo(5));
                temp(temp());}"""
        expect = str(Program([FuncDecl(Id("func"), [], ArrayPointerType(BoolType()), Block(
            [CallExpr(Id("foo"), [CallExpr(Id("foo"), [IntLiteral(5)])]),
             CallExpr(Id("temp"), [CallExpr(Id("temp"), [])])]))]))

        self.assertTrue(TestAST.checkASTGen(input,expect,400))
