#MSSV: 1710214
#Ten: Cao Thanh Nhan
import sys
sys.setrecursionlimit(10**6)
from MCVisitor import MCVisitor
from MCParser import MCParser
from AST import *

class ASTGeneration(MCVisitor):
    def visitProgram(self,ctx:MCParser.ProgramContext):
        return Program(self.visit(ctx.manydecls()))
    
    def visitManydecls(self, ctx:MCParser.ManydeclsContext):
        temp = [self.visit(x) for x in ctx.getChildren()]
        lst = []
        for x in temp:
            if isinstance(x, list):
                lst += x
            else:
                lst.append(x)
        return lst

    def visitVardecl(self,ctx:MCParser.VardeclContext):
        if ctx.getChildCount() == 3:
            return self.visit(ctx.var(0))(self.visit(ctx.primtype()))
        else:
            return [self.visit(x)(self.visit(ctx.primtype())) for x in ctx.var()]
 
    def visitPrimtype(self,ctx:MCParser.PrimtypeContext):
        if ctx.INTTYPE():
            return IntType()
        if ctx.FLOATTYPE():
            return FloatType()
        if ctx.BOOLTYPE():
            return BoolType()
        else:
            return StringType()

    def visitVar(self,ctx:MCParser.VarContext):
        if ctx.getChildCount() == 1:
            return lambda x: VarDecl(ctx.ID().getText(), x)  
        else:
            return lambda x: VarDecl(ctx.ID().getText(), ArrayType(int(ctx.INTLIT().getText()), x))

    def visitFundecl(self,ctx:MCParser.FundeclContext):
        return FuncDecl(Id(ctx.ID().getText()), self.visit(ctx.paralist()), self.visit(ctx.typ()), self.visit(ctx.block_stmt()))

    def visitTyp(self,ctx:MCParser.TypContext):
        if ctx.primtype():
            return self.visit(ctx.primtype())
        if ctx.arrp_type():
            return self.visit(ctx.arrp_type())
        else:
            return VoidType()
    
    def visitArrp_type(self,ctx:MCParser.Arrp_typeContext):
        return ArrayPointerType(self.visit(ctx.primtype()))

    def visitParalist(self,ctx:MCParser.ParalistContext):
        return self.visit(ctx.paradecls())

    def visitParadecls(self,ctx:MCParser.ParadeclsContext):
        return [self.visit(x) for x in ctx.paradecl()]

    def visitParadecl(self,ctx:MCParser.ParadeclContext):
        if ctx.getChildCount() == 2:
            return VarDecl(ctx.ID().getText(), self.visit(ctx.primtype()))
        else:
            return VarDecl(ctx.ID().getText(), ArrayPointerType(self.visit(ctx.primtype())))

    def visitStmt(self,ctx:MCParser.StmtContext):
        if ctx.if_stmt():
            return self.visit(ctx.if_stmt())
        if ctx.for_stmt():
            return self.visit(ctx.for_stmt())
        if ctx.dowhile_stmt():
            return self.visit(ctx.dowhile_stmt())
        if ctx.break_stmt():
            return self.visit(ctx.break_stmt())
        if ctx.continue_stmt():
            return self.visit(ctx.continue_stmt())
        if ctx.return_stmt():
            return self.visit(ctx.return_stmt())
        if ctx.exp():
            return self.visit(ctx.exp())
        else:
            return self.visit(ctx.block_stmt())
    
    def visitIf_stmt(self,ctx:MCParser.If_stmtContext):
        if ctx.ELSE():
            return If(self.visit(ctx.exp()), self.visit(ctx.stmt(0)), self.visit(ctx.stmt(1)))
        else:
            return If(self.visit(ctx.exp()), self.visit(ctx.stmt(0)))

    def visitDowhile_stmt(self,ctx:MCParser.Dowhile_stmtContext):
        return Dowhile([self.visit(x) for x in ctx.stmt()], self.visit(ctx.exp()))

    def visitFor_stmt(self,ctx:MCParser.For_stmtContext):
        return For(self.visit(ctx.exp(0)), self.visit(ctx.exp(1)), self.visit(ctx.exp(2)), self.visit(ctx.stmt()))

    def visitBreak_stmt(self,ctx:MCParser.Break_stmtContext):
        return Break()

    def visitContinue_stmt(self,ctx:MCParser.Continue_stmtContext):
        return Continue()

    def visitReturn_stmt(self,ctx:MCParser.Return_stmtContext):
        if ctx.getChildCount() == 2:
            return Return()
        else:
            return Return(self.visit(ctx.exp()))
    
    def visitBlock_stmt(self,ctx:MCParser.Block_stmtContext):
        return Block(self.visit(ctx.vardecl_stmtlist()))

    def visitVardecl_stmtlist(self,ctx:MCParser.Vardecl_stmtlistContext):
        temp = [self.visit(x) for x in ctx.vardecl_stmt()]
        lst = []
        for x in temp:
            if isinstance(x, list):
                lst += x
            else:
                lst.append(x)
        return lst

    def visitVardecl_stmt(self,ctx:MCParser.Vardecl_stmtContext):
        return self.visit(ctx.vardecl()) if ctx.vardecl() else self.visit(ctx.stmt())

    def visitExp(self,ctx:MCParser.ExpContext):
        return BinaryOp(ctx.ASSIGN().getText(), self.visit(ctx.exp1()), self.visit(ctx.exp())) if ctx.getChildCount() == 3 else self.visit(ctx.exp1())

    def visitExp1(self,ctx:MCParser.Exp1Context):
        return BinaryOp(ctx.OR().getText(), self.visit(ctx.exp1()), self.visit(ctx.exp2())) if ctx.getChildCount() == 3 else self.visit(ctx.exp2())

    def visitExp2(self,ctx:MCParser.Exp2Context):
        return BinaryOp(ctx.AND().getText(), self.visit(ctx.exp2()), self.visit(ctx.exp3())) if ctx.getChildCount() == 3 else self.visit(ctx.exp3())

    def visitExp3(self,ctx:MCParser.Exp3Context):
        return BinaryOp(ctx.getChild(1).getText(), self.visit(ctx.exp4(0)), self.visit(ctx.exp4(1))) if ctx.getChildCount() == 3 else self.visit(ctx.exp4(0))

    def visitExp4(self,ctx:MCParser.Exp4Context):
        return BinaryOp(ctx.getChild(1).getText(), self.visit(ctx.exp5(0)), self.visit(ctx.exp5(1))) if ctx.getChildCount() == 3 else self.visit(ctx.exp5(0))

    def visitExp5(self,ctx:MCParser.Exp5Context):
        return BinaryOp(ctx.getChild(1).getText(), self.visit(ctx.exp5()), self.visit(ctx.exp6())) if ctx.getChildCount() == 3 else self.visit(ctx.exp6())

    def visitExp6(self,ctx:MCParser.Exp6Context):
        return BinaryOp(ctx.getChild(1).getText(), self.visit(ctx.exp6()), self.visit(ctx.exp7())) if ctx.getChildCount() == 3 else self.visit(ctx.exp7())

    def visitExp7(self,ctx:MCParser.Exp7Context):
        return UnaryOp(ctx.getChild(0).getText(), self.visit(ctx.exp7())) if ctx.getChildCount() == 2 else self.visit(ctx.exp8())

    def visitExp8(self,ctx:MCParser.Exp8Context):
        return ArrayCell(self.visit(ctx.operand()), self.visit(ctx.exp())) if ctx.getChildCount() == 4 else self.visit(ctx.operand())

    def visitOperand(self,ctx:MCParser.OperandContext):
        if ctx.exp():
            return self.visit(ctx.exp())
        if ctx.funcall():
            return self.visit(ctx.funcall())
        if ctx.INTLIT():
            return IntLiteral(int(ctx.INTLIT().getText()))
        if ctx.FLOATLIT():
            return FloatLiteral(float(ctx.FLOATLIT().getText()))
        if ctx.BOOLLIT():
            return BooleanLiteral(ctx.BOOLLIT().getText() == 'true')
        if ctx.STRINGLIT():
            return StringLiteral(ctx.STRINGLIT().getText())
        else:
            return Id(ctx.ID().getText())
    
    def visitFuncall(self,ctx:MCParser.FuncallContext):
        return CallExpr(Id(ctx.ID().getText()), self.visit(ctx.explist()))

    def visitExplist(self,ctx:MCParser.ExplistContext):
        return [self.visit(x) for x in ctx.exp()]

        
