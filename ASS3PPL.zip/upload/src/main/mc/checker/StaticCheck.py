
"""
 * Cao Thanh Nhan
 * MSSV: 1710214
"""
from AST import * 
from functools import *
from Visitor import *
from Utils import Utils
from StaticError import *

def flatten(lst):
    return [x for y in lst for x in y]

class MType:
    def __init__(self,partype,rettype):
        self.partype = partype
        self.rettype = rettype

class Symbol:
    def __init__(self, name, mtype, fret = False, fcall = False, value = None):
        self.name = name
        self.mtype = mtype
        self.fret = fret
        self.value = value
        self.fcall = fcall

class StaticChecker(BaseVisitor,Utils):

    global_envi = [
    Symbol("getInt",MType([],IntType()), True, True),
    Symbol("putInt",MType([IntType()],VoidType()), True, True),
    Symbol("putIntLn",MType([IntType()],VoidType()), True, True),
    Symbol("getFloat",MType([],FloatType()), True, True),
    Symbol("putFloat",MType([FloatType()],VoidType()), True, True),
    Symbol("putFloatLn",MType([FloatType()],VoidType()), True, True),
    Symbol("putBool",MType([BoolType()],VoidType()), True, True),
    Symbol("putBoolLn",MType([BoolType()],VoidType()), True, True),
    Symbol("putString",MType([StringType()],VoidType()), True, True),
    Symbol("putStringLn",MType([StringType()],VoidType()), True, True),
    Symbol("putLn",MType([],VoidType()), True, True)
    ]
    
    def __init__(self,ast):
        self.ast = ast

    
    def check(self):
        return self.visit(self.ast, StaticChecker.global_envi)

    def visitProgram(self, ast, c):
        global checkGlobal
        checkGlobal = True
        glo = reduce(lambda x, y: [self.visit(y, x) + x[0]], ast.decl, [c])
        checkGlobal = False

        funclist = list(filter(lambda x: isinstance(x, FuncDecl), ast.decl))
        res = self.lookup("main", funclist, lambda x: x.name.name)
        if res is None:
            raise NoEntryPoint()
        
        global inLoop
        inLoop = 0
        for x in funclist:
            self.visit(x, glo)
        # map(lambda x: self.visit(x, glo), funclist)
        
        funcheck = list(filter(lambda x: isinstance(x.mtype, MType), glo[0]))
        for x in funcheck:
            if x.name != "main" and not x.fcall:
                raise UnreachableFunction(x.name)

    def visitVarDecl(self, ast, c):
        res = self.lookup(ast.variable, c[0], lambda x: x.name)
        if res is None:
            return [Symbol(ast.variable, ast.varType)]
        else:
            raise Redeclared(Variable(), ast.variable)

    def visitFuncDecl(self, ast, c): 
        if checkGlobal:
            res = self.lookup(ast.name.name, c[0], lambda x: x.name)
            if not res is None:
                raise Redeclared(Function(), ast.name.name)
            try:
                local = reduce(lambda x, y: [x[0] + self.visit(y, x)], ast.param, [[]])[0]
            except Redeclared as e:
                raise Redeclared(Parameter(), e.n)
            Mtype = MType([x.mtype for x in local], ast.returnType)
            func = Symbol(ast.name.name, Mtype)
            if isinstance(ast.returnType, VoidType):
                func.fret = True
            return [func]
        else:
            global pos
            pos = 0
            temp = c[0]
            for x in range(len(temp)):
                if ast.name.name == temp[x].name:
                    temp.insert(0, temp.pop(x))
            local = reduce(lambda x, y: [x[0] + self.visit(y, x)], ast.param, [[]])[0]
            decllst = reduce(lambda x, y: [self.visitMember(y, x) + x[0], temp], ast.body.member, [local, temp])
            if decllst[1][0].fret == False:
                raise FunctionNotReturn(ast.name.name)
            

    def visitMember(self, ast, c):
        res = self.visit(ast, c)
        return res if isinstance(ast, VarDecl) else []

    def visitIf(self, ast, c):
        cond = self.visit(ast.expr, c)
        notRet = True
        if c[1][pos].fret:
            notRet = False
        if not isinstance(cond, BoolType):
            raise TypeMismatchInStatement(ast)
        self.visit(ast.thenStmt, c)
        if ast.elseStmt is None:
            if notRet:
                c[1][pos].fret = False
        else:
            afterIf = c[1][pos].fret
            c[1][pos].fret = False
            self.visit(ast.elseStmt, c)
            if (notRet and afterIf and c[1][pos].fret) or not notRet:
                c[1][pos].fret = True
            elif notRet:
                c[1][pos].fret = False

    def visitFor(self, ast, c):
        cond1 = self.visit(ast.expr1, c)
        cond2 = self.visit(ast.expr2, c)
        cond3 = self.visit(ast.expr3, c)
        if not (isinstance(cond1, IntType) and isinstance(cond2, BoolType) and isinstance(cond3, IntType)):
            raise TypeMismatchInStatement(ast)
        flag = c[1][pos].fret
        global inLoop
        inLoop += 1
        self.visit(ast.loop, c)
        if not flag:
            c[1][pos].fret = flag
        inLoop -= 1

    def visitDowhile(self, ast, c):
        cond = self.visit(ast.exp, c)
        if not isinstance(cond, BoolType):
            raise TypeMismatchInStatement(ast)
        global inLoop
        inLoop += 1
        for x in ast.sl:
            self.visit(x, c)
        # map(lambda x: self.visit(x, c), ast.sl)
        inLoop -= 1

    def visitBreak(self, ast, c):
        global inLoop
        if inLoop == 0:
            raise BreakNotInLoop()

    def visitContinue(self, ast, c):
        global inLoop
        if inLoop == 0:
            raise ContinueNotInLoop()

    def visitBlock(self, ast, c):
        envi = flatten(c)
        global pos
        pos += len(c[0])
        local = []
        temp = reduce(lambda x, y: [self.visitMember(y, x) + x[0], envi], ast.member, [local, envi])
        pos -= len(c[0])
        if temp[1][pos].fret:
            c[1][pos].fret = True
        

    def visitReturn(self, ast, c):
        func = c[1][pos]
        if isinstance(func.mtype.rettype, VoidType):
            if not ast.expr is None:
                raise TypeMismatchInStatement(ast)
            else:
                return
        elif ast.expr is None:
            raise TypeMismatchInStatement(ast)
        ret = self.visit(ast.expr, c)
        if isinstance(func.mtype.rettype, FloatType) and isinstance(ret, IntType):
            c[1][pos].fret = True
        elif isinstance(func.mtype.rettype, ArrayPointerType) and (isinstance(ret, ArrayType) or isinstance(ret, ArrayPointerType)):
            if type(func.mtype.rettype.eleType) is type(ret.eleType):
                c[1][pos].fret = True
            else:
                raise TypeMismatchInStatement(ast)
        elif type(ret) is type(func.mtype.rettype):
            c[1][pos].fret = True
        else:
            raise TypeMismatchInStatement(ast)

    def visitUnaryOp(self, ast, c):
        typ = self.visit(ast.body, c)
        if ast.op == '!':
            if not isinstance(typ, BoolType):
                raise TypeMismatchInExpression(ast)
            return typ
        if ast.op == '-':
            if not (isinstance(typ, IntType) or isinstance(typ, FloatType)):
                raise TypeMismatchInExpression(ast)
            return typ

    def visitBinaryOp(self, ast, c):
        left = self.visit(ast.left, c)
        right = self.visit(ast.right, c)
        if isinstance(left, Function) and isinstance(right, Function):
            raise TypeMismatchInExpression(ast)
        if ast.op == '%':
            if isinstance(left, IntType) and isinstance(right, IntType):
                return IntType()
            else:
                raise TypeMismatchInExpression(ast)
        if ast.op in ['+', '-', '*', '/']:
            if isinstance(left, IntType) and isinstance(right, IntType):
                return IntType()
            if (isinstance(left, IntType) or isinstance(left, FloatType)) and (isinstance(right, IntType) or isinstance(right, FloatType)):
                return FloatType()
            else:
                raise TypeMismatchInExpression(ast)
        if ast.op in ['<', '>', '<=', '>=']:
            if (isinstance(left, IntType) or isinstance(left, FloatType)) and (isinstance(right, IntType) or isinstance(right, FloatType)):
                return BoolType()
            else:
                raise TypeMismatchInExpression(ast)
        if ast.op in ['==', '!=']:
            if (isinstance(left, BoolType) and isinstance(right, BoolType)) or (isinstance(left, IntType) and isinstance(right, IntType)):
                return BoolType()
            else:
                raise TypeMismatchInExpression(ast)
        if ast.op in ['||', '&&']:
            if isinstance(left, BoolType) and isinstance(right, BoolType):
                return BoolType()
            else:
                raise TypeMismatchInExpression(ast)
        if ast.op == '=':
            if not (type(ast.left) is Id or type(ast.left) is ArrayCell):
                raise NotLeftValue(ast.left)
            if isinstance(left, FloatType) and isinstance(right, IntType):
                return FloatType()
            if type(left) is type(right) and not (isinstance(left, ArrayType) or isinstance(left, VoidType) or isinstance(left, ArrayPointerType)):
                return left
            else:
                raise TypeMismatchInExpression(ast)

    def visitArrayCell(self, ast, c):
        arr = self.visit(ast.arr, c)
        idx = self.visit(ast.idx, c)
        if isinstance(idx, IntType):
            if isinstance(arr, ArrayType):
                return arr.eleType
            if isinstance(arr, ArrayPointerType):
                return arr.eleType
        raise TypeMismatchInExpression(ast)

    def visitId(self, ast, c):
        res = self.lookup(ast.name, flatten(c), lambda x: x.name)
        if res is None:
            raise Undeclared(Identifier(), ast.name)
        if isinstance(res.mtype, MType):
            return Function()
        else:
            return res.mtype


    def visitCallExpr(self, ast, c):
        at = [self.visit(x, c) for x in ast.param]
        funclist = list(filter(lambda x: isinstance(x.mtype, MType), flatten(c)))
        res = self.lookup(ast.method.name, flatten(c), lambda x: x.name)
        if res is None:
            raise Undeclared(Function(), ast.method.name)
        if not isinstance(res.mtype, MType):
            raise TypeMismatchInExpression(ast)
        else:
            if len(res.mtype.partype) != len(at):
                raise TypeMismatchInExpression(ast)
            else: 
                if (res.name != funclist[0].name):
                    for x in range(len(c[1])):
                        if isinstance(c[1][x].mtype, MType) and c[1][x].name == ast.method.name:
                            c[1][x].fcall = True
                            break
                param = res.mtype.partype
                for x in range(len(at)):
                    if isinstance(param[x], ArrayPointerType) and (isinstance(at[x], ArrayType) or isinstance(at[x], ArrayPointerType)):
                        if not type(param[x].eleType) is type(at[x].eleType):
                            raise TypeMismatchInExpression(ast)
                    elif not ((type(at[x]) is type(param[x])) or (isinstance(param[x], FloatType) and isinstance(at[x], IntType))):
                        raise TypeMismatchInExpression(ast)
                return res.mtype.rettype

    def visitIntLiteral(self, ast, c): 
        return IntType()

    def visitFloatLiteral(self, ast, c):
        return FloatType()

    def visitBooleanLiteral(self, ast, c):
        return BoolType()

    def visitStringLiteral(self, ast, c):
        return StringType()
    

