import unittest
from TestUtils import TestChecker
from AST import *

class CheckSuite(unittest.TestCase):
    def test_simple_vardecl(self):
        """More complex program"""
        input = """
                int a;
                int main(){return 0;}
                """
        expect = ""
        self.assertTrue(TestChecker.test(input,expect,400))
    def test_simple_re_vardecl(self):
        """More complex program"""
        input = """
                int a;
                int a;
                int main(){}
                """
        expect = "Redeclared Variable: a"
        self.assertTrue(TestChecker.test(input,expect,401))
    def test_double_re_vardecl(self):
        input = """
                int a, a;
                int main(){}
                """
        expect = "Redeclared Variable: a"
        self.assertTrue(TestChecker.test(input,expect,402))
    def test_difference_type_re_vardecl(self):
        input = """
                float a, b;
                int b;
                int main(){}
                """
        expect = "Redeclared Variable: b"
        self.assertTrue(TestChecker.test(input,expect,403))
    def test_simple_funcdecl(self):
        input = """
                int main(){return 0;}
                """
        expect = ""
        self.assertTrue(TestChecker.test(input,expect,404))
    def test_funcdecl_with_param(self):
        input = """
                int main(int a){return 0;}
                """
        expect = ""
        self.assertTrue(TestChecker.test(input,expect,405))
    def test_funcdecl_with_re_param(self):
        input = """
                int main(int a, int a){}
                """
        expect = "Redeclared Parameter: a"
        self.assertTrue(TestChecker.test(input,expect,406))
    def test_funcdecl_with_re_param_double(self):
        input = """
                int main(int a, int b, float a){}
                """
        expect = "Redeclared Parameter: a"
        self.assertTrue(TestChecker.test(input,expect,407))
    def test_re_funcdecl(self):
        input = """
                int main(float b){return 0;}
                int main(int a){return 0;}
                """
        expect = "Redeclared Function: main"
        self.assertTrue(TestChecker.test(input,expect,408))
    def test_funcdecl_with_block(self):
        input = """
                int main(float b){
                    int c;
                    return 0;
                }
                """
        expect = ""
        self.assertTrue(TestChecker.test(input,expect,409))
    def test_funcdecl_redecl_block(self):
        input = """
                int main(float b){
                    int b;
                }
                """
        expect = "Redeclared Variable: b"
        self.assertTrue(TestChecker.test(input,expect,410))
    def test_funcdecl_and_vardecl_in_global(self):
        input = """
                string a;
                int main(float b){
                    return 0;
                }
                """
        expect = ""
        self.assertTrue(TestChecker.test(input,expect,411))
    def test_funcdecl_and_vardecl_in_global_same_variable_in_block(self):
        input = """
                string a;
                int main(float b){
                    int a;
                    return 0;
                }
                """
        expect = ""
        self.assertTrue(TestChecker.test(input,expect,412))
    def test_funcdecl_and_vardecl_in_global_same_variable_in_param(self):
        input = """
                string a;
                int main(float a){
                    int b;
                    return 0;
                }
                """
        expect = ""
        self.assertTrue(TestChecker.test(input,expect,413))
    def test_funcdecl_and_re_vardecl_in_global_same_variable_in_param(self):
        input = """
                string a;
                int main(float a){
                    int b;
                    return 0;
                }
                boolean a;
                """
        expect = "Redeclared Variable: a"
        self.assertTrue(TestChecker.test(input,expect,414))
    def test_funcdecl_as_vardecl(self):
        input = """
                string foo;
                int foo(float a){
                    int b;
                }
                """
        expect = "Redeclared Function: foo"
        self.assertTrue(TestChecker.test(input,expect,415))
    def test_vardecl_as_funcdecl(self):
        input = """
                int foo(float a){
                    int b;
                    return 0;
                }
                string foo;
                """
        expect = "Redeclared Variable: foo"
        self.assertTrue(TestChecker.test(input,expect,416))
    def test_undecl_in_funcdecl(self):
        input = """
                int main(int a){
                    int b;
                    c;
                    return 0;
                }
                """
        expect = "Undeclared Identifier: c"
        self.assertTrue(TestChecker.test(input,expect,417))
    def test_undecl_in_funcdecl_1(self):
        input = """
                int main(){
                    int a,b;
                    c;
                    return 0;
                }
                """
        expect = "Undeclared Identifier: c"
        self.assertTrue(TestChecker.test(input,expect,418))
    def test_undecl_in_second_funcdecl(self):
        input = """
                int a,b;
                int foo(){
                    a;
                    return 0;
                }
                float main(){
                    c;
                    return 0.5;
                }
                """
        expect = "Undeclared Identifier: c"
        self.assertTrue(TestChecker.test(input,expect,419))
    def test_undecl_in_second_funcdecl_same_param_in_first_func(self):
        input = """
                int a,b;
                int foo(int c){
                    a;
                    return 0;
                }
                float main(){
                    c;
                    return 0.5;
                }
                """
        expect = "Undeclared Identifier: c"
        self.assertTrue(TestChecker.test(input,expect,420))
    def test_decl_same_variable_in_global(self):
        input = """
                int a,b;
                int main(int c){
                    a;
                    return 0;
                }
                """
        expect = ""
        self.assertTrue(TestChecker.test(input,expect,421))
    def test_not_left_value(self):
        input = """
                boolean a,b;
                int main(float a){
                    a + b = 5;
                    return 0;
                }
                """
        expect = "Not Left Value: BinaryOp(+,Id(a),Id(b))"
        self.assertTrue(TestChecker.test(input,expect,422))
    def test_exp_int(self):
        input = """
                int a,b;
                int main(){
                    b = (a*6 + 5 * b) / 6;
                    return 0;
                }
                """
        expect = ""
        self.assertTrue(TestChecker.test(input,expect,423))
    def test_exp_string(self):
        input = """
                string a,b;
                int main(){
                    b = a + "abc" + b;
                    return 0;
                }
                """
        expect = "Type Mismatch In Expression: BinaryOp(+,BinaryOp(+,Id(a),StringLiteral(abc)),Id(b))"
        self.assertTrue(TestChecker.test(input,expect,424))
    def test_exp_float_with_all_int(self):
        input = """
                float a,b;
                int main(){
                    b = (6 + 5) / 6;
                    return 0;
                }
                """
        expect = ""
        self.assertTrue(TestChecker.test(input,expect,425))
    def test_exp_float_with_all_float(self):
        input = """
                float a,b;
                int main(){
                    b = (a * 6.5 + 9.5) / 14.5;
                    return 0;
                }
                """
        expect = ""
        self.assertTrue(TestChecker.test(input,expect,426))
    def test_exp_float_with_int_and_float(self):
        input = """
                float a,b;
                int main(){
                    b = (a * 6 + 9.5) / 14;
                    return 0;
                }
                """
        expect = ""
        self.assertTrue(TestChecker.test(input,expect,427))
    def test_typemismatch_exp_int_with_string(self):
        input = """
                int a,b;
                int main(){
                    b = a + "abc";
                    return 0;
                }
                """
        expect = "Type Mismatch In Expression: BinaryOp(+,Id(a),StringLiteral(abc))"
        self.assertTrue(TestChecker.test(input,expect,428))
    def test_typemismatch_exp_int_with_float(self):
        input = """
                int a,b;
                int main(){
                    b = a + 0.5;
                    return 0;
                }
                """
        expect = "Type Mismatch In Expression: BinaryOp(=,Id(b),BinaryOp(+,Id(a),FloatLiteral(0.5)))"
        self.assertTrue(TestChecker.test(input,expect,429))
    def test_typemismatch_exp_string_with_int(self):
        input = """
                string a,b;
                int main(){
                    b = a + 10;
                    return 0;
                }
                """
        expect = "Type Mismatch In Expression: BinaryOp(+,Id(a),IntLiteral(10))"
        self.assertTrue(TestChecker.test(input,expect,430))
    def test_typemismatch_exp_string_with_float(self):
        input = """
                string a,b;
                int main(){
                    b = a + 10.0;
                    return 0;
                }
                """
        expect = "Type Mismatch In Expression: BinaryOp(+,Id(a),FloatLiteral(10.0))"
        self.assertTrue(TestChecker.test(input,expect,431))
    def test_typemismatch_exp_float_with_string(self):
        input = """
                float a,b;
                int main(){
                    b = a + "abc";
                    return 0;
                }
                """
        expect = "Type Mismatch In Expression: BinaryOp(+,Id(a),StringLiteral(abc))"
        self.assertTrue(TestChecker.test(input,expect,432))
    def test_bool_with_bool_variable(self):
        input = """
                boolean a,b;
                int main(){
                    b = a;
                    return 0;
                }
                """
        expect = ""
        self.assertTrue(TestChecker.test(input,expect,433))
    def test_bool_with_all_bool_with_right_binary_operator(self):
        input = """
                boolean a,b;
                int main(){
                    b = a == b;
                    return 0;
                }
                """
        expect = ""
        self.assertTrue(TestChecker.test(input,expect,434))
    def test_bool_with_bool_and_int_with_right_binary_operator(self):
        input = """
                boolean b;
                int a;
                int main(){
                    b = 10 < 10 + a;
                    return 0;
                }
                """
        expect = ""
        self.assertTrue(TestChecker.test(input,expect,435))
    def test_bool_with_bool_and_float_with_right_binary_operator(self):
        input = """
                boolean b;
                float a;
                int main(){
                    b = 10 < 10 + a;
                    return 0;
                }
                """
        expect = ""
        self.assertTrue(TestChecker.test(input,expect,436))
    def test_typemismatch_bool_variable_operator(self):
        input = """
                boolean a,b;
                int main(){
                    b = a > b;
                    return 0;
                }
                """
        expect = "Type Mismatch In Expression: BinaryOp(>,Id(a),Id(b))"
        self.assertTrue(TestChecker.test(input,expect,437))
    def test_typemismatch_int_variable_operator(self):
        input = """
                boolean a;
                int b;
                int main(){
                    a = b || 5;
                }
                """
        expect = "Type Mismatch In Expression: BinaryOp(||,Id(b),IntLiteral(5))"
        self.assertTrue(TestChecker.test(input,expect,438))
    def test_typemismatch_float_variable_operator(self):
        input = """
                boolean a;
                float b;
                int main(){
                    a = b == 5;
                }
                """
        expect = "Type Mismatch In Expression: BinaryOp(==,Id(b),IntLiteral(5))"
        self.assertTrue(TestChecker.test(input,expect,439))
    def test_typemismatch_float_variable_operator_1(self):
        input = """
                boolean a;
                float b;
                int main(){
                    a = !b;
                }
                """
        expect = "Type Mismatch In Expression: UnaryOp(!,Id(b))"
        self.assertTrue(TestChecker.test(input,expect,440))
    def test_typemismatch_bool_variable_unary_operator(self):
        input = """
                boolean a,b;
                int main(){
                   a = -b;
                }
                """
        expect = "Type Mismatch In Expression: UnaryOp(-,Id(b))"
        self.assertTrue(TestChecker.test(input,expect,441))
    def test_typemismatch_bool_variable_unary_operator_complex(self):
        input = """
                boolean a,b,c;
                int main(){
                   a = c && -(b||c);
                }
                """
        expect = "Type Mismatch In Expression: UnaryOp(-,BinaryOp(||,Id(b),Id(c)))"
        self.assertTrue(TestChecker.test(input,expect,442))
    def test_typemismatch_int_variable_unary_operator(self):
        input = """
                int a,b,c;
                int main(){
                   a = !b;
                }
                """
        expect = "Type Mismatch In Expression: UnaryOp(!,Id(b))"
        self.assertTrue(TestChecker.test(input,expect,443))
    def test_typemismatch_int_variable_unary_operator_complex(self):
        input = """
                int a,b;
                float c;
                int main(){
                   c = 10.5 + !(b + 5);
                }
                """
        expect = "Type Mismatch In Expression: UnaryOp(!,BinaryOp(+,Id(b),IntLiteral(5)))"
        self.assertTrue(TestChecker.test(input,expect,444))
    def test_typemismatch_float_variable_modulo_operator(self):
        input = """
                float a,b;
                float c;
                int main(){
                   c = a % b;
                }
                """
        expect = "Type Mismatch In Expression: BinaryOp(%,Id(a),Id(b))"
        self.assertTrue(TestChecker.test(input,expect,445))
    def test_array_undeclare(self):
        input = """
                //int a[5];
                int main(int b){
                    b = a[4];
                }
                """
        expect = "Undeclared Identifier: a"
        self.assertTrue(TestChecker.test(input,expect,446))
    def test_array_redeclare(self):
        input = """
                int a[5];
                int main(int b){
                    int b[4];
                }
                """
        expect = "Redeclared Variable: b"
        self.assertTrue(TestChecker.test(input,expect,447))
    def test_array_typemismatch_int(self):
        input = """
                float a[5];
                int main(int b){
                   b = a[4];
                }
                """
        expect = "Type Mismatch In Expression: BinaryOp(=,Id(b),ArrayCell(Id(a),IntLiteral(4)))"
        self.assertTrue(TestChecker.test(input,expect,448))
    def test_array_typemismatch_float(self):
        input = """
                string a[5];
                int main(float b){
                   b = a[4];
                }
                """
        expect = "Type Mismatch In Expression: BinaryOp(=,Id(b),ArrayCell(Id(a),IntLiteral(4)))"
        self.assertTrue(TestChecker.test(input,expect,449))
    def test_array_typemismatch_string(self):
        input = """
                int a[5];
                int main(string b){
                   b = a[4];
                }
                """
        expect = "Type Mismatch In Expression: BinaryOp(=,Id(b),ArrayCell(Id(a),IntLiteral(4)))"
        self.assertTrue(TestChecker.test(input,expect,450))
    def test_array_typemismatch_arraytype(self):
        input = """
                int a;
                int main(string b){
                   b = a[4];
                }
                """
        expect = "Type Mismatch In Expression: ArrayCell(Id(a),IntLiteral(4))"
        self.assertTrue(TestChecker.test(input,expect,451))
    def test_array_in_func(self):
        input = """
                int a[5];
                int main(int b){
                   a[4];
                   return 0;
                }
                """
        expect = ""
        self.assertTrue(TestChecker.test(input,expect,452))
    def test_array_typemismatch_idx_not_int(self):
        input = """
                int a[5];
                int main(int b){
                   b = a[0.4];
                }
                """
        expect = "Type Mismatch In Expression: FloatLiteral(0.4)"
        self.assertTrue(TestChecker.test(input,expect,453))
    def test_block_vardecl_in_block_func(self):
        input = """
                string a;
                int main(){
                    int b;
                   {
                       int b;
                   }
                   return 0;
                }
                """
        expect = ""
        self.assertTrue(TestChecker.test(input,expect,454))
    def test_block_vardecl_in_block_func_1(self):
        input = """
                string a;
                int main(int a){
                    int b;
                   {
                       int a;
                   }
                   return 0;
                }
                """
        expect = ""
        self.assertTrue(TestChecker.test(input,expect,455))
    def test_block_binaryop_in_block_func(self):
        input = """
                string a;
                int main(int a){
                    int b;
                   {
                       b = a + 5;
                   }
                   return 0;
                }
                """
        expect = ""
        self.assertTrue(TestChecker.test(input,expect,456))
    def test_block_string_typemismatch_binaryop_in_block_func(self):
        input = """
                string a;
                int main(){
                    int b;
                   {
                       a = b +5;
                   }
                }
                """
        expect = "Type Mismatch In Expression: BinaryOp(=,Id(a),BinaryOp(+,Id(b),IntLiteral(5)))"
        self.assertTrue(TestChecker.test(input,expect,457))
    def test_block_string_binaryop_in_block_func(self):
        input = """
                string a;
                int main(){
                    int b;
                   {
                       a = "abc";
                   }
                   return 0;
                }
                """
        expect = ""
        self.assertTrue(TestChecker.test(input,expect,458))
    def test_block_redeclare_in_block_func(self):
        input = """
                string a;
                int main(){
                    int b;
                   {
                       int a;
                       int a;
                   }
                }
                """
        expect = "Redeclared Variable: a"
        self.assertTrue(TestChecker.test(input,expect,459))
    def test_block_undeclare_in_block_func(self):
        input = """
                string a;
                int main(){
                    int b;
                   {
                       b = c + 5;
                   }
                }
                """
        expect = "Undeclared Identifier: c"
        self.assertTrue(TestChecker.test(input,expect,460))
    def test_if_stmt_func(self):
        input = """
                string a;
                int main(int b){
                    if(b > 5)
                        b = 5;
                    return 0;
                }
                """
        expect = ""
        self.assertTrue(TestChecker.test(input,expect,461))
    def test_if_typemismatch_stmt_func(self):
        input = """
                string a;
                int main(int b){
                    if(b + 5)
                        b = 5;
                }
                """
        expect = "Type Mismatch In Statement: If(BinaryOp(+,Id(b),IntLiteral(5)),BinaryOp(=,Id(b),IntLiteral(5)))"
        self.assertTrue(TestChecker.test(input,expect,462))
    def test_if__stmt_with_block_in_func(self):
        input = """
                string a;
                int main(int b){
                    if(b < 5){
                        int a;
                        b = 5;
                    }
                    return 0;
                }
                """
        expect = ""
        self.assertTrue(TestChecker.test(input,expect,463))
    def test_if__stmt_with_undeclare_block_in_func(self):
        input = """
                string a;
                int main(int b){
                    if(b < 5){
                        c = 5;
                    }
                }
                """
        expect = "Undeclared Identifier: c"
        self.assertTrue(TestChecker.test(input,expect,464))
    def test_if__stmt_with_redeclare_block_in_func(self):
        input = """
                string a;
                int main(int b){
                    if(b < 5){
                        int b;
                        int b;
                    }
                }
                """
        expect = "Redeclared Variable: b"
        self.assertTrue(TestChecker.test(input,expect,465))
    def test_if__stmt_with_typmismatch_exp_block_in_func(self):
        input = """
                string a;
                int main(int b){
                    if(b < 5){
                        b = 5;
                    }
                    else
                    {
                        b = "abb" + 5;
                    }
                }
                """
        expect = "Type Mismatch In Expression: BinaryOp(+,StringLiteral(abb),IntLiteral(5))"
        self.assertTrue(TestChecker.test(input,expect,466))
    def test_for__stmt_in_func(self):
        input = """
                float a;
                int main(int b){
                    for(b = 0; b < 10; b = b + 1)
                        a = 20*0.5;
                    return 0;
                }
                """
        expect = ""
        self.assertTrue(TestChecker.test(input,expect,467))
    def test_for__stmt_typemismatch_exp1_in_func(self):
        input = """
                float a;
                int main(int b){
                    for(b != 0; b < 10; b = b + 1)
                        a = 20*0.5;
                    return 0;
                }
                """
        expect = "Type Mismatch In Statement: For(BinaryOp(!=,Id(b),IntLiteral(0));BinaryOp(<,Id(b),IntLiteral(10));BinaryOp(=,Id(b),BinaryOp(+,Id(b),IntLiteral(1)));BinaryOp(=,Id(a),BinaryOp(*,IntLiteral(20),FloatLiteral(0.5))))"
        self.assertTrue(TestChecker.test(input,expect,468))
    def test_for__stmt_typemismatch_exp2_in_func(self):
        input = """
                float a;
                int main(int b){
                    for(b = 0; b + 10; b = b + 1)
                        a = 20*0.5;
                }
                """
        expect = "Type Mismatch In Statement: For(BinaryOp(=,Id(b),IntLiteral(0));BinaryOp(+,Id(b),IntLiteral(10));BinaryOp(=,Id(b),BinaryOp(+,Id(b),IntLiteral(1)));BinaryOp(=,Id(a),BinaryOp(*,IntLiteral(20),FloatLiteral(0.5))))"
        self.assertTrue(TestChecker.test(input,expect,469))
    def test_for__stmt_typemismatch_exp3_in_func(self):
        input = """
                float a;
                int main(int b){
                    for(b = 0; b < 10; b == b + 1)
                        a = 20*0.5;
                }
                """
        expect = "Type Mismatch In Statement: For(BinaryOp(=,Id(b),IntLiteral(0));BinaryOp(<,Id(b),IntLiteral(10));BinaryOp(==,Id(b),BinaryOp(+,Id(b),IntLiteral(1)));BinaryOp(=,Id(a),BinaryOp(*,IntLiteral(20),FloatLiteral(0.5))))"
        self.assertTrue(TestChecker.test(input,expect,470))
    def test_for__stmt_nested_if_stmt_in_func(self):
        input = """
                float a;
                int main(int b){
                    for(b = 0; b < 10; b = b + 1){
                        if (b == 5)
                            a = -5;
                        else
                            a = 0.5;
                    }
                    return 0;
                }
                """
        expect = ""
        self.assertTrue(TestChecker.test(input,expect,471))
    def test_dowhile_stmt_in_func(self):
        input = """
                float a;
                int main(int b){
                    do 
                        a = 10;
                        b = b + 1;
                    while
                        b < 10;
                    return 0;
                }
                """
        expect = ""
        self.assertTrue(TestChecker.test(input,expect,472))
    def test_dowhile_stmt_typemismatch_exp_in_func(self):
        input = """
                float a;
                int main(int b){
                    do 
                        a = 10;
                    while
                        b + 10;
                }
                """
        expect = "Type Mismatch In Statement: Dowhile([BinaryOp(=,Id(a),IntLiteral(10))],BinaryOp(+,Id(b),IntLiteral(10)))"
        self.assertTrue(TestChecker.test(input,expect,473))
    def test_return_stmt_in_func(self):
        input = """
                float a;
                int main(int b){
                    a = 20*0.5;
                    return 0;
                }
                """
        expect = ""
        self.assertTrue(TestChecker.test(input,expect,474))
    def test_return_typemismatch_stmt_in_func(self):
        input = """
                float a;
                int main(int b){
                    string c;
                    a = 20*0.5;
                    return c;
                }
                """
        expect = "Type Mismatch In Statement: Return(Id(c))"
        self.assertTrue(TestChecker.test(input,expect,475))
    def test_return_typemismatch_stmt_void_in_func(self):
        input = """
                float a;
                int main(int b){
                    string c;
                    a = 20*0.5;
                    return ;
                }
                """
        expect = "Type Mismatch In Statement: Return()"
        self.assertTrue(TestChecker.test(input,expect,476))
    def test_return_type_float_Coercions_stmt_in_func(self):
        input = """
                float a;
                float main(int b){
                    string c;
                    a = 20*0.5;
                    return b*0.5;
                }
                """
        expect = ""
        self.assertTrue(TestChecker.test(input,expect,477))
    def test_return_type_bool_Coercions_stmt_in_func(self):
        input = """
                float a;
                boolean main(int b){
                    string c;
                    a = 20*0.5;
                    return b > 0.5;
                }
                """
        expect = ""
        self.assertTrue(TestChecker.test(input,expect,478))
    def test_return_void_type_in_func(self):
        input = """
                float a;
                void main(int b){
                    string c;
                    a = 20*0.5;
                    return ;
                }
                """
        expect = ""
        self.assertTrue(TestChecker.test(input,expect,479))
    def test_return_array_pointer_type_in_func(self):
        input = """
                int[] main(int b){
                    int a[5];
                    return a;
                }
                """
        expect = ""
        self.assertTrue(TestChecker.test(input,expect,480))
    def test_return_type_not_arraytype_typemismatch_array_pointer_type_in_func(self):
        input = """
                int[] main(int b){
                    int a[5];
                    return b;
                }
                """
        expect = "Type Mismatch In Statement: Return(Id(b))"
        self.assertTrue(TestChecker.test(input,expect,481))
    def test_return_typemismatch_type_array_pointer_type_in_func(self):
        input = """
                int[] main(int b){
                    float a[5];
                    return a;
                }
                """
        expect = "Type Mismatch In Statement: Return(Id(a))"
        self.assertTrue(TestChecker.test(input,expect,482))
    def test_no_entry_point(self):
        input = """
                int a,b;
                int[] foo(int b){
                    int a[5];
                    return a;
                }
                """
        expect = "No Entry Point"
        self.assertTrue(TestChecker.test(input,expect,483))
    def test_main_not_return(self):
        input = """
                int a,b;
                int foo(int b){
                    return a;
                }
                int main(){}
                """
        expect = "Function main Not Return"
        self.assertTrue(TestChecker.test(input,expect,484))
    def test_other_func_not_return(self):
        input = """
                int a,b;
                int main(){
                    return 0;
                }
                int foo(int a, string b){

                }
                """
        expect = "Function foo Not Return"
        self.assertTrue(TestChecker.test(input,expect,485))
    def test_func_in_stmt_return(self):
        input = """
                int a,b;
                int main(){
                    if (a > 0){
                        for(b = 0; b < 10; b = b + 1)
                            a = a + 1;
                        return 0;
                    }
                    if (a < 0)
                        a = a + 1;
                        //return 0;
                }
                """
        expect = ""
        self.assertTrue(TestChecker.test(input,expect,486))
    def test_func_in_if_stmt_return(self):
        input = """
                int a,b;
                int main(){
                    if (a > 0){
                        for(b = 0; b < 10; b = b + 1)
                            a = a + 1;
                        return 0;
                    }
                    else{
                        a = a + 1;
                    }
                    if (a < 0)
                        a = a + 1;
                        //return 0;
                }
                """
        expect = "Function main Not Return"
        self.assertTrue(TestChecker.test(input,expect,487))
    def test_func_in_for_stmt_break_continue_indirectly(self):
        input = """
                int a,b;
                int main(){
                    for(b = 0; b < 10; b = b + 1){
                        a = a + 1;
                        if (a % 5 == 0)
                            break;
                        else
                            continue;
                    }
                    return 0;
                }
                """
        expect = ""
        self.assertTrue(TestChecker.test(input,expect,488))
    def test_func_in_for_stmt_break_directly(self):
        input = """
                int a,b;
                int main(){
                    for(b = 0; b < 10; b = b + 1){
                        break;
                    }
                    return 0;
                }
                """
        expect = ""
        self.assertTrue(TestChecker.test(input,expect,489))
    def test_func_break_not_in_loop(self):
        input = """
                int a,b;
                int main(){
                    if (a > 5)
                        break;
                    else
                        a = a + 1;
                    return 0;
                }
                """
        expect = "Break Not In Loop"
        self.assertTrue(TestChecker.test(input,expect,490))
    def test_func_continue_not_in_loop(self):
        input = """
                int a,b;
                int main(){
                    continue;
                    return 0;
                }
                """
        expect = "Continue Not In Loop"
        self.assertTrue(TestChecker.test(input,expect,491))
    def test_func_dowhile_with_break_indirectly(self):
        input = """
                int a,b;
                int main(){
                    do
                    {
                        if (a > 5)
                            break;
                        a = a + 1;
                        b = b + 1;
                    }
                    while (b < 10);
                    return 0;
                }
                """
        expect = ""
        self.assertTrue(TestChecker.test(input,expect,492))
    def test_built_func_call_exp(self):
        input = """
                int a,b;
                int main(){
                    float c;
                    putIntLn(a);
                    return 0;
                }
                """
        expect = ""
        self.assertTrue(TestChecker.test(input,expect,493))
    def test_built_func_mismatch_stmt(self):
        input = """
                int a,b;
                int main(){
                    float c;
                    putIntLn(c);
                    return 0;
                }
                """
        expect = "Type Mismatch In Expression: CallExpr(Id(putIntLn),[Id(c)])"
        self.assertTrue(TestChecker.test(input,expect,494))
    def test_built_func_mismatch_exp(self):
        input = """
                int a,b;
                int main(){
                    float c;
                    putIntLn(getInt(4));
                    return 0;
                }
                """
        expect = "Type Mismatch In Expression: CallExpr(Id(getInt),[IntLiteral(4)])"
        self.assertTrue(TestChecker.test(input,expect,495))
    def test_func_mismatch_stmt(self):
        input = """
                int a,b;
                int main(){
                    float c;
                    foo(a,b);
                    return 0;
                }
                void foo(int a, float b){}
                """
        expect = "Type Mismatch In Expression: CallExpr(Id(foo),[Id(a),Id(b)])"
        self.assertTrue(TestChecker.test(input,expect,496))
    def test_func_assign_to_variable(self):
        input = """
                int a,b;
                int main(){
                    float c;
                    c = foo(a,c);
                    return 0;
                }
                int foo(int a, float b){return a;}
                """
        expect = ""
        self.assertTrue(TestChecker.test(input,expect,497))
    def test_func_assign_to_variable_mismatch(self):
        input = """
                int a,b;
                int main(){
                    string c;
                    c = foo(a,b);
                    return 0;
                }
                int foo(int a, int b){return a;}
                """
        expect = "Type Mismatch In Expression: BinaryOp(=,Id(c),CallExpr(Id(foo),[Id(a),Id(b)]))"
        self.assertTrue(TestChecker.test(input,expect,498))
    def test_arraypointer_exp_assign(self):
        input = """
                int a,b;
                int main(){
                    float c[5];
                    foo(a,b)[4] = 1;
                    return 0;
                }
                int[] foo(int a, int b){
                    int c[5];
                    c[4] = c[2] + 2;
                    return c;
                }
                """
        expect = ""
        self.assertTrue(TestChecker.test(input,expect,499))
    def test_arraypointer_exp_assign_mismatch_exp(self):
        input = """
                int a,b;
                int main(){
                    float c[5];
                    //c = foo(a,b);
                    return 0;
                }
                int[] foo(int a[], int b){
                    int c[5];
                    c[4] = c[2] + 2;
                    a = c + 2;
                    return c;
                }
                """
        expect = "Type Mismatch In Expression: BinaryOp(+,Id(c),IntLiteral(2))"
        self.assertTrue(TestChecker.test(input,expect,500))
    def test_arraypointer_func_assign(self):
        input = """
                int a,b;
                int main(){
                    int c[5];
                    foo()[4] = c[2] + 3;
                    return 0;
                }
                int[] foo(){
                    int c[5];
                    return c;
                }
                """
        expect = ""
        self.assertTrue(TestChecker.test(input,expect,501))
    def test_arraypointer_func_assign_mismatch_exp(self):
        input = """
                int a,b;
                int main(){
                    int c[5];
                    foo() = c[2] + 3;
                    return 0;
                }
                int[] foo(){
                    int c[5];
                    return c;
                }
                """
        expect = "Type Mismatch In Expression: CallExpr(Id(foo),[])"
        self.assertTrue(TestChecker.test(input,expect,502))
    def test_mismatch_exp_assign(self):
        input = """
                int a,b;
                int main(){
                    a = "abs";
                    return 0;
                }
                """
        expect = "Type Mismatch In Expression: BinaryOp(=,Id(a),StringLiteral(abs))"
        self.assertTrue(TestChecker.test(input,expect,503))
    def test_mismatch_exp_multi_assign(self):
        input = """
                int main(){
                    int a;
                    float b;
                    a = b = 1;
                    return 0;
                }
                """
        expect = "Type Mismatch In Expression: BinaryOp(=,Id(a),BinaryOp(=,Id(b),IntLiteral(1)))"
        self.assertTrue(TestChecker.test(input,expect,504))
    def test_unreachable_function(self):
        input = """
                int main(){
                    int a;
                    foo1();
                    return 0;
                }
                int[] foo(){
                    int a[5];
                    return a;
                }
                void foo1(){}
                """
        expect = "Unreachable Function: foo"
        self.assertTrue(TestChecker.test(input,expect,505))
    def test_undeclare_function_1(self):
        input = """
                int main(){
                    int foo;
                    foo() = 5;
                    return 0;
                }
                """
        expect = "Type Mismatch In Statement: CallExpr(Id(foo),[])"
        self.assertTrue(TestChecker.test(input,expect,506))
    def test_undeclare_function_1(self):
        input = """
                int main(){
                    int a;
                    3 = a;
                    return 0;
                }
                """
        expect = "Not Left Value: IntLiteral(3)"
        self.assertTrue(TestChecker.test(input,expect,507))
    