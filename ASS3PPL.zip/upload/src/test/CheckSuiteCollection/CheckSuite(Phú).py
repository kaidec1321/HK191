import unittest
from TestUtils import TestChecker
from AST import *
from StaticError import *

class CheckSuite(unittest.TestCase):
    def test_1(self):
        print(400)
        input = Program([VarDecl("a",IntType())])
        expect = "No Entry Point"
        self.assertTrue(TestChecker.test(input,expect,400))
    def test_2(self):
        # redeclared in global
        print(401)
        input = Program([VarDecl("a",IntType()),VarDecl("a",FloatType())])
        expect = "Redeclared Variable: a"
        self.assertTrue(TestChecker.test(input,expect,401))
    def test_3(self):
        # redeclared in global
        print(402)
        input = Program([VarDecl("a",IntType()),VarDecl("b",FloatType()),VarDecl("a",BoolType())])
        expect = "Redeclared Variable: a"
        self.assertTrue(TestChecker.test(input,expect,402))
    def test_4(self):
        print(403)
        input = Program([VarDecl("a",IntType()),FuncDecl(Id("main"),[],VoidType(),Block([]))])
        expect = ""
        self.assertTrue(TestChecker.test(input,expect,403))
    def test_5(self):
        # redeclared in global
        print(404)
        input = Program([VarDecl("foo",IntType()),FuncDecl(Id("foo"),[], BoolType(),Block([]))])
        expect= "Redeclared Function: foo"
        self.assertTrue(TestChecker.test(input,expect,404))
    def test_6(self):
        # redeclared in global
        print(405)
        input = Program([VarDecl("x",IntType()),FuncDecl(Id("main"),[],VoidType(),Block([])),VarDecl("x",FloatType())])
        expect = "Redeclared Variable: x"
        self.assertTrue(TestChecker.test(input,expect,405))
    def test_7(self):
        print(406)
        input = Program([FuncDecl(Id("main"),[],VoidType(),Block([VarDecl("a",IntType())]))])
        expect= ""
        self.assertTrue(TestChecker.test(input,expect,406))
    def test_8(self):
        # redeclared in body of a function
        print(407)
        input = Program([FuncDecl(Id("main"),[],VoidType(),Block([VarDecl("a",IntType()),VarDecl("a",FloatType())]))])
        expect = "Redeclared Variable: a"
        self.assertTrue(TestChecker.test(input,expect,407))
    def test_9(self):
        # declared in global and in parameter of function
        print(408)
        input = Program([VarDecl("a",IntType()),FuncDecl(Id("main"),[VarDecl("a",IntType())],VoidType(),Block([]))])
        expect = ""
        self.assertTrue(TestChecker.test(input,expect,408))
    def test_10(self):
        # redeclared in parameter of a function
        print(409)
        input = Program([FuncDecl(Id("main"),[VarDecl("a",IntType()),VarDecl("a",FloatType())],VoidType(),Block([]))])
        expect = "Redeclared Parameter: a"
        self.assertTrue(TestChecker.test(input,expect,409))
    def test_11(self):
        # declare a variable in function
        print(410)
        input = Program([FuncDecl(Id("main"),[],VoidType(),Block([VarDecl("a",IntType())]))])
        expect = ""
        self.assertTrue(TestChecker.test(input,expect,410))
    def test_12(self):
        # declare in global and in function
        print(411)
        input = Program([VarDecl("a",IntType()),FuncDecl(Id("main"),[],VoidType(),Block([VarDecl("a",IntType())]))])
        expect = ""
        self.assertTrue(TestChecker.test(input,expect,411))
    def test_13(self):
        # redeclare in parameter and in function
        print(412)
        input = Program([FuncDecl(Id("main"),[VarDecl("a",IntType())],VoidType(),Block([VarDecl("a",FloatType())]))])
        expect = "Redeclared Variable: a"
        self.assertTrue(TestChecker.test(input,expect,412))
    def test_14(self):
        # undeclared id
        print(413)
        input = Program([FuncDecl(Id("main"),[],VoidType(),Block([Id("a")]))])
        expect = "Undeclared Identifier: a"
        self.assertTrue(TestChecker.test(input,expect,413))
    def test_15(self):
        # declare variable in parameter
        print(414)
        input = Program([FuncDecl(Id("main"),[VarDecl("a",IntType())],VoidType(),Block([BinaryOp("=",Id("a"),IntLiteral(0)),Id("a")]))])
        expect = ""
        self.assertTrue(TestChecker.test(input,expect,414))
    def test_16(self):
        # declare in global, use in function
        print(415)
        input = Program([VarDecl("a",IntType()),FuncDecl(Id("main"),[],VoidType(),Block([Id("a")]))])
        expect = ""
        self.assertTrue(TestChecker.test(input,expect,415))
    def test_17(self):
        # declare in function, use in function
        print(416)
        input = Program([FuncDecl(Id("main"),[],VoidType(),Block([VarDecl("a",IntType()),BinaryOp("=",Id("a"),IntLiteral(1)),Id("a")]))])
        expect = ""
        self.assertTrue(TestChecker.test(input,expect,416))
    def test_18(self):
        #declare in function, use in another function
        print(417)
        input = Program([FuncDecl(Id("main"),[],VoidType(),Block([VarDecl("a",IntType())])),FuncDecl(Id("foo"),[],VoidType(),Block([Id("a")]))])
        expect = "Undeclared Identifier: a"
        self.assertTrue(TestChecker.test(input,expect,417))
    def test_19(self):
        #declare in para, use in another function
        print(418)
        input=Program([FuncDecl(Id("main"),[VarDecl("a",IntType())],VoidType(),Block([])),FuncDecl(Id("foo"),[],VoidType(),Block([Id("a")]))])
        expect = "Undeclared Identifier: a"
        self.assertTrue(TestChecker.test(input,expect,418))
    def test_20(self):
        # redeclared function with same name as global variable
        print(419)
        input = Program([VarDecl("a",IntType()),FuncDecl(Id("a"),[],FloatType(),Block([]))])
        expect = "Redeclared Function: a"
        self.assertTrue(TestChecker.test(input,expect,419))
    def test_21(self):
        # use variable before declare
        print(420)
        input = Program([FuncDecl(Id("main"),[],VoidType(),Block([Id("a")])),VarDecl("a",IntType())])
        expect = ""
        self.assertTrue(TestChecker.test(input,expect,420))
    def test_22(self):
        # undeclared function
        print(421)
        input = Program([FuncDecl(Id("main"),[],VoidType(),Block([CallExpr(Id("foo"),[])]))])
        expect = "Undeclared Function: foo"
        self.assertTrue(TestChecker.test(input,expect,421))
    def test_23(self):
        # use function before declare
        print(422)
        input = Program([FuncDecl(Id("main"),[],VoidType(),Block([CallExpr(Id("foo"),[])])),FuncDecl(Id("foo"),[],IntType(),Block([Return(IntLiteral(1))]))])
        expect =""
        self.assertTrue(TestChecker.test(input,expect,422))
    def test_24(self):
        # undeclared identifier in funcall
        print(423)
        input = """int foo(float x) {return 0;}
        void main() {
            foo(a);
        }"""
        expect = "Undeclared Identifier: a"
        self.assertTrue(TestChecker.test(input,expect,423))
    def test_25(self):
        # declare variable in global and use in funcall
        print(424)
        input = """ void foo(int x) {}
        int a;
        void main() {
            foo(a);
        }"""
        expect = ""
        self.assertTrue(TestChecker.test(input,expect,424))
    def test_26(self):
        # declare variable in parameter and use in funcall, function declared after used
        print(425)
        input = """void main(int a) {
            a = 1;
            foo(a);
        }
        void foo(int x) {}"""
        expect = ""
        self.assertTrue(TestChecker.test(input,expect,425))
    def test_27(self):
        # declare variable in body and use in funcall
        print(426)
        input = """ void foo(int x) {}
        void main() {
            int a;
            a = -10; 
            foo(a);
        }
        """
        expect = ""
        self.assertTrue(TestChecker.test(input,expect,426))
    def test_28(self):
        # declare a function and use inside it
        print(427)
        input = """void foo() { foo(); }
        void main() {}"""
        expect = ""
        self.assertTrue(TestChecker.test(input,expect,427))
    def test_29(self):
        # test assign operator and TypeMismatchInExpression
        print(428)
        input = """void main(int a, float b) {
            a = b;
        }"""
        expect = str(TypeMismatchInExpression(BinaryOp("=",Id("a"),Id("b"))))
        self.assertTrue(TestChecker.test(input,expect,428))
    def test_30(self):
        # assign int variable to float variable
        print(429)
        input = """void main(int a, float b) {
            b = a;
        }"""
        expect = ""
        self.assertTrue(TestChecker.test(input,expect,429))
    def test_31(self):
        # assign float variable to float variable. use before declare variable
        print(430)
        input = """void main() {
            a = a;
        }
        float a;
        """
        expect = ""
        self.assertTrue(TestChecker.test(input,expect,430))
    def test_32(self):
        # multiple assign
        print(431)
        input = """void main() {
            float a,b,c;
            a = b = c;
        }"""
        expect = ""
        self.assertTrue(TestChecker.test(input,expect,431))
    def test_33(self):
        # multiple assign between int and float
        print(432)
        input = """void main(int x) {
            float b,c;
            b = c = x;
            x = b = c;
        }"""
        expect = str(TypeMismatchInExpression(BinaryOp("=",Id("x"),BinaryOp("=",Id("b"),Id("c")))))
        self.assertTrue(TestChecker.test(input,expect,432))
    def test_34(self):
        # type mismatch between string and int
        print(433)
        input = """int x;
        void main() {
            string str;
            str = x;
        }"""
        expect = str(TypeMismatchInExpression(BinaryOp("=",Id("str"),Id("x"))))
        self.assertTrue(TestChecker.test(input,expect,433))
    def test_35(self):
        # type match: boolean
        print(434)
        input = """boolean x,y;
        void main() {
            x = y;
        }"""
        expect = ""
        self.assertTrue(TestChecker.test(input,expect,434))
    def test_36(self):
        # operator %
        print(435)
        input = """void main() {
            int x, y; 
            float z;
            x = -10 ;
            y = 3;
            z = -1.45;
            x % y ;
            x % z;
        }"""
        expect = str(TypeMismatchInExpression(BinaryOp("%",Id("x"),Id("z"))))
        self.assertTrue(TestChecker.test(input,expect,435))
    def test_37(self):
        # check type of operator == and !=
        print(436)
        input = """
        int x , y;
        boolean a,b,c;
        void main() {
            x ==  y ;
            a != (b == c);
            (x == y) != x;
        }
        """
        expect = str(TypeMismatchInExpression(BinaryOp("!=",BinaryOp("==",Id("x"),Id("y")),Id("x"))))
        self.assertTrue(TestChecker.test(input,expect,436))
    def test_38(self):
        # check type of operator + - * /
        print(437)
        input = """
        float a,b,c;
        boolean bool;
        void main() {
            a = a + b * (c - y) / z;
            x = a + bool;
        }
        int x,y,z;"""
        expect =str(TypeMismatchInExpression(BinaryOp("+",Id("a"),Id("bool"))))
        self.assertTrue(TestChecker.test(input,expect,437))
    def test_39(self):
        # check type of unary operator - !
        print(438)
        input = """int x;
        float y; 
        void main() {
            boolean bool;
            bool = true;
            !bool;
            -x;
            -y;
            -bool;
        }"""
        expect = str(TypeMismatchInExpression(UnaryOp("-",Id("bool"))))
        self.assertTrue(TestChecker.test(input,expect,438))
    def test_40(self):
        # test binary and unary operator
        print(439)
        input = """ int x,y,z;
        float a,b,c;
        boolean bool;
        void main() {
            z= 1;
            b = 2;
            a = x - -y / (b+c) + (x % -z);
            bool =  !(x >= a) && bool;
        }"""
        expect = ""
        self.assertTrue(TestChecker.test(input,expect,439))
    def test_41(self):
        # check condition in if statement
        print(440)
        input = """
        void main() {
            int x, y;
            x = 3;
            y = -100;
            if (x == y) x; else y; 
        }"""
        expect =""
        self.assertTrue(TestChecker.test(input,expect,440))
    def test_42(self):
        # check type of condition in if statement
        print(441)
        input = """
        void main() {
            float x,y;
            if (x = y) x; else y;
        }"""
        expect = str(TypeMismatchInStatement(If(BinaryOp("=",Id("x"),Id("y")),Id("x"),Id("y"))))
        self.assertTrue(TestChecker.test(input,expect,441))
    def test_43(self):
        # check type in for statement
        print(442)
        input = """void main() {
        int x,y;
        x= -1; y = 2;
        for (x = 0 ; x < y; x = x + 1) y;
        }"""
        expect = ""
        self.assertTrue(TestChecker.test(input,expect,442))
    def test_44(self):
        # check condition type in do while statement
        print (443)
        input = """void main() {
            int x, y;
            x =1; y = 2;
            do {} while x<y;
            do {} while x + y;
        }"""
        expect = str(TypeMismatchInStatement(Dowhile([Block([])],BinaryOp("+",Id("x"),Id("y")))))
        self.assertTrue(TestChecker.test(input,expect,443))
    def test_45(self):
        # return type in void
        print(444)
        input = """void main() {
            return;
        }"""
        expect = ""
        self.assertTrue(TestChecker.test(input,expect,444))
    def test_46(self):
        # return type mismatch
        print(445)
        input = """void main() {
            int x;
            x = 0;
            return x;
        }"""
        expect = str(TypeMismatchInStatement(Return(Id("x"))))
        self.assertTrue(TestChecker.test(input,expect,445))
    def test_47(self):
        # undeclared in return statement
        print(446)
        input = """void main() {
            return x;
        }
        """
        expect = "Undeclared Identifier: x"
        self.assertTrue(TestChecker.test(input,expect,446))
    def test_48(self):
        # return array type to array pointer type function
        print (447)
        input = """int a[5];
        int[] main() {
            return a;
        }"""
        expect = ""
        self.assertTrue(TestChecker.test(input,expect,447))
    def test_49(self):
        # return array type with different eleType to array pointer type function
        print(448)
        input = """float a[3];
        int[] main() {
            return a;
        }"""
        expect = str(TypeMismatchInStatement(Return(Id("a"))))
        self.assertTrue(TestChecker.test(input,expect,448))
    def test_50(self):
        # array cell
        print(449)
        input = """int a[5];
        float b[5];
        boolean x;
        void main() {
            a[0] = a[1] + a[2];
            b[0] = b[2] / b[1];
            b[a[0]];
            a[0+1*4];
            x[0];
        }"""
        expect =str(TypeMismatchInExpression(ArrayCell(Id("x"),IntLiteral(0))))
        self.assertTrue(TestChecker.test(input,expect,449))
    def test_51(self):
        # differences between number of parameter in funcall
        print(450)
        input = """void foo(int x, float y) {return;}
        void main() {
            int a;
            a = 0;
            foo(a);
            return;
        }"""
        expect = str(TypeMismatchInExpression(CallExpr(Id("foo"),[Id("a")])))
        self.assertTrue(TestChecker.test(input,expect,450))
    def test_52(self):
        # different type in parameter of funcall
        print(451)
        input = """
        int a;
        float b[2]; 
        boolean c[3];
        void foo(int x, float b[]){ return ; }
        void main() {
            foo(a,b);
            foo(a,c);
            return; 
        }"""
        expect =str(TypeMismatchInExpression(CallExpr(Id("foo"),[Id("a"),Id("c")])))
        self.assertTrue(TestChecker.test(input,expect,451))
    def test_53(self):
        # return in if statement
        print (452)
        input = """int main() {
            boolean bool;
            //if (bool) return 0; else return 1;
            //return 0;
            //do {return 0;} while bool;
            int x,y;
            for (x = 0; bool; x + 1) return 0;
        }
        """
        expect = ""
        self.assertTrue(TestChecker.test(input,expect,452))
    def test_54(self):
        # variable has same name with funcall
        print (453)
        input = """int pow(int a, int n) {
            a= 2; n = 4;
            return a*pow(a,n-1); 
        }
        void main() {
            int pow;
            pow = 2;
            pow(pow,4);
        }"""
        expect = "Undeclared Function: pow"
        self.assertTrue(TestChecker.test(input,expect,453))
    def test_55(self):
        # function has same name with parameter
        print(454)
        input = """void foo (int foo) {}
        void main() {int x; x =2; foo(x);}
        """
        expect = ""
        self.assertTrue(TestChecker.test(input, expect, 454))
    def test_56(self):
        # not left value
        print(455)
        input = """void foo() {}
        int a[5];
        void main() {
            a[1] = 0;
            foo = 0;
        }"""
        expect = str(NotLeftValue(BinaryOp("=",Id("foo"),IntLiteral(0))))
        self.assertTrue(TestChecker.test(input,expect,455))
    def test_57(self):
        # not left value: LHS is a funcall
        print(456)
        input = """int foo(int x) {return 0;}
        void main() {
            int a;
            a = 1;
            a = a + foo(0);
            foo(a) = 5;
        }"""
        expect= str(NotLeftValue(BinaryOp("=",CallExpr(Id("foo"),[Id("a")]),IntLiteral(5))))
        self.assertTrue(TestChecker.test(input,expect,456))
    def test_58(self):
        # break in main
        print(457)
        input = """void main() { break; }"""
        expect = "Break Not In Loop"
        self.assertTrue(TestChecker.test(input, expect, 457))
    def test_59(self):
        # break in for
        print(458)
        input = """int x,y,z;
        void main() {
            for (x = 0; x < y; x = x + 1) {
                break;
            }
        }"""
        expect = ""
        self.assertTrue(TestChecker.test(input, expect, 458))
    def test_60(self):
        # break in do
        print(459)
        input = """void main() {
            boolean bool;
            bool = false;
            do break; while bool;
        }"""
        expect = ""
        self.assertTrue(TestChecker.test(input,expect, 459))
    def test_61(self):
        # break in if in for
        print(460)
        input = """void main() {
            int x,y,z;
            x = 1; 
            y = 2; 
            z = 3;
            for (x = 0; x < y; x = x+1) {
                if (x == y) break;
            }
        }"""
        expect = ""
        self.assertTrue(TestChecker.test(input,expect,460))
    def test_62(self):
        # test unreachable function
        print(461)
        input = """ int foo() { return 0; }
        void main() {}"""
        expect = "Unreachable Function: foo"
        self.assertTrue(TestChecker.test(input,expect, 461))
    def test_63(self):
        # test index of of range
        print(462)
        input = """
        int a[5];
        void main() {
            a[5];
        }"""
        expect = str(IndexOutOfRange(ArrayCell(Id("a"),IntLiteral(5))))
        self.assertTrue(TestChecker.test(input, expect, 462))
    def test_64(self):
        # test index out of range, constant expression
        print(463)
        input = """
        int a[5];
        void main() {
            a[5%6];
        }"""
        expect = str(IndexOutOfRange(ArrayCell(Id("a"),BinaryOp("%",IntLiteral(5),IntLiteral(6)))))
        self.assertTrue(TestChecker.test(input,expect,463))
    def test_65(self):
        # declare function after using
        print(464)
        input = """void goo(float a) {}
        void main() {
            int x;
            x = 1;
            goo(x);
            foo(x);
            hoo(x);
        }
        void foo(int a) {}"""
        expect = "Undeclared Function: hoo"
        self.assertTrue(TestChecker.test(input,expect,464))
    def test_66(self):
        # type mismatch in expression in funcall + declare function after using
        print(465)
        input = """
        float a;
        float b[5];
        void main() {
            foo(a,b);
        }
        void foo(int x, float y[]) {}"""
        expect = str(TypeMismatchInExpression(CallExpr(Id("foo"),[Id("a"),Id("b")])))
        self.assertTrue(TestChecker.test(input,expect,465))
    def test_67(self):
        # unreach in body
        print(466)
        input = """
        int x;
        float main() {
            return x;
            x = 0;
        }
        """
        expect = str(UnreachableStatement(BinaryOp("=",Id("x"),IntLiteral(0))))
        self.assertTrue(TestChecker.test(input, expect, 466))
    def test_68(self):
        # unreach break
        print(467)
        input = """
        int x,y,z;
        void main() {
            for (x = 0; x < y; x = x + 1) {
                break;
                return;
            }
        }"""
        expect = str(UnreachableStatement(Return()))
        self.assertTrue(TestChecker.test(input,expect,467))
    def test_69(self):
        # test break
        print(468)
        input = """int x,y,z;
        void main() {
            for (x; x < y; x = x +1 ) {
                {
                    z = x + 1;
                    break;
                    {
                        z = x + y;
                    }
                }
            }
        }
        """
        expect = str(UnreachableStatement(Block([BinaryOp("=",Id("z"),BinaryOp("+",Id("x"),Id("y")))])))
        self.assertTrue(TestChecker.test(input,expect,468))
    def test_70(self):
        # unreachable continue
        input = """boolean bool;
        void main() {
            do {
                continue;
                break;
            }
            while bool;
        }
        """
        expect = str(UnreachableStatement(Break()))
        self.assertTrue(TestChecker.test(input,expect,469))
    def test_71(self):
        # test not left value
        print(470)
        input = """int x;
        void main() {
            3 = x + 1;
        }
        """
        expect = str(NotLeftValue(BinaryOp("=",IntLiteral(3),BinaryOp("+",Id("x"),IntLiteral(1)))))
        self.assertTrue(TestChecker.test(input,expect,470))
    def test_72(self):
        # test not left value, LHS is a exp
        print(471)
        input = """float x;
        void main() {
            x+1 = x / 2;
        }"""
        expect = str(NotLeftValue(BinaryOp("=",BinaryOp("+",Id("x"),IntLiteral(1)),BinaryOp("/",Id("x"),IntLiteral(2)))))
        self.assertTrue(TestChecker.test(input, expect, 471))
    def test_73(self):
        # function not return in if
        print(472)
        input = """boolean bool;
        int x,y;
        int main() {
            if (bool)  {return x; }  else x;
        }
        """
        expect = str(FunctionNotReturn("main"))
        self.assertTrue(TestChecker.test(input,expect,472))
    def test_74(self):
        # function not return with if
        print(473)
        input = """boolean bool;
        int x, y;
        int main() {
            if (bool) {return x;}
            if (bool) x; else {return x; }
            // if (bool) return x; else return y;
            {
                return y;
            }
            x = 0;
        }
        """
        expect = ""
        self.assertTrue(TestChecker.test(input,expect,473))
    def  test_75(self):
        # redeclared in block
        print(474)
        input = """int x;
        void main() {
            int x;
            {
                int x;
            }
        }"""
        expect = ""
        self.assertTrue(TestChecker.test(input,expect, 474))